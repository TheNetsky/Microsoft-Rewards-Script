"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9555], {
        9555: (e, r, o) => {
            o.d(r, {
                SV: () => ec,
                zu: () => ef
            });
            let t = (e = new Map, r = null, o) => ({
                    nextPart: e,
                    validators: r,
                    classGroupId: o
                }),
                l = [],
                a = (e, r, o) => {
                    if (0 == e.length - r) return o.classGroupId;
                    let t = e[r],
                        l = o.nextPart.get(t);
                    if (l) {
                        let o = a(e, r + 1, l);
                        if (o) return o
                    }
                    let s = o.validators;
                    if (null === s) return;
                    let n = 0 === r ? e.join("-") : e.slice(r).join("-"),
                        i = s.length;
                    for (let e = 0; e < i; e++) {
                        let r = s[e];
                        if (r.validator(n)) return r.classGroupId
                    }
                },
                s = (e, r) => {
                    let o = t();
                    for (let t in e) n(e[t], o, t, r);
                    return o
                },
                n = (e, r, o, t) => {
                    let l = e.length;
                    for (let a = 0; a < l; a++) i(e[a], r, o, t)
                },
                i = (e, r, o, t) => {
                    "string" == typeof e ? d(e, r, o) : "function" == typeof e ? c(e, r, o, t) : m(e, r, o, t)
                },
                d = (e, r, o) => {
                    ("" === e ? r : p(r, e)).classGroupId = o
                },
                c = (e, r, o, t) => {
                    u(e) ? n(e(t), r, o, t) : (null === r.validators && (r.validators = []), r.validators.push({
                        classGroupId: o,
                        validator: e
                    }))
                },
                m = (e, r, o, t) => {
                    let l = Object.entries(e),
                        a = l.length;
                    for (let e = 0; e < a; e++) {
                        let [a, s] = l[e];
                        n(s, p(r, a), o, t)
                    }
                },
                p = (e, r) => {
                    let o = e,
                        l = r.split("-"),
                        a = l.length;
                    for (let e = 0; e < a; e++) {
                        let r = l[e],
                            a = o.nextPart.get(r);
                        a || (a = t(), o.nextPart.set(r, a)), o = a
                    }
                    return o
                },
                u = e => "isThemeGetter" in e && !0 === e.isThemeGetter,
                b = [],
                f = (e, r, o, t, l) => ({
                    modifiers: e,
                    hasImportantModifier: r,
                    baseClassName: o,
                    maybePostfixModifierPosition: t,
                    isExternal: l
                }),
                g = /\s+/,
                h = e => {
                    let r;
                    if ("string" == typeof e) return e;
                    let o = "";
                    for (let t = 0; t < e.length; t++) e[t] && (r = h(e[t])) && (o && (o += " "), o += r);
                    return o
                },
                k = (e, ...r) => {
                    let o, t, n, i, d = e => {
                        let r = t(e);
                        if (r) return r;
                        let l = ((e, r) => {
                            let {
                                parseClassName: o,
                                getClassGroupId: t,
                                getConflictingClassGroupIds: l,
                                sortModifiers: a
                            } = r, s = [], n = e.trim().split(g), i = "";
                            for (let e = n.length - 1; e >= 0; e -= 1) {
                                let r = n[e],
                                    {
                                        isExternal: d,
                                        modifiers: c,
                                        hasImportantModifier: m,
                                        baseClassName: p,
                                        maybePostfixModifierPosition: u
                                    } = o(r);
                                if (d) {
                                    i = r + (i.length > 0 ? " " + i : i);
                                    continue
                                }
                                let b = !!u,
                                    f = t(b ? p.substring(0, u) : p);
                                if (!f) {
                                    if (!b || !(f = t(p))) {
                                        i = r + (i.length > 0 ? " " + i : i);
                                        continue
                                    }
                                    b = !1
                                }
                                let g = 0 === c.length ? "" : 1 === c.length ? c[0] : a(c).join(":"),
                                    h = m ? g + "!" : g,
                                    k = h + f;
                                if (s.indexOf(k) > -1) continue;
                                s.push(k);
                                let x = l(f, b);
                                for (let e = 0; e < x.length; ++e) {
                                    let r = x[e];
                                    s.push(h + r)
                                }
                                i = r + (i.length > 0 ? " " + i : i)
                            }
                            return i
                        })(e, o);
                        return n(e, l), l
                    };
                    return i = c => {
                        var m;
                        let p;
                        return t = (o = {
                            cache: (e => {
                                if (e < 1) return {
                                    get: () => void 0,
                                    set: () => {}
                                };
                                let r = 0,
                                    o = Object.create(null),
                                    t = Object.create(null),
                                    l = (l, a) => {
                                        o[l] = a, ++r > e && (r = 0, t = o, o = Object.create(null))
                                    };
                                return {
                                    get(e) {
                                        let r = o[e];
                                        return void 0 !== r ? r : void 0 !== (r = t[e]) ? (l(e, r), r) : void 0
                                    },
                                    set(e, r) {
                                        e in o ? o[e] = r : l(e, r)
                                    }
                                }
                            })((m = r.reduce((e, r) => r(e), e())).cacheSize),
                            parseClassName: (e => {
                                let {
                                    prefix: r,
                                    experimentalParseClassName: o
                                } = e, t = e => {
                                    let r, o = [],
                                        t = 0,
                                        l = 0,
                                        a = 0,
                                        s = e.length;
                                    for (let n = 0; n < s; n++) {
                                        let s = e[n];
                                        if (0 === t && 0 === l) {
                                            if (":" === s) {
                                                o.push(e.slice(a, n)), a = n + 1;
                                                continue
                                            }
                                            if ("/" === s) {
                                                r = n;
                                                continue
                                            }
                                        }
                                        "[" === s ? t++ : "]" === s ? t-- : "(" === s ? l++ : ")" === s && l--
                                    }
                                    let n = 0 === o.length ? e : e.slice(a),
                                        i = n,
                                        d = !1;
                                    return n.endsWith("!") ? (i = n.slice(0, -1), d = !0) : n.startsWith("!") && (i = n.slice(1), d = !0), f(o, d, i, r && r > a ? r - a : void 0)
                                };
                                if (r) {
                                    let e = r + ":",
                                        o = t;
                                    t = r => r.startsWith(e) ? o(r.slice(e.length)) : f(b, !1, r, void 0, !0)
                                }
                                if (o) {
                                    let e = t;
                                    t = r => o({
                                        className: r,
                                        parseClassName: e
                                    })
                                }
                                return t
                            })(m),
                            sortModifiers: (p = new Map, m.orderSensitiveModifiers.forEach((e, r) => {
                                p.set(e, 1e6 + r)
                            }), e => {
                                let r = [],
                                    o = [];
                                for (let t = 0; t < e.length; t++) {
                                    let l = e[t],
                                        a = "[" === l[0],
                                        s = p.has(l);
                                    a || s ? (o.length > 0 && (o.sort(), r.push(...o), o = []), r.push(l)) : o.push(l)
                                }
                                return o.length > 0 && (o.sort(), r.push(...o)), r
                            }),
                            ...(e => {
                                let r = (e => {
                                        let {
                                            theme: r,
                                            classGroups: o
                                        } = e;
                                        return s(o, r)
                                    })(e),
                                    {
                                        conflictingClassGroups: o,
                                        conflictingClassGroupModifiers: t
                                    } = e;
                                return {
                                    getClassGroupId: e => {
                                        if (e.startsWith("[") && e.endsWith("]")) {
                                            var o;
                                            let r, t, l;
                                            return -1 === (o = e).slice(1, -1).indexOf(":") ? void 0 : (t = (r = o.slice(1, -1)).indexOf(":"), (l = r.slice(0, t)) ? "arbitrary.." + l : void 0)
                                        }
                                        let t = e.split("-"),
                                            l = +("" === t[0] && t.length > 1);
                                        return a(t, l, r)
                                    },
                                    getConflictingClassGroupIds: (e, r) => {
                                        if (r) {
                                            let r = t[e],
                                                a = o[e];
                                            if (r) {
                                                if (a) {
                                                    let e = Array(a.length + r.length);
                                                    for (let r = 0; r < a.length; r++) e[r] = a[r];
                                                    for (let o = 0; o < r.length; o++) e[a.length + o] = r[o];
                                                    return e
                                                }
                                                return r
                                            }
                                            return a || l
                                        }
                                        return o[e] || l
                                    }
                                }
                            })(m)
                        }).cache.get, n = o.cache.set, i = d, d(c)
                    }, (...e) => i(((...e) => {
                        let r, o, t = 0,
                            l = "";
                        for (; t < e.length;)(r = e[t++]) && (o = h(r)) && (l && (l += " "), l += o);
                        return l
                    })(...e))
                },
                x = [],
                w = e => {
                    let r = r => r[e] || x;
                    return r.isThemeGetter = !0, r
                },
                v = /^\[(?:(\w[\w-]*):)?(.+)\]$/i,
                y = /^\((?:(\w[\w-]*):)?(.+)\)$/i,
                z = /^\d+\/\d+$/,
                G = /^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,
                j = /\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,
                C = /^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,
                M = /^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,
                N = /^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,
                S = e => z.test(e),
                I = e => !!e && !Number.isNaN(Number(e)),
                O = e => !!e && Number.isInteger(Number(e)),
                $ = e => e.endsWith("%") && I(e.slice(0, -1)),
                W = e => G.test(e),
                _ = () => !0,
                P = e => j.test(e) && !C.test(e),
                E = () => !1,
                T = e => M.test(e),
                q = e => N.test(e),
                A = e => !B(e) && !L(e),
                V = e => ee(e, el, E),
                B = e => v.test(e),
                D = e => ee(e, ea, P),
                F = e => ee(e, es, I),
                H = e => ee(e, eo, E),
                J = e => ee(e, et, q),
                K = e => ee(e, ei, T),
                L = e => y.test(e),
                Q = e => er(e, ea),
                R = e => er(e, en),
                U = e => er(e, eo),
                X = e => er(e, el),
                Y = e => er(e, et),
                Z = e => er(e, ei, !0),
                ee = (e, r, o) => {
                    let t = v.exec(e);
                    return !!t && (t[1] ? r(t[1]) : o(t[2]))
                },
                er = (e, r, o = !1) => {
                    let t = y.exec(e);
                    return !!t && (t[1] ? r(t[1]) : o)
                },
                eo = e => "position" === e || "percentage" === e,
                et = e => "image" === e || "url" === e,
                el = e => "length" === e || "size" === e || "bg-size" === e,
                ea = e => "length" === e,
                es = e => "number" === e,
                en = e => "family-name" === e,
                ei = e => "shadow" === e,
                ed = () => {
                    let e = w("color"),
                        r = w("font"),
                        o = w("text"),
                        t = w("font-weight"),
                        l = w("tracking"),
                        a = w("leading"),
                        s = w("breakpoint"),
                        n = w("container"),
                        i = w("spacing"),
                        d = w("radius"),
                        c = w("shadow"),
                        m = w("inset-shadow"),
                        p = w("text-shadow"),
                        u = w("drop-shadow"),
                        b = w("blur"),
                        f = w("perspective"),
                        g = w("aspect"),
                        h = w("ease"),
                        k = w("animate"),
                        x = () => ["auto", "avoid", "all", "avoid-page", "page", "left", "right", "column"],
                        v = () => ["center", "top", "bottom", "left", "right", "top-left", "left-top", "top-right", "right-top", "bottom-right", "right-bottom", "bottom-left", "left-bottom"],
                        y = () => [...v(), L, B],
                        z = () => ["auto", "hidden", "clip", "visible", "scroll"],
                        G = () => ["auto", "contain", "none"],
                        j = () => [L, B, i],
                        C = () => [S, "full", "auto", ...j()],
                        M = () => [O, "none", "subgrid", L, B],
                        N = () => ["auto", {
                            span: ["full", O, L, B]
                        }, O, L, B],
                        P = () => [O, "auto", L, B],
                        E = () => ["auto", "min", "max", "fr", L, B],
                        T = () => ["start", "end", "center", "between", "around", "evenly", "stretch", "baseline", "center-safe", "end-safe"],
                        q = () => ["start", "end", "center", "stretch", "center-safe", "end-safe"],
                        ee = () => ["auto", ...j()],
                        er = () => [S, "auto", "full", "dvw", "dvh", "lvw", "lvh", "svw", "svh", "min", "max", "fit", ...j()],
                        eo = () => [e, L, B],
                        et = () => [...v(), U, H, {
                            position: [L, B]
                        }],
                        el = () => ["no-repeat", {
                            repeat: ["", "x", "y", "space", "round"]
                        }],
                        ea = () => ["auto", "cover", "contain", X, V, {
                            size: [L, B]
                        }],
                        es = () => [$, Q, D],
                        en = () => ["", "none", "full", d, L, B],
                        ei = () => ["", I, Q, D],
                        ed = () => ["solid", "dashed", "dotted", "double"],
                        ec = () => ["normal", "multiply", "screen", "overlay", "darken", "lighten", "color-dodge", "color-burn", "hard-light", "soft-light", "difference", "exclusion", "hue", "saturation", "color", "luminosity"],
                        em = () => [I, $, U, H],
                        ep = () => ["", "none", b, L, B],
                        eu = () => ["none", I, L, B],
                        eb = () => ["none", I, L, B],
                        ef = () => [I, L, B],
                        eg = () => [S, "full", ...j()];
                    return {
                        cacheSize: 500,
                        theme: {
                            animate: ["spin", "ping", "pulse", "bounce"],
                            aspect: ["video"],
                            blur: [W],
                            breakpoint: [W],
                            color: [_],
                            container: [W],
                            "drop-shadow": [W],
                            ease: ["in", "out", "in-out"],
                            font: [A],
                            "font-weight": ["thin", "extralight", "light", "normal", "medium", "semibold", "bold", "extrabold", "black"],
                            "inset-shadow": [W],
                            leading: ["none", "tight", "snug", "normal", "relaxed", "loose"],
                            perspective: ["dramatic", "near", "normal", "midrange", "distant", "none"],
                            radius: [W],
                            shadow: [W],
                            spacing: ["px", I],
                            text: [W],
                            "text-shadow": [W],
                            tracking: ["tighter", "tight", "normal", "wide", "wider", "widest"]
                        },
                        classGroups: {
                            aspect: [{
                                aspect: ["auto", "square", S, B, L, g]
                            }],
                            container: ["container"],
                            columns: [{
                                columns: [I, B, L, n]
                            }],
                            "break-after": [{
                                "break-after": x()
                            }],
                            "break-before": [{
                                "break-before": x()
                            }],
                            "break-inside": [{
                                "break-inside": ["auto", "avoid", "avoid-page", "avoid-column"]
                            }],
                            "box-decoration": [{
                                "box-decoration": ["slice", "clone"]
                            }],
                            box: [{
                                box: ["border", "content"]
                            }],
                            display: ["block", "inline-block", "inline", "flex", "inline-flex", "table", "inline-table", "table-caption", "table-cell", "table-column", "table-column-group", "table-footer-group", "table-header-group", "table-row-group", "table-row", "flow-root", "grid", "inline-grid", "contents", "list-item", "hidden"],
                            sr: ["sr-only", "not-sr-only"],
                            float: [{
                                float: ["right", "left", "none", "start", "end"]
                            }],
                            clear: [{
                                clear: ["left", "right", "both", "none", "start", "end"]
                            }],
                            isolation: ["isolate", "isolation-auto"],
                            "object-fit": [{
                                object: ["contain", "cover", "fill", "none", "scale-down"]
                            }],
                            "object-position": [{
                                object: y()
                            }],
                            overflow: [{
                                overflow: z()
                            }],
                            "overflow-x": [{
                                "overflow-x": z()
                            }],
                            "overflow-y": [{
                                "overflow-y": z()
                            }],
                            overscroll: [{
                                overscroll: G()
                            }],
                            "overscroll-x": [{
                                "overscroll-x": G()
                            }],
                            "overscroll-y": [{
                                "overscroll-y": G()
                            }],
                            position: ["static", "fixed", "absolute", "relative", "sticky"],
                            inset: [{
                                inset: C()
                            }],
                            "inset-x": [{
                                "inset-x": C()
                            }],
                            "inset-y": [{
                                "inset-y": C()
                            }],
                            start: [{
                                start: C()
                            }],
                            end: [{
                                end: C()
                            }],
                            top: [{
                                top: C()
                            }],
                            right: [{
                                right: C()
                            }],
                            bottom: [{
                                bottom: C()
                            }],
                            left: [{
                                left: C()
                            }],
                            visibility: ["visible", "invisible", "collapse"],
                            z: [{
                                z: [O, "auto", L, B]
                            }],
                            basis: [{
                                basis: [S, "full", "auto", n, ...j()]
                            }],
                            "flex-direction": [{
                                flex: ["row", "row-reverse", "col", "col-reverse"]
                            }],
                            "flex-wrap": [{
                                flex: ["nowrap", "wrap", "wrap-reverse"]
                            }],
                            flex: [{
                                flex: [I, S, "auto", "initial", "none", B]
                            }],
                            grow: [{
                                grow: ["", I, L, B]
                            }],
                            shrink: [{
                                shrink: ["", I, L, B]
                            }],
                            order: [{
                                order: [O, "first", "last", "none", L, B]
                            }],
                            "grid-cols": [{
                                "grid-cols": M()
                            }],
                            "col-start-end": [{
                                col: N()
                            }],
                            "col-start": [{
                                "col-start": P()
                            }],
                            "col-end": [{
                                "col-end": P()
                            }],
                            "grid-rows": [{
                                "grid-rows": M()
                            }],
                            "row-start-end": [{
                                row: N()
                            }],
                            "row-start": [{
                                "row-start": P()
                            }],
                            "row-end": [{
                                "row-end": P()
                            }],
                            "grid-flow": [{
                                "grid-flow": ["row", "col", "dense", "row-dense", "col-dense"]
                            }],
                            "auto-cols": [{
                                "auto-cols": E()
                            }],
                            "auto-rows": [{
                                "auto-rows": E()
                            }],
                            gap: [{
                                gap: j()
                            }],
                            "gap-x": [{
                                "gap-x": j()
                            }],
                            "gap-y": [{
                                "gap-y": j()
                            }],
                            "justify-content": [{
                                justify: [...T(), "normal"]
                            }],
                            "justify-items": [{
                                "justify-items": [...q(), "normal"]
                            }],
                            "justify-self": [{
                                "justify-self": ["auto", ...q()]
                            }],
                            "align-content": [{
                                content: ["normal", ...T()]
                            }],
                            "align-items": [{
                                items: [...q(), {
                                    baseline: ["", "last"]
                                }]
                            }],
                            "align-self": [{
                                self: ["auto", ...q(), {
                                    baseline: ["", "last"]
                                }]
                            }],
                            "place-content": [{
                                "place-content": T()
                            }],
                            "place-items": [{
                                "place-items": [...q(), "baseline"]
                            }],
                            "place-self": [{
                                "place-self": ["auto", ...q()]
                            }],
                            p: [{
                                p: j()
                            }],
                            px: [{
                                px: j()
                            }],
                            py: [{
                                py: j()
                            }],
                            ps: [{
                                ps: j()
                            }],
                            pe: [{
                                pe: j()
                            }],
                            pt: [{
                                pt: j()
                            }],
                            pr: [{
                                pr: j()
                            }],
                            pb: [{
                                pb: j()
                            }],
                            pl: [{
                                pl: j()
                            }],
                            m: [{
                                m: ee()
                            }],
                            mx: [{
                                mx: ee()
                            }],
                            my: [{
                                my: ee()
                            }],
                            ms: [{
                                ms: ee()
                            }],
                            me: [{
                                me: ee()
                            }],
                            mt: [{
                                mt: ee()
                            }],
                            mr: [{
                                mr: ee()
                            }],
                            mb: [{
                                mb: ee()
                            }],
                            ml: [{
                                ml: ee()
                            }],
                            "space-x": [{
                                "space-x": j()
                            }],
                            "space-x-reverse": ["space-x-reverse"],
                            "space-y": [{
                                "space-y": j()
                            }],
                            "space-y-reverse": ["space-y-reverse"],
                            size: [{
                                size: er()
                            }],
                            w: [{
                                w: [n, "screen", ...er()]
                            }],
                            "min-w": [{
                                "min-w": [n, "screen", "none", ...er()]
                            }],
                            "max-w": [{
                                "max-w": [n, "screen", "none", "prose", {
                                    screen: [s]
                                }, ...er()]
                            }],
                            h: [{
                                h: ["screen", "lh", ...er()]
                            }],
                            "min-h": [{
                                "min-h": ["screen", "lh", "none", ...er()]
                            }],
                            "max-h": [{
                                "max-h": ["screen", "lh", ...er()]
                            }],
                            "font-size": [{
                                text: ["base", o, Q, D]
                            }],
                            "font-smoothing": ["antialiased", "subpixel-antialiased"],
                            "font-style": ["italic", "not-italic"],
                            "font-weight": [{
                                font: [t, L, F]
                            }],
                            "font-stretch": [{
                                "font-stretch": ["ultra-condensed", "extra-condensed", "condensed", "semi-condensed", "normal", "semi-expanded", "expanded", "extra-expanded", "ultra-expanded", $, B]
                            }],
                            "font-family": [{
                                font: [R, B, r]
                            }],
                            "fvn-normal": ["normal-nums"],
                            "fvn-ordinal": ["ordinal"],
                            "fvn-slashed-zero": ["slashed-zero"],
                            "fvn-figure": ["lining-nums", "oldstyle-nums"],
                            "fvn-spacing": ["proportional-nums", "tabular-nums"],
                            "fvn-fraction": ["diagonal-fractions", "stacked-fractions"],
                            tracking: [{
                                tracking: [l, L, B]
                            }],
                            "line-clamp": [{
                                "line-clamp": [I, "none", L, F]
                            }],
                            leading: [{
                                leading: [a, ...j()]
                            }],
                            "list-image": [{
                                "list-image": ["none", L, B]
                            }],
                            "list-style-position": [{
                                list: ["inside", "outside"]
                            }],
                            "list-style-type": [{
                                list: ["disc", "decimal", "none", L, B]
                            }],
                            "text-alignment": [{
                                text: ["left", "center", "right", "justify", "start", "end"]
                            }],
                            "placeholder-color": [{
                                placeholder: eo()
                            }],
                            "text-color": [{
                                text: eo()
                            }],
                            "text-decoration": ["underline", "overline", "line-through", "no-underline"],
                            "text-decoration-style": [{
                                decoration: [...ed(), "wavy"]
                            }],
                            "text-decoration-thickness": [{
                                decoration: [I, "from-font", "auto", L, D]
                            }],
                            "text-decoration-color": [{
                                decoration: eo()
                            }],
                            "underline-offset": [{
                                "underline-offset": [I, "auto", L, B]
                            }],
                            "text-transform": ["uppercase", "lowercase", "capitalize", "normal-case"],
                            "text-overflow": ["truncate", "text-ellipsis", "text-clip"],
                            "text-wrap": [{
                                text: ["wrap", "nowrap", "balance", "pretty"]
                            }],
                            indent: [{
                                indent: j()
                            }],
                            "vertical-align": [{
                                align: ["baseline", "top", "middle", "bottom", "text-top", "text-bottom", "sub", "super", L, B]
                            }],
                            whitespace: [{
                                whitespace: ["normal", "nowrap", "pre", "pre-line", "pre-wrap", "break-spaces"]
                            }],
                            break: [{
                                break: ["normal", "words", "all", "keep"]
                            }],
                            wrap: [{
                                wrap: ["break-word", "anywhere", "normal"]
                            }],
                            hyphens: [{
                                hyphens: ["none", "manual", "auto"]
                            }],
                            content: [{
                                content: ["none", L, B]
                            }],
                            "bg-attachment": [{
                                bg: ["fixed", "local", "scroll"]
                            }],
                            "bg-clip": [{
                                "bg-clip": ["border", "padding", "content", "text"]
                            }],
                            "bg-origin": [{
                                "bg-origin": ["border", "padding", "content"]
                            }],
                            "bg-position": [{
                                bg: et()
                            }],
                            "bg-repeat": [{
                                bg: el()
                            }],
                            "bg-size": [{
                                bg: ea()
                            }],
                            "bg-image": [{
                                bg: ["none", {
                                    linear: [{
                                        to: ["t", "tr", "r", "br", "b", "bl", "l", "tl"]
                                    }, O, L, B],
                                    radial: ["", L, B],
                                    conic: [O, L, B]
                                }, Y, J]
                            }],
                            "bg-color": [{
                                bg: eo()
                            }],
                            "gradient-from-pos": [{
                                from: es()
                            }],
                            "gradient-via-pos": [{
                                via: es()
                            }],
                            "gradient-to-pos": [{
                                to: es()
                            }],
                            "gradient-from": [{
                                from: eo()
                            }],
                            "gradient-via": [{
                                via: eo()
                            }],
                            "gradient-to": [{
                                to: eo()
                            }],
                            rounded: [{
                                rounded: en()
                            }],
                            "rounded-s": [{
                                "rounded-s": en()
                            }],
                            "rounded-e": [{
                                "rounded-e": en()
                            }],
                            "rounded-t": [{
                                "rounded-t": en()
                            }],
                            "rounded-r": [{
                                "rounded-r": en()
                            }],
                            "rounded-b": [{
                                "rounded-b": en()
                            }],
                            "rounded-l": [{
                                "rounded-l": en()
                            }],
                            "rounded-ss": [{
                                "rounded-ss": en()
                            }],
                            "rounded-se": [{
                                "rounded-se": en()
                            }],
                            "rounded-ee": [{
                                "rounded-ee": en()
                            }],
                            "rounded-es": [{
                                "rounded-es": en()
                            }],
                            "rounded-tl": [{
                                "rounded-tl": en()
                            }],
                            "rounded-tr": [{
                                "rounded-tr": en()
                            }],
                            "rounded-br": [{
                                "rounded-br": en()
                            }],
                            "rounded-bl": [{
                                "rounded-bl": en()
                            }],
                            "border-w": [{
                                border: ei()
                            }],
                            "border-w-x": [{
                                "border-x": ei()
                            }],
                            "border-w-y": [{
                                "border-y": ei()
                            }],
                            "border-w-s": [{
                                "border-s": ei()
                            }],
                            "border-w-e": [{
                                "border-e": ei()
                            }],
                            "border-w-t": [{
                                "border-t": ei()
                            }],
                            "border-w-r": [{
                                "border-r": ei()
                            }],
                            "border-w-b": [{
                                "border-b": ei()
                            }],
                            "border-w-l": [{
                                "border-l": ei()
                            }],
                            "divide-x": [{
                                "divide-x": ei()
                            }],
                            "divide-x-reverse": ["divide-x-reverse"],
                            "divide-y": [{
                                "divide-y": ei()
                            }],
                            "divide-y-reverse": ["divide-y-reverse"],
                            "border-style": [{
                                border: [...ed(), "hidden", "none"]
                            }],
                            "divide-style": [{
                                divide: [...ed(), "hidden", "none"]
                            }],
                            "border-color": [{
                                border: eo()
                            }],
                            "border-color-x": [{
                                "border-x": eo()
                            }],
                            "border-color-y": [{
                                "border-y": eo()
                            }],
                            "border-color-s": [{
                                "border-s": eo()
                            }],
                            "border-color-e": [{
                                "border-e": eo()
                            }],
                            "border-color-t": [{
                                "border-t": eo()
                            }],
                            "border-color-r": [{
                                "border-r": eo()
                            }],
                            "border-color-b": [{
                                "border-b": eo()
                            }],
                            "border-color-l": [{
                                "border-l": eo()
                            }],
                            "divide-color": [{
                                divide: eo()
                            }],
                            "outline-style": [{
                                outline: [...ed(), "none", "hidden"]
                            }],
                            "outline-offset": [{
                                "outline-offset": [I, L, B]
                            }],
                            "outline-w": [{
                                outline: ["", I, Q, D]
                            }],
                            "outline-color": [{
                                outline: eo()
                            }],
                            shadow: [{
                                shadow: ["", "none", c, Z, K]
                            }],
                            "shadow-color": [{
                                shadow: eo()
                            }],
                            "inset-shadow": [{
                                "inset-shadow": ["none", m, Z, K]
                            }],
                            "inset-shadow-color": [{
                                "inset-shadow": eo()
                            }],
                            "ring-w": [{
                                ring: ei()
                            }],
                            "ring-w-inset": ["ring-inset"],
                            "ring-color": [{
                                ring: eo()
                            }],
                            "ring-offset-w": [{
                                "ring-offset": [I, D]
                            }],
                            "ring-offset-color": [{
                                "ring-offset": eo()
                            }],
                            "inset-ring-w": [{
                                "inset-ring": ei()
                            }],
                            "inset-ring-color": [{
                                "inset-ring": eo()
                            }],
                            "text-shadow": [{
                                "text-shadow": ["none", p, Z, K]
                            }],
                            "text-shadow-color": [{
                                "text-shadow": eo()
                            }],
                            opacity: [{
                                opacity: [I, L, B]
                            }],
                            "mix-blend": [{
                                "mix-blend": [...ec(), "plus-darker", "plus-lighter"]
                            }],
                            "bg-blend": [{
                                "bg-blend": ec()
                            }],
                            "mask-clip": [{
                                "mask-clip": ["border", "padding", "content", "fill", "stroke", "view"]
                            }, "mask-no-clip"],
                            "mask-composite": [{
                                mask: ["add", "subtract", "intersect", "exclude"]
                            }],
                            "mask-image-linear-pos": [{
                                "mask-linear": [I]
                            }],
                            "mask-image-linear-from-pos": [{
                                "mask-linear-from": em()
                            }],
                            "mask-image-linear-to-pos": [{
                                "mask-linear-to": em()
                            }],
                            "mask-image-linear-from-color": [{
                                "mask-linear-from": eo()
                            }],
                            "mask-image-linear-to-color": [{
                                "mask-linear-to": eo()
                            }],
                            "mask-image-t-from-pos": [{
                                "mask-t-from": em()
                            }],
                            "mask-image-t-to-pos": [{
                                "mask-t-to": em()
                            }],
                            "mask-image-t-from-color": [{
                                "mask-t-from": eo()
                            }],
                            "mask-image-t-to-color": [{
                                "mask-t-to": eo()
                            }],
                            "mask-image-r-from-pos": [{
                                "mask-r-from": em()
                            }],
                            "mask-image-r-to-pos": [{
                                "mask-r-to": em()
                            }],
                            "mask-image-r-from-color": [{
                                "mask-r-from": eo()
                            }],
                            "mask-image-r-to-color": [{
                                "mask-r-to": eo()
                            }],
                            "mask-image-b-from-pos": [{
                                "mask-b-from": em()
                            }],
                            "mask-image-b-to-pos": [{
                                "mask-b-to": em()
                            }],
                            "mask-image-b-from-color": [{
                                "mask-b-from": eo()
                            }],
                            "mask-image-b-to-color": [{
                                "mask-b-to": eo()
                            }],
                            "mask-image-l-from-pos": [{
                                "mask-l-from": em()
                            }],
                            "mask-image-l-to-pos": [{
                                "mask-l-to": em()
                            }],
                            "mask-image-l-from-color": [{
                                "mask-l-from": eo()
                            }],
                            "mask-image-l-to-color": [{
                                "mask-l-to": eo()
                            }],
                            "mask-image-x-from-pos": [{
                                "mask-x-from": em()
                            }],
                            "mask-image-x-to-pos": [{
                                "mask-x-to": em()
                            }],
                            "mask-image-x-from-color": [{
                                "mask-x-from": eo()
                            }],
                            "mask-image-x-to-color": [{
                                "mask-x-to": eo()
                            }],
                            "mask-image-y-from-pos": [{
                                "mask-y-from": em()
                            }],
                            "mask-image-y-to-pos": [{
                                "mask-y-to": em()
                            }],
                            "mask-image-y-from-color": [{
                                "mask-y-from": eo()
                            }],
                            "mask-image-y-to-color": [{
                                "mask-y-to": eo()
                            }],
                            "mask-image-radial": [{
                                "mask-radial": [L, B]
                            }],
                            "mask-image-radial-from-pos": [{
                                "mask-radial-from": em()
                            }],
                            "mask-image-radial-to-pos": [{
                                "mask-radial-to": em()
                            }],
                            "mask-image-radial-from-color": [{
                                "mask-radial-from": eo()
                            }],
                            "mask-image-radial-to-color": [{
                                "mask-radial-to": eo()
                            }],
                            "mask-image-radial-shape": [{
                                "mask-radial": ["circle", "ellipse"]
                            }],
                            "mask-image-radial-size": [{
                                "mask-radial": [{
                                    closest: ["side", "corner"],
                                    farthest: ["side", "corner"]
                                }]
                            }],
                            "mask-image-radial-pos": [{
                                "mask-radial-at": v()
                            }],
                            "mask-image-conic-pos": [{
                                "mask-conic": [I]
                            }],
                            "mask-image-conic-from-pos": [{
                                "mask-conic-from": em()
                            }],
                            "mask-image-conic-to-pos": [{
                                "mask-conic-to": em()
                            }],
                            "mask-image-conic-from-color": [{
                                "mask-conic-from": eo()
                            }],
                            "mask-image-conic-to-color": [{
                                "mask-conic-to": eo()
                            }],
                            "mask-mode": [{
                                mask: ["alpha", "luminance", "match"]
                            }],
                            "mask-origin": [{
                                "mask-origin": ["border", "padding", "content", "fill", "stroke", "view"]
                            }],
                            "mask-position": [{
                                mask: et()
                            }],
                            "mask-repeat": [{
                                mask: el()
                            }],
                            "mask-size": [{
                                mask: ea()
                            }],
                            "mask-type": [{
                                "mask-type": ["alpha", "luminance"]
                            }],
                            "mask-image": [{
                                mask: ["none", L, B]
                            }],
                            filter: [{
                                filter: ["", "none", L, B]
                            }],
                            blur: [{
                                blur: ep()
                            }],
                            brightness: [{
                                brightness: [I, L, B]
                            }],
                            contrast: [{
                                contrast: [I, L, B]
                            }],
                            "drop-shadow": [{
                                "drop-shadow": ["", "none", u, Z, K]
                            }],
                            "drop-shadow-color": [{
                                "drop-shadow": eo()
                            }],
                            grayscale: [{
                                grayscale: ["", I, L, B]
                            }],
                            "hue-rotate": [{
                                "hue-rotate": [I, L, B]
                            }],
                            invert: [{
                                invert: ["", I, L, B]
                            }],
                            saturate: [{
                                saturate: [I, L, B]
                            }],
                            sepia: [{
                                sepia: ["", I, L, B]
                            }],
                            "backdrop-filter": [{
                                "backdrop-filter": ["", "none", L, B]
                            }],
                            "backdrop-blur": [{
                                "backdrop-blur": ep()
                            }],
                            "backdrop-brightness": [{
                                "backdrop-brightness": [I, L, B]
                            }],
                            "backdrop-contrast": [{
                                "backdrop-contrast": [I, L, B]
                            }],
                            "backdrop-grayscale": [{
                                "backdrop-grayscale": ["", I, L, B]
                            }],
                            "backdrop-hue-rotate": [{
                                "backdrop-hue-rotate": [I, L, B]
                            }],
                            "backdrop-invert": [{
                                "backdrop-invert": ["", I, L, B]
                            }],
                            "backdrop-opacity": [{
                                "backdrop-opacity": [I, L, B]
                            }],
                            "backdrop-saturate": [{
                                "backdrop-saturate": [I, L, B]
                            }],
                            "backdrop-sepia": [{
                                "backdrop-sepia": ["", I, L, B]
                            }],
                            "border-collapse": [{
                                border: ["collapse", "separate"]
                            }],
                            "border-spacing": [{
                                "border-spacing": j()
                            }],
                            "border-spacing-x": [{
                                "border-spacing-x": j()
                            }],
                            "border-spacing-y": [{
                                "border-spacing-y": j()
                            }],
                            "table-layout": [{
                                table: ["auto", "fixed"]
                            }],
                            caption: [{
                                caption: ["top", "bottom"]
                            }],
                            transition: [{
                                transition: ["", "all", "colors", "opacity", "shadow", "transform", "none", L, B]
                            }],
                            "transition-behavior": [{
                                transition: ["normal", "discrete"]
                            }],
                            duration: [{
                                duration: [I, "initial", L, B]
                            }],
                            ease: [{
                                ease: ["linear", "initial", h, L, B]
                            }],
                            delay: [{
                                delay: [I, L, B]
                            }],
                            animate: [{
                                animate: ["none", k, L, B]
                            }],
                            backface: [{
                                backface: ["hidden", "visible"]
                            }],
                            perspective: [{
                                perspective: [f, L, B]
                            }],
                            "perspective-origin": [{
                                "perspective-origin": y()
                            }],
                            rotate: [{
                                rotate: eu()
                            }],
                            "rotate-x": [{
                                "rotate-x": eu()
                            }],
                            "rotate-y": [{
                                "rotate-y": eu()
                            }],
                            "rotate-z": [{
                                "rotate-z": eu()
                            }],
                            scale: [{
                                scale: eb()
                            }],
                            "scale-x": [{
                                "scale-x": eb()
                            }],
                            "scale-y": [{
                                "scale-y": eb()
                            }],
                            "scale-z": [{
                                "scale-z": eb()
                            }],
                            "scale-3d": ["scale-3d"],
                            skew: [{
                                skew: ef()
                            }],
                            "skew-x": [{
                                "skew-x": ef()
                            }],
                            "skew-y": [{
                                "skew-y": ef()
                            }],
                            transform: [{
                                transform: [L, B, "", "none", "gpu", "cpu"]
                            }],
                            "transform-origin": [{
                                origin: y()
                            }],
                            "transform-style": [{
                                transform: ["3d", "flat"]
                            }],
                            translate: [{
                                translate: eg()
                            }],
                            "translate-x": [{
                                "translate-x": eg()
                            }],
                            "translate-y": [{
                                "translate-y": eg()
                            }],
                            "translate-z": [{
                                "translate-z": eg()
                            }],
                            "translate-none": ["translate-none"],
                            accent: [{
                                accent: eo()
                            }],
                            appearance: [{
                                appearance: ["none", "auto"]
                            }],
                            "caret-color": [{
                                caret: eo()
                            }],
                            "color-scheme": [{
                                scheme: ["normal", "dark", "light", "light-dark", "only-dark", "only-light"]
                            }],
                            cursor: [{
                                cursor: ["auto", "default", "pointer", "wait", "text", "move", "help", "not-allowed", "none", "context-menu", "progress", "cell", "crosshair", "vertical-text", "alias", "copy", "no-drop", "grab", "grabbing", "all-scroll", "col-resize", "row-resize", "n-resize", "e-resize", "s-resize", "w-resize", "ne-resize", "nw-resize", "se-resize", "sw-resize", "ew-resize", "ns-resize", "nesw-resize", "nwse-resize", "zoom-in", "zoom-out", L, B]
                            }],
                            "field-sizing": [{
                                "field-sizing": ["fixed", "content"]
                            }],
                            "pointer-events": [{
                                "pointer-events": ["auto", "none"]
                            }],
                            resize: [{
                                resize: ["none", "", "y", "x"]
                            }],
                            "scroll-behavior": [{
                                scroll: ["auto", "smooth"]
                            }],
                            "scroll-m": [{
                                "scroll-m": j()
                            }],
                            "scroll-mx": [{
                                "scroll-mx": j()
                            }],
                            "scroll-my": [{
                                "scroll-my": j()
                            }],
                            "scroll-ms": [{
                                "scroll-ms": j()
                            }],
                            "scroll-me": [{
                                "scroll-me": j()
                            }],
                            "scroll-mt": [{
                                "scroll-mt": j()
                            }],
                            "scroll-mr": [{
                                "scroll-mr": j()
                            }],
                            "scroll-mb": [{
                                "scroll-mb": j()
                            }],
                            "scroll-ml": [{
                                "scroll-ml": j()
                            }],
                            "scroll-p": [{
                                "scroll-p": j()
                            }],
                            "scroll-px": [{
                                "scroll-px": j()
                            }],
                            "scroll-py": [{
                                "scroll-py": j()
                            }],
                            "scroll-ps": [{
                                "scroll-ps": j()
                            }],
                            "scroll-pe": [{
                                "scroll-pe": j()
                            }],
                            "scroll-pt": [{
                                "scroll-pt": j()
                            }],
                            "scroll-pr": [{
                                "scroll-pr": j()
                            }],
                            "scroll-pb": [{
                                "scroll-pb": j()
                            }],
                            "scroll-pl": [{
                                "scroll-pl": j()
                            }],
                            "snap-align": [{
                                snap: ["start", "end", "center", "align-none"]
                            }],
                            "snap-stop": [{
                                snap: ["normal", "always"]
                            }],
                            "snap-type": [{
                                snap: ["none", "x", "y", "both"]
                            }],
                            "snap-strictness": [{
                                snap: ["mandatory", "proximity"]
                            }],
                            touch: [{
                                touch: ["auto", "none", "manipulation"]
                            }],
                            "touch-x": [{
                                "touch-pan": ["x", "left", "right"]
                            }],
                            "touch-y": [{
                                "touch-pan": ["y", "up", "down"]
                            }],
                            "touch-pz": ["touch-pinch-zoom"],
                            select: [{
                                select: ["none", "text", "all", "auto"]
                            }],
                            "will-change": [{
                                "will-change": ["auto", "scroll", "contents", "transform", L, B]
                            }],
                            fill: [{
                                fill: ["none", ...eo()]
                            }],
                            "stroke-w": [{
                                stroke: [I, Q, D, F]
                            }],
                            stroke: [{
                                stroke: ["none", ...eo()]
                            }],
                            "forced-color-adjust": [{
                                "forced-color-adjust": ["auto", "none"]
                            }]
                        },
                        conflictingClassGroups: {
                            overflow: ["overflow-x", "overflow-y"],
                            overscroll: ["overscroll-x", "overscroll-y"],
                            inset: ["inset-x", "inset-y", "start", "end", "top", "right", "bottom", "left"],
                            "inset-x": ["right", "left"],
                            "inset-y": ["top", "bottom"],
                            flex: ["basis", "grow", "shrink"],
                            gap: ["gap-x", "gap-y"],
                            p: ["px", "py", "ps", "pe", "pt", "pr", "pb", "pl"],
                            px: ["pr", "pl"],
                            py: ["pt", "pb"],
                            m: ["mx", "my", "ms", "me", "mt", "mr", "mb", "ml"],
                            mx: ["mr", "ml"],
                            my: ["mt", "mb"],
                            size: ["w", "h"],
                            "font-size": ["leading"],
                            "fvn-normal": ["fvn-ordinal", "fvn-slashed-zero", "fvn-figure", "fvn-spacing", "fvn-fraction"],
                            "fvn-ordinal": ["fvn-normal"],
                            "fvn-slashed-zero": ["fvn-normal"],
                            "fvn-figure": ["fvn-normal"],
                            "fvn-spacing": ["fvn-normal"],
                            "fvn-fraction": ["fvn-normal"],
                            "line-clamp": ["display", "overflow"],
                            rounded: ["rounded-s", "rounded-e", "rounded-t", "rounded-r", "rounded-b", "rounded-l", "rounded-ss", "rounded-se", "rounded-ee", "rounded-es", "rounded-tl", "rounded-tr", "rounded-br", "rounded-bl"],
                            "rounded-s": ["rounded-ss", "rounded-es"],
                            "rounded-e": ["rounded-se", "rounded-ee"],
                            "rounded-t": ["rounded-tl", "rounded-tr"],
                            "rounded-r": ["rounded-tr", "rounded-br"],
                            "rounded-b": ["rounded-br", "rounded-bl"],
                            "rounded-l": ["rounded-tl", "rounded-bl"],
                            "border-spacing": ["border-spacing-x", "border-spacing-y"],
                            "border-w": ["border-w-x", "border-w-y", "border-w-s", "border-w-e", "border-w-t", "border-w-r", "border-w-b", "border-w-l"],
                            "border-w-x": ["border-w-r", "border-w-l"],
                            "border-w-y": ["border-w-t", "border-w-b"],
                            "border-color": ["border-color-x", "border-color-y", "border-color-s", "border-color-e", "border-color-t", "border-color-r", "border-color-b", "border-color-l"],
                            "border-color-x": ["border-color-r", "border-color-l"],
                            "border-color-y": ["border-color-t", "border-color-b"],
                            translate: ["translate-x", "translate-y", "translate-none"],
                            "translate-none": ["translate", "translate-x", "translate-y", "translate-z"],
                            "scroll-m": ["scroll-mx", "scroll-my", "scroll-ms", "scroll-me", "scroll-mt", "scroll-mr", "scroll-mb", "scroll-ml"],
                            "scroll-mx": ["scroll-mr", "scroll-ml"],
                            "scroll-my": ["scroll-mt", "scroll-mb"],
                            "scroll-p": ["scroll-px", "scroll-py", "scroll-ps", "scroll-pe", "scroll-pt", "scroll-pr", "scroll-pb", "scroll-pl"],
                            "scroll-px": ["scroll-pr", "scroll-pl"],
                            "scroll-py": ["scroll-pt", "scroll-pb"],
                            touch: ["touch-x", "touch-y", "touch-pz"],
                            "touch-x": ["touch"],
                            "touch-y": ["touch"],
                            "touch-pz": ["touch"]
                        },
                        conflictingClassGroupModifiers: {
                            "font-size": ["leading"]
                        },
                        orderSensitiveModifiers: ["*", "**", "after", "backdrop", "before", "details-content", "file", "first-letter", "first-line", "marker", "placeholder", "selection"]
                    }
                },
                ec = (e, {
                    cacheSize: r,
                    prefix: o,
                    experimentalParseClassName: t,
                    extend: l = {},
                    override: a = {}
                }) => (em(e, "cacheSize", r), em(e, "prefix", o), em(e, "experimentalParseClassName", t), ep(e.theme, a.theme), ep(e.classGroups, a.classGroups), ep(e.conflictingClassGroups, a.conflictingClassGroups), ep(e.conflictingClassGroupModifiers, a.conflictingClassGroupModifiers), em(e, "orderSensitiveModifiers", a.orderSensitiveModifiers), eu(e.theme, l.theme), eu(e.classGroups, l.classGroups), eu(e.conflictingClassGroups, l.conflictingClassGroups), eu(e.conflictingClassGroupModifiers, l.conflictingClassGroupModifiers), eb(e, l, "orderSensitiveModifiers"), e),
                em = (e, r, o) => {
                    void 0 !== o && (e[r] = o)
                },
                ep = (e, r) => {
                    if (r)
                        for (let o in r) em(e, o, r[o])
                },
                eu = (e, r) => {
                    if (r)
                        for (let o in r) eb(e, r, o)
                },
                eb = (e, r, o) => {
                    let t = r[o];
                    void 0 !== t && (e[o] = e[o] ? e[o].concat(t) : t)
                },
                ef = (e, ...r) => "function" == typeof e ? k(ed, e, ...r) : k(() => ec(ed(), e), ...r)
        }
    }
]);
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3064], {
        26484: (e, t, a) => {
            a.d(t, {
                A: () => i
            });
            var r = a(20748),
                s = a(10812),
                l = a(75564);

            function i(e) {
                let t, a, i = (0, s.c)(5),
                    {
                        children: n,
                        className: o
                    } = e;
                return i[0] !== o ? (t = (0, l.tw)("absolute flex size-6 items-center justify-center", "m-2 rounded-md bg-grey-16 text-neutralFgOnBrand", "mai:m-paddingCardBodyInsetDefault mai:rounded-ctrlBadgeCorner mai:bg-bgCtrlOnImageRest mai:text-fgCtrlOnImage", o), i[0] = o, i[1] = t) : t = i[1], i[2] !== n || i[3] !== t ? (a = (0, r.jsx)("div", {
                    className: t,
                    children: n
                }), i[2] = n, i[3] = t, i[4] = a) : a = i[4], a
            }
        },
        28170: (e, t, a) => {
            a.d(t, {
                A: () => d
            });
            var r = a(20748),
                s = a(10812),
                l = a(65177),
                i = a(84662),
                n = a(55964),
                o = a(75564);

            function d(e) {
                let t, a, d, c, m = (0, s.c)(15),
                    {
                        isCompleted: u,
                        points: g,
                        size: p,
                        showEmpty: f
                    } = e,
                    x = (0, i.k)();
                if (!(0, l.O9)(g) && !u && !(void 0 !== f && f) || (0, l.O9)(g) && g <= 0) return;
                let v = u ? "bg-statusSuccessBg3 text-neutralFgInverted1 mai:bg-statusSuccessTintBg mai:text-statusSuccessTintFg" : "border border-neutralStroke1 mai:border-strokeDividerDefault mai:bg-statusInformativeTintBg",
                    h = "large" === p && "h-8 px-3";
                return m[0] !== v || m[1] !== h ? (t = (0, o.tw)("flex h-5 w-fit min-w-5 shrink-0 items-center justify-center gap-0.5 rounded-full px-1.5", v, h), m[0] = v, m[1] = h, m[2] = t) : t = m[2], m[3] !== u || m[4] !== p ? (a = u && (0, r.jsx)(n.default, {
                    className: (0, o.tw)("size-2 text-neutralFgOnBrand mai:text-statusSuccessTintFg", "large" === p && "size-3")
                }), m[3] = u, m[4] = p, m[5] = a) : a = m[5], m[6] !== x || m[7] !== u || m[8] !== g || m[9] !== p ? (d = (0, l.O9)(g) && (0, r.jsxs)("p", {
                    className: (0, o.tw)("text-caption1Stronger mai:text-metadata", !u && "leading-none text-neutralFg2 mai:text-statusInformativeTintFg", u && "text-neutralFgOnBrand mai:text-statusSuccessTintFg", "large" === p && "text-subtitle2Stronger mai:text-globalBody2"),
                    children: [u ? "" : "+", x.number(g)]
                }), m[6] = x, m[7] = u, m[8] = g, m[9] = p, m[10] = d) : d = m[10], m[11] !== t || m[12] !== a || m[13] !== d ? (c = (0, r.jsxs)("div", {
                    className: t,
                    children: [a, d]
                }), m[11] = t, m[12] = a, m[13] = d, m[14] = c) : c = m[14], c
            }
        },
        32255: (e, t, a) => {
            a.r(t), a.d(t, {
                default: () => i
            });
            var r, s = a(59328);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var r in a)({}).hasOwnProperty.call(a, r) && (e[r] = a[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            let i = function(e) {
                return s.createElement("svg", l({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), r || (r = s.createElement("path", {
                    fill: "currentColor",
                    d: "M12 1.999c5.524 0 10.002 4.478 10.002 10.002 0 5.523-4.478 10.001-10.002 10.001S1.998 17.524 1.998 12.001C1.998 6.477 6.476 1.999 12 1.999m0 1.5a8.502 8.502 0 1 0 0 17.003A8.502 8.502 0 0 0 12 3.5Zm-.004 7a.75.75 0 0 1 .744.648l.007.102.003 5.502a.75.75 0 0 1-1.493.102l-.007-.101-.003-5.502a.75.75 0 0 1 .75-.75ZM12 7.003A.999.999 0 1 1 12 9a.999.999 0 0 1 0-1.997"
                })))
            }
        },
        32582: (e, t, a) => {
            a.d(t, {
                A: () => n
            });
            var r = a(20748),
                s = a(10812),
                l = a(34813),
                i = a(75564);

            function n(e) {
                let t, a, n, o, d, c, m, u, g, p, f, x = (0, s.c)(29);
                if (x[0] !== e ? ({
                        src: d,
                        srcSet: c,
                        darkSrc: a,
                        darkSrcSet: n,
                        className: t,
                        ...o
                    } = e, x[0] = e, x[1] = t, x[2] = a, x[3] = n, x[4] = o, x[5] = d, x[6] = c) : (t = x[1], a = x[2], n = x[3], o = x[4], d = x[5], c = x[6]), !a) {
                    let e;
                    return x[7] !== t || x[8] !== o || x[9] !== d || x[10] !== c ? (e = (0, r.jsx)(l.default, {
                        src: d,
                        srcSet: c,
                        className: t,
                        ...o
                    }), x[7] = t, x[8] = o, x[9] = d, x[10] = c, x[11] = e) : e = x[11], e
                }
                return x[12] !== t ? (m = (0, i.tw)("dark:hidden", t), x[12] = t, x[13] = m) : m = x[13], x[14] !== o || x[15] !== d || x[16] !== c || x[17] !== m ? (u = (0, r.jsx)(l.default, {
                    src: d,
                    srcSet: c,
                    className: m,
                    ...o
                }), x[14] = o, x[15] = d, x[16] = c, x[17] = m, x[18] = u) : u = x[18], x[19] !== t ? (g = (0, i.tw)("hidden dark:block", t), x[19] = t, x[20] = g) : g = x[20], x[21] !== a || x[22] !== n || x[23] !== o || x[24] !== g ? (p = (0, r.jsx)(l.default, {
                    src: a,
                    srcSet: n,
                    className: g,
                    ...o
                }), x[21] = a, x[22] = n, x[23] = o, x[24] = g, x[25] = p) : p = x[25], x[26] !== u || x[27] !== p ? (f = (0, r.jsxs)(r.Fragment, {
                    children: [u, p]
                }), x[26] = u, x[27] = p, x[28] = f) : f = x[28], f
            }
        },
        52789: (e, t, a) => {
            a.d(t, {
                G: () => n
            });
            var r = a(20748),
                s = a(10812),
                l = a(65177),
                i = a(28170);

            function n(e) {
                let t = (0, s.c)(15),
                    {
                        isCompleted: a,
                        isInProgress: n,
                        completedCount: o,
                        completedMax: d,
                        size: c
                    } = e,
                    m = void 0 === o ? 0 : o,
                    u = m >= 1,
                    g = (void 0 === d ? 0 : d) > 1 && m > 0;
                if ((a || !n) && u) {
                    let e, a, s;
                    return t[0] !== c ? (e = e => (0, r.jsx)(i.A, {
                        isCompleted: !0,
                        size: c
                    }, e), t[0] = c, t[1] = e) : e = t[1], t[2] !== m || t[3] !== e ? (a = (0, l.ux)(m, e), t[2] = m, t[3] = e, t[4] = a) : a = t[4], t[5] !== a ? (s = (0, r.jsx)("div", {
                        className: "flex flex-wrap gap-2",
                        children: a
                    }), t[5] = a, t[6] = s) : s = t[6], s
                }
                if (n && g) {
                    let e, a, s, n;
                    return t[7] === Symbol.for("react.memo_cache_sentinel") ? (e = (0, r.jsx)(i.A, {
                        isCompleted: !1,
                        showEmpty: !0
                    }), t[7] = e) : e = t[7], t[8] !== c ? (a = e => (0, r.jsx)(i.A, {
                        isCompleted: !0,
                        size: c
                    }, e), t[8] = c, t[9] = a) : a = t[9], t[10] !== m || t[11] !== a ? (s = (0, l.ux)(m, a), t[10] = m, t[11] = a, t[12] = s) : s = t[12], t[13] !== s ? (n = (0, r.jsxs)("div", {
                        className: "flex gap-2",
                        children: [e, s]
                    }), t[13] = s, t[14] = n) : n = t[14], n
                }
            }
        },
        62368: (e, t, a) => {
            a.d(t, {
                Z: () => n
            });
            var r = a(20748),
                s = a(10812);
            a(37223);
            var l = a(32582),
                i = a(75564);

            function n(e) {
                let t, a, n, o, d = (0, s.c)(22),
                    {
                        children: c,
                        className: m,
                        imageClassName: u,
                        contentClassName: g,
                        overlayNode: p,
                        imageUrl: f,
                        darkModeImageUrl: x,
                        imageSizes: v,
                        altText: h,
                        isClickable: w,
                        isNested: b,
                        showEmptyImage: C,
                        hideShadow: y
                    } = e,
                    j = void 0 !== w && w,
                    N = void 0 !== b && b,
                    S = void 0 !== C && C,
                    k = void 0 !== y && y,
                    z = N && "mai:rounded-cornerListCardNestedDefault";
                return d[0] !== m || d[1] !== k || d[2] !== j || d[3] !== z ? (t = (0, i.tw)("flex size-full flex-col gap-1.5 p-1.5", "overflow-hidden rounded-2xl bg-neutralBg1 forced-colors:border", "mai:gap-0 mai:rounded-cornerCardRewards mai:bg-bgCardOnPrimaryDefaultRest mai:p-paddingCardRewards", "mai:border mai:border-strokeCardOnPrimaryRest", z, j && ["cursor-pointer hover:bg-neutralBg1Hover active:bg-neutralBg1Pressed hover:[&_img]:scale-110", "mai:hover:bg-bgCardOnPrimaryDefaultHover mai:active:bg-bgCardOnPrimaryDefaultPressed", "mai:hover:border-strokeCardOnPrimaryHover mai:active:border-strokeCardOnPrimaryPressed"], !k && ["shadow-4 mai:shadow-shadowCardRest", j && "hover:shadow-8 mai:shadow-shadowCardHover mai:active:shadow-shadowCardPressed"], m), d[0] = m, d[1] = k, d[2] = j, d[3] = z, d[4] = t) : t = d[4], d[5] !== h || d[6] !== x || d[7] !== u || d[8] !== v || d[9] !== f || d[10] !== j || d[11] !== N || d[12] !== p || d[13] !== S ? (a = (f || S) && (0, r.jsxs)("div", {
                    className: (0, i.tw)("relative aspect-video shrink-0 overflow-hidden rounded-lg bg-neutralBg2", "mai:rounded-cornerCardNestedRewards mai:bg-bgCtrlNeutralDisabled", N && "mai:rounded-cornerListCardNestedDefault", u),
                    children: [f && (0, r.jsx)(l.A, {
                        alt: h,
                        className: (0, i.tw)(j && "transition-transform duration-200"),
                        fill: !0,
                        sizes: v,
                        src: f,
                        darkSrc: x
                    }), p]
                }), d[5] = h, d[6] = x, d[7] = u, d[8] = v, d[9] = f, d[10] = j, d[11] = N, d[12] = p, d[13] = S, d[14] = a) : a = d[14], d[15] !== c || d[16] !== g ? (n = c && (0, r.jsx)("div", {
                    className: (0, i.tw)("flex grow flex-col gap-1.5", "mai:p-paddingCardBodyRewards", g),
                    children: c
                }), d[15] = c, d[16] = g, d[17] = n) : n = d[17], d[18] !== t || d[19] !== a || d[20] !== n ? (o = (0, r.jsxs)("div", {
                    className: t,
                    children: [a, n]
                }), d[18] = t, d[19] = a, d[20] = n, d[21] = o) : o = d[21], o
            }
        },
        70390: (e, t, a) => {
            a.d(t, {
                U: () => l
            });
            var r = a(10812),
                s = a(84662);

            function l(e) {
                let t = (0, r.c)(6),
                    {
                        isCompleted: a,
                        isInProgress: l,
                        completedAmount: i,
                        showNotStarted: n
                    } = e,
                    o = (0, s.c)("ActivityCard.Status");
                if ((a || !l) && i >= 1) {
                    let e;
                    return t[0] !== o ? (e = o("completed"), t[0] = o, t[1] = e) : e = t[1], e
                }
                if (l) {
                    let e;
                    return t[2] !== o ? (e = o("inProgress"), t[2] = o, t[3] = e) : e = t[3], e
                }
                if (void 0 !== n && n) {
                    let e;
                    return t[4] !== o ? (e = o("notStarted"), t[4] = o, t[5] = e) : e = t[5], e
                }
                return ""
            }
        },
        73064: (e, t, a) => {
            a.d(t, {
                O: () => k
            });
            var r = a(20748),
                s = a(10812),
                l = a(65177),
                i = a(84662),
                n = a(62368),
                o = a(26484),
                d = a(34813),
                c = a(10343),
                m = a(92282),
                u = a(90803),
                g = a(82780),
                p = a(93906),
                f = a(33114),
                x = a(75564),
                v = a(52789),
                h = a(28170),
                w = a(46516),
                b = a(32255),
                C = a(33142),
                y = a(70390);

            function j(e) {
                let t, a, l, i, n, o, d, c, m = (0, s.c)(27),
                    {
                        className: u,
                        description: g,
                        prefix: p,
                        isCompleted: f,
                        isInProgress: v,
                        points: h,
                        status: w,
                        statusIcon: b,
                        title: C,
                        titleClassName: y,
                        completedAmount: j,
                        completedMax: S
                    } = e;
                m[0] !== u ? (t = (0, x.tw)("flex grow flex-col p-1.5 not-mai:justify-between not-mai:text-neutralFg3 mai:gap-2 mai:p-0", u), m[0] = u, m[1] = t) : t = m[1], m[2] !== p ? (a = p && (0, r.jsx)("span", {
                    className: "mai:text-metadata mai:text-fgCtrlNeutralSecondaryRest",
                    children: p
                }), m[2] = p, m[3] = a) : a = m[3], m[4] !== y ? (l = (0, x.tw)("line-clamp-3 text-body1Strong mai:text-globalBody2Strong", y), m[4] = y, m[5] = l) : l = m[5], m[6] !== l || m[7] !== C ? (i = (0, r.jsx)("p", {
                    className: l,
                    children: C
                }), m[6] = l, m[7] = C, m[8] = i) : i = m[8], m[9] !== g ? (n = g && (0, r.jsx)("p", {
                    className: "line-clamp-3 mai:text-fgCtrlNeutralSecondaryRest",
                    children: g
                }), m[9] = g, m[10] = n) : n = m[10], m[11] !== i || m[12] !== n ? (o = (0, r.jsxs)("div", {
                    className: "flex flex-col gap-0.5 mai:grow",
                    children: [i, n]
                }), m[11] = i, m[12] = n, m[13] = o) : o = m[13];
                let k = h && h > 0 ? h : void 0;
                return m[14] !== j || m[15] !== S || m[16] !== f || m[17] !== v || m[18] !== w || m[19] !== b || m[20] !== k ? (d = (0, r.jsx)(N, {
                    className: "not-mai:mt-2",
                    isCompleted: f,
                    isInProgress: v,
                    points: k,
                    status: w,
                    statusIcon: b,
                    completedAmount: j,
                    completedMax: S
                }), m[14] = j, m[15] = S, m[16] = f, m[17] = v, m[18] = w, m[19] = b, m[20] = k, m[21] = d) : d = m[21], m[22] !== t || m[23] !== a || m[24] !== o || m[25] !== d ? (c = (0, r.jsxs)("div", {
                    className: t,
                    children: [a, o, d]
                }), m[22] = t, m[23] = a, m[24] = o, m[25] = d, m[26] = c) : c = m[26], c
            }

            function N(e) {
                let t, a, l, i, n, o, d, c, m, u = (0, s.c)(32),
                    {
                        className: g,
                        isCompleted: p,
                        isInProgress: f,
                        points: j,
                        startContent: N,
                        status: S,
                        statusIcon: k,
                        completedAmount: z,
                        completedMax: O
                    } = e,
                    A = void 0 !== z && void 0 !== O && O > 1,
                    B = p ? ? !1,
                    P = f ? ? !1,
                    R = z ? ? 0;
                u[0] !== B || u[1] !== P || u[2] !== R ? (t = {
                    isCompleted: B,
                    isInProgress: P,
                    completedAmount: R
                }, u[0] = B, u[1] = P, u[2] = R, u[3] = t) : t = u[3];
                let F = (0, y.U)(t),
                    I = A ? F : S,
                    M = A && "flex-wrap";
                return u[4] !== g || u[5] !== M ? (a = (0, x.tw)("flex w-full items-center gap-2", M, g), u[4] = g, u[5] = M, u[6] = a) : a = u[6], u[7] !== z || u[8] !== O || u[9] !== A || u[10] !== p || u[11] !== f || u[12] !== j ? (l = A ? (0, r.jsx)(v.G, {
                    isCompleted: p ? ? !1,
                    isInProgress: f ? ? !1,
                    completedCount: z,
                    completedMax: O
                }) : (j || p) && (0, r.jsx)(h.A, {
                    isCompleted: !!p,
                    points: j
                }), u[7] = z, u[8] = O, u[9] = A, u[10] = p, u[11] = f, u[12] = j, u[13] = l) : l = u[13], u[14] !== I ? (i = !!I && (0, r.jsx)("div", {
                    className: "line-clamp-2 pb-0.5 text-end text-caption1 wrap-anywhere mai:text-metadata mai:text-fgCtrlNeutralSecondaryRest",
                    children: I
                }), u[14] = I, u[15] = i) : i = u[15], u[16] !== k ? (n = "external" === k && (0, r.jsx)(C.default, {
                    className: "size-4 shrink-0 text-neutralFg2Link mai:text-fgCtrlNeutralSecondaryRest"
                }), u[16] = k, u[17] = n) : n = u[17], u[18] !== k ? (o = "info" === k && (0, r.jsx)(b.default, {
                    className: "size-4 shrink-0 text-neutralFg2Link mai:text-fgCtrlNeutralSecondaryRest"
                }), u[18] = k, u[19] = o) : o = u[19], u[20] !== k ? (d = "chevron" === k && (0, r.jsx)(w.default, {
                    className: "size-4 shrink-0 rotate-270 text-neutralFg2Link mai:text-fgCtrlNeutralSecondaryRest"
                }), u[20] = k, u[21] = d) : d = u[21], u[22] !== o || u[23] !== d || u[24] !== i || u[25] !== n ? (c = (0, r.jsxs)("div", {
                    className: "flex grow items-center justify-end gap-0.5",
                    children: [i, n, o, d]
                }), u[22] = o, u[23] = d, u[24] = i, u[25] = n, u[26] = c) : c = u[26], u[27] !== N || u[28] !== c || u[29] !== a || u[30] !== l ? (m = (0, r.jsxs)("div", {
                    className: a,
                    children: [l, N, c]
                }), u[27] = N, u[28] = c, u[29] = a, u[30] = l, u[31] = m) : m = u[31], m
            }
            let S = ["isUnlocked", "isLocked", "isInProgress", "isActivated", "isCompleted", "isLevelUp"];

            function k(e) {
                let t, a, v, h, w, b, C, y, N = (0, s.c)(44),
                    {
                        altText: k,
                        className: z,
                        description: O,
                        destinationType: A,
                        imageUrl: B,
                        darkModeImageUrl: P,
                        layout: R,
                        points: F,
                        isLocked: I,
                        isInProgress: M,
                        isNested: E,
                        title: L,
                        completedAmount: _,
                        completedMax: D
                    } = e,
                    H = void 0 === R ? "vertical" : R,
                    U = (0, i.c)("ActivityCard"),
                    T = (0, i.c)("General");
                N[0] !== e || N[1] !== U || N[2] !== T ? (t = function(e, t, a) {
                    let s = {};
                    for (let h of S) {
                        var i, n, x, v;
                        e[h] && (s = { ...s,
                            ...(i = e, n = h, x = t, v = a, "isActivated" === n ? {
                                footerStatus: x("Status.activated"),
                                overlay: (0, r.jsx)(o.A, {
                                    className: "bg-brandBg1 text-neutralFgOnBrand",
                                    children: (0, r.jsx)(m.default, {
                                        className: "size-4"
                                    })
                                })
                            } : "isCompleted" === n ? {
                                footerStatus: x("Status.completed"),
                                isCompleted: !0,
                                overlay: void 0
                            } : "isInProgress" === n ? (0, l.O9)(i.progressCurrent) && (0, l.O9)(i.progressMax) ? {
                                footerStatus: (0, r.jsxs)("div", {
                                    className: "flex items-center gap-1.5 text-body1",
                                    children: [(0, r.jsx)("p", {
                                        children: v.rich("progressFormatted", { ...f.V,
                                            completed: i.progressCurrent,
                                            total: i.progressMax
                                        })
                                    }), (0, r.jsx)(c.default, {
                                        thickness: .125,
                                        className: "size-5",
                                        value: i.progressCurrent,
                                        maxValue: i.progressMax,
                                        "aria-label": v("progressAlt", {
                                            title: i.title
                                        })
                                    })]
                                })
                            } : {
                                footerStatus: x("Status.inProgress")
                            } : "isLevelUp" === n ? {
                                overlay: (0, r.jsxs)(o.A, {
                                    className: "bg-white text-grey-14",
                                    children: [(0, r.jsx)(g.default, {
                                        className: "size-4 mai:hidden"
                                    }), (0, r.jsx)(d.default, {
                                        src: "https://bing.com/th?id=OMR.Medals.Gold-256.png&pid=Rewards",
                                        alt: "",
                                        width: 16,
                                        height: 16,
                                        className: "size-4 not-mai:hidden"
                                    })]
                                })
                            } : "isLocked" === n ? {
                                footerStatus: x(i.unlockCriteria ? `UnlockCriteria.${i.unlockCriteria}` : "Status.locked"),
                                isCompleted: !1,
                                overlay: (0, r.jsxs)(r.Fragment, {
                                    children: [(0, r.jsx)("div", {
                                        className: "absolute inset-0 bg-black opacity-40"
                                    }), (0, r.jsx)(o.A, {
                                        children: (0, r.jsx)(u.default, {
                                            className: "size-4"
                                        })
                                    })]
                                })
                            } : "isUnlocked" === n ? {
                                overlay: (0, r.jsx)(o.A, {
                                    className: "bg-brand-80 text-neutralFgOnBrand",
                                    children: (0, r.jsx)(p.default, {
                                        className: "size-4"
                                    })
                                })
                            } : void 0)
                        })
                    }
                    return s
                }(e, U, T), N[0] = e, N[1] = U, N[2] = T, N[3] = t) : t = N[3];
                let V = t;
                if ("horizontal" === e.layout) {
                    let e;
                    N[4] === Symbol.for("react.memo_cache_sentinel") ? (e = {
                        xs: {
                            w: 98,
                            h: 98
                        }
                    }, N[4] = e) : e = N[4], a = e
                } else if ("responsive" === e.layout && e.imageSizes && "string" != typeof e.imageSizes) {
                    let t, r;
                    N[5] === Symbol.for("react.memo_cache_sentinel") ? (t = {
                        w: 98,
                        h: 98
                    }, N[5] = t) : t = N[5], N[6] !== e.imageSizes ? (r = {
                        xs: t,
                        sm: 1,
                        ...e.imageSizes
                    }, N[6] = e.imageSizes, N[7] = r) : r = N[7], a = r
                } else a = e.imageSizes;
                let Z = k || L,
                    G = a,
                    q = V.overlay,
                    $ = ("horizontal" === H || "responsive" === H) && "flex-row gap-1 rounded-xl p-1",
                    J = "responsive" === H && "sm:flex-col sm:gap-1.5 sm:rounded-2xl sm:p-1.5";
                N[8] !== z || N[9] !== $ || N[10] !== J ? (v = (0, x.tw)($, J, z), N[8] = z, N[9] = $, N[10] = J, N[11] = v) : v = N[11];
                let K = ("horizontal" === H || "responsive" === H) && "aspect-square h-24.5 mai:h-26.5",
                    Q = "responsive" === H && "sm:aspect-video sm:h-auto mai:sm:h-auto",
                    W = I && "grayscale";
                N[12] !== W || N[13] !== K || N[14] !== Q ? (h = (0, x.tw)(K, Q, W), N[12] = W, N[13] = K, N[14] = Q, N[15] = h) : h = N[15];
                let X = ("horizontal" === H || "responsive" === H) && "mai:py-paddingCardBodyRewardsCompact",
                    Y = "responsive" === H && "mai:sm:p-paddingCardBodyRewards";
                N[16] !== X || N[17] !== Y ? (w = (0, x.tw)(X, Y), N[16] = X, N[17] = Y, N[18] = w) : w = N[18];
                let ee = ("horizontal" === H || "responsive" === H) && "not-mai:p-1",
                    et = "responsive" === H && "not-mai:sm:p-1.5";
                N[19] !== ee || N[20] !== et ? (b = (0, x.tw)(ee, et), N[19] = ee, N[20] = et, N[21] = b) : b = N[21];
                let ea = !!V.isCompleted;
                return N[22] !== _ || N[23] !== D || N[24] !== O || N[25] !== A || N[26] !== M || N[27] !== F || N[28] !== V.footerStatus || N[29] !== b || N[30] !== ea || N[31] !== L ? (C = (0, r.jsx)(j, {
                    className: b,
                    description: O,
                    isCompleted: ea,
                    isInProgress: M,
                    points: F,
                    status: V.footerStatus,
                    statusIcon: A,
                    title: L,
                    completedAmount: _,
                    completedMax: D
                }), N[22] = _, N[23] = D, N[24] = O, N[25] = A, N[26] = M, N[27] = F, N[28] = V.footerStatus, N[29] = b, N[30] = ea, N[31] = L, N[32] = C) : C = N[32], N[33] !== P || N[34] !== B || N[35] !== E || N[36] !== a || N[37] !== V.overlay || N[38] !== h || N[39] !== w || N[40] !== C || N[41] !== Z || N[42] !== v ? (y = (0, r.jsx)(n.Z, {
                    altText: Z,
                    imageUrl: B,
                    darkModeImageUrl: P,
                    imageSizes: G,
                    overlayNode: q,
                    className: v,
                    imageClassName: h,
                    contentClassName: w,
                    isNested: E,
                    isClickable: !0,
                    showEmptyImage: !0,
                    children: C
                }), N[33] = P, N[34] = B, N[35] = E, N[36] = a, N[37] = V.overlay, N[38] = h, N[39] = w, N[40] = C, N[41] = Z, N[42] = v, N[43] = y) : y = N[43], y
            }
        },
        82780: (e, t, a) => {
            a.r(t), a.d(t, {
                default: () => n
            });
            var r, s, l = a(59328);

            function i() {
                return (i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var r in a)({}).hasOwnProperty.call(a, r) && (e[r] = a[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            let n = function(e) {
                return l.createElement("svg", i({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none"
                }, e), r || (r = l.createElement("path", {
                    fill: "#242424",
                    d: "M6.186 11.414a.4.4 0 0 0 .565-.566 1.2 1.2 0 0 1 .84-2.048.4.4 0 0 0-.006-.8 2 2 0 0 0-1.399 3.414"
                })), s || (s = l.createElement("path", {
                    fill: "currentColor",
                    fillRule: "evenodd",
                    d: "m12.614 6.016-2.097 1.247a4 4 0 1 1-5.835 0L2.587 6.016A1.2 1.2 0 0 1 2 4.984V3.2A1.2 1.2 0 0 1 3.2 2H12a1.2 1.2 0 0 1 1.2 1.2v1.784a1.2 1.2 0 0 1-.586 1.032M3.2 2.8h3.568L4.18 6.034l-1.186-.706a.4.4 0 0 1-.195-.344V3.2c0-.22.18-.4.4-.4Zm6.768 0H7.792L4.875 6.447l.446.265a4 4 0 0 1 2.083-.707zm1.024 0H12c.22 0 .4.18.4.4v1.784a.4.4 0 0 1-.195.344L9.879 6.712a4 4 0 0 0-1.506-.637zM7.6 6.8a3.2 3.2 0 1 0 0 6.4 3.2 3.2 0 0 0 0-6.4",
                    clipRule: "evenodd"
                })))
            }
        },
        93906: (e, t, a) => {
            a.r(t), a.d(t, {
                default: () => i
            });
            var r, s = a(59328);

            function l() {
                return (l = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var a = arguments[t];
                        for (var r in a)({}).hasOwnProperty.call(a, r) && (e[r] = a[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            let i = function(e) {
                return s.createElement("svg", l({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none"
                }, e), r || (r = s.createElement("path", {
                    fill: "currentColor",
                    d: "M11 2.5a1 1 0 1 1 2 0 .5.5 0 0 0 1 0 2 2 0 1 0-4 0V4H4.5A2.5 2.5 0 0 0 2 6.5v5A2.5 2.5 0 0 0 4.5 14h7a2.5 2.5 0 0 0 2.5-2.5v-5A2.5 2.5 0 0 0 11.5 4H11zM8 10a1 1 0 1 1 0-2 1 1 0 0 1 0 2"
                })))
            }
        }
    }
]);
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3881], {
        13881: (e, t, r) => {
            r.r(t), r.d(t, {
                default: () => O
            });
            var a = r(20748),
                n = r(10812),
                l = r(84662),
                s = r(23454),
                i = r(59328),
                c = r(76645),
                d = r(40862),
                o = r(95168),
                u = r(77128),
                f = r(71389),
                m = r(28170),
                h = r(60440),
                p = r(14926),
                x = r(34813),
                g = r(96471),
                w = r(39690),
                v = r(75564);

            function j(e) {
                let t, r, s, i, c, d, o, f, m, h = (0, n.c)(24),
                    {
                        title: p,
                        description: j,
                        imageUrl: y,
                        ctaText: b,
                        ctaUrl: E
                    } = e,
                    S = (0, l.c)("General");
                return h[0] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, v.tw)("flex w-80 flex-col gap-2 rounded-md bg-neutralBg1 p-4 shadow-16", "mai:rounded-cornerFlyoutRest mai:bg-flyout mai:shadow-shadowFlyout mai:backdrop-blur-ctrlDialogBaseBgBlur"), h[0] = t) : t = h[0], h[1] !== y || h[2] !== p ? (r = y && (0, a.jsx)("div", {
                    className: "relative aspect-video overflow-hidden rounded-md mai:rounded-cornerCardNestedRewards",
                    children: (0, a.jsx)(x.default, {
                        src: y,
                        alt: p,
                        fill: !0,
                        sizes: {
                            xs: 320
                        }
                    })
                }), h[1] = y, h[2] = p, h[3] = r) : r = h[3], h[4] !== p ? (s = (0, a.jsx)(w.D, {
                    slot: "title",
                    className: "text-subtitle2 mai:text-itemHeader",
                    children: p
                }), h[4] = p, h[5] = s) : s = h[5], h[6] !== j ? (i = (0, a.jsx)("p", {
                    children: j
                }), h[6] = j, h[7] = i) : i = h[7], h[8] !== b || h[9] !== E || h[10] !== S ? (c = !!E && (0, a.jsx)(g.default, {
                    href: E,
                    shape: "circular",
                    appearance: "primary",
                    children: b || S("learnMore")
                }), h[8] = b, h[9] = E, h[10] = S, h[11] = c) : c = h[11], h[12] !== S ? (d = S("closeButton"), h[12] = S, h[13] = d) : d = h[13], h[14] !== d ? (o = (0, a.jsx)(u.default, {
                    shape: "circular",
                    slot: "close",
                    children: d
                }), h[14] = d, h[15] = o) : o = h[15], h[16] !== c || h[17] !== o ? (f = (0, a.jsxs)("div", {
                    className: "mt-4 flex justify-end gap-2",
                    children: [c, o]
                }), h[16] = c, h[17] = o, h[18] = f) : f = h[18], h[19] !== r || h[20] !== s || h[21] !== i || h[22] !== f ? (m = (0, a.jsxs)("div", {
                    className: t,
                    children: [r, s, i, f]
                }), h[19] = r, h[20] = s, h[21] = i, h[22] = f, h[23] = m) : m = h[23], m
            }
            var y = r(46516),
                b = r(32255),
                E = r(32530),
                S = r(26991),
                N = r(17244);

            function O(e) {
                var t;
                let r, l, d, u, f, m, h, x, g, w, j, y, b, N, O, A, _, k, I, R, B, F, T, M, L, z, D, G = (0, n.c)(57);
                G[0] !== e ? ({
                    title: O,
                    children: l,
                    action: r,
                    id: h,
                    href: m,
                    className: d,
                    instrument: g,
                    impression: x,
                    discovery: u,
                    featureEdu: f,
                    onExpandedChange: w,
                    isExpandable: y,
                    defaultExpanded: b,
                    persistState: N,
                    ...j
                } = e, G[0] = e, G[1] = r, G[2] = l, G[3] = d, G[4] = u, G[5] = f, G[6] = m, G[7] = h, G[8] = x, G[9] = g, G[10] = w, G[11] = j, G[12] = y, G[13] = b, G[14] = N, G[15] = O) : (r = G[1], l = G[2], d = G[3], u = G[4], f = G[5], m = G[6], h = G[7], x = G[8], g = G[9], w = G[10], j = G[11], y = G[12], b = G[13], N = G[14], O = G[15]);
                let J = void 0 === y || y,
                    H = void 0 === b || b,
                    P = void 0 !== N && N,
                    [V, q] = (0, i.useState)(H),
                    [K, U] = (t = `${h}_exp`, z = (0, i.useRef)(void 0), D = (0, i.useCallback)(e => {
                        if (!t) return () => {};
                        let r = r => {
                            r.key === t && e()
                        };
                        return window.addEventListener("storage", r), () => {
                            window.removeEventListener("storage", r)
                        }
                    }, [t]), [(0, i.useSyncExternalStore)(D, function() {
                        if (t) try {
                            let e = window.localStorage.getItem(t),
                                r = e ? JSON.parse(e) : void 0;
                            return z.current = r, r
                        } catch (e) {
                            return E.C.logError(e), z.current
                        }
                    }, () => void 0), (0, i.useCallback)(e => {
                        if (!t) return;
                        let r = "function" == typeof e ? e(z.current) : e;
                        try {
                            void 0 === r ? window.localStorage.removeItem(t) : window.localStorage.setItem(t, JSON.stringify(r))
                        } catch (e) {
                            E.C.logError(e)
                        } finally {
                            z.current = r, window.dispatchEvent(new StorageEvent("storage", {
                                key: t,
                                newValue: JSON.stringify(r)
                            }))
                        }
                    }, [t])]),
                    $ = P ? K : V,
                    Q = P ? U : q,
                    [W, X] = (0, i.useState)(!1);
                G[16] !== x || G[17] !== g ? (A = {
                    instrument: g,
                    impression: x
                }, G[16] = x, G[17] = g, G[18] = A) : A = G[18];
                let Y = (0, S.A)(A),
                    {
                        reportActivity: Z
                    } = (0, i.use)(c.H);
                G[19] !== u || G[20] !== $ || G[21] !== Z ? (_ = () => {
                    !async function() {
                        $ && u && !u.isCompleted && u.offerId && u.hash && await Z(u.hash, {
                            offerId: u.offerId
                        })
                    }()
                }, k = [$, u, Z], G[19] = u, G[20] = $, G[21] = Z, G[22] = _, G[23] = k) : (_ = G[22], k = G[23]), (0, i.useEffect)(_, k), G[24] !== g || G[25] !== w || G[26] !== Q ? (I = async function(e) {
                    Q(e), X(!0), w ? .(e), g ? .name && g.change && E.C.logPageAction(g.name, "Change", { ...g.data,
                        expanded: e
                    })
                }, G[24] = g, G[25] = w, G[26] = Q, G[27] = I) : I = G[27];
                let ee = I,
                    et = (0, s.useSearchParams)(),
                    [er, ea] = (0, i.useState)(!1);
                G[28] !== er || G[29] !== h || G[30] !== et || G[31] !== Q ? (R = () => {
                    let e = et.get("section");
                    if (e !== h || er) e !== h && er && ea(!1);
                    else {
                        let e = document.getElementById(h);
                        e && (ea(!0), Q(!0), e.scrollIntoView({
                            behavior: "smooth"
                        }))
                    }
                }, B = [et, h, Q, er], G[28] = er, G[29] = h, G[30] = et, G[31] = Q, G[32] = R, G[33] = B) : (R = G[32], B = G[33]), (0, i.useEffect)(R, B), G[34] !== d ? (F = (0, v.tw)("scroll-mt-28 xl:scroll-mt-19", d), G[34] = d, G[35] = F) : F = G[35];
                let en = $ ? ? H;
                return G[36] !== r || G[37] !== l || G[38] !== H || G[39] !== W || G[40] !== u || G[41] !== f || G[42] !== m || G[43] !== J || G[44] !== $ || G[45] !== O ? (T = e => (0, a.jsxs)(a.Fragment, {
                    children: [(0, a.jsx)(C, {
                        title: O,
                        action: (0, v.hd)(r, e),
                        href: m,
                        isExpandable: J,
                        isExpanded: $ ? ? H,
                        didManuallyToggle: W,
                        discovery: u,
                        featureEdu: f
                    }), (0, a.jsx)(o.kS, {
                        children: (0, a.jsx)(p.A, {
                            children: (0, v.hd)(l, e)
                        })
                    })]
                }), G[36] = r, G[37] = l, G[38] = H, G[39] = W, G[40] = u, G[41] = f, G[42] = m, G[43] = J, G[44] = $, G[45] = O, G[46] = T) : T = G[46], G[47] !== ee || G[48] !== j || G[49] !== en || G[50] !== T ? (M = (0, a.jsx)(o.EN, { ...j,
                    isExpanded: en,
                    onExpandedChange: ee,
                    children: T
                }), G[47] = ee, G[48] = j, G[49] = en, G[50] = T, G[51] = M) : M = G[51], G[52] !== h || G[53] !== Y || G[54] !== F || G[55] !== M ? (L = (0, a.jsx)("section", {
                    id: h,
                    ref: Y,
                    className: F,
                    children: M
                }), G[52] = h, G[53] = Y, G[54] = F, G[55] = M, G[56] = L) : L = G[56], L
            }

            function C(e) {
                let t, r, s, i, c, d, o, h, p, x = (0, n.c)(30),
                    {
                        title: g,
                        action: w,
                        href: j,
                        discovery: b,
                        featureEdu: E,
                        isExpanded: S,
                        isExpandable: N,
                        didManuallyToggle: O
                    } = e;
                (0, l.c)("General");
                let C = !S && "bg-rewardsBgAlpha1 mai:bg-bgCardOnSecondaryDefaultRest";
                return x[0] !== C ? (t = (0, v.tw)("-mx-3 flex flex-wrap items-center gap-2 rounded-xl p-3 mai:-mx-5 mai:rounded-cornerCardRewards mai:px-5", C), x[0] = C, x[1] = t) : t = x[1], x[2] !== j || x[3] !== g ? (r = j ? (0, a.jsx)(f.default, {
                    href: j,
                    appearance: "subtle",
                    children: g
                }) : g, x[2] = j, x[3] = g, x[4] = r) : r = x[4], x[5] !== r ? (s = (0, a.jsx)("h2", {
                    className: "truncate text-subtitle2Stronger not-mai:text-neutralFg2 lg:text-title3 mai:text-sectionHeader",
                    children: r
                }), x[5] = r, x[6] = s) : s = x[6], x[7] !== b ? (i = b && (0, a.jsx)(m.A, {
                    points: b.points,
                    isCompleted: b.isCompleted
                }), x[7] = b, x[8] = i) : i = x[8], x[9] !== O || x[10] !== b || x[11] !== E || x[12] !== S || x[13] !== g ? (c = E && (0, a.jsx)(A, {
                    featureEdu: E,
                    isExpanded: S,
                    didManuallyToggle: O,
                    isFirstImpression: !!b && !b.isCompleted,
                    title: g
                }), x[9] = O, x[10] = b, x[11] = E, x[12] = S, x[13] = g, x[14] = c) : c = x[14], x[15] !== s || x[16] !== i || x[17] !== c ? (d = (0, a.jsxs)("div", {
                    className: "flex max-w-full grow-9999 items-center gap-2",
                    children: [s, i, c]
                }), x[15] = s, x[16] = i, x[17] = c, x[18] = d) : d = x[18], x[19] !== N || x[20] !== S || x[21] !== g ? (o = N && (0, a.jsx)(u.default, {
                    appearance: "secondary",
                    className: "p-1.5",
                    shape: "circular",
                    slot: "trigger",
                    "aria-label": g,
                    iconOnly: !0,
                    children: (0, a.jsx)(y.default, {
                        className: (0, v.tw)("size-3.5 mai:size-5", S && "rotate-180")
                    })
                }), x[19] = N, x[20] = S, x[21] = g, x[22] = o) : o = x[22], x[23] !== w || x[24] !== o ? (h = (0, a.jsxs)("div", {
                    className: "flex grow items-center justify-between gap-2 wrap-anywhere",
                    children: [w, o]
                }), x[23] = w, x[24] = o, x[25] = h) : h = x[25], x[26] !== t || x[27] !== d || x[28] !== h ? (p = (0, a.jsxs)("div", {
                    className: t,
                    children: [d, h]
                }), x[26] = t, x[27] = d, x[28] = h, x[29] = p) : p = x[29], p
            }

            function A(e) {
                let t, r, s, c, o, f, m = (0, n.c)(15),
                    {
                        featureEdu: p,
                        isExpanded: x,
                        isFirstImpression: g,
                        didManuallyToggle: w,
                        title: v
                    } = e,
                    y = (0, l.c)("General"),
                    [E, S] = (0, i.useState)(!1),
                    [O, C] = (0, i.useState)(g);
                w && x && O && (S(!0), C(!1));
                let A = (0, N.A)("(max-width: 767px)");
                m[0] !== y || m[1] !== v ? (t = y("infoLabel", {
                    title: v
                }), m[0] = y, m[1] = v, m[2] = t) : t = m[2];
                let _ = t;
                m[3] === Symbol.for("react.memo_cache_sentinel") ? (r = (0, a.jsx)(b.default, {
                    className: "size-4 text-neutralFg2 mai:text-fgCtrlNeutralSecondaryRest"
                }), m[3] = r) : r = m[3], m[4] !== _ ? (s = (0, a.jsx)(u.default, {
                    appearance: "subtle",
                    className: "-ms-1 p-1",
                    shape: "circular",
                    "aria-label": _,
                    iconOnly: !0,
                    children: r
                }), m[4] = _, m[5] = s) : s = m[5];
                let k = A ? "top" : "right";
                return m[6] !== p ? (c = (0, a.jsx)(d.default, {
                    children: (0, a.jsx)(j, { ...p
                    })
                }), m[6] = p, m[7] = c) : c = m[7], m[8] !== k || m[9] !== c ? (o = (0, a.jsx)(h.default, {
                    offset: 16,
                    placement: k,
                    showArrow: !0,
                    children: c
                }), m[8] = k, m[9] = c, m[10] = o) : o = m[10], m[11] !== E || m[12] !== s || m[13] !== o ? (f = (0, a.jsxs)(d.DialogTrigger, {
                    isOpen: E,
                    onOpenChange: S,
                    children: [s, o]
                }), m[11] = E, m[12] = s, m[13] = o, m[14] = f) : f = m[14], f
            }
        },
        14926: (e, t, r) => {
            r.d(t, {
                A: () => l
            });
            var a = r(20748),
                n = r(10812);

            function l(e) {
                let t, r = (0, n.c)(2),
                    {
                        children: l
                    } = e;
                return r[0] !== l ? (t = (0, a.jsx)("div", {
                    className: "-mx-3 rounded-2xl not-mai:bg-rewardsBgAlpha1 not-mai:backdrop-blur-lg",
                    children: (0, a.jsx)("div", {
                        className: "mx-3 flex flex-col py-3",
                        children: l
                    })
                }), r[0] = l, r[1] = t) : t = r[1], t
            }
        },
        17244: (e, t, r) => {
            r.d(t, {
                A: () => l
            });
            var a = r(10812),
                n = r(59328);

            function l(e, t) {
                let r, l, i, c = (0, a.c)(7),
                    d = void 0 !== t && t;
                c[0] !== e ? (r = t => {
                    if (!e) return s;
                    let r = window.matchMedia(e);
                    return r.addEventListener("change", t), () => {
                        r.removeEventListener("change", t)
                    }
                }, c[0] = e, c[1] = r) : r = c[1];
                let o = r;
                return c[2] !== d || c[3] !== e ? (l = () => e ? window.matchMedia(e).matches : d, c[2] = d, c[3] = e, c[4] = l) : l = c[4], c[5] !== d ? (i = () => d, c[5] = d, c[6] = i) : i = c[6], (0, n.useSyncExternalStore)(o, l, i)
            }

            function s() {}
        },
        60440: (e, t, r) => {
            r.d(t, {
                default: () => f
            });
            var a = r(20748),
                n = r(10812),
                l = r(24819),
                s = r(59328),
                i = r(22995),
                c = r(69190),
                d = r(54149),
                o = r(52392),
                u = r(68041);

            function f(e) {
                let t, r, f, m, h, p = (0, n.c)(12);
                p[0] !== e ? ({
                    ref: r,
                    ...t
                } = e, p[0] = e, p[1] = t, p[2] = r) : (t = p[1], r = p[2]);
                let [x, g] = (0, i.JT)(t, r, c.n), w = (0, s.use)(d.RG), v = (0, o.T)(t), j = null == t.isOpen && null == t.defaultOpen && w ? w : v;
                return p[3] !== g || p[4] !== j.isOpen ? (f = () => {
                    if (j.isOpen && g.current) return (0, l.h)([g.current], {
                        shouldUseInert: !0
                    })
                }, m = [j.isOpen, g], p[3] = g, p[4] = j.isOpen, p[5] = f, p[6] = m) : (f = p[5], m = p[6]), (0, s.useEffect)(f, m), p[7] !== x || p[8] !== g || p[9] !== j.isOpen || p[10] !== j.setOpen ? (h = (0, a.jsx)(u.default, { ...x,
                    ref: g,
                    isOpen: j.isOpen,
                    onOpenChange: j.setOpen,
                    isNonModal: !0,
                    trigger: "SubmenuTrigger"
                }), p[7] = x, p[8] = g, p[9] = j.isOpen, p[10] = j.setOpen, p[11] = h) : h = p[11], h
            }
        },
        68041: (e, t, r) => {
            r.d(t, {
                PopoverRef: () => u,
                default: () => o
            });
            var a = r(20748),
                n = r(10812),
                l = r(59328),
                s = r(69190),
                i = r(22995),
                c = r(84429),
                d = r(75564);

            function o(e) {
                let t, r, l, i, o, u, f, m, h = (0, n.c)(16);
                h[0] !== e ? ({
                    showArrow: u,
                    offset: l,
                    ref: o,
                    isTooltip: r,
                    children: t,
                    ...i
                } = e, h[0] = e, h[1] = t, h[2] = r, h[3] = l, h[4] = i, h[5] = o, h[6] = u) : (t = h[1], r = h[2], l = h[3], i = h[4], o = h[5], u = h[6]);
                let p = l ? ? 8;
                return h[7] !== t || h[8] !== r || h[9] !== u ? (f = e => (0, a.jsxs)(a.Fragment, {
                    children: [u && (0, a.jsx)(c.A, {
                        placement: e.placement,
                        isTooltip: r
                    }), (0, d.hd)(t, e)]
                }), h[7] = t, h[8] = r, h[9] = u, h[10] = f) : f = h[10], h[11] !== i || h[12] !== o || h[13] !== p || h[14] !== f ? (m = (0, a.jsx)(s.A, { ...i,
                    ref: o,
                    offset: p,
                    children: f
                }), h[11] = i, h[12] = o, h[13] = p, h[14] = f, h[15] = m) : m = h[15], m
            }

            function u(e) {
                let t, r, c = (0, n.c)(4),
                    {
                        children: d,
                        className: o
                    } = e,
                    u = (0, l.useRef)(null);
                return c[0] === Symbol.for("react.memo_cache_sentinel") ? (t = [
                    [s.n, {
                        triggerRef: u
                    }]
                ], c[0] = t) : t = c[0], c[1] !== d || c[2] !== o ? (r = (0, a.jsx)(i.Kq, {
                    values: t,
                    children: (0, a.jsx)("div", {
                        ref: u,
                        className: o,
                        children: d
                    })
                }), c[1] = d, c[2] = o, c[3] = r) : r = c[3], r
            }
        }
    }
]);
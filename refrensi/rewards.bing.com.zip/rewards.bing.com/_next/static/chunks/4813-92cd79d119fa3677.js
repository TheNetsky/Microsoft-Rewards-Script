"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4813], {
        34813: (e, t, i) => {
            i.r(t), i.d(t, {
                default: () => x
            });
            var r = i(20748),
                n = i(10812),
                s = i(59328);
            let h = /^https?:\/\/((www\.|th\.)?bing\.com|tse[1-4]\.mm\.bing\.net)\/th\?(.*&)?id=.*$/,
                a = /^https?:\/\/rewards\.bing\.com\/rewardscdn\/images\/(.*)$/,
                d = [{
                    key: "xs",
                    minWidth: 320,
                    maxWidth: 479,
                    pagePadding: 24
                }, {
                    key: "sm",
                    minWidth: 480,
                    maxWidth: 639,
                    pagePadding: 24
                }, {
                    key: "md",
                    minWidth: 640,
                    maxWidth: 767,
                    pagePadding: 48
                }, {
                    key: "lg",
                    minWidth: 768,
                    maxWidth: 1023,
                    pagePadding: 48
                }, {
                    key: "xl",
                    minWidth: 1024,
                    maxWidth: 1365,
                    pagePadding: 48
                }, {
                    key: "2xl",
                    minWidth: 1366,
                    maxWidth: 1599,
                    pagePadding: 144
                }, {
                    key: "3xl",
                    minWidth: 1600,
                    maxWidth: 1600,
                    pagePadding: 144
                }],
                l = d[0],
                c = d[d.length - 1],
                o = c.minWidth - 2 * c.pagePadding,
                f = [48, 64, 72, 96, 128, 144, 192, 256, 384, 512, 640, 720, 840, 960, 1080, 1200, 1312, 1600, 1920, 2560, 3840];

            function u(e, {
                width: t,
                height: i,
                quality: r,
                UNSTABLE_asWebp: n
            }) {
                var s;
                if (s = e, !h.test(s)) return e;
                let a = new URL(e);
                return (t || i) && (t && a.searchParams.set("w", t.toString()), i && a.searchParams.set("h", i.toString()), a.searchParams.set("p", "0"), t && i && a.searchParams.set("c", "1")), a.searchParams.set("qlt", (r ? ? 100).toString()), a.searchParams.set("r", "0"), n && a.searchParams.set("oif", "webp"), a.href
            }

            function g(e) {
                let t = e.match(a);
                if (!t) return e;
                let [i, r] = t;
                return `https://bing.com/th?id=BMR.${encodeURIComponent(r)}&pid=Rewards`
            }

            function m(e) {
                return d.find(t => t.key === e)
            }

            function p(e) {
                return Math.round(100 * e) / 100
            }
            var w = i(75564);

            function x(e) {
                let t, i, a, d, x, y = (0, n.c)(22),
                    {
                        src: W,
                        srcSet: v,
                        onError: S,
                        className: b,
                        quality: $,
                        unoptimized: k,
                        fallbackSrc: j,
                        UNSTABLE_asWebp: z,
                        UNSTABLE_optimizeBlobImages: O,
                        decoding: R,
                        loading: C,
                        preload: E,
                        errorClassName: N,
                        ..._
                    } = e,
                    L = void 0 === R ? "async" : R,
                    U = void 0 === C ? "lazy" : C,
                    I = (0, s.useRef)(null),
                    [M, q] = (0, s.useState)(!1),
                    [B, F] = (0, s.useState)(!1),
                    [A, D] = (0, s.useState)(W);
                A !== W && (q(!1), D(W));
                let [G, H] = (0, s.useState)(j);
                G !== j && (F(!1), H(j)), y[0] !== j || y[1] !== M || y[2] !== S ? (t = e => {
                    M && j ? F(!0) : q(!0), S ? .(e)
                }, y[0] = j, y[1] = M, y[2] = S, y[3] = t) : t = y[3];
                let J = t;
                y[4] !== J || y[5] !== M ? (i = () => {
                    I.current ? .complete && I.current ? .naturalWidth === 0 && !M && J()
                }, a = [M, J], y[4] = J, y[5] = M, y[6] = i, y[7] = a) : (i = y[6], a = y[7]), (0, s.useEffect)(i, a);
                let K = M && j ? j : W,
                    Q = M && j ? void 0 : v,
                    T = M && (!j || B),
                    V = function({
                        src: e,
                        srcSet: t,
                        quality: i,
                        unoptimized: r,
                        UNSTABLE_asWebp: n,
                        UNSTABLE_optimizeBlobImages: s,
                        ...a
                    }) {
                        var d, w, x, P, y, W;
                        let v = a.fill ? void 0 : a.width,
                            S = a.fill ? void 0 : a.height,
                            b = function(e) {
                                if (!e) return;
                                if ("string" == typeof e) return e;
                                let {
                                    _ratioType: t,
                                    ...i
                                } = e, r = Object.entries({
                                    xs: 1,
                                    ...i
                                }).map(([e, t]) => ({
                                    breakpoint: e,
                                    minWidth: m(e).minWidth,
                                    size: t
                                })).sort((e, t) => t.minWidth - e.minWidth), n = r[0].breakpoint;
                                return r.map(({
                                    breakpoint: e,
                                    minWidth: i,
                                    size: r
                                }) => {
                                    let s = function(e, t, i, r = "content") {
                                        let {
                                            w: n
                                        } = "number" == typeof e ? {
                                            w: e
                                        } : e;
                                        if (n > 1) return `${n}px`;
                                        if ("viewport" === r) return `${p(100*n)}vw`;
                                        if (t === c.key) return `${p(o*n)}px`;
                                        let s = m(t),
                                            h = `calc(${p(100*n)}vw - ${p(2*s.pagePadding*n)}px)`;
                                        return i ? `min(${h}, ${p(o*n)}px)` : h
                                    }(r, e, e === n, t);
                                    return e === l.key ? s : `(min-width: ${i}px) ${s}`
                                }).join(", ")
                            }(!!a.fill && a.sizes),
                            $ = {
                                quality: i,
                                UNSTABLE_asWebp: n
                            };
                        if (t) {
                            return {
                                src: u(e, $),
                                srcSet: (d = t, w = $, d.split(",").map(e => {
                                    let [t, i] = e.trim().split(" ");
                                    return `${u(t,w)} ${i}`
                                }).join(", ")),
                                sizes: b,
                                width: v,
                                height: S
                            }
                        }
                        if (function(e, t, i) {
                                var r;
                                if (t) return !0;
                                let n = i ? g(e) : e;
                                if (r = n, !h.test(r)) return !0;
                                if (void 0 === t) {
                                    let e = new URL(n).searchParams.get("id");
                                    if (!["jpg", "jpeg", "png", "webp"].includes(e ? .split(".").pop() ? .toLowerCase() ? ? "")) return !0
                                }
                                return !1
                            }(e, r, s) || !a.fill && !a.width) return {
                            src: u(e, $),
                            width: v,
                            height: S
                        };
                        let k = s ? g(e) : e;
                        if (!a.fill) {
                            return {
                                src: u(k, {
                                    width: a.width,
                                    height: a.height,
                                    ...$
                                }),
                                srcSet: (x = k, P = a.width, y = a.height, W = $, `${u(x,{width:P,height:y,...W})} 1x, ${u(x,{width:2*P,height:2*y,...W})} 2x`),
                                sizes: b,
                                width: v,
                                height: S
                            }
                        }
                        let j = function(e, t, i) {
                            if (!t) return;
                            let r = [],
                                n = !1,
                                s = 1 / 0,
                                h = -1 / 0;
                            if ("object" == typeof t) {
                                n = !0;
                                let {
                                    _ratioType: e,
                                    ...i
                                } = t;
                                for (let [e, t] of Object.entries({
                                        xs: 1,
                                        ...i
                                    })) {
                                    let i = m(e),
                                        {
                                            w: n,
                                            h: a
                                        } = "number" == typeof t ? {
                                            w: t
                                        } : t;
                                    if (n > 1) r.push({
                                        w: n,
                                        h: a
                                    }), r.push({
                                        w: 2 * n,
                                        h: a && 2 * a
                                    });
                                    else {
                                        let e = i.minWidth * n;
                                        e < s && (s = e);
                                        let t = i.maxWidth * n;
                                        t > h && (h = t)
                                    }
                                }
                            }
                            let a = [...f];
                            if (n) {
                                let e = (a = a.filter(e => e >= s)).findIndex(e => e >= h);
                                e > 0 && (a = a.slice(0, e + 1))
                            }
                            let d = {};
                            for (let e of a) d[e] = {
                                w: e
                            };
                            for (let e of r) d[e.w] = e;
                            let l = Object.values(d).sort((e, t) => e.w - t.w);
                            if (l.length) return l.map(t => `${u(e,{width:t.w,height:t.h,...i})} ${t.w}w`).join(", ")
                        }(k, a.sizes, $);
                        return {
                            src: u(k, $),
                            srcSet: j,
                            sizes: j && b,
                            width: v,
                            height: S
                        }
                    }({
                        src: K,
                        srcSet: Q,
                        quality: $,
                        unoptimized: k,
                        UNSTABLE_asWebp: z,
                        UNSTABLE_optimizeBlobImages: O,
                        ..._
                    }),
                    {
                        fill: X,
                        width: Y,
                        height: Z,
                        sizes: ee,
                        ...et
                    } = _,
                    ei = void 0 !== E && E && (0, r.jsx)(P, {
                        crossOrigin: _.crossOrigin,
                        referrerPolicy: _.referrerPolicy,
                        fetchPriority: _.fetchPriority,
                        sizes: V.sizes,
                        srcSet: V.srcSet,
                        src: V.src
                    }),
                    er = (0, w.tw)("text-transparent", _.fill && "absolute inset-0 h-full w-full object-cover", b, T && (void 0 === N ? "invisible" : N));
                return y[8] !== L || y[9] !== et || y[10] !== J || y[11] !== U || y[12] !== V.height || y[13] !== V.sizes || y[14] !== V.src || y[15] !== V.srcSet || y[16] !== V.width || y[17] !== er ? (d = (0, r.jsx)("img", { ...et,
                    ref: I,
                    decoding: L,
                    loading: U,
                    onError: J,
                    className: er,
                    width: V.width,
                    height: V.height,
                    sizes: V.sizes,
                    srcSet: V.srcSet,
                    src: V.src
                }), y[8] = L, y[9] = et, y[10] = J, y[11] = U, y[12] = V.height, y[13] = V.sizes, y[14] = V.src, y[15] = V.srcSet, y[16] = V.width, y[17] = er, y[18] = d) : d = y[18], y[19] !== d || y[20] !== ei ? (x = (0, r.jsxs)(r.Fragment, {
                    children: [ei, d]
                }), y[19] = d, y[20] = ei, y[21] = x) : x = y[21], x
            }

            function P(e) {
                let t, i = (0, n.c)(7),
                    {
                        src: s,
                        srcSet: h,
                        sizes: a,
                        crossOrigin: d,
                        referrerPolicy: l,
                        fetchPriority: c
                    } = e;
                if (!h && !s) return null;
                let o = h ? void 0 : s;
                return i[0] !== d || i[1] !== c || i[2] !== l || i[3] !== a || i[4] !== h || i[5] !== o ? (t = (0, r.jsx)("link", {
                    rel: "preload",
                    as: "image",
                    href: o,
                    imageSrcSet: h,
                    imageSizes: a,
                    crossOrigin: d,
                    referrerPolicy: l,
                    fetchPriority: c
                }), i[0] = d, i[1] = c, i[2] = l, i[3] = a, i[4] = h, i[5] = o, i[6] = t) : t = i[6], t
            }
        }
    }
]);
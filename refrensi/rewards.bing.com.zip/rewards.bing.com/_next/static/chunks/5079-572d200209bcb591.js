"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5079], {
        23347: (e, t, l) => {
            l.d(t, {
                Tooltip: () => o,
                TooltipTrigger: () => i.k$,
                TooltipView: () => d
            });
            var a = l(20748),
                r = l(10812),
                i = l(36985),
                n = l(84429),
                s = l(75564);

            function o(e) {
                let t, l, o, c, u, p, h, x = (0, r.c)(14);
                x[0] !== e ? ({
                    className: l,
                    offset: o,
                    children: t,
                    showArrow: u,
                    ...c
                } = e, x[0] = e, x[1] = t, x[2] = l, x[3] = o, x[4] = c, x[5] = u) : (t = x[1], l = x[2], o = x[3], c = x[4], u = x[5]);
                let m = void 0 === u || u,
                    f = o ? ? 8;
                return x[6] !== t || x[7] !== l || x[8] !== m ? (p = e => (0, a.jsxs)(a.Fragment, {
                    children: [m && (0, a.jsx)(n.A, {
                        placement: e.placement,
                        isTooltip: !0
                    }), (0, a.jsx)(d, {
                        className: (0, s.hd)(l, { ...e,
                            defaultClassName: void 0
                        }),
                        children: (0, s.hd)(t, e)
                    })]
                }), x[6] = t, x[7] = l, x[8] = m, x[9] = p) : p = x[9], x[10] !== c || x[11] !== f || x[12] !== p ? (h = (0, a.jsx)(i.m_, { ...c,
                    offset: f,
                    children: p
                }), x[10] = c, x[11] = f, x[12] = p, x[13] = h) : h = x[13], h
            }

            function d(e) {
                let t, l, i = (0, r.c)(5),
                    {
                        children: n,
                        className: o
                    } = e;
                return i[0] !== o ? (t = (0, s.tw)("max-w-60 px-3 py-1.5 text-caption1", "rounded-md bg-neutralBg1 shadow-8", "mai:rounded-[8px] mai:bg-ctrlTooltipBg mai:shadow-ctrlTooltipShadow", "mai:text-metadata mai:text-ctrlTooltipFg", "mai:border mai:border-ctrlTooltipStroke mai:py-2.5", o), i[0] = o, i[1] = t) : t = i[1], i[2] !== n || i[3] !== t ? (l = (0, a.jsx)("div", {
                    className: t,
                    children: n
                }), i[2] = n, i[3] = t, i[4] = l) : l = i[4], l
            }
        },
        33114: (e, t, l) => {
            l.d(t, {
                V: () => r
            });
            var a = l(20748);
            let r = {
                "brand-color": e => (0, a.jsx)("span", {
                    className: "not-mai:text-brandFg1",
                    children: e
                }),
                li: e => (0, a.jsx)("li", {
                    children: e
                }),
                muted: e => (0, a.jsx)("span", {
                    className: "text-neutralFg3 mai:text-fgCtrlNeutralSecondaryRest",
                    children: e
                }),
                ol: e => (0, a.jsx)("ol", {
                    className: "list-decimal ps-5",
                    children: e
                }),
                p: e => (0, a.jsx)("p", {
                    children: e
                }),
                semibold: e => (0, a.jsx)("span", {
                    className: "font-semibold",
                    children: e
                }),
                sup: e => (0, a.jsx)("sup", {
                    children: e
                }),
                ul: e => (0, a.jsx)("ul", {
                    className: "list-disc ps-5",
                    children: e
                }),
                br: () => (0, a.jsx)("br", {})
            };
            Object.fromEntries(["brand-color", "li", "muted", "ol", "p", "semibold", "sup", "ul", "br"].map(e => [e, e => e]))
        },
        37982: (e, t, l) => {
            l.d(t, {
                Focusable: () => s
            });
            var a = l(20748),
                r = l(10812),
                i = l(59328),
                n = l(94828);

            function s(e) {
                let t, l, s, o, d = (0, r.c)(9);
                d[0] !== e ? ({
                    children: t,
                    className: l,
                    ...s
                } = e, d[0] = e, d[1] = t, d[2] = l, d[3] = s) : (t = d[1], l = d[2], s = d[3]);
                let c = (0, i.useRef)(null),
                    {
                        focusableProps: u
                    } = (0, n.Wc)(s, c),
                    p = u.tabIndex ? ? 0;
                return d[4] !== t || d[5] !== l || d[6] !== u || d[7] !== p ? (o = (0, a.jsx)("div", {
                    ref: c,
                    ...u,
                    className: l,
                    tabIndex: p,
                    children: t
                }), d[4] = t, d[5] = l, d[6] = u, d[7] = p, d[8] = o) : o = d[8], o
            }
        },
        52795: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => n
            });
            var a, r = l(59328);

            function i() {
                return (i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var a in l)({}).hasOwnProperty.call(l, a) && (e[a] = l[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            let n = function(e) {
                return r.createElement("svg", i({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 10 10"
                }, e), a || (a = r.createElement("path", {
                    fill: "currentColor",
                    d: "M4.66.343c.09-.352.59-.352.68 0l.552 2.186a.35.35 0 0 0 .484.233l2.054-.931c.33-.15.643.241.423.53L7.488 4.158a.35.35 0 0 0 .12.523l2.008 1.025c.324.166.212.654-.151.662L7.21 6.42a.35.35 0 0 0-.335.42l.451 2.21c.073.356-.378.573-.611.294l-1.446-1.73a.35.35 0 0 0-.538 0l-1.446 1.73c-.233.279-.684.062-.611-.294l.45-2.21a.35.35 0 0 0-.334-.42L.535 6.367C.172 6.36.06 5.871.385 5.705L2.392 4.68a.35.35 0 0 0 .12-.523L1.146 2.362c-.22-.29.093-.681.423-.531l2.054.931a.35.35 0 0 0 .484-.233z"
                })))
            }
        },
        84429: (e, t, l) => {
            l.d(t, {
                A: () => s
            });
            var a = l(20748),
                r = l(10812),
                i = l(81017),
                n = l(75564);

            function s(e) {
                let t, l, s, o, d, c, u, p = (0, r.c)(16);
                p[0] !== e ? ({
                    placement: s,
                    isTooltip: l,
                    className: t,
                    ...o
                } = e, p[0] = e, p[1] = t, p[2] = l, p[3] = s, p[4] = o) : (t = p[1], l = p[2], s = p[3], o = p[4]);
                let h = l && "mai:bg-ctrlTooltipBg mai:shadow-ctrlTooltipShadow",
                    x = "right" === s && "-rotate-90",
                    m = "top" === s && "rotate-180",
                    f = "left" === s && "rotate-90";
                return p[5] !== t || p[6] !== h || p[7] !== x || p[8] !== m || p[9] !== f ? (d = (0, n.tw)("size-4 bg-neutralBg1 mai:bg-flyout", "[clip-path:polygon(50%_50%,0%_100%,100%_100%)]", h, x, m, f, t), p[5] = t, p[6] = h, p[7] = x, p[8] = m, p[9] = f, p[10] = d) : d = p[10], p[11] !== d ? (c = (0, a.jsx)("div", {
                    className: d
                }), p[11] = d, p[12] = c) : c = p[12], p[13] !== o || p[14] !== c ? (u = (0, a.jsx)(i.k, { ...o,
                    className: "z-1",
                    children: c
                }), p[13] = o, p[14] = c, p[15] = u) : u = p[15], u
            }
        },
        88582: (e, t, l) => {
            l.r(t), l.d(t, {
                default: () => n
            });
            var a, r = l(59328);

            function i() {
                return (i = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var l = arguments[t];
                        for (var a in l)({}).hasOwnProperty.call(l, a) && (e[a] = l[a])
                    }
                    return e
                }).apply(null, arguments)
            }
            let n = function(e) {
                return r.createElement("svg", i({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 52 52"
                }, e), a || (a = r.createElement("path", {
                    fill: "currentColor",
                    d: "m13.34 20.2-.006.004-.009.006-.022.018-.066.051a10 10 0 0 0-.86.805 13 13 0 0 0-1.814 2.452c-1.261 2.2-2.321 5.477-1.726 9.861.588 4.326 2.405 7.943 5.479 10.465 3.063 2.513 7.21 3.805 12.226 3.805 5.173 0 9.3-1.939 12.034-5.266 2.709-3.296 3.917-7.79 3.628-12.705-.277-4.714-2.845-8.29-5.113-11.45l-.646-.904c-2.474-3.492-4.428-6.711-3.954-11.213a1.625 1.625 0 0 0-1.616-1.796c-.827 0-1.774.256-2.691.642-.945.397-1.97.978-2.974 1.735-2.004 1.511-4.007 3.789-5.076 6.835-1.067 3.039-.526 5.935.255 8.042.513 1.383-.044 2.751-.881 3.149a1.53 1.53 0 0 1-2.01-.67l-1.748-3.321a1.625 1.625 0 0 0-2.41-.545"
                })))
            }
        },
        95168: (e, t, l) => {
            l.d(t, {
                EN: () => y,
                kS: () => w
            });
            var a = l(83814),
                r = l(22995),
                i = l(16785),
                n = l(59328),
                s = l(51164),
                o = l(7815),
                d = l(20118),
                c = l(71043),
                u = l(3298),
                p = l(46116),
                h = l(64128),
                x = l(39298),
                m = l(68552);
            let f = (0, n.createContext)(null),
                g = (0, n.createContext)(null),
                b = (0, n.createContext)(null),
                v = (0, n.createContext)(null),
                y = (0, n.forwardRef)(function(e, t) {
                    [e, t] = (0, r.JT)(e, t, g);
                    let l = (0, n.useContext)(f),
                        {
                            id: m,
                            ...y
                        } = e,
                        w = (0, s.Bi)();
                    m || (m = w);
                    let E = l ? l.expandedKeys.has(m) : e.isExpanded,
                        P = function(e) {
                            let [t, l] = (0, p.P)(e.isExpanded, e.defaultExpanded || !1, e.onExpandedChange), a = (0, n.useCallback)(() => {
                                l(!0)
                            }, [l]), r = (0, n.useCallback)(() => {
                                l(!1)
                            }, [l]), i = (0, n.useCallback)(() => {
                                l(!t)
                            }, [l, t]);
                            return {
                                isExpanded: t,
                                setExpanded: l,
                                expand: a,
                                collapse: r,
                                toggle: i
                            }
                        }({ ...e,
                            isExpanded: E,
                            onExpandedChange(t) {
                                var a;
                                l && l.toggleKey(m), null == (a = e.onExpandedChange) || a.call(e, t)
                            }
                        }),
                        C = n.useRef(null),
                        j = e.isDisabled || (null == l ? void 0 : l.isDisabled) || !1,
                        {
                            buttonProps: N,
                            panelProps: k
                        } = function(e, t, l) {
                            let {
                                isDisabled: a
                            } = e, r = (0, s.Bi)(), u = (0, s.Bi)(), p = (0, c.wR)(), h = (0, n.useRef)(null), x = (0, n.useCallback)(() => {
                                h.current = requestAnimationFrame(() => {
                                    l.current && l.current.setAttribute("hidden", "until-found")
                                }), (0, i.flushSync)(() => {
                                    t.toggle()
                                })
                            }, [l, t]);
                            (0, o._)(l, "beforematch", x);
                            let m = (0, n.useRef)(null);
                            return (0, d.N)(() => {
                                if (h.current && cancelAnimationFrame(h.current), l.current && !p) {
                                    let e = l.current;
                                    null == m.current || "function" != typeof e.getAnimations ? t.isExpanded ? (e.removeAttribute("hidden"), e.style.setProperty("--disclosure-panel-width", "auto"), e.style.setProperty("--disclosure-panel-height", "auto")) : (e.setAttribute("hidden", "until-found"), e.style.setProperty("--disclosure-panel-width", "0px"), e.style.setProperty("--disclosure-panel-height", "0px")) : t.isExpanded !== m.current && (t.isExpanded ? (e.removeAttribute("hidden"), e.style.setProperty("--disclosure-panel-width", e.scrollWidth + "px"), e.style.setProperty("--disclosure-panel-height", e.scrollHeight + "px"), Promise.all(e.getAnimations().map(e => e.finished)).then(() => {
                                        e.style.setProperty("--disclosure-panel-width", "auto"), e.style.setProperty("--disclosure-panel-height", "auto")
                                    }).catch(() => {})) : (e.style.setProperty("--disclosure-panel-width", e.scrollWidth + "px"), e.style.setProperty("--disclosure-panel-height", e.scrollHeight + "px"), window.getComputedStyle(e).height, e.style.setProperty("--disclosure-panel-width", "0px"), e.style.setProperty("--disclosure-panel-height", "0px"), Promise.all(e.getAnimations().map(e => e.finished)).then(() => e.setAttribute("hidden", "until-found")).catch(() => {}))), m.current = t.isExpanded
                                }
                            }, [a, l, t.isExpanded, p]), (0, n.useEffect)(() => () => {
                                h.current && cancelAnimationFrame(h.current)
                            }, []), {
                                buttonProps: {
                                    id: r,
                                    "aria-expanded": t.isExpanded,
                                    "aria-controls": u,
                                    onPress: e => {
                                        a || "keyboard" === e.pointerType || t.toggle()
                                    },
                                    isDisabled: a,
                                    onPressStart(e) {
                                        "keyboard" !== e.pointerType || a || t.toggle()
                                    }
                                },
                                panelProps: {
                                    id: u,
                                    role: "group",
                                    "aria-labelledby": r,
                                    "aria-hidden": !t.isExpanded,
                                    hidden: p ? !t.isExpanded : void 0
                                }
                            }
                        }({ ...e,
                            isExpanded: E,
                            isDisabled: j
                        }, P, C),
                        {
                            isFocusVisible: T,
                            focusProps: A
                        } = (0, u.o)({
                            within: !0
                        }),
                        F = (0, r.Sl)({ ...e,
                            id: void 0,
                            defaultClassName: "react-aria-Disclosure",
                            values: {
                                isExpanded: P.isExpanded,
                                isDisabled: j,
                                isFocusVisibleWithin: T,
                                state: P
                            }
                        }),
                        R = (0, h.$)(y, {
                            global: !0
                        });
                    return n.createElement(r.Kq, {
                        values: [
                            [a.k, {
                                slots: {
                                    [r.P_]: {},
                                    trigger: N
                                }
                            }],
                            [v, {
                                panelProps: k,
                                panelRef: C
                            }],
                            [b, P]
                        ]
                    }, n.createElement(r.tT.div, { ...(0, x.v)(R, F, A),
                        ref: t,
                        "data-expanded": P.isExpanded || void 0,
                        "data-disabled": j || void 0,
                        "data-focus-visible-within": T || void 0
                    }, F.children))
                }),
                w = (0, n.forwardRef)(function(e, t) {
                    let {
                        role: l = "group"
                    } = e, {
                        panelProps: i,
                        panelRef: s
                    } = (0, n.useContext)(v), {
                        isFocusVisible: o,
                        focusProps: d
                    } = (0, u.o)({
                        within: !0
                    }), c = (0, r.Sl)({ ...e,
                        defaultClassName: "react-aria-DisclosurePanel",
                        values: {
                            isFocusVisibleWithin: o
                        }
                    }), p = (0, h.$)(e, {
                        global: !0,
                        labelable: !0
                    });
                    return n.createElement(r.tT.div, { ...(0, x.v)(p, c, i, d),
                        ref: (0, m.P)(t, s),
                        role: l,
                        "data-focus-visible-within": o || void 0
                    }, n.createElement(r.Kq, {
                        values: [
                            [a.k, null]
                        ]
                    }, e.children))
                })
        }
    }
]);
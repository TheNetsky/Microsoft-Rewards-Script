"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4096], {
        54096: (t, e, i) => {
            i.r(e), i.d(e, {
                default: () => r
            });
            let r = {
                init(t) {
                    ! function(t) {
                        try {
                            var e, i, r, n, c;
                            e = window, i = document, r = "clarity", i.getElementById("clarity-script") || (e[r] = e[r] || function() {
                                (e[r].q = e[r].q || []).push(arguments)
                            }, (n = i.createElement("script")).async = 1, n.src = "https://www.clarity.ms/tag/" + t + "?ref=npm", n.id = "clarity-script", (c = i.getElementsByTagName("script")[0]).parentNode.insertBefore(n, c))
                        } catch (t) {
                            return
                        }
                    }(t, "clarity-script")
                },
                setTag(t, e) {
                    window.clarity("set", t, e)
                },
                identify(t, e, i, r) {
                    window.clarity("identify", t, e, i, r)
                },
                consent(t = !0) {
                    window.clarity("consent", t)
                },
                upgrade(t) {
                    window.clarity("upgrade", t)
                },
                event(t) {
                    window.clarity("event", t)
                }
            }
        }
    }
]);
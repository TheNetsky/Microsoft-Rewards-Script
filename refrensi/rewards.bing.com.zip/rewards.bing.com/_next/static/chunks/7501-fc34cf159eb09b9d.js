(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
            [7501], {
                8962: (e, t, n) => {
                    "use strict";
                    n.d(t, {
                        default: () => o
                    });
                    var r = n(92837),
                        i = n(20748);

                    function o({
                        locale: e,
                        ...t
                    }) {
                        if (!e) throw Error(void 0);
                        return (0, i.jsx)(r.Dk, {
                            locale: e,
                            ...t
                        })
                    }
                },
                13329: (e, t, n) => {
                    "use strict";
                    Object.defineProperty(t, "__esModule", {
                        value: !0
                    }), Object.defineProperty(t, "useReportWebVitals", {
                        enumerable: !0,
                        get: function() {
                            return o
                        }
                    });
                    let r = n(59328),
                        i = n(57880);

                    function o(e) {
                        (0, r.useEffect)(() => {
                            (0, i.onCLS)(e), (0, i.onFID)(e), (0, i.onLCP)(e), (0, i.onINP)(e), (0, i.onFCP)(e), (0, i.onTTFB)(e)
                        }, [e])
                    }("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                        value: !0
                    }), Object.assign(t.default, t), e.exports = t.default)
                },
                18828: (e, t, n) => {
                    "use strict";
                    n.d(t, {
                        Fe: () => c,
                        PJ: () => h,
                        _h: () => f,
                        pg: () => s,
                        rd: () => a
                    });
                    var r = n(93647),
                        i = n(45205),
                        o = n(59328);
                    let u = (0, o.createContext)({
                        isNative: !0,
                        open: function(e, t) {
                            d(e, e => c(e, t))
                        },
                        useHref: e => e
                    });

                    function s(e) {
                        let {
                            children: t,
                            navigate: n,
                            useHref: r
                        } = e, i = (0, o.useMemo)(() => ({
                            isNative: !1,
                            open: (e, t, r, i) => {
                                d(e, e => {
                                    l(e, t) ? n(r, i) : c(e, t)
                                })
                            },
                            useHref: r || (e => e)
                        }), [n, r]);
                        return o.createElement(u.Provider, {
                            value: i
                        }, t)
                    }

                    function a() {
                        return (0, o.useContext)(u)
                    }

                    function l(e, t) {
                        let n = e.getAttribute("target");
                        return (!n || "_self" === n) && e.origin === location.origin && !e.hasAttribute("download") && !t.metaKey && !t.ctrlKey && !t.altKey && !t.shiftKey
                    }

                    function c(e, t, n = !0) {
                        var o, u;
                        let {
                            metaKey: s,
                            ctrlKey: a,
                            altKey: l,
                            shiftKey: d
                        } = t;
                        (0, i.gm)() && (null == (u = window.event) || null == (o = u.type) ? void 0 : o.startsWith("key")) && "_blank" === e.target && ((0, i.cX)() ? s = !0 : a = !0);
                        let f = (0, i.Tc)() && (0, i.cX)() && !(0, i.bh)() && 1 ? new KeyboardEvent("keydown", {
                            keyIdentifier: "Enter",
                            metaKey: s,
                            ctrlKey: a,
                            altKey: l,
                            shiftKey: d
                        }) : new MouseEvent("click", {
                            metaKey: s,
                            ctrlKey: a,
                            altKey: l,
                            shiftKey: d,
                            detail: 1,
                            bubbles: !0,
                            cancelable: !0
                        });
                        c.isOpening = n, (0, r.e)(e), e.dispatchEvent(f), c.isOpening = !1
                    }

                    function d(e, t) {
                        if (e instanceof HTMLAnchorElement) t(e);
                        else if (e.hasAttribute("data-href")) {
                            let n = document.createElement("a");
                            n.href = e.getAttribute("data-href"), e.hasAttribute("data-target") && (n.target = e.getAttribute("data-target")), e.hasAttribute("data-rel") && (n.rel = e.getAttribute("data-rel")), e.hasAttribute("data-download") && (n.download = e.getAttribute("data-download")), e.hasAttribute("data-ping") && (n.ping = e.getAttribute("data-ping")), e.hasAttribute("data-referrer-policy") && (n.referrerPolicy = e.getAttribute("data-referrer-policy")), e.appendChild(n), t(n), e.removeChild(n)
                        }
                    }

                    function f(e) {
                        var t;
                        let n = a().useHref(null != (t = null == e ? void 0 : e.href) ? t : "");
                        return {
                            href: (null == e ? void 0 : e.href) ? n : void 0,
                            target: null == e ? void 0 : e.target,
                            rel: null == e ? void 0 : e.rel,
                            download: null == e ? void 0 : e.download,
                            ping: null == e ? void 0 : e.ping,
                            referrerPolicy: null == e ? void 0 : e.referrerPolicy
                        }
                    }

                    function h(e, t, n, r) {
                        !t.isNative && e.currentTarget instanceof HTMLAnchorElement && e.currentTarget.href && !e.isDefaultPrevented() && l(e.currentTarget, e) && n && (e.preventDefault(), t.open(e.currentTarget, e, n, r))
                    }
                    c.isOpening = !1
                },
                23454: (e, t, n) => {
                    "use strict";
                    var r = n(80178);
                    n.o(r, "usePathname") && n.d(t, {
                        usePathname: function() {
                            return r.usePathname
                        }
                    }), n.o(r, "useRouter") && n.d(t, {
                        useRouter: function() {
                            return r.useRouter
                        }
                    }), n.o(r, "useSearchParams") && n.d(t, {
                        useSearchParams: function() {
                            return r.useSearchParams
                        }
                    })
                },
                25560: (e, t, n) => {
                    "use strict";
                    Object.defineProperty(t, "__esModule", {
                        value: !0
                    });
                    var r = {
                        default: function() {
                            return b
                        },
                        handleClientScriptLoad: function() {
                            return v
                        },
                        initScriptLoader: function() {
                            return g
                        }
                    };
                    for (var i in r) Object.defineProperty(t, i, {
                        enumerable: !0,
                        get: r[i]
                    });
                    let o = n(31710),
                        u = n(16631),
                        s = n(20748),
                        a = o._(n(16785)),
                        l = u._(n(59328)),
                        c = n(98347),
                        d = n(66255),
                        f = n(58571),
                        h = new Map,
                        p = new Set,
                        m = e => {
                            let {
                                src: t,
                                id: n,
                                onLoad: r = () => {},
                                onReady: i = null,
                                dangerouslySetInnerHTML: o,
                                children: u = "",
                                strategy: s = "afterInteractive",
                                onError: l,
                                stylesheets: c
                            } = e, f = n || t;
                            if (f && p.has(f)) return;
                            if (h.has(t)) {
                                p.add(f), h.get(t).then(r, l);
                                return
                            }
                            let m = () => {
                                    i && i(), p.add(f)
                                },
                                v = document.createElement("script"),
                                g = new Promise((e, t) => {
                                    v.addEventListener("load", function(t) {
                                        e(), r && r.call(this, t), m()
                                    }), v.addEventListener("error", function(e) {
                                        t(e)
                                    })
                                }).catch(function(e) {
                                    l && l(e)
                                });
                            o ? (v.innerHTML = o.__html || "", m()) : u ? (v.textContent = "string" == typeof u ? u : Array.isArray(u) ? u.join("") : "", m()) : t && (v.src = t, h.set(t, g)), (0, d.setAttributesFromProps)(v, e), "worker" === s && v.setAttribute("type", "text/partytown"), v.setAttribute("data-nscript", s), c && (e => {
                                if (a.default.preinit) return e.forEach(e => {
                                    a.default.preinit(e, {
                                        as: "style"
                                    })
                                }); {
                                    let t = document.head;
                                    e.forEach(e => {
                                        let n = document.createElement("link");
                                        n.type = "text/css", n.rel = "stylesheet", n.href = e, t.appendChild(n)
                                    })
                                }
                            })(c), document.body.appendChild(v)
                        };

                    function v(e) {
                        let {
                            strategy: t = "afterInteractive"
                        } = e;
                        "lazyOnload" === t ? window.addEventListener("load", () => {
                            (0, f.requestIdleCallback)(() => m(e))
                        }) : m(e)
                    }

                    function g(e) {
                        e.forEach(v), [...document.querySelectorAll('[data-nscript="beforeInteractive"]'), ...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(e => {
                            let t = e.id || e.getAttribute("src");
                            p.add(t)
                        })
                    }

                    function y(e) {
                        let {
                            id: t,
                            src: n = "",
                            onLoad: r = () => {},
                            onReady: i = null,
                            strategy: o = "afterInteractive",
                            onError: u,
                            stylesheets: d,
                            ...h
                        } = e, {
                            updateScripts: v,
                            scripts: g,
                            getIsSsr: y,
                            appDir: b,
                            nonce: w
                        } = (0, l.useContext)(c.HeadManagerContext);
                        w = h.nonce || w;
                        let q = (0, l.useRef)(!1);
                        (0, l.useEffect)(() => {
                            let e = t || n;
                            q.current || (i && e && p.has(e) && i(), q.current = !0)
                        }, [i, t, n]);
                        let S = (0, l.useRef)(!1);
                        if ((0, l.useEffect)(() => {
                                if (!S.current) {
                                    if ("afterInteractive" === o) m(e);
                                    else "lazyOnload" === o && ("complete" === document.readyState ? (0, f.requestIdleCallback)(() => m(e)) : window.addEventListener("load", () => {
                                        (0, f.requestIdleCallback)(() => m(e))
                                    }));
                                    S.current = !0
                                }
                            }, [e, o]), ("beforeInteractive" === o || "worker" === o) && (v ? (g[o] = (g[o] || []).concat([{
                                id: t,
                                src: n,
                                onLoad: r,
                                onReady: i,
                                onError: u,
                                ...h,
                                nonce: w
                            }]), v(g)) : y && y() ? p.add(t || n) : y && !y() && m({ ...e,
                                nonce: w
                            })), b) {
                            if (d && d.forEach(e => {
                                    a.default.preinit(e, {
                                        as: "style"
                                    })
                                }), "beforeInteractive" === o)
                                if (!n) return h.dangerouslySetInnerHTML && (h.children = h.dangerouslySetInnerHTML.__html, delete h.dangerouslySetInnerHTML), (0, s.jsx)("script", {
                                    nonce: w,
                                    dangerouslySetInnerHTML: {
                                        __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify([0,{...h,id:t}])})`
                                    }
                                });
                                else return a.default.preload(n, h.integrity ? {
                                    as: "script",
                                    integrity: h.integrity,
                                    nonce: w,
                                    crossOrigin: h.crossOrigin
                                } : {
                                    as: "script",
                                    nonce: w,
                                    crossOrigin: h.crossOrigin
                                }), (0, s.jsx)("script", {
                                    nonce: w,
                                    dangerouslySetInnerHTML: {
                                        __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify([n,{...h,id:t}])})`
                                    }
                                });
                            "afterInteractive" === o && n && a.default.preload(n, h.integrity ? {
                                as: "script",
                                integrity: h.integrity,
                                nonce: w,
                                crossOrigin: h.crossOrigin
                            } : {
                                as: "script",
                                nonce: w,
                                crossOrigin: h.crossOrigin
                            })
                        }
                        return null
                    }
                    Object.defineProperty(y, "__nextScript", {
                        value: !0
                    });
                    let b = y;
                    ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                        value: !0
                    }), Object.assign(t.default, t), e.exports = t.default)
                },
                31603: (e, t, n) => {
                        "use strict";
                        n.d(t, {
                            a: () => p,
                            c: () => o,
                            i: () => h,
                            l: () => u,
                            n: () => d,
                            o: () => l,
                            r: () => f,
                            s: () => a
                        });
                        var r = n(59328);
                        let i = function() {
                            try {
                                let e = "nuqs-localStorage-test";
                                if ("u" < typeof localStorage) return !1;
                                localStorage.setItem(e, e);
                                let t = localStorage.getItem(e) === e;
                                return localStorage.removeItem(e), t && (localStorage.getItem("debug") || "").includes("nuqs")
                            } catch {
                                return !1
                            }
                        }();

                        function o(e, ...t) {
                            if (!i) return;
                            let n = function(e, ...t) {
                                return e.replace(/%[sfdO]/g, e => {
                                    let n = t.shift();
                                    return "%O" === e && n ? JSON.stringify(n).replace(/"([^"]+)":/g, "$1:") : String(n)
                                })
                            }(e, ...t);
                            performance.mark(n);
                            try {
                                console.log(e, ...t)
                            } catch {
                                console.log(n)
                            }
                        }

                        function u(e, ...t) {
                            i && console.warn(e, ...t)
                        }
                        let s = {
                            303: "Multiple adapter contexts detected. This might happen in monorepos.",
                            404: "nuqs requires an adapter to work with your framework.",
                            409: "Multiple versions of the library are loaded. This may lead to unexpected behavior. Currently using `%s`, but `%s` (via the %s adapter) was about to load on top.",
                            414: "Max safe URL length exceeded. Some browsers may not be able to accept this URL. Consider limiting the amount of state stored in the URL.",
                            422: "Invalid options combination: `limitUrlUpdates: debounce` should be used in SSR scenarios, with `shallow: false`",
                            429: "URL update rate-limited by the browser. Consider increasing `throttleMs` for key(s) `%s`. %O",
                            500: "Empty search params cache. Search params can't be accessed in Layouts.",
                            501: "Search params cache already populated. Have you called `parse` twice?"
                        };

                        function a(e) {
                            return `[nuqs] ${s[e]}
  See https://nuqs.dev/NUQS-${e}`
                        }

                        function l(e) {
                            if (0 === e.size) return "";
                            let t = [];
                            for (let [n, r] of e.entries()) {
                                let e = n.replace(/#/g, "%23").replace(/&/g, "%26").replace(/\+/g, "%2B").replace(/=/g, "%3D").replace(/\?/g, "%3F");
                                t.push(`${e}=${r.replace(/%/g,"%25").replace(/\+/g,"%2B").replace(/ /g,"+").replace(/#/g,"%23").replace(/&/g,"%26").replace(/"/g,"%22").replace(/'/g,"%27").replace(/`/g,"%60").replace(/</g,"%3C").replace(/>/g,"%3E").replace(/[\x00-\x1F]/g,e=>encodeURIComponent(e))}`)}return"?"+t.join("&")}let c=(0,r.createContext)({useAdapter(){throw Error(a(404))}});function d(e){return({children:t,defaultOptions:n,processUrlSearchParams:i,...o})=>(0,r.createElement)(c.Provider,{...o,value:{useAdapter:e,defaultOptions:n,processUrlSearchParams:i}},t)}function f(e){let t=(0,r.useContext)(c);if(!("useAdapter"in t))throw Error(a(404));return t.useAdapter(e)}c.displayName="NuqsAdapterContext",i&&"u">typeof window&&(window.__NuqsAdapterContext&&window.__NuqsAdapterContext!==c&&console.error(a(303)),window.__NuqsAdapterContext=c);let h=()=>(0,r.useContext)(c).defaultOptions,p=()=>(0,r.useContext)(c).processUrlSearchParams},33389:(e,t,n)=>{"use strict";n.d(t,{NuqsAdapter:()=>h});var r=n(31603),i=n(78693);function o(){(0,r.c)("[nuqs] Aborting queues"),i.t.abortAll(),i.n.abort().forEach(e=>i.t.queuedQuerySync.emit(e))}var u=n(59328),s=n(23454);let a=0;function l(){a=0,o()}function c(){--a<=0&&(a=0,queueMicrotask(o))}function d(){return(0,u.useEffect)(()=>(!function(){var e;if(e="next/app","u"<typeof history||(history.nuqs?.version&&"0.0.0-inject-version-here"!==history.nuqs.version?(console.error((0,r.s)(409),history.nuqs.version,"0.0.0-inject-version-here",e),!0):!!history.nuqs?.adapters?.includes(e)))return;let t=history.replaceState,n=history.pushState;history.replaceState=function(e,n,r){return c(),t.call(history,e,n,r)},history.pushState=function(e,t,r){return c(),n.call(history,e,t,r)},history.nuqs=history.nuqs??{version:"0.0.0-inject-version-here",adapters:[]},history.nuqs.adapters.push("next/app")}(),window.addEventListener("popstate",l),()=>window.removeEventListener("popstate",l)),[]),null}let f=(0,r.n)(function(){let e=(0,s.useRouter)(),[t,n]=(0,u.useOptimistic)((0,s.useSearchParams)());return{searchParams:t,updateUrl:(0,u.useCallback)((t,i)=>{(0,u.startTransition)(()=>{i.shallow||n(t);let o=function(e){let{origin:t,pathname:n,hash:i}=location;return t+n+(0,r.o)(e)+i}(t);(0,r.c)("[nuqs next/app] Updating url: %s",o);let u="push"===i.history?history.pushState:history.replaceState;a=3,u.call(history,null,"",o),i.scroll&&window.scrollTo(0,0),i.shallow||e.replace(o,{scroll:!1})})},[]),rateLimitFactor:3,autoResetQueueOnUpdate:!1}});function h({children:e,...t}){return(0,u.createElement)(f,{...t,children:[(0,u.createElement)(u.Suspense,{key:"nuqs-adapter-suspense-navspy",children:(0,u.createElement)(d)}),e]})}},37003:(e,t,n)=>{"use strict";n.d(t,{default:()=>i.a});var r=n(25560),i=n.n(r)},37386:(e,t,n)=>{e.exports=n(13329)},45205:(e,t,n)=>{"use strict";function r(e){var t;if("u"<typeof window||null==window.navigator)return!1;let n=null==(t=window.navigator.userAgentData)?void 0:t.brands;return Array.isArray(n)&&n.some(t=>e.test(t.brand))||e.test(window.navigator.userAgent)}function i(e){var t;return"u">typeof window&&null!=window.navigator&&e.test((null==(t=window.navigator.userAgentData)?void 0:t.platform)||window.navigator.platform)}function o(e){let t=null;return()=>(null==t&&(t=e()),t)}n.d(t,{H8:()=>f,Tc:()=>d,bh:()=>a,cX:()=>u,gm:()=>p,lg:()=>c,m0:()=>h,mU:()=>s,un:()=>l});let u=o(function(){return i(/^Mac/i)}),s=o(function(){return i(/^iPhone/i)}),a=o(function(){return i(/^iPad/i)||u()&&navigator.maxTouchPoints>1}),l=o(function(){return s()||a()}),c=o(function(){return u()||l()}),d=o(function(){return r(/AppleWebKit/i)&&!f()}),f=o(function(){return r(/Chrome/i)}),h=o(function(){return r(/Android/i)}),p=o(function(){return r(/Firefox/i)})},57880:e=>{!function(){"use strict";var t={};t.d=function(e,n){for(var r in n)t.o(n,r)&&!t.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:n[r]})},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.r=function(e){"u">typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},void 0!==t&&(t.ab="//");var n={};t.r(n),t.d(n,{CLSThresholds:function(){return A},FCPThresholds:function(){return P},FIDThresholds:function(){return ee},INPThresholds:function(){return H},LCPThresholds:function(){return D},TTFBThresholds:function(){return B},onCLS:function(){return M},onFCP:function(){return C},onFID:function(){return et},onINP:function(){return U},onLCP:function(){return V},onTTFB:function(){return J}});var r,i,o,u,s,a=-1,l=function(e){addEventListener("pageshow",function(t){t.persisted&&(a=t.timeStamp,e(t))},!0)},c=function(){var e=self.performance&&performance.getEntriesByType&&performance.getEntriesByType("navigation")[0];if(e&&e.responseStart>0&&e.responseStart<performance.now())return e},d=function(){var e=c();return e&&e.activationStart||0},f=function(e,t){var n=c(),r="navigate";return a>=0?r="back-forward-cache":n&&(document.prerendering||d()>0?r="prerender":document.wasDiscarded?r="restore":n.type&&(r=n.type.replace(/_/g,"-"))),{name:e,value:void 0===t?-1:t,rating:"good",delta:0,entries:[],id:"v4-".concat(Date.now(),"-").concat(Math.floor(0x82f79cd8fff*Math.random())+1e12),navigationType:r}},h=function(e,t,n){try{if(PerformanceObserver.supportedEntryTypes.includes(e)){var r=new PerformanceObserver(function(e){Promise.resolve().then(function(){t(e.getEntries())})});return r.observe(Object.assign({type:e,buffered:!0},n||{})),r}}catch(e){}},p=function(e,t,n,r){var i,o;return function(u){var s;t.value>=0&&(u||r)&&((o=t.value-(i||0))||void 0===i)&&(i=t.value,t.delta=o,s=t.value,t.rating=s>n[1]?"poor":s>n[0]?"needs-improvement":"good",e(t))}},m=function(e){requestAnimationFrame(function(){return requestAnimationFrame(function(){return e()})})},v=function(e){document.addEventListener("visibilitychange",function(){"hidden"===document.visibilityState&&e()})},g=function(e){var t=!1;return function(){t||(e(),t=!0)}},y=-1,b=function(){return"hidden"!==document.visibilityState||document.prerendering?1/0:0},w=function(e){"hidden"===document.visibilityState&&y>-1&&(y="visibilitychange"===e.type?e.timeStamp:0,S())},q=function(){addEventListener("visibilitychange",w,!0),addEventListener("prerenderingchange",w,!0)},S=function(){removeEventListener("visibilitychange",w,!0),removeEventListener("prerenderingchange",w,!0)},E=function(){return y<0&&(y=b(),q(),l(function(){setTimeout(function(){y=b(),q()},0)})),{get firstHiddenTime(){return y}}},T=function(e){document.prerendering?addEventListener("prerenderingchange",function(){return e()},!0):e()},P=[1800,3e3],C=function(e,t){t=t||{},T(function(){var n,r=E(),i=f("FCP"),o=h("paint",function(e){e.forEach(function(e){"first-contentful-paint"===e.name&&(o.disconnect(),e.startTime<r.firstHiddenTime&&(i.value=Math.max(e.startTime-d(),0),i.entries.push(e),n(!0)))})});o&&(n=p(e,i,P,t.reportAllChanges),l(function(r){n=p(e,i=f("FCP"),P,t.reportAllChanges),m(function(){i.value=performance.now()-r.timeStamp,n(!0)})}))})},A=[.1,.25],M=function(e,t){t=t||{},C(g(function(){var n,r=f("CLS",0),i=0,o=[],u=function(e){e.forEach(function(e){if(!e.hadRecentInput){var t=o[0],n=o[o.length-1];i&&e.startTime-n.startTime<1e3&&e.startTime-t.startTime<5e3?(i+=e.value,o.push(e)):(i=e.value,o=[e])}}),i>r.value&&(r.value=i,r.entries=o,n())},s=h("layout-shift",u);s&&(n=p(e,r,A,t.reportAllChanges),v(function(){u(s.takeRecords()),n(!0)}),l(function(){i=0,n=p(e,r=f("CLS",0),A,t.reportAllChanges),m(function(){return n()})}),setTimeout(n,0))}))},L=0,O=1/0,_=0,x=function(e){e.forEach(function(e){e.interactionId&&(O=Math.min(O,e.interactionId),L=(_=Math.max(_,e.interactionId))?(_-O)/7+1:0)})},k=function(){"interactionCount"in performance||r||(r=h("event",x,{type:"event",buffered:!0,durationThreshold:0}))},I=[],j=new Map,R=0,F=[],N=function(e){if(F.forEach(function(t){return t(e)}),e.interactionId||"first-input"===e.entryType){var t=I[I.length-1],n=j.get(e.interactionId);if(n||I.length<10||e.duration>t.latency){if(n)e.duration>n.latency?(n.entries=[e],n.latency=e.duration):e.duration===n.latency&&e.startTime===n.entries[0].startTime&&n.entries.push(e);else{var r={id:e.interactionId,latency:e.duration,entries:[e]};j.set(r.id,r),I.push(r)}I.sort(function(e,t){return t.latency-e.latency}),I.length>10&&I.splice(10).forEach(function(e){return j.delete(e.id)})}}},Q=function(e){var t=self.requestIdleCallback||self.setTimeout,n=-1;return e=g(e),"hidden"===document.visibilityState?e():(n=t(e),v(e)),n},H=[200,500],U=function(e,t){"PerformanceEventTiming"in self&&"interactionId"in PerformanceEventTiming.prototype&&(t=t||{},T(function(){k();var n,i,o=f("INP"),u=function(e){Q(function(){e.forEach(N);var t,n=(t=Math.min(I.length-1,Math.floor(((r?L:performance.interactionCount||0)-R)/50)),I[t]);n&&n.latency!==o.value&&(o.value=n.latency,o.entries=n.entries,i())})},s=h("event",u,{durationThreshold:null!=(n=t.durationThreshold)?n:40});i=p(e,o,H,t.reportAllChanges),s&&(s.observe({type:"first-input",buffered:!0}),v(function(){u(s.takeRecords()),i(!0)}),l(function(){R=0,I.length=0,j.clear(),i=p(e,o=f("INP"),H,t.reportAllChanges)}))}))},D=[2500,4e3],K={},V=function(e,t){t=t||{},T(function(){var n,r=E(),i=f("LCP"),o=function(e){t.reportAllChanges||(e=e.slice(-1)),e.forEach(function(e){e.startTime<r.firstHiddenTime&&(i.value=Math.max(e.startTime-d(),0),i.entries=[e],n())})},u=h("largest-contentful-paint",o);if(u){n=p(e,i,D,t.reportAllChanges);var s=g(function(){K[i.id]||(o(u.takeRecords()),u.disconnect(),K[i.id]=!0,n(!0))});["keydown","click"].forEach(function(e){addEventListener(e,function(){return Q(s)},!0)}),v(s),l(function(r){n=p(e,i=f("LCP"),D,t.reportAllChanges),m(function(){i.value=performance.now()-r.timeStamp,K[i.id]=!0,n(!0)})})}})},B=[800,1800],$=function e(t){document.prerendering?T(function(){return e(t)}):"complete"!==document.readyState?addEventListener("load",function(){return e(t)},!0):setTimeout(t,0)},J=function(e,t){t=t||{};var n=f("TTFB"),r=p(e,n,B,t.reportAllChanges);$(function(){var i=c();i&&(n.value=Math.max(i.responseStart-d(),0),n.entries=[i],r(!0),l(function(){(r=p(e,n=f("TTFB",0),B,t.reportAllChanges))(!0)}))})},z={passive:!0,capture:!0},W=new Date,X=function(e,t){i||(i=t,o=e,u=new Date,Z(removeEventListener),G())},G=function(){if(o>=0&&o<u-W){var e={entryType:"first-input",name:i.type,target:i.target,cancelable:i.cancelable,startTime:i.timeStamp,processingStart:i.timeStamp+o};s.forEach(function(t){t(e)}),s=[]}},Y=function(e){if(e.cancelable){var t,n,r,i=(e.timeStamp>1e12?new Date:performance.now())-e.timeStamp;"pointerdown"==e.type?(t=function(){X(i,e),r()},n=function(){r()},r=function(){removeEventListener("pointerup",t,z),removeEventListener("pointercancel",n,z)},addEventListener("pointerup",t,z),addEventListener("pointercancel",n,z)):X(i,e)}},Z=function(e){["mousedown","keydown","touchstart","pointerdown"].forEach(function(t){return e(t,Y,z)})},ee=[100,300],et=function(e,t){t=t||{},T(function(){var n,r=E(),u=f("FID"),a=function(e){e.startTime<r.firstHiddenTime&&(u.value=e.processingStart-e.startTime,u.entries.push(e),n(!0))},c=function(e){e.forEach(a)},d=h("first-input",c);n=p(e,u,ee,t.reportAllChanges),d&&(v(g(function(){c(d.takeRecords()),d.disconnect()})),l(function(){n=p(e,u=f("FID"),ee,t.reportAllChanges),s=[],o=-1,i=null,Z(addEventListener),s.push(a),G()}))})};e.exports=n}()},58571:(e,t)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});var n={cancelIdleCallback:function(){return o},requestIdleCallback:function(){return i}};for(var r in n)Object.defineProperty(t,r,{enumerable:!0,get:n[r]});let i="u">typeof self&&self.requestIdleCallback&&self.requestIdleCallback.bind(window)||function(e){let t=Date.now();return self.setTimeout(function(){e({didTimeout:!1,timeRemaining:function(){return Math.max(0,50-(Date.now()-t))}})},1)},o="u">typeof self&&self.cancelIdleCallback&&self.cancelIdleCallback.bind(window)||function(e){return clearTimeout(e)};("function"==typeof t.default||"object"==typeof t.default&&null!==t.default)&&void 0===t.default.__esModule&&(Object.defineProperty(t.default,"__esModule",{value:!0}),Object.assign(t.default,t),e.exports=t.default)},78693:(e,t,n)=>{"use strict";n.d(t,{i:()=>s,n:()=>h,o:()=>o,r:()=>a,s:()=>u,t:()=>m});var r=n(31603),i=n(59328);function o(e){return{method:"debounce",timeMs:e}}let u={method:"throttle",timeMs:function(){if("u"<typeof window||!window.GestureEvent)return 50;try{let e=navigator.userAgent?.match(/version\/([\d\.]+) safari/i);return parseFloat(e[1])>=17?120:320}catch{return 320}}()};function s(e){return null===e||Array.isArray(e)&&0===e.length}function a(){let e=new Map;return{on(t,n){let r=e.get(t)||[];return r.push(n),e.set(t,r),()=>this.off(t,n)},off(t,n){let r=e.get(t);r&&e.set(t,r.filter(e=>e!==n))},emit(t,n){e.get(t)?.forEach(e=>e(n))}}}function l(e,t,n){let r=setTimeout(function(){e(),n.removeEventListener("abort",i)},t);function i(){clearTimeout(r),n.removeEventListener("abort",i)}n.addEventListener("abort",i)}function c(){let e=Promise;if(Promise.hasOwnProperty("withResolvers"))return Promise.withResolvers();let t=()=>{},n=()=>{};return{promise:new e((e,r)=>{t=e,n=r}),resolve:t,reject:n}}function d(){return new URLSearchParams(location.search)}var f=class{updateMap=new Map;options={history:"replace",scroll:!1,shallow:!0};timeMs=u.timeMs;transitions=new Set;resolvers=null;controller=null;lastFlushedAt=0;resetQueueOnNextPush=!1;push({key:e,query:t,options:n},i=u.timeMs){this.resetQueueOnNextPush&&(this.reset(),this.resetQueueOnNextPush=!1),(0,r.c)("[nuqs gtq] Enqueueing %s=%s %O",e,t,n),this.updateMap.set(e,t),"push"===n.history&&(this.options.history="push"),n.scroll&&(this.options.scroll=!0),!1===n.shallow&&(this.options.shallow=!1),n.startTransition&&this.transitions.add(n.startTransition),(!Number.isFinite(this.timeMs)||i>this.timeMs)&&(this.timeMs=i)}getQueuedQuery(e){return this.updateMap.get(e)}getPendingPromise({getSearchParamsSnapshot:e=d}){return this.resolvers?.promise??Promise.resolve(e())}flush({getSearchParamsSnapshot:e=d,rateLimitFactor:t=1,...n},i){if(this.controller??=new AbortController,!Number.isFinite(this.timeMs))return(0,r.c)("[nuqs gtq] Skipping flush due to throttleMs=Infinity"),Promise.resolve(e());if(this.resolvers)return this.resolvers.promise;this.resolvers=c();let o=()=>{this.lastFlushedAt=performance.now();let[t,r]=this.applyPendingUpdates({...n,autoResetQueueOnUpdate:n.autoResetQueueOnUpdate??!0,getSearchParamsSnapshot:e},i);null===r?(this.resolvers.resolve(t),this.resetQueueOnNextPush=!0):this.resolvers.reject(t),this.resolvers=null},u=()=>{let e=performance.now()-this.lastFlushedAt,n=this.timeMs,i=t*Math.max(0,n-e);(0,r.c)("[nuqs gtq] Scheduling flush in %f ms. Throttled at %f ms (x%f)",i,n,t),0===i?o():l(o,i,this.controller.signal)};return l(u,0,this.controller.signal),this.resolvers.promise}abort(){return this.controller?.abort(),this.controller=new AbortController,this.resolvers?.resolve(new URLSearchParams),this.resolvers=null,this.reset()}reset(){let e=Array.from(this.updateMap.keys());return(0,r.c)("[nuqs gtq] Resetting queue %s",JSON.stringify(Object.fromEntries(this.updateMap))),this.updateMap.clear(),this.transitions.clear(),this.options={history:"replace",scroll:!1,shallow:!0},this.timeMs=u.timeMs,e}applyPendingUpdates(e,t){let{updateUrl:n,getSearchParamsSnapshot:i}=e,o=i();if((0,r.c)("[nuqs gtq] Applying %d pending update(s) on top of %s",this.updateMap.size,o.toString()),0===this.updateMap.size)return[o,null];let u=Array.from(this.updateMap.entries()),s={...this.options},a=Array.from(this.transitions);for(let[t,n]of(e.autoResetQueueOnUpdate&&this.reset(),(0,r.c)("[nuqs gtq] Flushing queue %O with options %O",u,s),u))null===n?o.delete(t):o=function(e,t,n){if("string"==typeof e)n.set(t,e);else{for(let r of(n.delete(t),e))n.append(t,r);n.has(t)||n.set(t,"")}return n}(n,t,o);t&&(o=t(o));try{return!function(e,t){let n=t;for(let t=e.length-1;t>=0;t--){let r=e[t];if(!r)continue;let i=n;n=()=>r(i)}n()}(a,()=>{n(o,s)}),[o,null]}catch(e){return console.error((0,r.s)(429),u.map(([e])=>e).join(),e),[o,e]}}};let h=new f;var p=class{callback;resolvers=c();controller=new AbortController;queuedValue=void 0;constructor(e){this.callback=e}abort(){this.controller.abort(),this.queuedValue=void 0}push(e,t){return this.queuedValue=e,this.controller.abort(),this.controller=new AbortController,l(()=>{let t=this.resolvers;try{(0,r.c)("[nuqs dq] Flushing debounce queue",e);let n=this.callback(e);(0,r.c)("[nuqs dq] Reset debounce queue %O",this.queuedValue),this.queuedValue=void 0,this.resolvers=c(),n.then(e=>t.resolve(e)).catch(e=>t.reject(e))}catch(e){this.queuedValue=void 0,t.reject(e)}},t,this.controller.signal),this.resolvers.promise}};let m=new class{throttleQueue;queues=new Map;queuedQuerySync=a();constructor(e=new f){this.throttleQueue=e}useQueuedQueries(e){var t,n;let r,o;return t=(e,t)=>this.queuedQuerySync.on(e,t),n=e=>this.getQueuedQuery(e),r=(0,i.useCallback)(()=>{let t=Object.fromEntries(e.map(e=>[e,n(e)]));return[JSON.stringify(t),t]},[e.join(","),n]),null===(o=(0,i.useRef)(null)).current&&(o.current=r()),(0,i.useSyncExternalStore)((0,i.useCallback)(n=>{let r=e.map(e=>t(e,n));return()=>r.forEach(e=>e())},[e.join(","),t]),()=>{let[e,t]=r();return o.current[0]===e?o.current[1]:(o.current=[e,t],t)},()=>o.current[1])}push(e,t,n){if(!Number.isFinite(t))return Promise.resolve((n.getSearchParamsSnapshot??d)());let i=e.key;if(!this.queues.has(i)){(0,r.c)("[nuqs dqc] Creating debounce queue for ` % s `",i);let e=new p(e=>(this.throttleQueue.push(e),this.throttleQueue.flush(n).finally(()=>{this.queues.get(e.key)?.queuedValue===void 0&&((0,r.c)("[nuqs dqc] Cleaning up empty queue for ` % s `",e.key),this.queues.delete(e.key)),this.queuedQuerySync.emit(e.key)})));this.queues.set(i,e)}(0,r.c)("[nuqs dqc] Enqueueing debounce update %O",e);let o=this.queues.get(i).push(e,t);return this.queuedQuerySync.emit(i),o}abort(e){let t=this.queues.get(e);return t?((0,r.c)("[nuqs dqc] Aborting debounce queue %s=%s",e,t.queuedValue?.query),this.queues.delete(e),t.abort(),this.queuedQuerySync.emit(e),e=>(e.then(t.resolvers.resolve,t.resolvers.reject),e)):e=>e}abortAll(){for(let[e,t]of this.queues.entries())(0,r.c)("[nuqs dqc] Aborting debounce queue %s=%s",e,t.queuedValue?.query),t.abort(),t.resolvers.resolve(new URLSearchParams),this.queuedQuerySync.emit(e);this.queues.clear()}getQueuedQuery(e){let t=this.queues.get(e)?.queuedValue?.query;return void 0!==t?t:this.throttleQueue.getQueuedQuery(e)}}(h)},79300:(e,t,n)=>{"use strict";Object.defineProperty(t,"__esModule",{value:!0});var r={callServer:function(){return o.callServer},createServerReference:function(){return s.createServerReference},findSourceMapURL:function(){return u.findSourceMapURL}};for(var i in r)Object.defineProperty(t,i,{enumerable:!0,get:r[i]});let o=n(50259),u=n(96443),s=n(86906)},93647:(e,t,n)=>{"use strict";function r(e){if(function(){if(null==i){i=!1;try{document.createElement("div").focus({get preventScroll(){return i=!0,!0}})}catch{}}return i}())e.focus({preventScroll:!0});else{let t=function(e){let t=e.parentNode,n=[],r=document.scrollingElement||document.documentElement;for(;t instanceof HTMLElement&&t!==r;)(t.offsetHeight<t.scrollHeight||t.offsetWidth<t.scrollWidth)&&n.push({element:t,scrollTop:t.scrollTop,scrollLeft:t.scrollLeft}),t=t.parentNode;return r instanceof HTMLElement&&n.push({element:r,scrollTop:r.scrollTop,scrollLeft:r.scrollLeft}),n}(e);e.focus(),function(e){for(let{element:t,scrollTop:n,scrollLeft:r}of e)t.scrollTop=n,t.scrollLeft=r}(t)}}n.d(t,{e:()=>r});let i=null}}]);
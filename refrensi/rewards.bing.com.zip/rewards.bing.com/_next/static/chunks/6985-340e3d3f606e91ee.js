"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6985], {
        36985: (e, t, r) => {
            r.d(t, {
                m_: () => $,
                k$: () => D
            });
            var n = r(22995),
                o = r(81017),
                l = r(36800),
                u = r(81698),
                i = r(94828),
                a = r(51164),
                c = r(39298),
                s = r(59328),
                d = r(23782),
                p = r(16785),
                f = r(71043);
            let m = s.createContext(null);

            function v(e) {
                let {
                    children: t
                } = e, r = (0, s.useContext)(m), [n, o] = (0, s.useState)(0), l = (0, s.useMemo)(() => ({
                    parent: r,
                    modalCount: n,
                    addModal() {
                        o(e => e + 1), r && r.addModal()
                    },
                    removeModal() {
                        o(e => e - 1), r && r.removeModal()
                    }
                }), [r, n]);
                return s.createElement(m.Provider, {
                    value: l
                }, t)
            }

            function E(e) {
                let t, {
                    modalProviderProps: r
                } = {
                    modalProviderProps: {
                        "aria-hidden": !!(t = (0, s.useContext)(m)) && t.modalCount > 0 || void 0
                    }
                };
                return s.createElement("div", {
                    "data-overlay-container": !0,
                    ...e,
                    ...r
                })
            }

            function g(e) {
                return s.createElement(v, null, s.createElement(E, e))
            }

            function P(e) {
                let t = (0, f.wR)(),
                    {
                        portalContainer: r = t ? null : document.body,
                        ...n
                    } = e,
                    {
                        getContainer: o
                    } = (0, d.gX)();
                if (!e.portalContainer && o && (r = o()), s.useEffect(() => {
                        if (null == r ? void 0 : r.closest("[data-overlay-container]")) throw Error("An OverlayContainer must not be inside another container. Please change the portalContainer prop.")
                    }, [r]), !r) return null;
                let l = s.createElement(g, n);
                return p.createPortal(l, r)
            }
            var C = r(75155),
                h = r(64128),
                y = r(94988),
                x = r(52392);
            let O = {},
                R = 0,
                T = !1,
                b = null,
                w = null;

            function M(e = {}) {
                let {
                    delay: t = 1500,
                    closeDelay: r = 500
                } = e, {
                    isOpen: n,
                    open: o,
                    close: l
                } = (0, x.T)(e), u = (0, s.useMemo)(() => `${++R}`, []), i = (0, s.useRef)(null), a = (0, s.useRef)(l), c = () => {
                    O[u] = f
                }, d = () => {
                    for (let e in O) e !== u && (O[e](!0), delete O[e])
                }, p = () => {
                    i.current && clearTimeout(i.current), i.current = null, d(), c(), T = !0, o(), b && (clearTimeout(b), b = null), w && (clearTimeout(w), w = null)
                }, f = e => {
                    e || r <= 0 ? (i.current && clearTimeout(i.current), i.current = null, a.current()) : i.current || (i.current = setTimeout(() => {
                        i.current = null, a.current()
                    }, r)), b && (clearTimeout(b), b = null), T && (w && clearTimeout(w), w = setTimeout(() => {
                        delete O[u], w = null, T = !1
                    }, Math.max(500, r)))
                };
                return (0, s.useEffect)(() => {
                    a.current = l
                }, [l]), (0, s.useEffect)(() => () => {
                    i.current && clearTimeout(i.current), O[u] && delete O[u]
                }, [u]), {
                    isOpen: n,
                    open: e => {
                        e || !(t > 0) || i.current ? p() : (d(), c(), n || b || T ? n || p() : b = setTimeout(() => {
                            b = null, T = !0, p()
                        }, t))
                    },
                    close: f
                }
            }
            let k = (0, s.createContext)(null),
                _ = (0, s.createContext)(null);

            function D(e) {
                let t = M(e),
                    r = (0, s.useRef)(null),
                    {
                        triggerProps: o,
                        tooltipProps: d
                    } = function(e, t, r) {
                        let {
                            isDisabled: n,
                            trigger: o,
                            shouldCloseOnPress: d = !0
                        } = e, p = (0, a.Bi)(), f = (0, s.useRef)(!1), m = (0, s.useRef)(!1), v = () => {
                            (f.current || m.current) && t.open(m.current)
                        }, E = e => {
                            f.current || m.current || t.close(e)
                        };
                        (0, s.useEffect)(() => {
                            let e = e => {
                                r && r.current && "Escape" === e.key && (e.stopPropagation(), t.close(!0))
                            };
                            if (t.isOpen) return document.addEventListener("keydown", e, !0), () => {
                                document.removeEventListener("keydown", e, !0)
                            }
                        }, [r, t]);
                        let g = () => {
                                d && (m.current = !1, f.current = !1, E(!0))
                            },
                            {
                                hoverProps: P
                            } = (0, u.M)({
                                isDisabled: n,
                                onHoverStart: () => {
                                    "focus" !== o && ("pointer" === (0, l.ME)() ? f.current = !0 : f.current = !1, v())
                                },
                                onHoverEnd: () => {
                                    "focus" !== o && (m.current = !1, f.current = !1, E())
                                }
                            }),
                            {
                                focusableProps: C
                            } = (0, i.Wc)({
                                isDisabled: n,
                                onFocus: () => {
                                    (0, l.pP)() && (m.current = !0, v())
                                },
                                onBlur: () => {
                                    m.current = !1, f.current = !1, E(!0)
                                }
                            }, r);
                        return {
                            triggerProps: {
                                "aria-describedby": t.isOpen ? p : void 0,
                                ...(0, c.v)(C, P, {
                                    onPointerDown: g,
                                    onKeyDown: g
                                }),
                                tabIndex: void 0
                            },
                            tooltipProps: {
                                id: p
                            }
                        }
                    }(e, t, r);
                return s.createElement(n.Kq, {
                    values: [
                        [k, t],
                        [_, { ...d,
                            triggerRef: r
                        }]
                    ]
                }, s.createElement(i.M2, { ...o,
                    ref: r
                }, e.children))
            }
            let $ = (0, s.forwardRef)(function({
                UNSTABLE_portalContainer: e,
                ...t
            }, r) {
                [t, r] = (0, n.JT)(t, r, _);
                let o = (0, s.useContext)(k),
                    l = M(t),
                    u = null == t.isOpen && null == t.defaultOpen && o ? o : l,
                    i = (0, y.O)(r, u.isOpen) || t.isExiting || !1;
                return u.isOpen || i ? s.createElement(P, {
                    portalContainer: e
                }, s.createElement(B, { ...t,
                    tooltipRef: r,
                    isExiting: i
                })) : null
            });

            function B(e) {
                let t = (0, s.useContext)(k),
                    r = (0, s.useRef)(null),
                    {
                        overlayProps: l,
                        arrowProps: i,
                        placement: a,
                        triggerAnchorPoint: d
                    } = (0, C.v)({
                        placement: e.placement || "top",
                        targetRef: e.triggerRef,
                        overlayRef: e.tooltipRef,
                        arrowRef: r,
                        offset: e.offset,
                        crossOffset: e.crossOffset,
                        isOpen: t.isOpen,
                        arrowBoundaryOffset: e.arrowBoundaryOffset,
                        shouldFlip: e.shouldFlip,
                        containerPadding: e.containerPadding,
                        onClose: () => t.close(!0)
                    }),
                    p = (0, y._)(e.tooltipRef, !!a) || e.isEntering || !1,
                    f = (0, n.Sl)({ ...e,
                        defaultClassName: "react-aria-Tooltip",
                        values: {
                            placement: a,
                            isEntering: p,
                            isExiting: e.isExiting,
                            state: t
                        }
                    }),
                    {
                        tooltipProps: m
                    } = function(e, t) {
                        let r = (0, h.$)(e, {
                                labelable: !0
                            }),
                            {
                                hoverProps: n
                            } = (0, u.M)({
                                onHoverStart: () => null == t ? void 0 : t.open(!0),
                                onHoverEnd: () => null == t ? void 0 : t.close()
                            });
                        return {
                            tooltipProps: (0, c.v)(r, n, {
                                role: "tooltip"
                            })
                        }
                    }(e = (0, c.v)(e, l), t),
                    v = (0, h.$)(e, {
                        global: !0
                    });
                return s.createElement(n.tT.div, { ...(0, c.v)(v, f, m),
                    ref: e.tooltipRef,
                    style: { ...l.style,
                        "--trigger-anchor-point": d ? `${d.x}px ${d.y}px` : void 0,
                        ...f.style
                    },
                    "data-placement": null != a ? a : void 0,
                    "data-entering": p || void 0,
                    "data-exiting": e.isExiting || void 0
                }, s.createElement(o.J.Provider, {
                    value: { ...i,
                        placement: a,
                        ref: r
                    }
                }, f.children))
            }
        }
    }
]);
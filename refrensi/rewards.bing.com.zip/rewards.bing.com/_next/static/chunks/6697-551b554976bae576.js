"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6697], {
        32530: (e, t, r) => {
            r.d(t, {
                C: () => d
            });
            var o = r(89122),
                l = r(41085),
                i = r(45362);
            class n {
                constructor() {
                    this.analytics = null
                }
                static getInstance() {
                    return n.instance || (n.instance = new n), n.instance
                }
                log(e, t) {
                    this.logEvent("Diagnostic", {
                        message: e,
                        props: JSON.stringify(t)
                    })
                }
                logPageAction(e, t, r) {
                    this.logEvent("PageAction", {
                        tag: e,
                        kind: t,
                        props: JSON.stringify(r)
                    })
                }
                logPageView(e, t, r) {
                    this.logEvent("PageView", {
                        path: e,
                        searchParams: t,
                        referrer: r
                    })
                }
                logError(e, t = !1) {
                    this.logEvent("Error", {
                        errorName: e.name,
                        errorMessage: e.message,
                        errorStack: e.stack || "",
                        isUnhandled: t.toString()
                    })
                }
                logWebVitals(e, t) {
                    this.logEvent("WebVitals", {
                        webVitalsMetric: e,
                        ...t
                    })
                }
                logEvent(e, t) {
                    try {
                        let r = window.telemetryContext || {},
                            o = window.location.pathname,
                            l = { ...t,
                                traceId: r.traceId,
                                anid: r.anid,
                                country: r.country,
                                language: r.language,
                                sessionId: r.sessionId,
                                path: o
                            };
                        if ("1" === i.env.NEXT_PUBLIC_TELEMETRY_CONSOLE_LOG_ENABLED && console.log(`[ClientTelemetry] ${e}:`, l), !this.analytics && !this.tryInitialize1DS()) return;
                        this.analytics ? .track({
                            name: "vnext_" + e,
                            data: l
                        })
                    } catch (e) {
                        "1" === i.env.NEXT_PUBLIC_TELEMETRY_CONSOLE_LOG_ENABLED && console.error("Error logging telemetry event:", e)
                    }
                }
                tryInitialize1DS() {
                    if (!window.telemetryContext) return "1" === i.env.NEXT_PUBLIC_TELEMETRY_CONSOLE_LOG_ENABLED && console.warn("[ClientTelemetry] Telemetry context is not set."), !1;
                    let e = window.telemetryContext.instrumentationKey;
                    if (!e) return !1;
                    let t = new o.a,
                        r = new l.I,
                        n = {
                            instrumentationKey: e,
                            channels: [
                                [r]
                            ],
                            extensionConfig: {
                                [r.identifier]: {
                                    storageKey: "vnextTelemetry"
                                }
                            }
                        };
                    return t.initialize(n, []), this.analytics = t, !0
                }
            }
            let d = n.getInstance()
        },
        75564: (e, t, r) => {
            r.d(t, {
                hd: () => p,
                TX: () => I,
                yA: () => k,
                ul: () => L,
                Rb: () => b,
                tw: () => W
            });
            var o = r(9555);
            let l = ["ctrlAvatarActiveRingSize", "ctrlAvatarActiveRingStrokeWidth", "ctrlAvatarIconSize", "ctrlAvatarPresenceBadgePaddingBottomRightOffset", "ctrlAvatarPresenceBadgeSize", "ctrlAvatarPresenceBadgeStrokeWidth", "ctrlAvatarSize", "ctrlAvatarTextPaddingTopOffset", "ctrlBadgeBeaconSize", "ctrlBadgeGap", "ctrlBadgeIconSize", "ctrlBadgeLgIconSize", "ctrlBadgeLgPadding", "ctrlBadgeLgSize", "ctrlBadgeLgTextPaddingBottom", "ctrlBadgeLgTextPaddingTop", "ctrlBadgePadding", "ctrlBadgeSize", "ctrlBadgeSmIconSize", "ctrlBadgeSmPadding", "ctrlBadgeSmSize", "ctrlBadgeSmTextPaddingBottom", "ctrlBadgeSmTextPaddingTop", "ctrlBadgeTextPaddingBottom", "ctrlBadgeTextPaddingTop", "ctrlChoiceBaseSize", "ctrlChoiceBaseStrokeWidthHover", "ctrlChoiceBaseStrokeWidthPressed", "ctrlChoiceBaseStrokeWidthRest", "ctrlChoiceBaseStrokeWidthSelected", "ctrlChoiceCheckboxIconSize", "ctrlChoiceCheckboxIndeterminateHeight", "ctrlChoiceCheckboxIndeterminateWidth", "ctrlChoiceLgBaseSize", "ctrlChoiceLgCheckboxIconSize", "ctrlChoiceLgRadioDotSizeHover", "ctrlChoiceLgRadioDotSizePressed", "ctrlChoiceLgRadioDotSizeRest", "ctrlChoiceLgSwitchHeight", "ctrlChoiceLgSwitchThumbWidthHover", "ctrlChoiceLgSwitchThumbWidthPressed", "ctrlChoiceLgSwitchThumbWidthRest", "ctrlChoiceLgSwitchWidth", "ctrlChoicePaddingHorizontal", "ctrlChoicePaddingVertical", "ctrlChoiceRadioDotSizeHover", "ctrlChoiceRadioDotSizePressed", "ctrlChoiceRadioDotSizeRest", "ctrlChoiceSmBaseSize", "ctrlChoiceSmCheckboxIconSize", "ctrlChoiceSmRadioDotSize", "ctrlChoiceSmSwitchHeight", "ctrlChoiceSmSwitchThumbWidthHover", "ctrlChoiceSmSwitchThumbWidthPressed", "ctrlChoiceSmSwitchThumbWidthRest", "ctrlChoiceSmSwitchWidth", "ctrlChoiceSwitchHeight", "ctrlChoiceSwitchPaddingHover", "ctrlChoiceSwitchPaddingPressed", "ctrlChoiceSwitchPaddingRest", "ctrlChoiceSwitchThumbWidthHover", "ctrlChoiceSwitchThumbWidthPressed", "ctrlChoiceSwitchThumbWidthRest", "ctrlChoiceSwitchWidth", "ctrlCoachmarkPaddingHorizontal", "ctrlCoachmarkPaddingVertical", "ctrlCoachmarkWidth", "ctrlComposerInputBottomStrokeWidthHover", "ctrlComposerInputBottomStrokeWidthPressed", "ctrlComposerInputBottomStrokeWidthRest", "ctrlComposerInputBottomStrokeWidthSelectedRest", "ctrlComposerInputStrokeWidthHover", "ctrlComposerInputStrokeWidthPressed", "ctrlComposerInputStrokeWidthRest", "ctrlComposerInputStrokeWidthSelectedRest", "ctrlDialogLayerPaddingBottom", "ctrlDialogMaxWidth", "ctrlDialogPadding", "ctrlDividerFixedLineLength", "ctrlFocusInnerStrokeWidth", "ctrlFocusOuterStrokeWidth", "ctrlInputBottomLineStrokeWidthHover", "ctrlInputBottomLineStrokeWidthPressed", "ctrlInputBottomLineStrokeWidthRest", "ctrlInputBottomLineStrokeWidthSelected", "ctrlInputStrokeWidthHover", "ctrlInputStrokeWidthPressed", "ctrlInputStrokeWidthRest", "ctrlInputStrokeWidthSelected", "ctrlLinkInlineStrokeWidthHover", "ctrlLinkInlineStrokeWidthRest", "ctrlLinkOnPageStrokeWidthHover", "ctrlLinkOnPageStrokeWidthRest", "ctrlListChoiceCheckboxIconSize", "ctrlListChoiceDotSize", "ctrlListIndentLevel1", "ctrlListIndentLevel2", "ctrlListIndentLevel3", "ctrlListLgIndentLevel1", "ctrlListLgIndentLevel2", "ctrlListLgIndentLevel3", "ctrlListPillLengthHint", "ctrlListPillLengthHover", "ctrlListPillLengthPressed", "ctrlListPillLengthRest", "ctrlListPillStretchPaddingDefault", "ctrlListPillStretchPaddingHint", "ctrlListPillWidth", "ctrlListSmIndentLevel1", "ctrlListSmIndentLevel2", "ctrlListSmIndentLevel3", "ctrlListSplitDividerPaddingInset", "ctrlLiteFilterStrokeWidthSelected", "ctrlProgressHeightEmpty", "ctrlProgressHeightFilled", "ctrlProgressLgHeightEmpty", "ctrlProgressLgHeightFilled", "ctrlProgressSmHeightEmpty", "ctrlProgressSmHeightFilled", "ctrlRatingIconGap", "ctrlRatingIconSize", "ctrlSegmentedGap", "ctrlSegmentedLgPaddingHover", "ctrlSegmentedLgPaddingPressed", "ctrlSegmentedLgPaddingRest", "ctrlSegmentedPaddingHover", "ctrlSegmentedPaddingPressed", "ctrlSegmentedPaddingRest", "ctrlSegmentedSmPaddingHover", "ctrlSegmentedSmPaddingPressed", "ctrlSegmentedSmPaddingRest", "ctrlSliderBarHeight", "ctrlSliderLgBarHeight", "ctrlSliderLgThumbSizeHover", "ctrlSliderLgThumbSizePressed", "ctrlSliderLgThumbSizeRest", "ctrlSliderSmBarHeight", "ctrlSliderSmThumbSizeHover", "ctrlSliderSmThumbSizePressed", "ctrlSliderSmThumbSizeRest", "ctrlSliderThumbInnerStrokeWidthHover", "ctrlSliderThumbInnerStrokeWidthPressed", "ctrlSliderThumbInnerStrokeWidthRest", "ctrlSliderThumbOuterStrokeWidth", "ctrlSliderThumbSizeHover", "ctrlSliderThumbSizePressed", "ctrlSliderThumbSizeRest", "ctrlSpinnerStrokeWidth", "ctrlSplitDividerStrokeWidth", "ctrlSplitDividerStrokeWidthOnOutline", "ctrlSplitDividerStrokeWidthOnSubtle", "ctrlTooltipMinHeight", "gapBetweenCard", "gapBetweenContentLarge", "gapBetweenContentMedium", "gapBetweenContentNone", "gapBetweenContentSmall", "gapBetweenContentXLarge", "gapBetweenContentXSmall", "gapBetweenContentXxLarge", "gapBetweenContentXxSmall", "gapBetweenContentXxxSmall", "gapBetweenCtrlDefault", "gapBetweenCtrlLgDefault", "gapBetweenCtrlLgNested", "gapBetweenCtrlNested", "gapBetweenCtrlSmDefault", "gapBetweenCtrlSmNested", "gapBetweenListItem", "gapBetweenTextLarge", "gapBetweenTextSmall", "gapInsideCtrlDefault", "gapInsideCtrlLgDefault", "gapInsideCtrlLgToLabel", "gapInsideCtrlLgToSecondaryIcon", "gapInsideCtrlSmDefault", "gapInsideCtrlSmToLabel", "gapInsideCtrlSmToSecondaryIcon", "gapInsideCtrlToLabel", "gapInsideCtrlToSecondaryIcon", "nullNumber", "paddingCardBodyDefaultInside", "paddingCardBodyDefaultOutside", "paddingCardBodyInsetDefault", "paddingCardBodyXSmallDefault", "paddingCardDefault", "paddingCardNestedDefault", "paddingCardNestedImage", "paddingContentAlignDefault", "paddingContentAlignOutdentIconOnSubtle", "paddingContentAlignOutdentTextOnSubtle", "paddingContentLarge", "paddingContentMedium", "paddingContentNone", "paddingContentSmall", "paddingContentXLarge", "paddingContentXSmall", "paddingContentXxLarge", "paddingContentXxSmall", "paddingContentXxxLarge", "paddingContentXxxSmall", "paddingCtrlHorizontalDefault", "paddingCtrlHorizontalIconOnly", "paddingCtrlLgHorizontalDefault", "paddingCtrlLgHorizontalIconOnly", "paddingCtrlLgTextBottom", "paddingCtrlLgTextTop", "paddingCtrlLgToNestedControl", "paddingCtrlSmHorizontalDefault", "paddingCtrlSmHorizontalIconOnly", "paddingCtrlSmTextBottom", "paddingCtrlSmTextTop", "paddingCtrlSmToNestedControl", "paddingCtrlTextBottom", "paddingCtrlTextSide", "paddingCtrlTextTop", "paddingCtrlToNestedControl", "paddingFlyoutDefault", "paddingListCardDefault", "paddingToolbarInside", "paddingToolbarOutside", "sizeCtrlDefault", "sizeCtrlIcon", "sizeCtrlIconSecondary", "sizeCtrlLgDefault", "sizeCtrlLgIcon", "sizeCtrlSmDefault", "sizeCtrlSmIcon", "strokeWidthCardDefault", "strokeWidthCtrlOutlineHover", "strokeWidthCtrlOutlinePressed", "strokeWidthCtrlOutlineRest", "strokeWidthCtrlOutlineSelected", "strokeWidthDefault", "strokeWidthDividerDefault", "strokeWidthDividerStrong", "strokeWidthWindowDefault"],
                i = ["ctrlAvatarActiveRingStrokeWidth", "ctrlAvatarPresenceBadgeStrokeWidth", "ctrlChoiceBaseStrokeWidthHover", "ctrlChoiceBaseStrokeWidthPressed", "ctrlChoiceBaseStrokeWidthRest", "ctrlChoiceBaseStrokeWidthSelected", "ctrlComposerInputBottomStrokeWidthHover", "ctrlComposerInputBottomStrokeWidthPressed", "ctrlComposerInputBottomStrokeWidthRest", "ctrlComposerInputBottomStrokeWidthSelectedRest", "ctrlComposerInputStrokeWidthHover", "ctrlComposerInputStrokeWidthPressed", "ctrlComposerInputStrokeWidthRest", "ctrlComposerInputStrokeWidthSelectedRest", "ctrlFocusInnerStrokeWidth", "ctrlFocusOuterStrokeWidth", "ctrlInputBottomLineStrokeWidthHover", "ctrlInputBottomLineStrokeWidthPressed", "ctrlInputBottomLineStrokeWidthRest", "ctrlInputBottomLineStrokeWidthSelected", "ctrlInputStrokeWidthHover", "ctrlInputStrokeWidthPressed", "ctrlInputStrokeWidthRest", "ctrlInputStrokeWidthSelected", "ctrlLinkInlineStrokeWidthHover", "ctrlLinkInlineStrokeWidthRest", "ctrlLinkOnPageStrokeWidthHover", "ctrlLinkOnPageStrokeWidthRest", "ctrlLiteFilterStrokeWidthSelected", "ctrlSliderThumbInnerStrokeWidthHover", "ctrlSliderThumbInnerStrokeWidthPressed", "ctrlSliderThumbInnerStrokeWidthRest", "ctrlSliderThumbOuterStrokeWidth", "ctrlSpinnerStrokeWidth", "ctrlSplitDividerStrokeWidth", "ctrlSplitDividerStrokeWidthOnOutline", "ctrlSplitDividerStrokeWidthOnSubtle", "strokeWidthCardDefault", "strokeWidthCtrlOutlineHover", "strokeWidthCtrlOutlinePressed", "strokeWidthCtrlOutlineRest", "strokeWidthCtrlOutlineSelected", "strokeWidthDefault", "strokeWidthDividerDefault", "strokeWidthDividerStrong", "strokeWidthWindowDefault"],
                n = ["cornerBezel", "cornerCardBodyInsetDefault", "cornerCardBodyInsetSmall", "cornerCardDefault", "cornerCardHover", "cornerCardNestedDefaultInside", "cornerCardNestedDefaultOutside", "cornerCardNestedSmallInside", "cornerCardNestedSmallOutside", "cornerCardPressed", "cornerCardRest", "cornerCardSmall", "cornerCircular", "cornerCtrlHover", "cornerCtrlLgHover", "cornerCtrlLgPressed", "cornerCtrlLgRest", "cornerCtrlPressed", "cornerCtrlRest", "cornerCtrlSmHover", "cornerCtrlSmPressed", "cornerCtrlSmRest", "cornerFavicon", "cornerFlyoutHover", "cornerFlyoutPressed", "cornerFlyoutRest", "cornerFlyoutShellRest", "cornerImageInCard", "cornerImageOnPage", "cornerLayerDefault", "cornerLayerIntersection", "cornerLayerMacOs", "cornerListCardDefault", "cornerListCardNestedDefault", "cornerToolbarDefault", "cornerWindowDefault", "cornerWindowMacOs", "cornerZero", "ctrlAvatarCornerGroup", "ctrlAvatarCornerItem", "ctrlBadgeCorner", "ctrlBadgeLgCorner", "ctrlBadgeSmCorner", "ctrlChoiceCheckboxCorner", "ctrlChoiceCheckboxIndeterminateCorner", "ctrlChoiceLgCheckboxCorner", "ctrlChoiceRadioCorner", "ctrlChoiceSmCheckboxCorner", "ctrlChoiceSwitchCorner", "ctrlCoachmarkCorner", "ctrlComposerContainerCorner", "ctrlComposerInputCornerHover", "ctrlComposerInputCornerPressed", "ctrlComposerInputCornerRest", "ctrlDialogBaseCorner", "ctrlFabCornerHover", "ctrlFabCornerPressed", "ctrlFabCornerRest", "ctrlListChoiceCheckboxCorner", "ctrlListCornerHover", "ctrlListCornerPressed", "ctrlListCornerRest", "ctrlListLgCornerHover", "ctrlListLgCornerPressed", "ctrlListLgCornerRest", "ctrlListSmCornerHover", "ctrlListSmCornerPressed", "ctrlListSmCornerRest", "ctrlProgressCorner", "ctrlSegmentedCornerHover", "ctrlSegmentedCornerPressed", "ctrlSegmentedCornerRest", "ctrlSegmentedItemCornerHover", "ctrlSegmentedItemCornerPressed", "ctrlSegmentedItemCornerRest", "ctrlSegmentedLgCornerHover", "ctrlSegmentedLgCornerPressed", "ctrlSegmentedLgCornerRest", "ctrlSegmentedLgItemCornerHover", "ctrlSegmentedLgItemCornerPressed", "ctrlSegmentedLgItemCornerRest", "ctrlSegmentedSmCornerHover", "ctrlSegmentedSmCornerPressed", "ctrlSegmentedSmCornerRest", "ctrlSegmentedSmItemCornerHover", "ctrlSegmentedSmItemCornerPressed", "ctrlSegmentedSmItemCornerRest", "ctrlSliderBarCorner", "ctrlSliderThumbCorner", "ctrlTooltipCorner"],
                d = [],
                a = [],
                c = [],
                s = [],
                g = ["accelerateMax", "accelerateMid", "accelerateMin", "decelerateMax", "decelerateMid", "decelerateMin", "easyEase", "easyEaseMax", "linear"],
                S = ["fast", "faster", "gentle", "normal", "slow", "slower", "ultraFast", "ultraSlow"],
                h = ["ctrlDialogBaseBgBlur", "materialAcrylicBlur", "materialMicaBlur"],
                C = ["ctrlAvatarShadow", "ctrlChoiceSwitchThumbShadow", "ctrlCoachmarkShadow", "ctrlComposerContainerShadow", "ctrlDialogBaseShadow", "ctrlFabShadowDisabled", "ctrlFabShadowHover", "ctrlFabShadowPressed", "ctrlFabShadowRest", "ctrlTooltipShadow", "shadowCardDisabled", "shadowCardHover", "shadowCardPressed", "shadowCardRest", "shadowCtrlBrand", "shadowCtrlNeutral", "shadowCtrlOnDrag", "shadowFlyout", "shadowLayer", "shadowToolbar", "shadowWindowActive", "shadowWindowInactive"],
                m = ["indeterminate"],
                u = ["globalDisplay1", "globalDisplay2", "globalTitle1Strong", "globalTitle1", "globalTitle2Strong", "globalTitle2", "globalBody1Strong", "globalBody1", "globalBody2Strong", "globalBody2", "globalBody3Strong", "globalBody3", "globalCaption1Strong", "globalCaption1", "globalCaption2", "pageHeaderSm", "pageHeaderMd", "pageHeaderLg", "pageHeader", "sectionHeaderSm", "sectionHeaderMd", "sectionHeaderLg", "sectionHeader", "subsectionHeaderSm", "subsectionHeaderMd", "subsectionHeaderLg", "subsectionHeader", "readingBodySm", "readingBodyMd", "readingBodyLg", "readingBody", "itemHeaderSm", "itemHeaderMd", "itemHeaderLg", "itemHeader", "itemBodySm", "itemBodyMd", "itemBodyLg", "itemBody", "metadataSm", "metadataMd", "metadataLg", "metadata", "legalSm", "legalMd", "legalLg", "legal", "labelControlSm", "labelControl", "labelControlLg", "labelControlSelectedSm", "labelControlSelected", "labelControlSelectedLg", "labelButtonSm", "labelButton", "labelButtonLg", "labelButtonSelectedSm", "labelButtonSelected", "labelButtonSelectedLg"];

            function p(e, ...t) {
                return "function" == typeof e ? e(...t) : e
            }

            function L(e, t) {
                return !!t ? .["data-force-hovered"] || e.isHovered
            }

            function b(e, t) {
                return !!t ? .["data-force-pressed"] || e.isPressed
            }

            function k(e, t) {
                return !!t ? .["data-force-focused"] || e.isFocused
            }

            function I(e, t) {
                return !!t ? .["data-force-focused"] || e.isFocusVisible
            }
            let B = ["2", "4", "8", "16", "28", "64", "brand2", "brand4", "brand8", "brand16", "brand28", "brand64"],
                W = (0, o.zu)({
                    override: {
                        theme: {
                            text: ["100", "200", "300", "400", "500", "600", "700", "800", "900", "1000"],
                            shadow: B,
                            "drop-shadow": B
                        }
                    },
                    extend: {
                        theme: {
                            radius: ["cornerCardRewards", "cornerCardNestedRewards"],
                            spacing: ["paddingCardRewards", "paddingCardBodyRewards"]
                        },
                        classGroups: {
                            typography: [{
                                text: ["caption2", "caption2Strong", "caption1", "caption1Strong", "caption1Stronger", "body1", "body1Strong", "body1Stronger", "body2", "subtitle2", "subtitle2Stronger", "subtitle1", "title3", "title2", "title1", "largeTitle", "display"]
                            }]
                        },
                        conflictingClassGroups: {
                            typography: ["font-size", "font-weight"]
                        }
                    }
                }, function(e) {
                    return (0, o.SV)(e, {
                        extend: {
                            theme: {
                                spacing: l,
                                radius: n,
                                text: d,
                                font: a,
                                "font-weight": c,
                                tracking: s,
                                ease: g,
                                shadow: C,
                                animate: m,
                                blur: h
                            },
                            classGroups: {
                                "mai.typography": [{
                                    text: u
                                }],
                                "border-w": [{
                                    border: i
                                }],
                                "border-w-x": [{
                                    "border-x": i
                                }],
                                "border-w-y": [{
                                    "border-y": i
                                }],
                                "border-w-s": [{
                                    "border-s": i
                                }],
                                "border-w-e": [{
                                    "border-e": i
                                }],
                                "border-w-t": [{
                                    "border-t": i
                                }],
                                "border-w-r": [{
                                    "border-r": i
                                }],
                                "border-w-b": [{
                                    "border-b": i
                                }],
                                "border-w-l": [{
                                    "border-l": i
                                }],
                                "outline-w": [{
                                    outline: i
                                }],
                                "ring-w": [{
                                    ring: i
                                }],
                                "inset-ring-w": [{
                                    "inset-ring": i
                                }],
                                "stroke-w": [{
                                    stroke: i
                                }],
                                duration: [{
                                    duration: S
                                }]
                            },
                            conflictingClassGroups: {
                                "mai.typography": ["font-size", "font-weight", "font-family", "tracking", "leading"]
                            }
                        }
                    })
                })
        }
    }
]);
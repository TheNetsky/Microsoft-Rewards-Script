(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7177], {
        143: (e, t, n) => {
            "use strict";
            n.d(t, {
                i: () => i
            });
            var r = n(79300);
            let i = (0, r.createServerReference)("70babbc81d2724f60d29a95c03b3d739cba77cea92", r.callServer, void 0, r.findSourceMapURL, "reportActivity")
        },
        8235: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => a
            });
            var r = n(20748),
                i = n(10812),
                s = n(23454),
                o = n(18828);

            function a(e) {
                let t, n, a = (0, i.c)(5),
                    {
                        children: l
                    } = e,
                    c = (0, s.useRouter)();
                a[0] !== c ? (t = function(e, t) {
                    c.push(e, t)
                }, a[0] = c, a[1] = t) : t = a[1];
                let u = t;
                return a[2] !== l || a[3] !== u ? (n = (0, r.jsx)(o.pg, {
                    navigate: u,
                    children: l
                }), a[2] = l, a[3] = u, a[4] = n) : n = a[4], n
            }
        },
        9943: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => a
            });
            var r = n(10812),
                i = n(37386),
                s = n(59328),
                o = n(32530);

            function a() {
                let e, t = (0, r.c)(1),
                    n = (0, s.useRef)(null);
                t[0] === Symbol.for("react.memo_cache_sentinel") ? (e = e => {
                    n.current || (n.current = window.location.pathname), o.C.logWebVitals(e.name, {
                        initialRenderPathname: n.current,
                        currentPathname: window.location.pathname,
                        value: e.value.toString(),
                        id: e.id,
                        label: e.label,
                        delta: e.delta.toString(),
                        entries: JSON.stringify(e.entries)
                    })
                }, t[0] = e) : e = t[0];
                let a = e;
                return (0, i.useReportWebVitals)(a), null
            }
        },
        22551: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => s
            });
            var r = n(10812),
                i = n(59328);

            function s() {
                let e, t = (0, r.c)(2),
                    n = (0, i.useSyncExternalStore)(l, o, a);
                return t[0] !== n ? (e = n ? JSON.parse(n) : void 0, t[0] = n, t[1] = e) : e = t[1], e
            }

            function o() {
                if (window.WcpConsent ? .siteConsent) return JSON.stringify({
                    isConsentRequired: window.WcpConsent.siteConsent.isConsentRequired,
                    consents: window.WcpConsent.siteConsent.getConsent()
                })
            }

            function a() {}

            function l(e) {
                return window.addEventListener("siteconsent-updated", e), () => {
                    window.removeEventListener("siteconsent-updated", e)
                }
            }
        },
        23194: (e, t, n) => {
            "use strict";
            n.d(t, {
                S: () => o,
                default: () => a
            });
            var r = n(20748),
                i = n(10812),
                s = n(59328);
            let o = (0, s.createContext)({
                enabled: !1
            });

            function a(e) {
                let t, n, a, l = (0, i.c)(6),
                    {
                        value: c,
                        children: u
                    } = e;
                return l[0] !== c.enabled ? (t = () => {
                    c.enabled ? document.documentElement.setAttribute("data-mai", "true") : document.documentElement.removeAttribute("data-mai")
                }, n = [c.enabled], l[0] = c.enabled, l[1] = t, l[2] = n) : (t = l[1], n = l[2]), (0, s.useEffect)(t, n), l[3] !== u || l[4] !== c ? (a = (0, r.jsx)(o.Provider, {
                    value: c,
                    children: u
                }), l[3] = u, l[4] = c, l[5] = a) : a = l[5], a
            }
        },
        32530: (e, t, n) => {
            "use strict";
            n.d(t, {
                C: () => a
            });
            var r = n(89122),
                i = n(41085),
                s = n(45362);
            class o {
                constructor() {
                    this.analytics = null
                }
                static getInstance() {
                    return o.instance || (o.instance = new o), o.instance
                }
                log(e, t) {
                    this.logEvent("Diagnostic", {
                        message: e,
                        props: JSON.stringify(t)
                    })
                }
                logPageAction(e, t, n) {
                    this.logEvent("PageAction", {
                        tag: e,
                        kind: t,
                        props: JSON.stringify(n)
                    })
                }
                logPageView(e, t, n) {
                    this.logEvent("PageView", {
                        path: e,
                        searchParams: t,
                        referrer: n
                    })
                }
                logError(e, t = !1) {
                    this.logEvent("Error", {
                        errorName: e.name,
                        errorMessage: e.message,
                        errorStack: e.stack || "",
                        isUnhandled: t.toString()
                    })
                }
                logWebVitals(e, t) {
                    this.logEvent("WebVitals", {
                        webVitalsMetric: e,
                        ...t
                    })
                }
                logEvent(e, t) {
                    try {
                        let n = window.telemetryContext || {},
                            r = window.location.pathname,
                            i = { ...t,
                                traceId: n.traceId,
                                anid: n.anid,
                                country: n.country,
                                language: n.language,
                                sessionId: n.sessionId,
                                path: r
                            };
                        if ("1" === s.env.NEXT_PUBLIC_TELEMETRY_CONSOLE_LOG_ENABLED && console.log(`[ClientTelemetry] ${e}:`, i), !this.analytics && !this.tryInitialize1DS()) return;
                        this.analytics ? .track({
                            name: "vnext_" + e,
                            data: i
                        })
                    } catch (e) {
                        "1" === s.env.NEXT_PUBLIC_TELEMETRY_CONSOLE_LOG_ENABLED && console.error("Error logging telemetry event:", e)
                    }
                }
                tryInitialize1DS() {
                    if (!window.telemetryContext) return "1" === s.env.NEXT_PUBLIC_TELEMETRY_CONSOLE_LOG_ENABLED && console.warn("[ClientTelemetry] Telemetry context is not set."), !1;
                    let e = window.telemetryContext.instrumentationKey;
                    if (!e) return !1;
                    let t = new r.a,
                        n = new i.I,
                        o = {
                            instrumentationKey: e,
                            channels: [
                                [n]
                            ],
                            extensionConfig: {
                                [n.identifier]: {
                                    storageKey: "vnextTelemetry"
                                }
                            }
                        };
                    return t.initialize(o, []), this.analytics = t, !0
                }
            }
            let a = o.getInstance()
        },
        41176: (e, t, n) => {
            Promise.resolve().then(n.t.bind(n, 58583, 23)), Promise.resolve().then(n.bind(n, 23194)), Promise.resolve().then(n.bind(n, 76645)), Promise.resolve().then(n.bind(n, 8235)), Promise.resolve().then(n.bind(n, 50591)), Promise.resolve().then(n.bind(n, 89448)), Promise.resolve().then(n.bind(n, 9943)), Promise.resolve().then(n.bind(n, 8962)), Promise.resolve().then(n.bind(n, 33389))
        },
        50591: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => o
            });
            var r = n(20748),
                i = n(10812),
                s = n(37003);

            function o(e) {
                let t, n = (0, i.c)(2),
                    {
                        instrumentationKey: o,
                        traceId: a,
                        anid: l,
                        country: c,
                        language: u,
                        sessionId: d
                    } = e,
                    f = `
        window.telemetryContext = {
          instrumentationKey: "${o||""}",
          rootTraceId: "${a||""}",
          traceId: "${a||""}",
          anid: "${l||""}",
          country: "${c||""}",
          language: "${u||""}",
          sessionId: "${d||""}"
        };
      `;
                return n[0] !== f ? (t = (0, r.jsx)(s.default, {
                    id: "telemetry-context",
                    strategy: "beforeInteractive",
                    children: f
                }), n[0] = f, n[1] = t) : t = n[1], t
            }
        },
        58583: () => {},
        76645: (e, t, n) => {
            "use strict";
            n.d(t, {
                H: () => c,
                default: () => u
            });
            var r = n(20748),
                i = n(10812),
                s = n(23454),
                o = n(59328),
                a = n(143),
                l = n(97863);
            let c = (0, o.createContext)({
                reportActivity: async () => !1
            });

            function u(e) {
                let t, n, u, m, v, g, E = (0, i.c)(10),
                    {
                        children: h
                    } = e,
                    y = (0, s.useRouter)(),
                    [b, w] = (0, o.useState)(0),
                    [C, S] = (0, o.useState)(!1),
                    [_, p] = (0, o.useState)(null);
                E[0] !== y ? (t = () => {
                    S(!1), p(Date.now()), y.refresh()
                }, E[0] = y, E[1] = t) : t = E[1];
                let P = t;
                (0, l.Z)(P, 0 === b && C ? 1e3 : null), E[2] !== _ || E[3] !== y ? (n = () => {
                    let e = () => {
                        if ("visible" === document.visibilityState) {
                            let e = Date.now();
                            (!_ || e - _ > 5e3) && (p(e), y.refresh())
                        }
                    };
                    return document.addEventListener("visibilitychange", e), () => {
                        document.removeEventListener("visibilitychange", e)
                    }
                }, u = [_, y], E[2] = _, E[3] = y, E[4] = n, E[5] = u) : (n = E[4], u = E[5]), (0, o.useEffect)(n, u), E[6] === Symbol.for("react.memo_cache_sentinel") ? (m = async (e, t) => {
                    w(f);
                    let n = await (0, a.i)(e, t ? .type ? ? 11, {
                        offerid: t ? .offerId,
                        isPromotional: t ? .isPromotional ? .toString(),
                        timezoneOffset: new Date().getTimezoneOffset().toString()
                    });
                    return w(d), n && S(!0), n
                }, E[6] = m) : m = E[6];
                let L = m;
                return E[7] === Symbol.for("react.memo_cache_sentinel") ? (v = {
                    reportActivity: L
                }, E[7] = v) : v = E[7], E[8] !== h ? (g = (0, r.jsx)(c.Provider, {
                    value: v,
                    children: h
                }), E[8] = h, E[9] = g) : g = E[9], g
            }

            function d(e) {
                return e - 1
            }

            function f(e) {
                return e + 1
            }
        },
        89448: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => s
            });
            var r = n(59328),
                i = n(22551);

            function s({
                projectId: e
            }) {
                let t = (0, i.A)(),
                    s = (0, r.useRef)(!1),
                    o = void 0 !== t && (!t.isConsentRequired || !!t.consents.Analytics);
                return (0, r.useEffect)(() => {
                    e && o && !s.current && t();
                    async function t() {
                        let t = (await n.e(4096).then(n.bind(n, 54096))).default;
                        t.init(e), t.consent(), s.current = !0
                    }
                }, [e, o]), null
            }
        },
        97863: (e, t, n) => {
            "use strict";
            n.d(t, {
                $: () => o,
                Z: () => s
            });
            var r = n(10812),
                i = n(59328);

            function s(e, t) {
                let n, s, o, a, l = (0, r.c)(6),
                    c = (0, i.useRef)(null);
                l[0] !== e ? (n = () => {
                    c.current = e
                }, s = [e], l[0] = e, l[1] = n, l[2] = s) : (n = l[1], s = l[2]), (0, i.useEffect)(n, s), l[3] !== t ? (o = () => {
                    if (null === t) return;
                    let e = setTimeout(() => c.current ? .(), t);
                    return () => clearTimeout(e)
                }, a = [t], l[3] = t, l[4] = o, l[5] = a) : (o = l[4], a = l[5]), (0, i.useEffect)(o, a)
            }

            function o(e, t) {
                let n, s, o, a, l = (0, r.c)(6),
                    c = (0, i.useRef)(null);
                l[0] !== e ? (n = () => {
                    c.current = e
                }, s = [e], l[0] = e, l[1] = n, l[2] = s) : (n = l[1], s = l[2]), (0, i.useEffect)(n, s), l[3] !== t ? (o = () => {
                    if (null === t) return;
                    let e = setInterval(() => c.current ? .(), t);
                    return () => clearInterval(e)
                }, a = [t], l[3] = t, l[4] = o, l[5] = a) : (o = l[4], a = l[5]), (0, i.useEffect)(o, a)
            }
        }
    },
    e => {
        e.O(0, [610, 2781, 7501, 8267, 7298, 7358], () => e(e.s = 41176)), _N_E = e.O()
    }
]);
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4530], {
        8392: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => c
            });
            var r = n(20748),
                l = n(10812),
                s = n(90769),
                i = n(75564),
                a = n(17244),
                o = n(72700);

            function c(e) {
                let t, n, c, u, d, f = (0, l.c)(12);
                f[0] !== e ? ({
                    className: t,
                    ...n
                } = e, f[0] = e, f[1] = t, f[2] = n) : (t = f[1], n = f[2]);
                let h = (0, a.A)(s.collapsibleHeaderMediaQuery);
                f[3] !== h ? (c = {
                    enabled: h
                }, f[3] = h, f[4] = c) : c = f[4];
                let v = (0, s.n)(c),
                    m = v && "top-0";
                return f[5] !== t || f[6] !== v || f[7] !== m ? (u = (0, i.tw)("top-25 transition-all duration-200 xl:top-14", m, (0, i.hd)(t, {
                    isActive: v
                })), f[5] = t, f[6] = v, f[7] = m, f[8] = u) : u = f[8], f[9] !== n || f[10] !== u ? (d = (0, r.jsx)(o.tE, {
                    className: u,
                    ...n
                }), f[9] = n, f[10] = u, f[11] = d) : d = f[11], d
            }
        },
        16280: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => a
            });
            var r = n(20748),
                l = n(10812),
                s = n(71389),
                i = n(22551);

            function a(e) {
                let t = (0, l.c)(2),
                    {
                        children: n
                    } = e,
                    a = (0, i.A)();
                if (a ? .isConsentRequired) {
                    let e;
                    return t[0] !== n ? (e = (0, r.jsx)(s.default, {
                        className: "cursor-pointer",
                        appearance: "subtle",
                        onPress: o,
                        children: n
                    }), t[0] = n, t[1] = e) : e = t[1], e
                }
                return null
            }

            function o() {
                return window ? .WcpConsent ? .siteConsent ? .manageConsent()
            }
        },
        17244: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => s
            });
            var r = n(10812),
                l = n(59328);

            function s(e, t) {
                let n, s, a, o = (0, r.c)(7),
                    c = void 0 !== t && t;
                o[0] !== e ? (n = t => {
                    if (!e) return i;
                    let n = window.matchMedia(e);
                    return n.addEventListener("change", t), () => {
                        n.removeEventListener("change", t)
                    }
                }, o[0] = e, o[1] = n) : n = o[1];
                let u = n;
                return o[2] !== c || o[3] !== e ? (s = () => e ? window.matchMedia(e).matches : c, o[2] = c, o[3] = e, o[4] = s) : s = o[4], o[5] !== c ? (a = () => c, o[5] = c, o[6] = a) : a = o[6], (0, l.useSyncExternalStore)(u, s, a)
            }

            function i() {}
        },
        22551: (e, t, n) => {
            "use strict";
            n.d(t, {
                A: () => s
            });
            var r = n(10812),
                l = n(59328);

            function s() {
                let e, t = (0, r.c)(2),
                    n = (0, l.useSyncExternalStore)(o, i, a);
                return t[0] !== n ? (e = n ? JSON.parse(n) : void 0, t[0] = n, t[1] = e) : e = t[1], e
            }

            function i() {
                if (window.WcpConsent ? .siteConsent) return JSON.stringify({
                    isConsentRequired: window.WcpConsent.siteConsent.isConsentRequired,
                    consents: window.WcpConsent.siteConsent.getConsent()
                })
            }

            function a() {}

            function o(e) {
                return window.addEventListener("siteconsent-updated", e), () => {
                    window.removeEventListener("siteconsent-updated", e)
                }
            }
        },
        25560: (e, t, n) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var r = {
                default: function() {
                    return b
                },
                handleClientScriptLoad: function() {
                    return w
                },
                initScriptLoader: function() {
                    return p
                }
            };
            for (var l in r) Object.defineProperty(t, l, {
                enumerable: !0,
                get: r[l]
            });
            let s = n(31710),
                i = n(16631),
                a = n(20748),
                o = s._(n(16785)),
                c = i._(n(59328)),
                u = n(98347),
                d = n(66255),
                f = n(58571),
                h = new Map,
                v = new Set,
                m = e => {
                    let {
                        src: t,
                        id: n,
                        onLoad: r = () => {},
                        onReady: l = null,
                        dangerouslySetInnerHTML: s,
                        children: i = "",
                        strategy: a = "afterInteractive",
                        onError: c,
                        stylesheets: u
                    } = e, f = n || t;
                    if (f && v.has(f)) return;
                    if (h.has(t)) {
                        v.add(f), h.get(t).then(r, c);
                        return
                    }
                    let m = () => {
                            l && l(), v.add(f)
                        },
                        w = document.createElement("script"),
                        p = new Promise((e, t) => {
                            w.addEventListener("load", function(t) {
                                e(), r && r.call(this, t), m()
                            }), w.addEventListener("error", function(e) {
                                t(e)
                            })
                        }).catch(function(e) {
                            c && c(e)
                        });
                    s ? (w.innerHTML = s.__html || "", m()) : i ? (w.textContent = "string" == typeof i ? i : Array.isArray(i) ? i.join("") : "", m()) : t && (w.src = t, h.set(t, p)), (0, d.setAttributesFromProps)(w, e), "worker" === a && w.setAttribute("type", "text/partytown"), w.setAttribute("data-nscript", a), u && (e => {
                        if (o.default.preinit) return e.forEach(e => {
                            o.default.preinit(e, {
                                as: "style"
                            })
                        }); {
                            let t = document.head;
                            e.forEach(e => {
                                let n = document.createElement("link");
                                n.type = "text/css", n.rel = "stylesheet", n.href = e, t.appendChild(n)
                            })
                        }
                    })(u), document.body.appendChild(w)
                };

            function w(e) {
                let {
                    strategy: t = "afterInteractive"
                } = e;
                "lazyOnload" === t ? window.addEventListener("load", () => {
                    (0, f.requestIdleCallback)(() => m(e))
                }) : m(e)
            }

            function p(e) {
                e.forEach(w), [...document.querySelectorAll('[data-nscript="beforeInteractive"]'), ...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(e => {
                    let t = e.id || e.getAttribute("src");
                    v.add(t)
                })
            }

            function g(e) {
                let {
                    id: t,
                    src: n = "",
                    onLoad: r = () => {},
                    onReady: l = null,
                    strategy: s = "afterInteractive",
                    onError: i,
                    stylesheets: d,
                    ...h
                } = e, {
                    updateScripts: w,
                    scripts: p,
                    getIsSsr: g,
                    appDir: b,
                    nonce: x
                } = (0, c.useContext)(u.HeadManagerContext);
                x = h.nonce || x;
                let y = (0, c.useRef)(!1);
                (0, c.useEffect)(() => {
                    let e = t || n;
                    y.current || (l && e && v.has(e) && l(), y.current = !0)
                }, [l, t, n]);
                let _ = (0, c.useRef)(!1);
                if ((0, c.useEffect)(() => {
                        if (!_.current) {
                            if ("afterInteractive" === s) m(e);
                            else "lazyOnload" === s && ("complete" === document.readyState ? (0, f.requestIdleCallback)(() => m(e)) : window.addEventListener("load", () => {
                                (0, f.requestIdleCallback)(() => m(e))
                            }));
                            _.current = !0
                        }
                    }, [e, s]), ("beforeInteractive" === s || "worker" === s) && (w ? (p[s] = (p[s] || []).concat([{
                        id: t,
                        src: n,
                        onLoad: r,
                        onReady: l,
                        onError: i,
                        ...h,
                        nonce: x
                    }]), w(p)) : g && g() ? v.add(t || n) : g && !g() && m({ ...e,
                        nonce: x
                    })), b) {
                    if (d && d.forEach(e => {
                            o.default.preinit(e, {
                                as: "style"
                            })
                        }), "beforeInteractive" === s)
                        if (!n) return h.dangerouslySetInnerHTML && (h.children = h.dangerouslySetInnerHTML.__html, delete h.dangerouslySetInnerHTML), (0, a.jsx)("script", {
                            nonce: x,
                            dangerouslySetInnerHTML: {
                                __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify([0,{...h,id:t}])})`
                            }
                        });
                        else return o.default.preload(n, h.integrity ? {
                            as: "script",
                            integrity: h.integrity,
                            nonce: x,
                            crossOrigin: h.crossOrigin
                        } : {
                            as: "script",
                            nonce: x,
                            crossOrigin: h.crossOrigin
                        }), (0, a.jsx)("script", {
                            nonce: x,
                            dangerouslySetInnerHTML: {
                                __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify([n,{...h,id:t}])})`
                            }
                        });
                    "afterInteractive" === s && n && o.default.preload(n, h.integrity ? {
                        as: "script",
                        integrity: h.integrity,
                        nonce: x,
                        crossOrigin: h.crossOrigin
                    } : {
                        as: "script",
                        nonce: x,
                        crossOrigin: h.crossOrigin
                    })
                }
                return null
            }
            Object.defineProperty(g, "__nextScript", {
                value: !0
            });
            let b = g;
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        31905: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => c
            });
            var r = n(20748),
                l = n(10812),
                s = n(23454),
                i = n(59328),
                a = n(66752),
                o = n(75564);

            function c(e) {
                let t, n, c, u, d, f, h, v = (0, l.c)(17),
                    {
                        links: m
                    } = e,
                    w = (0, s.usePathname)();
                v[0] !== m || v[1] !== w ? (t = m.find(e => "/" === e.Url ? "/" === w : w.startsWith(e.Url)) ? .Url ? ? w, v[0] = m, v[1] = w, v[2] = t) : t = v[2];
                let p = t,
                    [g, b] = (0, i.useState)(!0),
                    [x, y] = (0, i.useState)(!0),
                    _ = (0, i.useRef)(null),
                    C = (0, i.useRef)(null);
                v[3] === Symbol.for("react.memo_cache_sentinel") ? (n = () => {
                    let e = _.current;
                    if (!e) return;
                    C.current ? .scrollIntoView({
                        inline: "center"
                    });
                    let t = () => {
                        b(12 > Math.abs(e.scrollLeft)), y(e.scrollWidth - Math.abs(e.scrollLeft) - e.clientWidth < 12)
                    };
                    return e.addEventListener("scroll", t), t(), () => {
                        e.removeEventListener("scroll", t)
                    }
                }, c = [], v[3] = n, v[4] = c) : (n = v[3], c = v[4]), (0, i.useEffect)(n, c);
                let E = "";
                if (g || x ? g ? x || (E = "mask-l-to-12 rtl:mask-r-to-12") : E = "mask-r-to-12 rtl:mask-l-to-12" : E = "mask-x-to-12", v[5] !== m || v[6] !== p) {
                    let e;
                    v[8] !== p ? (e = e => ({
                        title: e.Title,
                        url: e.Url,
                        isSelected: e.Url === p
                    }), v[8] = p, v[9] = e) : e = v[9], u = m.map(e), v[5] = m, v[6] = p, v[7] = u
                } else u = v[7];
                let j = u;
                return v[10] !== E ? (d = (0, o.tw)("scrollbar-none overflow-x-auto mask-invert", "mai:[&_a]:-outline-offset-2", E), v[10] = E, v[11] = d) : d = v[11], v[12] !== j ? (f = (0, r.jsx)(a.A, {
                    links: j,
                    selectedRef: C
                }), v[12] = j, v[13] = f) : f = v[13], v[14] !== d || v[15] !== f ? (h = (0, r.jsx)("div", {
                    className: d,
                    ref: _,
                    children: f
                }), v[14] = d, v[15] = f, v[16] = h) : h = v[16], h
            }
        },
        37003: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => l.a
            });
            var r = n(25560),
                l = n.n(r)
        },
        58571: (e, t) => {
            "use strict";
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = {
                cancelIdleCallback: function() {
                    return s
                },
                requestIdleCallback: function() {
                    return l
                }
            };
            for (var r in n) Object.defineProperty(t, r, {
                enumerable: !0,
                get: n[r]
            });
            let l = "u" > typeof self && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function(e) {
                    let t = Date.now();
                    return self.setTimeout(function() {
                        e({
                            didTimeout: !1,
                            timeRemaining: function() {
                                return Math.max(0, 50 - (Date.now() - t))
                            }
                        })
                    }, 1)
                },
                s = "u" > typeof self && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function(e) {
                    return clearTimeout(e)
                };
            ("function" == typeof t.default || "object" == typeof t.default && null !== t.default) && void 0 === t.default.__esModule && (Object.defineProperty(t.default, "__esModule", {
                value: !0
            }), Object.assign(t.default, t), e.exports = t.default)
        },
        60486: (e, t, n) => {
            "use strict";
            n.d(t, {
                default: () => c
            });
            var r = n(20748),
                l = n(10812),
                s = n(92837),
                i = n(37003),
                a = n(59328);

            function o() {
                window.dispatchEvent(new Event("siteconsent-updated"))
            }

            function c() {
                let e, t, n, c = (0, l.c)(5),
                    f = (0, a.useRef)(null),
                    h = (0, s.Ym)();
                c[0] !== h ? (e = function() {
                    let e = window.matchMedia("(prefers-color-scheme: dark)"),
                        t = e.matches ? window.WcpConsent.themes.dark : window.WcpConsent.themes.light;
                    e.addEventListener("change", d), window.WcpConsent.init(h, f.current, u, o, t)
                }, c[0] = h, c[1] = e) : e = c[1];
                let v = e;
                return c[2] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, r.jsx)("div", {
                    ref: f,
                    className: "sticky inset-x-0 bottom-0 z-30 shadow-4 *:transition-transform *:duration-200 *:ease-easyEase *:starting:translate-y-full"
                }), c[2] = t) : t = c[2], c[3] !== v ? (n = (0, r.jsxs)(r.Fragment, {
                    children: [t, (0, r.jsx)(i.default, {
                        strategy: "lazyOnload",
                        onLoad: v,
                        src: "https://wcpstatic.microsoft.com/mscc/lib/v2/wcp-consent.js"
                    })]
                }), c[3] = v, c[4] = n) : n = c[4], n
            }

            function u(e) {
                o()
            }

            function d(e) {
                let t = new CustomEvent("theme-changed", {
                    detail: {
                        currentTheme: e.matches ? window.WcpConsent.themes.dark : window.WcpConsent.themes.light
                    }
                });
                window.dispatchEvent(t)
            }
        },
        65177: (e, t, n) => {
            "use strict";
            n.d(t, {
                IM: () => o,
                O9: () => c,
                HX: () => d,
                zz: () => u,
                ux: () => f
            });
            let r = /[\(\[\{][^\)\]\}]*[\)\]\}]/g,
                l = /[\0-\u001F\!-/:-@\[-`\{-\u00BF\u0250-\u036F\uD800-\uFFFF]/g,
                s = /^\d+[\d\s]*(:?ext|x|)\s*\d+$/i,
                i = /\s+/g,
                a = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\u1100-\u11FF\u3130-\u318F\uA960-\uA97F\uAC00-\uD7AF\uD7B0-\uD7FF\u3040-\u309F\u30A0-\u30FF\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF]|[\uD840-\uD869][\uDC00-\uDED6]/;

            function o(e, t, n) {
                var o;
                let c, u;
                if (!e) return "";
                let d = e.replace(r, "").replace(l, "").replace(i, " ").trim();
                return a.test(d) || !n ? .allowPhoneInitials && s.test(d) ? "" : (o = n ? .firstInitialOnly, c = "", (0 !== (u = d.split(" ")).length && (c += u[0].charAt(0).toUpperCase()), o || (2 === u.length ? c += u[1].charAt(0).toUpperCase() : 3 === u.length && (c += u[2].charAt(0).toUpperCase())), t && c.length > 1) ? c.charAt(1) + c.charAt(0) : c)
            }

            function c(e) {
                return null != e
            }

            function u(e) {
                return !!e
            }

            function d(e, t) {
                return (e & t) === t
            }

            function f(e, t) {
                return Array.from({
                    length: e
                }, (e, n) => "function" == typeof t ? t(n) : t)
            }
        },
        68041: (e, t, n) => {
            "use strict";
            n.d(t, {
                PopoverRef: () => d,
                default: () => u
            });
            var r = n(20748),
                l = n(10812),
                s = n(59328),
                i = n(69190),
                a = n(22995),
                o = n(84429),
                c = n(75564);

            function u(e) {
                let t, n, s, a, u, d, f, h, v = (0, l.c)(16);
                v[0] !== e ? ({
                    showArrow: d,
                    offset: s,
                    ref: u,
                    isTooltip: n,
                    children: t,
                    ...a
                } = e, v[0] = e, v[1] = t, v[2] = n, v[3] = s, v[4] = a, v[5] = u, v[6] = d) : (t = v[1], n = v[2], s = v[3], a = v[4], u = v[5], d = v[6]);
                let m = s ? ? 8;
                return v[7] !== t || v[8] !== n || v[9] !== d ? (f = e => (0, r.jsxs)(r.Fragment, {
                    children: [d && (0, r.jsx)(o.A, {
                        placement: e.placement,
                        isTooltip: n
                    }), (0, c.hd)(t, e)]
                }), v[7] = t, v[8] = n, v[9] = d, v[10] = f) : f = v[10], v[11] !== a || v[12] !== u || v[13] !== m || v[14] !== f ? (h = (0, r.jsx)(i.A, { ...a,
                    ref: u,
                    offset: m,
                    children: f
                }), v[11] = a, v[12] = u, v[13] = m, v[14] = f, v[15] = h) : h = v[15], h
            }

            function d(e) {
                let t, n, o = (0, l.c)(4),
                    {
                        children: c,
                        className: u
                    } = e,
                    d = (0, s.useRef)(null);
                return o[0] === Symbol.for("react.memo_cache_sentinel") ? (t = [
                    [i.n, {
                        triggerRef: d
                    }]
                ], o[0] = t) : t = o[0], o[1] !== c || o[2] !== u ? (n = (0, r.jsx)(a.Kq, {
                    values: t,
                    children: (0, r.jsx)("div", {
                        ref: d,
                        className: u,
                        children: c
                    })
                }), o[1] = c, o[2] = u, o[3] = n) : n = o[3], n
            }
        },
        82008: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => i
            });
            var r, l = n(59328);

            function s() {
                return (s = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            let i = function(e) {
                return l.createElement("svg", s({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), r || (r = l.createElement("path", {
                    fill: "currentColor",
                    d: "m10.946 2.047.005.007Q11.469 2 12 2c5.522 0 10 4.477 10 10s-4.478 10-10 10a9.98 9.98 0 0 1-7.896-3.862h-.003v-.003A9.96 9.96 0 0 1 2 12c0-5.162 3.911-9.41 8.932-9.944zM12 3.5l-.16.001c.123.245.255.533.374.85.347.923.666 2.282.1 3.487-.522 1.113-1.424 1.4-2.09 1.573l-.084.021c-.657.17-.91.235-1.093.514-.17.257-.144.582.061 1.25l.046.148c.082.258.18.57.23.863.064.364.082.827-.152 1.275a2.2 2.2 0 0 1-.9.945c-.341.185-.694.256-.958.302l-.093.017c-.515.09-.761.134-1 .39-.187.2-.307.553-.377 1.079-.029.214-.046.427-.064.646l-.01.117c-.02.242-.044.521-.099.76v.002a8.48 8.48 0 0 0 6.27 2.76c1.576 0 3.053-.43 4.319-1.178a5 5 0 0 1-.31-.35c-.34-.428-.786-1.164-.631-2.033.074-.418.298-.768.515-1.036a7 7 0 0 1 .72-.74l.158-.146c.179-.163.33-.301.46-.437.172-.18.21-.262.212-.267.068-.224-.015-.384-.106-.454a.3.3 0 0 0-.19-.061c-.084 0-.22.024-.401.14a.91.91 0 0 1-.836.085 1.02 1.02 0 0 1-.486-.432c-.144-.237-.225-.546-.278-.772-.04-.174-.08-.372-.115-.553l-.04-.206a4 4 0 0 0-.134-.54l-.02-.037a2 2 0 0 0-.064-.105 6 6 0 0 0-.227-.317l-.11-.143a13 13 0 0 1-.516-.712c-.196-.298-.417-.688-.487-1.104a1.46 1.46 0 0 1 .055-.734c.094-.264.265-.482.487-.649.483-.362 1.193-1.172 1.823-1.959.288-.359.544-.695.736-.95A8.46 8.46 0 0 0 12 3.5m5.727 2.22c-.197.263-.461.608-.757.978-.602.751-1.4 1.685-2.05 2.187.026.1.1.262.255.498.131.2.281.396.44.604l.129.17c.172.229.411.548.52.844a5 5 0 0 1 .198.762l.049.246q.037.195.075.37c.601-.172 1.201-.068 1.67.294.608.47.862 1.286.624 2.074-.11.362-.364.66-.563.869-.17.177-.372.362-.556.53l-.132.12c-.23.212-.423.4-.568.579-.148.184-.195.299-.205.356-.04.219.067.51.328.838a3 3 0 0 0 .374.392A8.48 8.48 0 0 0 20.5 12a8.48 8.48 0 0 0-2.773-6.28M3.5 12c0 1.398.338 2.718.936 3.881.085-.557.262-1.248.748-1.768.6-.642 1.335-.763 1.798-.839l.13-.021c.248-.044.391-.083.502-.143.088-.049.188-.128.288-.321.015-.028.042-.107.004-.325a5 5 0 0 0-.172-.636q-.03-.09-.06-.192c-.185-.604-.48-1.602.12-2.515.522-.792 1.36-.994 1.893-1.123l.162-.04c.563-.145.883-.28 1.108-.758.295-.629.168-1.485-.146-2.32a7.6 7.6 0 0 0-.58-1.196A8.5 8.5 0 0 0 3.502 12Z"
                })))
            }
        },
        83131: (e, t, n) => {
            Promise.resolve().then(n.bind(n, 8392)), Promise.resolve().then(n.bind(n, 60486)), Promise.resolve().then(n.bind(n, 40862)), Promise.resolve().then(n.bind(n, 34813)), Promise.resolve().then(n.bind(n, 85833)), Promise.resolve().then(n.bind(n, 77128)), Promise.resolve().then(n.bind(n, 71389)), Promise.resolve().then(n.bind(n, 96471)), Promise.resolve().then(n.bind(n, 16280)), Promise.resolve().then(n.bind(n, 15569)), Promise.resolve().then(n.bind(n, 31905)), Promise.resolve().then(n.bind(n, 68041)), Promise.resolve().then(n.bind(n, 90769)), Promise.resolve().then(n.bind(n, 84710)), Promise.resolve().then(n.bind(n, 82008)), Promise.resolve().then(n.bind(n, 98937)), Promise.resolve().then(n.bind(n, 8962))
        },
        84710: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => i
            });
            var r, l = n(59328);

            function s() {
                return (s = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            let i = function(e) {
                return l.createElement("svg", s({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none"
                }, e), r || (r = l.createElement("path", {
                    fill: "currentColor",
                    d: "M6.799 17.803a1.01 1.01 0 0 1-1.4-.199.98.98 0 0 1-.199-.59v-2.172h-.6c-1.436 0-2.6-1.149-2.6-2.566v-6.71C2 4.149 3.164 3 4.6 3h10.8C16.836 3 18 4.149 18 5.566v6.71c0 1.418-1.164 2.566-2.6 2.566h-4.59z"
                })))
            }
        },
        85833: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => m
            });
            var r, l = n(20748),
                s = n(10812),
                i = n(65177),
                a = n(84662),
                o = n(59328),
                c = n(34813);

            function u() {
                return (u = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            let d = function(e) {
                return o.createElement("svg", u({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), r || (r = o.createElement("path", {
                    fill: "currentColor",
                    d: "M17.754 14a2.25 2.25 0 0 1 2.25 2.249v.575c0 .894-.32 1.76-.902 2.438-1.57 1.834-3.957 2.739-7.102 2.739s-5.532-.905-7.098-2.74a3.75 3.75 0 0 1-.898-2.435v-.577a2.25 2.25 0 0 1 2.249-2.25h11.501Zm0 1.5H6.253a.75.75 0 0 0-.75.749v.577c0 .536.192 1.054.54 1.461 1.253 1.468 3.219 2.214 5.957 2.214s4.706-.746 5.962-2.214a2.25 2.25 0 0 0 .541-1.463v-.575a.75.75 0 0 0-.749-.75ZM12 2.004a5 5 0 1 1 0 10 5 5 0 0 1 0-10m0 1.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7"
                })))
            };
            var f = n(75564),
                h = n(81893);
            let v = (0, n(15053).F)(["grid", "place-items-center", "relative", "overflow-hidden", "rounded-full", "select-none", "font-semibold"], {
                    variants: {
                        size: {
                            16: ["h-4", "w-4", "text-100", "[&>svg]:size-3"],
                            20: ["h-5", "w-5", "text-100", "[&>svg]:size-4"],
                            24: ["h-6", "w-6", "text-100", "[&>svg]:size-4"],
                            28: ["h-7", "w-7", "text-200", "[&>svg]:size-5"],
                            32: ["h-8", "w-8", "text-300", "[&>svg]:size-5"],
                            36: ["h-9", "w-9", "text-300", "[&>svg]:size-5"],
                            40: ["h-10", "w-10", "text-300", "[&>svg]:size-5"],
                            48: ["h-12", "w-12", "text-400", "[&>svg]:size-6"],
                            56: ["h-14", "w-14", "text-400", "[&>svg]:size-7"],
                            64: ["h-16", "w-16", "text-500", "[&>svg]:size-8"],
                            72: ["h-18", "w-18", "text-500", "[&>svg]:size-8"],
                            96: ["h-24", "w-24", "text-500", "[&>svg]:size-12"],
                            120: ["h-30", "w-30", "text-600", "[&>svg]:size-12"],
                            128: ["h-32", "w-32", "text-600", "[&>svg]:size-12"]
                        },
                        hasInitials: {
                            true: ["text-neutralFgOnBrand", "bg-brandBg1"],
                            false: ["text-neutralFg3", "bg-neutralBg6"]
                        },
                        hasImage: {
                            true: ["bg-neutralBg1"],
                            false: null
                        }
                    }
                }),
                m = (0, h.A)(function(e) {
                    let t, n, r, u, h, m = (0, s.c)(20),
                        {
                            name: w,
                            initials: p,
                            image: g,
                            size: b,
                            className: x
                        } = e,
                        y = void 0 === b ? 32 : b,
                        [_, C] = (0, o.useState)(!1),
                        [E, j] = (0, o.useState)(g);
                    E !== g && (C(!1), j(g));
                    let O = (0, a.c)("General");
                    m[0] !== p || m[1] !== w ? (t = p ? ? (0, i.IM)(w, !1), m[0] = p, m[1] = w, m[2] = t) : t = m[2];
                    let A = t;
                    m[3] !== A ? (n = A ? (0, l.jsx)("p", {
                        children: A
                    }) : (0, l.jsx)(d, {}), m[3] = A, m[4] = n) : n = m[4];
                    let F = n,
                        P = !!g && !_,
                        S = !!A;
                    return m[5] !== x || m[6] !== P || m[7] !== y || m[8] !== S ? (r = (0, f.tw)(v({
                        size: y,
                        hasInitials: S,
                        hasImage: P
                    }), "leading-none", x), m[5] = x, m[6] = P, m[7] = y, m[8] = S, m[9] = r) : r = m[9], m[10] !== P || m[11] !== g || m[12] !== w || m[13] !== y || m[14] !== F || m[15] !== O ? (u = P ? (0, l.jsx)(c.default, {
                        src: g,
                        alt: w || O("avatarLabel"),
                        width: y,
                        height: y,
                        onError: () => C(!0)
                    }) : F, m[10] = P, m[11] = g, m[12] = w, m[13] = y, m[14] = F, m[15] = O, m[16] = u) : u = m[16], m[17] !== r || m[18] !== u ? (h = (0, l.jsx)("div", {
                        className: r,
                        children: u
                    }), m[17] = r, m[18] = u, m[19] = h) : h = m[19], h
                }, function(e) {
                    let t, n, r, u, h, v = (0, s.c)(16),
                        {
                            name: m,
                            initials: w,
                            image: p,
                            className: g
                        } = e,
                        [b, x] = (0, o.useState)(!1),
                        [y, _] = (0, o.useState)(p);
                    y !== p && (x(!1), _(p));
                    let C = (0, a.c)("General");
                    v[0] !== w || v[1] !== m ? (t = w ? ? (0, i.IM)(m, !1), v[0] = w, v[1] = m, v[2] = t) : t = v[2];
                    let E = t;
                    v[3] !== E ? (n = E ? (0, l.jsx)("p", {
                        children: E
                    }) : (0, l.jsx)(d, {
                        className: "size-5"
                    }), v[3] = E, v[4] = n) : n = v[4];
                    let j = n,
                        O = !!p && !b;
                    return v[5] !== g ? (r = (0, f.tw)("relative grid place-items-center select-none", "size-8 overflow-hidden rounded-ctrlAvatarCornerItem", "bg-ctrlAvatarBg text-itemHeader text-ctrlAvatarFg shadow-ctrlAvatarShadow", g), v[5] = g, v[6] = r) : r = v[6], v[7] !== O || v[8] !== p || v[9] !== m || v[10] !== j || v[11] !== C ? (u = O ? (0, l.jsx)(c.default, {
                        src: p,
                        alt: m || C("avatarLabel"),
                        width: 32,
                        height: 32,
                        onError: () => x(!0)
                    }) : j, v[7] = O, v[8] = p, v[9] = m, v[10] = j, v[11] = C, v[12] = u) : u = v[12], v[13] !== r || v[14] !== u ? (h = (0, l.jsx)("div", {
                        className: r,
                        children: u
                    }), v[13] = r, v[14] = u, v[15] = h) : h = v[15], h
                }, function(e) {
                    let {
                        size: t,
                        ...n
                    } = e;
                    return n
                })
        },
        90769: (e, t, n) => {
            "use strict";
            n.d(t, {
                ScrollDownListener: () => c,
                collapsibleHeaderMediaQuery: () => o,
                n: () => u
            });
            var r = n(20748),
                l = n(10812),
                s = n(59328),
                i = n(75564),
                a = n(17244);
            let o = "(max-width: 1023px)";

            function c(e) {
                let t, n, s, o = (0, l.c)(9),
                    {
                        mediaQuery: c,
                        activeClassName: d,
                        className: f,
                        children: h,
                        ref: v
                    } = e,
                    m = (0, a.A)(c, !0);
                o[0] !== m ? (t = {
                    enabled: m
                }, o[0] = m, o[1] = t) : t = o[1];
                let w = u(t) && d;
                return o[2] !== f || o[3] !== w ? (n = (0, i.tw)(f, w), o[2] = f, o[3] = w, o[4] = n) : n = o[4], o[5] !== h || o[6] !== v || o[7] !== n ? (s = (0, r.jsx)("div", {
                    className: n,
                    ref: v,
                    children: h
                }), o[5] = h, o[6] = v, o[7] = n, o[8] = s) : s = o[8], s
            }

            function u(e) {
                let t, n, r = (0, l.c)(4),
                    i = e ? .enabled ? ? !0,
                    a = e ? .threshold ? ? 100,
                    [o, c] = (0, s.useState)(!1);
                return !i && o && c(!1), r[0] !== i || r[1] !== a ? (t = () => {
                    if (!i) return;
                    let e = window.scrollY,
                        t = window.innerWidth,
                        n = () => {
                            let n = window.scrollY,
                                r = window.innerWidth;
                            if (r === t && n !== e) {
                                let t = n > e,
                                    r = n > a;
                                c(t && r)
                            }
                            e = Math.max(n, 0), t = r
                        };
                    return window.addEventListener("scroll", n), () => {
                        window.removeEventListener("scroll", n)
                    }
                }, n = [i, a], r[0] = i, r[1] = a, r[2] = t, r[3] = n) : (t = r[2], n = r[3]), (0, s.useEffect)(t, n), o
            }
        },
        98937: (e, t, n) => {
            "use strict";
            n.r(t), n.d(t, {
                default: () => i
            });
            var r, l = n(59328);

            function s() {
                return (s = Object.assign ? Object.assign.bind() : function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var n = arguments[t];
                        for (var r in n)({}).hasOwnProperty.call(n, r) && (e[r] = n[r])
                    }
                    return e
                }).apply(null, arguments)
            }
            let i = function(e) {
                return l.createElement("svg", s({
                    xmlns: "http://www.w3.org/2000/svg",
                    fill: "none",
                    viewBox: "0 0 24 24"
                }, e), r || (r = l.createElement("path", {
                    fill: "currentColor",
                    d: "m13.855 10.507 7.26-8.257h-1.72L13.09 9.42 8.057 2.25H2.25l7.613 10.841L2.25 21.75h1.72l6.657-7.571 5.316 7.571h5.807z"
                })))
            }
        }
    },
    e => {
        e.O(0, [2781, 9555, 9135, 4003, 9553, 4622, 4813, 6697, 3163, 5569, 5834, 8267, 7298, 7358], () => e(e.s = 83131)), _N_E = e.O()
    }
]);
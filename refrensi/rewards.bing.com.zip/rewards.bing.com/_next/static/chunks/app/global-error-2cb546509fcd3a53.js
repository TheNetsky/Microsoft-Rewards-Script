(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [4219], {
        8962: (e, t, r) => {
            "use strict";
            r.d(t, {
                default: () => s
            });
            var l = r(92837),
                a = r(20748);

            function s({
                locale: e,
                ...t
            }) {
                if (!e) throw Error(void 0);
                return (0, a.jsx)(l.Dk, {
                    locale: e,
                    ...t
                })
            }
        },
        58583: () => {},
        58598: (e, t, r) => {
            Promise.resolve().then(r.bind(r, 97391))
        },
        74970: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                default: () => d
            });
            var l = r(20748),
                a = r(10812),
                s = r(84662),
                i = r(59328),
                n = r(75564);

            function c(e) {
                let t, r, s, i, c = (0, a.c)(10),
                    {
                        title: o,
                        description: d,
                        className: u
                    } = e;
                return c[0] !== u ? (t = (0, n.tw)("pg-content h-full py-6 lg:py-10", "min-h-[calc(100vh-100px)] xl:min-h-[calc(100vh-56px)]", "flex flex-col items-center justify-center gap-6", u), c[0] = u, c[1] = t) : t = c[1], c[2] !== o ? (r = (0, l.jsx)("p", {
                    className: "text-title2 lg:text-largeTitle mai:text-globalDisplay2 mai:xl:text-globalDisplay1",
                    children: o
                }), c[2] = o, c[3] = r) : r = c[3], c[4] !== d ? (s = (0, l.jsx)("div", {
                    className: "text-neutralFg3 lg:text-body2 mai:text-readingBody mai:text-fgCtrlNeutralSecondaryRest",
                    children: d
                }), c[4] = d, c[5] = s) : s = c[5], c[6] !== t || c[7] !== r || c[8] !== s ? (i = (0, l.jsxs)("div", {
                    className: t,
                    children: [r, s]
                }), c[6] = t, c[7] = r, c[8] = s, c[9] = i) : i = c[9], i
            }
            var o = r(32530);

            function d(e) {
                let t, r, n, d, u, x = (0, a.c)(10),
                    {
                        error: h
                    } = e;
                x[0] !== h ? (t = () => {
                    o.C.logError(h, !0)
                }, r = [h], x[0] = h, x[1] = t, x[2] = r) : (t = x[1], r = x[2]), (0, i.useEffect)(t, r);
                let f = (0, s.c)("Errors.Unhandled");
                return x[3] !== f ? (n = f("title"), x[3] = f, x[4] = n) : n = x[4], x[5] !== f ? (d = f("description"), x[5] = f, x[6] = d) : d = x[6], x[7] !== n || x[8] !== d ? (u = (0, l.jsx)("div", {
                    className: "fixed inset-0 z-50 bg-rewardsBgBrand1 mai:bg-bgWebPagePrimary",
                    children: (0, l.jsx)(c, {
                        title: n,
                        description: d
                    })
                }), x[7] = n, x[8] = d, x[9] = u) : u = x[9], u
            }
        },
        84662: (e, t, r) => {
            "use strict";
            r.d(t, {
                c: () => s,
                k: () => i
            });
            var l = r(92837);

            function a(e, t) {
                return (...e) => {
                    try {
                        return t(...e)
                    } catch {
                        throw Error(void 0)
                    }
                }
            }
            let s = a(0, l.c3),
                i = a(0, l.kc)
        },
        97391: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                default: () => n
            });
            var l = r(20748),
                a = r(10812),
                s = r(8962),
                i = r(74970);

            function n(e) {
                let t, r, n = (0, a.c)(3);
                n[0] === Symbol.for("react.memo_cache_sentinel") ? (t = {
                    Errors: {
                        Unhandled: {
                            title: "Something went wrong!",
                            description: "Sorry, we couldn't process your request. Please try again later."
                        }
                    }
                }, n[0] = t) : t = n[0];
                let c = t;
                return n[1] !== e ? (r = (0, l.jsx)("html", {
                    children: (0, l.jsx)("body", {
                        children: (0, l.jsx)(s.default, {
                            locale: "en",
                            messages: c,
                            children: (0, l.jsx)(i.default, { ...e
                            })
                        })
                    })
                }), n[1] = e, n[2] = r) : r = n[2], r
            }
            r(58583)
        }
    },
    e => {
        e.O(0, [610, 2781, 9555, 6697, 8267, 7298, 7358], () => e(e.s = 58598)), _N_E = e.O()
    }
]);
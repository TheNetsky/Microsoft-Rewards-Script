(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [8039], {
        71208: (e, t, r) => {
            Promise.resolve().then(r.bind(r, 74970))
        },
        74970: (e, t, r) => {
            "use strict";
            r.r(t), r.d(t, {
                default: () => o
            });
            var l = r(20748),
                i = r(10812),
                a = r(84662),
                c = r(59328),
                s = r(75564);

            function n(e) {
                let t, r, a, c, n = (0, i.c)(10),
                    {
                        title: d,
                        description: o,
                        className: x
                    } = e;
                return n[0] !== x ? (t = (0, s.tw)("pg-content h-full py-6 lg:py-10", "min-h-[calc(100vh-100px)] xl:min-h-[calc(100vh-56px)]", "flex flex-col items-center justify-center gap-6", x), n[0] = x, n[1] = t) : t = n[1], n[2] !== d ? (r = (0, l.jsx)("p", {
                    className: "text-title2 lg:text-largeTitle mai:text-globalDisplay2 mai:xl:text-globalDisplay1",
                    children: d
                }), n[2] = d, n[3] = r) : r = n[3], n[4] !== o ? (a = (0, l.jsx)("div", {
                    className: "text-neutralFg3 lg:text-body2 mai:text-readingBody mai:text-fgCtrlNeutralSecondaryRest",
                    children: o
                }), n[4] = o, n[5] = a) : a = n[5], n[6] !== t || n[7] !== r || n[8] !== a ? (c = (0, l.jsxs)("div", {
                    className: t,
                    children: [r, a]
                }), n[6] = t, n[7] = r, n[8] = a, n[9] = c) : c = n[9], c
            }
            var d = r(32530);

            function o(e) {
                let t, r, s, o, x, u = (0, i.c)(10),
                    {
                        error: g
                    } = e;
                u[0] !== g ? (t = () => {
                    d.C.logError(g, !0)
                }, r = [g], u[0] = g, u[1] = t, u[2] = r) : (t = u[1], r = u[2]), (0, c.useEffect)(t, r);
                let h = (0, a.c)("Errors.Unhandled");
                return u[3] !== h ? (s = h("title"), u[3] = h, u[4] = s) : s = u[4], u[5] !== h ? (o = h("description"), u[5] = h, u[6] = o) : o = u[6], u[7] !== s || u[8] !== o ? (x = (0, l.jsx)("div", {
                    className: "fixed inset-0 z-50 bg-rewardsBgBrand1 mai:bg-bgWebPagePrimary",
                    children: (0, l.jsx)(n, {
                        title: s,
                        description: o
                    })
                }), u[7] = s, u[8] = o, u[9] = x) : x = u[9], x
            }
        },
        84662: (e, t, r) => {
            "use strict";
            r.d(t, {
                c: () => a,
                k: () => c
            });
            var l = r(92837);

            function i(e, t) {
                return (...e) => {
                    try {
                        return t(...e)
                    } catch {
                        throw Error(void 0)
                    }
                }
            }
            let a = i(0, l.c3),
                c = i(0, l.kc)
        }
    },
    e => {
        e.O(0, [2781, 9555, 6697, 8267, 7298, 7358], () => e(e.s = 71208)), _N_E = e.O()
    }
]);
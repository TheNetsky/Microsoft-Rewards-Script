var extendedCSS = function() {
    "use strict";

    function e(e, t, n) {
        return (t = function(e) {
            var t = function(e, t) {
                if ("object" != typeof e || !e) return e;
                var n = e[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var r = n.call(e, t);
                    if ("object" != typeof r) return r;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === t ? String : Number)(e)
            }(e, "string");
            return "symbol" == typeof t ? t : t + ""
        }(t)) in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
    var t, n, r = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
        o = {};

    function i() {
        if (n) return t;
        n = 1;
        var e = function(e) {
            return e && e.Math === Math && e
        };
        return t = e("object" == typeof globalThis && globalThis) || e("object" == typeof window && window) || e("object" == typeof self && self) || e("object" == typeof r && r) || e("object" == typeof t && t) || function() {
            return this
        }() || Function("return this")()
    }
    var a, s, l, c, u, h, p, d, f = {};

    function m() {
        return s ? a : (s = 1, a = function(e) {
            try {
                return !!e()
            } catch (e) {
                return !0
            }
        })
    }

    function g() {
        if (c) return l;
        c = 1;
        var e = m();
        return l = !e(function() {
            return 7 !== Object.defineProperty({}, 1, {
                get: function() {
                    return 7
                }
            })[1]
        })
    }

    function b() {
        if (h) return u;
        h = 1;
        var e = m();
        return u = !e(function() {
            var e = function() {}.bind();
            return "function" != typeof e || e.hasOwnProperty("prototype")
        })
    }

    function y() {
        if (d) return p;
        d = 1;
        var e = b(),
            t = Function.prototype.call;
        return p = e ? t.bind(t) : function() {
            return t.apply(t, arguments)
        }, p
    }
    var k, v, x, w, S, C, z, A, _, O, T, L, E, j, I, R, P, D, N, M, F, B, q, W, U, $, G, V, H, K, Q, Y, X, Z, J, ee, te, ne, re, oe, ie, ae = {};

    function se() {
        return x || (x = 1, v = function(e, t) {
            return {
                enumerable: !(1 & e),
                configurable: !(2 & e),
                writable: !(4 & e),
                value: t
            }
        }), v
    }

    function le() {
        if (S) return w;
        S = 1;
        var e = b(),
            t = Function.prototype,
            n = t.call,
            r = e && t.bind.bind(n, n);
        return w = e ? r : function(e) {
            return function() {
                return n.apply(e, arguments)
            }
        }, w
    }

    function ce() {
        if (z) return C;
        z = 1;
        var e = le(),
            t = e({}.toString),
            n = e("".slice);
        return C = function(e) {
            return n(t(e), 8, -1)
        }
    }

    function ue() {
        return T ? O : (T = 1, O = function(e) {
            return null == e
        })
    }

    function he() {
        if (E) return L;
        E = 1;
        var e = ue(),
            t = TypeError;
        return L = function(n) {
            if (e(n)) throw new t("Can't call method on " + n);
            return n
        }
    }

    function pe() {
        if (I) return j;
        I = 1;
        var e = function() {
                if (_) return A;
                _ = 1;
                var e = le(),
                    t = m(),
                    n = ce(),
                    r = Object,
                    o = e("".split);
                return A = t(function() {
                    return !r("z").propertyIsEnumerable(0)
                }) ? function(e) {
                    return "String" === n(e) ? o(e, "") : r(e)
                } : r
            }(),
            t = he();
        return j = function(n) {
            return e(t(n))
        }
    }

    function de() {
        if (P) return R;
        P = 1;
        var e = "object" == typeof document && document.all;
        return R = void 0 === e && void 0 !== e ? function(t) {
            return "function" == typeof t || t === e
        } : function(e) {
            return "function" == typeof e
        }
    }

    function fe() {
        if (N) return D;
        N = 1;
        var e = de();
        return D = function(t) {
            return "object" == typeof t ? null !== t : e(t)
        }
    }

    function me() {
        if (F) return M;
        F = 1;
        var e = i(),
            t = de();
        return M = function(n, r) {
            return arguments.length < 2 ? (o = e[n], t(o) ? o : void 0) : e[n] && e[n][r];
            var o
        }, M
    }

    function ge() {
        if (q) return B;
        q = 1;
        var e = le();
        return B = e({}.isPrototypeOf)
    }

    function be() {
        if (G) return $;
        G = 1;
        var e, t, n = i(),
            r = function() {
                if (U) return W;
                U = 1;
                var e = i().navigator,
                    t = e && e.userAgent;
                return W = t ? String(t) : ""
            }(),
            o = n.process,
            a = n.Deno,
            s = o && o.versions || a && a.version,
            l = s && s.v8;
        return l && (t = (e = l.split("."))[0] > 0 && e[0] < 4 ? 1 : +(e[0] + e[1])), !t && r && (!(e = r.match(/Edge\/(\d+)/)) || e[1] >= 74) && (e = r.match(/Chrome\/(\d+)/)) && (t = +e[1]), $ = t
    }

    function ye() {
        if (H) return V;
        H = 1;
        var e = be(),
            t = m(),
            n = i().String;
        return V = !!Object.getOwnPropertySymbols && !t(function() {
            var t = Symbol("symbol detection");
            return !n(t) || !(Object(t) instanceof Symbol) || !Symbol.sham && e && e < 41
        })
    }

    function ke() {
        if (Q) return K;
        Q = 1;
        var e = ye();
        return K = e && !Symbol.sham && "symbol" == typeof Symbol.iterator
    }

    function ve() {
        if (X) return Y;
        X = 1;
        var e = me(),
            t = de(),
            n = ge(),
            r = ke(),
            o = Object;
        return Y = r ? function(e) {
            return "symbol" == typeof e
        } : function(r) {
            var i = e("Symbol");
            return t(i) && n(i.prototype, o(r))
        }
    }

    function xe() {
        if (J) return Z;
        J = 1;
        var e = String;
        return Z = function(t) {
            try {
                return e(t)
            } catch (e) {
                return "Object"
            }
        }
    }

    function we() {
        if (te) return ee;
        te = 1;
        var e = de(),
            t = xe(),
            n = TypeError;
        return ee = function(r) {
            if (e(r)) return r;
            throw new n(t(r) + " is not a function")
        }
    }

    function Se() {
        if (re) return ne;
        re = 1;
        var e = we(),
            t = ue();
        return ne = function(n, r) {
            var o = n[r];
            return t(o) ? void 0 : e(o)
        }
    }

    function Ce() {
        if (ie) return oe;
        ie = 1;
        var e = y(),
            t = de(),
            n = fe(),
            r = TypeError;
        return oe = function(o, i) {
            var a, s;
            if ("string" === i && t(a = o.toString) && !n(s = e(a, o))) return s;
            if (t(a = o.valueOf) && !n(s = e(a, o))) return s;
            if ("string" !== i && t(a = o.toString) && !n(s = e(a, o))) return s;
            throw new r("Can't convert object to primitive value")
        }
    }
    var ze, Ae, _e, Oe, Te, Le, Ee, je, Ie, Re, Pe, De, Ne, Me, Fe, Be, qe, We, Ue, $e, Ge, Ve, He, Ke, Qe = {
        exports: {}
    };

    function Ye() {
        return Ae ? ze : (Ae = 1, ze = !1)
    }

    function Xe() {
        if (Oe) return _e;
        Oe = 1;
        var e = i(),
            t = Object.defineProperty;
        return _e = function(n, r) {
            try {
                t(e, n, {
                    value: r,
                    configurable: !0,
                    writable: !0
                })
            } catch (t) {
                e[n] = r
            }
            return r
        }, _e
    }

    function Ze() {
        if (Te) return Qe.exports;
        Te = 1;
        var e = Ye(),
            t = i(),
            n = Xe(),
            r = "__core-js_shared__",
            o = Qe.exports = t[r] || n(r, {});
        return (o.versions || (o.versions = [])).push({
            version: "3.47.0",
            mode: e ? "pure" : "global",
            copyright: "© 2014-2025 Denis Pushkarev (zloirock.ru), 2025 CoreJS Company (core-js.io)",
            license: "https://github.com/zloirock/core-js/blob/v3.47.0/LICENSE",
            source: "https://github.com/zloirock/core-js"
        }), Qe.exports
    }

    function Je() {
        if (Ee) return Le;
        Ee = 1;
        var e = Ze();
        return Le = function(t, n) {
            return e[t] || (e[t] = n || {})
        }, Le
    }

    function et() {
        if (Ie) return je;
        Ie = 1;
        var e = he(),
            t = Object;
        return je = function(n) {
            return t(e(n))
        }
    }

    function tt() {
        if (Pe) return Re;
        Pe = 1;
        var e = le(),
            t = et(),
            n = e({}.hasOwnProperty);
        return Re = Object.hasOwn || function(e, r) {
            return n(t(e), r)
        }
    }

    function nt() {
        if (Ne) return De;
        Ne = 1;
        var e = le(),
            t = 0,
            n = Math.random(),
            r = e(1.1.toString);
        return De = function(e) {
            return "Symbol(" + (void 0 === e ? "" : e) + ")_" + r(++t + n, 36)
        }
    }

    function rt() {
        if (Fe) return Me;
        Fe = 1;
        var e = i(),
            t = Je(),
            n = tt(),
            r = nt(),
            o = ye(),
            a = ke(),
            s = e.Symbol,
            l = t("wks"),
            c = a ? s.for || s : s && s.withoutSetter || r;
        return Me = function(e) {
            return n(l, e) || (l[e] = o && n(s, e) ? s[e] : c("Symbol." + e)), l[e]
        }, Me
    }

    function ot() {
        if (qe) return Be;
        qe = 1;
        var e = y(),
            t = fe(),
            n = ve(),
            r = Se(),
            o = Ce(),
            i = rt(),
            a = TypeError,
            s = i("toPrimitive");
        return Be = function(i, l) {
            if (!t(i) || n(i)) return i;
            var c, u = r(i, s);
            if (u) {
                if (void 0 === l && (l = "default"), c = e(u, i, l), !t(c) || n(c)) return c;
                throw new a("Can't convert object to primitive value")
            }
            return void 0 === l && (l = "number"), o(i, l)
        }
    }

    function it() {
        if (Ue) return We;
        Ue = 1;
        var e = ot(),
            t = ve();
        return We = function(n) {
            var r = e(n, "string");
            return t(r) ? r : r + ""
        }
    }

    function at() {
        if (Ge) return $e;
        Ge = 1;
        var e = i(),
            t = fe(),
            n = e.document,
            r = t(n) && t(n.createElement);
        return $e = function(e) {
            return r ? n.createElement(e) : {}
        }
    }

    function st() {
        if (He) return Ve;
        He = 1;
        var e = g(),
            t = m(),
            n = at();
        return Ve = !e && !t(function() {
            return 7 !== Object.defineProperty(n("div"), "a", {
                get: function() {
                    return 7
                }
            }).a
        })
    }

    function lt() {
        if (Ke) return f;
        Ke = 1;
        var e = g(),
            t = y(),
            n = function() {
                if (k) return ae;
                k = 1;
                var e = {}.propertyIsEnumerable,
                    t = Object.getOwnPropertyDescriptor,
                    n = t && !e.call({
                        1: 2
                    }, 1);
                return ae.f = n ? function(e) {
                    var n = t(this, e);
                    return !!n && n.enumerable
                } : e, ae
            }(),
            r = se(),
            o = pe(),
            i = it(),
            a = tt(),
            s = st(),
            l = Object.getOwnPropertyDescriptor;
        return f.f = e ? l : function(e, c) {
            if (e = o(e), c = i(c), s) try {
                return l(e, c)
            } catch (e) {}
            if (a(e, c)) return r(!t(n.f, e, c), e[c])
        }, f
    }
    var ct, ut, ht, pt, dt, ft, mt, gt = {};

    function bt() {
        if (ut) return ct;
        ut = 1;
        var e = g(),
            t = m();
        return ct = e && t(function() {
            return 42 !== Object.defineProperty(function() {}, "prototype", {
                value: 42,
                writable: !1
            }).prototype
        })
    }

    function yt() {
        if (pt) return ht;
        pt = 1;
        var e = fe(),
            t = String,
            n = TypeError;
        return ht = function(r) {
            if (e(r)) return r;
            throw new n(t(r) + " is not an object")
        }
    }

    function kt() {
        if (dt) return gt;
        dt = 1;
        var e = g(),
            t = st(),
            n = bt(),
            r = yt(),
            o = it(),
            i = TypeError,
            a = Object.defineProperty,
            s = Object.getOwnPropertyDescriptor,
            l = "enumerable",
            c = "configurable",
            u = "writable";
        return gt.f = e ? n ? function(e, t, n) {
            if (r(e), t = o(t), r(n), "function" == typeof e && "prototype" === t && "value" in n && u in n && !n[u]) {
                var i = s(e, t);
                i && i[u] && (e[t] = n.value, n = {
                    configurable: c in n ? n[c] : i[c],
                    enumerable: l in n ? n[l] : i[l],
                    writable: !1
                })
            }
            return a(e, t, n)
        } : a : function(e, n, s) {
            if (r(e), n = o(n), r(s), t) try {
                return a(e, n, s)
            } catch (e) {}
            if ("get" in s || "set" in s) throw new i("Accessors not supported");
            return "value" in s && (e[n] = s.value), e
        }, gt
    }

    function vt() {
        if (mt) return ft;
        mt = 1;
        var e = g(),
            t = kt(),
            n = se();
        return ft = e ? function(e, r, o) {
            return t.f(e, r, n(1, o))
        } : function(e, t, n) {
            return e[t] = n, e
        }, ft
    }
    var xt, wt, St, Ct, zt, At, _t, Ot, Tt, Lt, Et, jt, It, Rt, Pt, Dt = {
        exports: {}
    };

    function Nt() {
        if (wt) return xt;
        wt = 1;
        var e = g(),
            t = tt(),
            n = Function.prototype,
            r = e && Object.getOwnPropertyDescriptor,
            o = t(n, "name"),
            i = o && "something" === function() {}.name,
            a = o && (!e || e && r(n, "name").configurable);
        return xt = {
            EXISTS: o,
            PROPER: i,
            CONFIGURABLE: a
        }
    }

    function Mt() {
        if (Ct) return St;
        Ct = 1;
        var e = le(),
            t = de(),
            n = Ze(),
            r = e(Function.toString);
        return t(n.inspectSource) || (n.inspectSource = function(e) {
            return r(e)
        }), St = n.inspectSource
    }

    function Ft() {
        if (Ot) return _t;
        Ot = 1;
        var e = Je(),
            t = nt(),
            n = e("keys");
        return _t = function(e) {
            return n[e] || (n[e] = t(e))
        }
    }

    function Bt() {
        return Lt ? Tt : (Lt = 1, Tt = {})
    }

    function qt() {
        if (jt) return Et;
        jt = 1;
        var e, t, n, r = function() {
                if (At) return zt;
                At = 1;
                var e = i(),
                    t = de(),
                    n = e.WeakMap;
                return zt = t(n) && /native code/.test(String(n))
            }(),
            o = i(),
            a = fe(),
            s = vt(),
            l = tt(),
            c = Ze(),
            u = Ft(),
            h = Bt(),
            p = "Object already initialized",
            d = o.TypeError,
            f = o.WeakMap;
        if (r || c.state) {
            var m = c.state || (c.state = new f);
            m.get = m.get, m.has = m.has, m.set = m.set, e = function(e, t) {
                if (m.has(e)) throw new d(p);
                return t.facade = e, m.set(e, t), t
            }, t = function(e) {
                return m.get(e) || {}
            }, n = function(e) {
                return m.has(e)
            }
        } else {
            var g = u("state");
            h[g] = !0, e = function(e, t) {
                if (l(e, g)) throw new d(p);
                return t.facade = e, s(e, g, t), t
            }, t = function(e) {
                return l(e, g) ? e[g] : {}
            }, n = function(e) {
                return l(e, g)
            }
        }
        return Et = {
            set: e,
            get: t,
            has: n,
            enforce: function(r) {
                return n(r) ? t(r) : e(r, {})
            },
            getterFor: function(e) {
                return function(n) {
                    var r;
                    if (!a(n) || (r = t(n)).type !== e) throw new d("Incompatible receiver, " + e + " required");
                    return r
                }
            }
        }
    }

    function Wt() {
        if (It) return Dt.exports;
        It = 1;
        var e = le(),
            t = m(),
            n = de(),
            r = tt(),
            o = g(),
            i = Nt().CONFIGURABLE,
            a = Mt(),
            s = qt(),
            l = s.enforce,
            c = s.get,
            u = String,
            h = Object.defineProperty,
            p = e("".slice),
            d = e("".replace),
            f = e([].join),
            b = o && !t(function() {
                return 8 !== h(function() {}, "length", {
                    value: 8
                }).length
            }),
            y = String(String).split("String"),
            k = Dt.exports = function(e, t, n) {
                "Symbol(" === p(u(t), 0, 7) && (t = "[" + d(u(t), /^Symbol\(([^)]*)\).*$/, "$1") + "]"), n && n.getter && (t = "get " + t), n && n.setter && (t = "set " + t), (!r(e, "name") || i && e.name !== t) && (o ? h(e, "name", {
                    value: t,
                    configurable: !0
                }) : e.name = t), b && n && r(n, "arity") && e.length !== n.arity && h(e, "length", {
                    value: n.arity
                });
                try {
                    n && r(n, "constructor") && n.constructor ? o && h(e, "prototype", {
                        writable: !1
                    }) : e.prototype && (e.prototype = void 0)
                } catch (e) {}
                var a = l(e);
                return r(a, "source") || (a.source = f(y, "string" == typeof t ? t : "")), e
            };
        return Function.prototype.toString = k(function() {
            return n(this) && c(this).source || a(this)
        }, "toString"), Dt.exports
    }

    function Ut() {
        if (Pt) return Rt;
        Pt = 1;
        var e = de(),
            t = kt(),
            n = Wt(),
            r = Xe();
        return Rt = function(o, i, a, s) {
            s || (s = {});
            var l = s.enumerable,
                c = void 0 !== s.name ? s.name : i;
            if (e(a) && n(a, c, s), s.global) l ? o[i] = a : r(i, a);
            else {
                try {
                    s.unsafe ? o[i] && (l = !0) : delete o[i]
                } catch (e) {}
                l ? o[i] = a : t.f(o, i, {
                    value: a,
                    enumerable: !1,
                    configurable: !s.nonConfigurable,
                    writable: !s.nonWritable
                })
            }
            return o
        }, Rt
    }
    var $t, Gt, Vt, Ht, Kt, Qt, Yt, Xt, Zt, Jt, en, tn, nn, rn, on, an, sn, ln = {};

    function cn() {
        if (Ht) return Vt;
        Ht = 1;
        var e = function() {
            if (Gt) return $t;
            Gt = 1;
            var e = Math.ceil,
                t = Math.floor;
            return $t = Math.trunc || function(n) {
                var r = +n;
                return (r > 0 ? t : e)(r)
            }
        }();
        return Vt = function(t) {
            var n = +t;
            return n != n || 0 === n ? 0 : e(n)
        }, Vt
    }

    function un() {
        if (Qt) return Kt;
        Qt = 1;
        var e = cn(),
            t = Math.max,
            n = Math.min;
        return Kt = function(r, o) {
            var i = e(r);
            return i < 0 ? t(i + o, 0) : n(i, o)
        }, Kt
    }

    function hn() {
        if (Xt) return Yt;
        Xt = 1;
        var e = cn(),
            t = Math.min;
        return Yt = function(n) {
            var r = e(n);
            return r > 0 ? t(r, 9007199254740991) : 0
        }
    }

    function pn() {
        if (Jt) return Zt;
        Jt = 1;
        var e = hn();
        return Zt = function(t) {
            return e(t.length)
        }
    }

    function dn() {
        if (rn) return nn;
        rn = 1;
        var e = le(),
            t = tt(),
            n = pe(),
            r = function() {
                if (tn) return en;
                tn = 1;
                var e = pe(),
                    t = un(),
                    n = pn(),
                    r = function(r) {
                        return function(o, i, a) {
                            var s = e(o),
                                l = n(s);
                            if (0 === l) return !r && -1;
                            var c, u = t(a, l);
                            if (r && i != i) {
                                for (; l > u;)
                                    if ((c = s[u++]) != c) return !0
                            } else
                                for (; l > u; u++)
                                    if ((r || u in s) && s[u] === i) return r || u || 0;
                            return !r && -1
                        }
                    };
                return en = {
                    includes: r(!0),
                    indexOf: r(!1)
                }
            }().indexOf,
            o = Bt(),
            i = e([].push);
        return nn = function(e, a) {
            var s, l = n(e),
                c = 0,
                u = [];
            for (s in l) !t(o, s) && t(l, s) && i(u, s);
            for (; a.length > c;) t(l, s = a[c++]) && (~r(u, s) || i(u, s));
            return u
        }
    }

    function fn() {
        return an ? on : (an = 1, on = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"])
    }

    function mn() {
        if (sn) return ln;
        sn = 1;
        var e = dn(),
            t = fn().concat("length", "prototype");
        return ln.f = Object.getOwnPropertyNames || function(n) {
            return e(n, t)
        }, ln
    }
    var gn, bn, yn, kn, vn, xn, wn, Sn, Cn, zn, An, _n, On, Tn, Ln, En, jn, In, Rn, Pn, Dn, Nn, Mn, Fn, Bn, qn, Wn, Un, $n, Gn, Vn, Hn, Kn, Qn, Yn, Xn, Zn, Jn, er, tr, nr, rr, or = {};

    function ir() {
        if (yn) return bn;
        yn = 1;
        var e = me(),
            t = le(),
            n = mn(),
            r = (gn || (gn = 1, or.f = Object.getOwnPropertySymbols), or),
            o = yt(),
            i = t([].concat);
        return bn = e("Reflect", "ownKeys") || function(e) {
            var t = n.f(o(e)),
                a = r.f;
            return a ? i(t, a(e)) : t
        }
    }

    function ar() {
        if (vn) return kn;
        vn = 1;
        var e = tt(),
            t = ir(),
            n = lt(),
            r = kt();
        return kn = function(o, i, a) {
            for (var s = t(i), l = r.f, c = n.f, u = 0; u < s.length; u++) {
                var h = s[u];
                e(o, h) || a && e(a, h) || l(o, h, c(i, h))
            }
        }
    }

    function sr() {
        if (wn) return xn;
        wn = 1;
        var e = m(),
            t = de(),
            n = /#|\.prototype\./,
            r = function(n, r) {
                var l = i[o(n)];
                return l === s || l !== a && (t(r) ? e(r) : !!r)
            },
            o = r.normalize = function(e) {
                return String(e).replace(n, ".").toLowerCase()
            },
            i = r.data = {},
            a = r.NATIVE = "N",
            s = r.POLYFILL = "P";
        return xn = r
    }

    function lr() {
        if (Cn) return Sn;
        Cn = 1;
        var e = i(),
            t = lt().f,
            n = vt(),
            r = Ut(),
            o = Xe(),
            a = ar(),
            s = sr();
        return Sn = function(i, l) {
            var c, u, h, p, d, f = i.target,
                m = i.global,
                g = i.stat;
            if (c = m ? e : g ? e[f] || o(f, {}) : e[f] && e[f].prototype)
                for (u in l) {
                    if (p = l[u], h = i.dontCallGetSet ? (d = t(c, u)) && d.value : c[u], !s(m ? u : f + (g ? "." : "#") + u, i.forced) && void 0 !== h) {
                        if (typeof p == typeof h) continue;
                        a(p, h)
                    }(i.sham || h && h.sham) && n(p, "sham", !0), r(c, u, p, i)
                }
        }
    }

    function cr() {
        if (An) return zn;
        An = 1;
        var e = b(),
            t = Function.prototype,
            n = t.apply,
            r = t.call;
        return zn = "object" == typeof Reflect && Reflect.apply || (e ? r.bind(n) : function() {
            return r.apply(n, arguments)
        }), zn
    }

    function ur() {
        if (On) return _n;
        On = 1;
        var e = le(),
            t = we();
        return _n = function(n, r, o) {
            try {
                return e(t(Object.getOwnPropertyDescriptor(n, r)[o]))
            } catch (e) {}
        }
    }

    function hr() {
        if (Ln) return Tn;
        Ln = 1;
        var e = fe();
        return Tn = function(t) {
            return e(t) || null === t
        }
    }

    function pr() {
        if (jn) return En;
        jn = 1;
        var e = hr(),
            t = String,
            n = TypeError;
        return En = function(r) {
            if (e(r)) return r;
            throw new n("Can't set " + t(r) + " as a prototype")
        }
    }

    function dr() {
        if (Rn) return In;
        Rn = 1;
        var e = ur(),
            t = fe(),
            n = he(),
            r = pr();
        return In = Object.setPrototypeOf || ("__proto__" in {} ? function() {
            var o, i = !1,
                a = {};
            try {
                (o = e(Object.prototype, "__proto__", "set"))(a, []), i = a instanceof Array
            } catch (e) {}
            return function(e, a) {
                return n(e), r(a), t(e) ? (i ? o(e, a) : e.__proto__ = a, e) : e
            }
        }() : void 0)
    }

    function fr() {
        if (Dn) return Pn;
        Dn = 1;
        var e = kt().f;
        return Pn = function(t, n, r) {
            r in t || e(t, r, {
                configurable: !0,
                get: function() {
                    return n[r]
                },
                set: function(e) {
                    n[r] = e
                }
            })
        }
    }

    function mr() {
        if (Mn) return Nn;
        Mn = 1;
        var e = de(),
            t = fe(),
            n = dr();
        return Nn = function(r, o, i) {
            var a, s;
            return n && e(a = o.constructor) && a !== i && t(s = a.prototype) && s !== i.prototype && n(r, s), r
        }
    }

    function gr() {
        if (Wn) return qn;
        Wn = 1;
        var e = function() {
                if (Bn) return Fn;
                Bn = 1;
                var e = {};
                return e[rt()("toStringTag")] = "z", Fn = "[object z]" === String(e)
            }(),
            t = de(),
            n = ce(),
            r = rt()("toStringTag"),
            o = Object,
            i = "Arguments" === n(function() {
                return arguments
            }());
        return qn = e ? n : function(e) {
            var a, s, l;
            return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(s = function(e, t) {
                try {
                    return e[t]
                } catch (e) {}
            }(a = o(e), r)) ? s : i ? n(a) : "Object" === (l = n(a)) && t(a.callee) ? "Arguments" : l
        }
    }

    function br() {
        if ($n) return Un;
        $n = 1;
        var e = gr(),
            t = String;
        return Un = function(n) {
            if ("Symbol" === e(n)) throw new TypeError("Cannot convert a Symbol value to a string");
            return t(n)
        }
    }

    function yr() {
        if (Vn) return Gn;
        Vn = 1;
        var e = br();
        return Gn = function(t, n) {
            return void 0 === t ? arguments.length < 2 ? "" : n : e(t)
        }, Gn
    }

    function kr() {
        if (Kn) return Hn;
        Kn = 1;
        var e = fe(),
            t = vt();
        return Hn = function(n, r) {
            e(r) && "cause" in r && t(n, "cause", r.cause)
        }
    }

    function vr() {
        if (er) return Jn;
        er = 1;
        var e = vt(),
            t = function() {
                if (Yn) return Qn;
                Yn = 1;
                var e = le(),
                    t = Error,
                    n = e("".replace),
                    r = String(new t("zxcasd").stack),
                    o = /\n\s*at [^:]*:[^\n]*/,
                    i = o.test(r);
                return Qn = function(e, r) {
                    if (i && "string" == typeof e && !t.prepareStackTrace)
                        for (; r--;) e = n(e, o, "");
                    return e
                }
            }(),
            n = function() {
                if (Zn) return Xn;
                Zn = 1;
                var e = m(),
                    t = se();
                return Xn = !e(function() {
                    var e = new Error("a");
                    return !("stack" in e) || (Object.defineProperty(e, "stack", t(1, 7)), 7 !== e.stack)
                })
            }(),
            r = Error.captureStackTrace;
        return Jn = function(o, i, a, s) {
            n && (r ? r(o, i) : e(o, "stack", t(a, s)))
        }
    }

    function xr() {
        if (nr) return tr;
        nr = 1;
        var e = me(),
            t = tt(),
            n = vt(),
            r = ge(),
            o = dr(),
            i = ar(),
            a = fr(),
            s = mr(),
            l = yr(),
            c = kr(),
            u = vr(),
            h = g(),
            p = Ye();
        return tr = function(d, f, m, g) {
            var b = "stackTraceLimit",
                y = g ? 2 : 1,
                k = d.split("."),
                v = k[k.length - 1],
                x = e.apply(null, k);
            if (x) {
                var w = x.prototype;
                if (!p && t(w, "cause") && delete w.cause, !m) return x;
                var S = e("Error"),
                    C = f(function(e, t) {
                        var o = l(g ? t : e, void 0),
                            i = g ? new x(e) : new x;
                        return void 0 !== o && n(i, "message", o), u(i, C, i.stack, 2), this && r(w, this) && s(i, this, C), arguments.length > y && c(i, arguments[y]), i
                    });
                if (C.prototype = w, "Error" !== v ? o ? o(C, S) : i(C, S, {
                        name: !0
                    }) : h && b in x && (a(C, x, b), a(C, x, "prepareStackTrace")), i(C, x), !p) try {
                    w.name !== v && n(w, "name", v), w.constructor = C
                } catch (e) {}
                return C
            }
        }, tr
    }! function() {
        if (rr) return o;
        rr = 1;
        var e = lr(),
            t = i(),
            n = cr(),
            r = xr(),
            a = "WebAssembly",
            s = t[a],
            l = 7 !== new Error("e", {
                cause: 7
            }).cause,
            c = function(t, n) {
                var o = {};
                o[t] = r(t, n, l), e({
                    global: !0,
                    constructor: !0,
                    arity: 1,
                    forced: l
                }, o)
            },
            u = function(t, n) {
                if (s && s[t]) {
                    var o = {};
                    o[t] = r(a + "." + t, n, l), e({
                        target: a,
                        stat: !0,
                        constructor: !0,
                        arity: 1,
                        forced: l
                    }, o)
                }
            };
        c("Error", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), c("EvalError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), c("RangeError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), c("ReferenceError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), c("SyntaxError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), c("TypeError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), c("URIError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), u("CompileError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), u("LinkError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        }), u("RuntimeError", function(e) {
            return function(t) {
                return n(e, this, arguments)
            }
        })
    }();
    var wr, Sr, Cr, zr, Ar, _r, Or, Tr = {};

    function Lr() {
        if (Sr) return wr;
        Sr = 1;
        var e = ce();
        return wr = Array.isArray || function(t) {
            return "Array" === e(t)
        }
    }

    function Er() {
        if (_r) return Ar;
        _r = 1;
        var e = TypeError;
        return Ar = function(t) {
            if (t > 9007199254740991) throw e("Maximum allowed index exceeded");
            return t
        }
    }! function() {
        if (Or) return Tr;
        Or = 1;
        var e = lr(),
            t = et(),
            n = pn(),
            r = function() {
                if (zr) return Cr;
                zr = 1;
                var e = g(),
                    t = Lr(),
                    n = TypeError,
                    r = Object.getOwnPropertyDescriptor,
                    o = e && ! function() {
                        if (void 0 !== this) return !0;
                        try {
                            Object.defineProperty([], "length", {
                                writable: !1
                            }).length = 1
                        } catch (e) {
                            return e instanceof TypeError
                        }
                    }();
                return Cr = o ? function(e, o) {
                    if (t(e) && !r(e, "length").writable) throw new n("Cannot set read only .length");
                    return e.length = o
                } : function(e, t) {
                    return e.length = t
                }, Cr
            }(),
            o = Er();
        e({
            target: "Array",
            proto: !0,
            arity: 1,
            forced: m()(function() {
                return 4294967297 !== [].push.call({
                    length: 4294967296
                }, 1)
            }) || ! function() {
                try {
                    Object.defineProperty([], "length", {
                        writable: !1
                    }).push()
                } catch (e) {
                    return e instanceof TypeError
                }
            }()
        }, {
            push: function(e) {
                var i = t(this),
                    a = n(i),
                    s = arguments.length;
                o(a + s);
                for (var l = 0; l < s; l++) i[a] = arguments[l], a++;
                return r(i, a), a
            }
        })
    }();
    var jr, Ir, Rr, Pr, Dr, Nr, Mr, Fr, Br, qr, Wr = {};

    function Ur() {
        if (Ir) return jr;
        Ir = 1;
        var e = ge(),
            t = TypeError;
        return jr = function(n, r) {
            if (e(r, n)) return n;
            throw new t("Incorrect invocation")
        }
    }

    function $r() {
        if (Nr) return Dr;
        Nr = 1;
        var e = tt(),
            t = de(),
            n = et(),
            r = Ft(),
            o = function() {
                if (Pr) return Rr;
                Pr = 1;
                var e = m();
                return Rr = !e(function() {
                    function e() {}
                    return e.prototype.constructor = null, Object.getPrototypeOf(new e) !== e.prototype
                }), Rr
            }(),
            i = r("IE_PROTO"),
            a = Object,
            s = a.prototype;
        return Dr = o ? a.getPrototypeOf : function(r) {
            var o = n(r);
            if (e(o, i)) return o[i];
            var l = o.constructor;
            return t(l) && o instanceof l ? l.prototype : o instanceof a ? s : null
        }
    }

    function Gr() {
        if (Fr) return Mr;
        Fr = 1;
        var e = Wt(),
            t = kt();
        return Mr = function(n, r, o) {
            return o.get && e(o.get, r, {
                getter: !0
            }), o.set && e(o.set, r, {
                setter: !0
            }), t.f(n, r, o)
        }, Mr
    }

    function Vr() {
        if (qr) return Br;
        qr = 1;
        var e = g(),
            t = kt(),
            n = se();
        return Br = function(r, o, i) {
            e ? t.f(r, o, n(0, i)) : r[o] = i
        }, Br
    }
    var Hr, Kr, Qr, Yr, Xr, Zr, Jr, eo, to, no, ro = {};

    function oo() {
        if (Kr) return Hr;
        Kr = 1;
        var e = dn(),
            t = fn();
        return Hr = Object.keys || function(n) {
            return e(n, t)
        }
    }

    function io() {
        if (Xr) return Yr;
        Xr = 1;
        var e = me();
        return Yr = e("document", "documentElement")
    }

    function ao() {
        if (Jr) return Zr;
        Jr = 1;
        var e, t = yt(),
            n = function() {
                if (Qr) return ro;
                Qr = 1;
                var e = g(),
                    t = bt(),
                    n = kt(),
                    r = yt(),
                    o = pe(),
                    i = oo();
                return ro.f = e && !t ? Object.defineProperties : function(e, t) {
                    r(e);
                    for (var a, s = o(t), l = i(t), c = l.length, u = 0; c > u;) n.f(e, a = l[u++], s[a]);
                    return e
                }, ro
            }(),
            r = fn(),
            o = Bt(),
            i = io(),
            a = at(),
            s = Ft(),
            l = "prototype",
            c = "script",
            u = s("IE_PROTO"),
            h = function() {},
            p = function(e) {
                return "<" + c + ">" + e + "</" + c + ">"
            },
            d = function(e) {
                e.write(p("")), e.close();
                var t = e.parentWindow.Object;
                return e = null, t
            },
            f = function() {
                try {
                    e = new ActiveXObject("htmlfile")
                } catch (e) {}
                var t, n, o;
                f = "undefined" != typeof document ? document.domain && e ? d(e) : (n = a("iframe"), o = "java" + c + ":", n.style.display = "none", i.appendChild(n), n.src = String(o), (t = n.contentWindow.document).open(), t.write(p("document.F=Object")), t.close(), t.F) : d(e);
                for (var s = r.length; s--;) delete f[l][r[s]];
                return f()
            };
        return o[u] = !0, Zr = Object.create || function(e, r) {
            var o;
            return null !== e ? (h[l] = t(e), o = new h, h[l] = null, o[u] = e) : o = f(), void 0 === r ? o : n.f(o, r)
        }
    }

    function so() {
        if (to) return eo;
        to = 1;
        var e, t, n, r = m(),
            o = de(),
            i = fe(),
            a = ao(),
            s = $r(),
            l = Ut(),
            c = rt(),
            u = Ye(),
            h = c("iterator"),
            p = !1;
        return [].keys && ("next" in (n = [].keys()) ? (t = s(s(n))) !== Object.prototype && (e = t) : p = !0), !i(e) || r(function() {
            var t = {};
            return e[h].call(t) !== t
        }) ? e = {} : u && (e = a(e)), o(e[h]) || l(e, h, function() {
            return this
        }), eo = {
            IteratorPrototype: e,
            BUGGY_SAFARI_ITERATORS: p
        }
    }! function() {
        if (no) return Wr;
        no = 1;
        var e = lr(),
            t = i(),
            n = Ur(),
            r = yt(),
            o = de(),
            a = $r(),
            s = Gr(),
            l = Vr(),
            c = m(),
            u = tt(),
            h = rt(),
            p = so().IteratorPrototype,
            d = g(),
            f = Ye(),
            b = "constructor",
            y = "Iterator",
            k = h("toStringTag"),
            v = TypeError,
            x = t[y],
            w = f || !o(x) || x.prototype !== p || !c(function() {
                x({})
            }),
            S = function() {
                if (n(this, p), a(this) === p) throw new v("Abstract class Iterator not directly constructable")
            },
            C = function(e, t) {
                d ? s(p, e, {
                    configurable: !0,
                    get: function() {
                        return t
                    },
                    set: function(t) {
                        if (r(this), this === p) throw new v("You can't redefine this property");
                        u(this, e) ? this[e] = t : l(this, e, t)
                    }
                }) : p[e] = t
            };
        u(p, k) || C(k, y), !w && u(p, b) && p[b] !== Object || C(b, S), S.prototype = p, e({
            global: !0,
            constructor: !0,
            forced: w
        }, {
            Iterator: S
        })
    }();
    var lo, co, uo, ho, po, fo, mo, go, bo, yo, ko, vo, xo, wo, So, Co, zo, Ao, _o, Oo = {};

    function To() {
        return co ? lo : (co = 1, lo = function(e) {
            return {
                iterator: e,
                next: e.next,
                done: !1
            }
        })
    }

    function Lo() {
        if (ho) return uo;
        ho = 1;
        var e = Ut();
        return uo = function(t, n, r) {
            for (var o in n) e(t, o, n[o], r);
            return t
        }
    }

    function Eo() {
        return fo || (fo = 1, po = function(e, t) {
            return {
                value: e,
                done: t
            }
        }), po
    }

    function jo() {
        if (go) return mo;
        go = 1;
        var e = y(),
            t = yt(),
            n = Se();
        return mo = function(r, o, i) {
            var a, s;
            t(r);
            try {
                if (!(a = n(r, "return"))) {
                    if ("throw" === o) throw i;
                    return i
                }
                a = e(a, r)
            } catch (e) {
                s = !0, a = e
            }
            if ("throw" === o) throw i;
            if (s) throw a;
            return t(a), i
        }, mo
    }

    function Io() {
        if (yo) return bo;
        yo = 1;
        var e = jo();
        return bo = function(t, n, r) {
            for (var o = t.length - 1; o >= 0; o--)
                if (void 0 !== t[o]) try {
                    r = e(t[o].iterator, n, r)
                } catch (e) {
                    n = "throw", r = e
                }
            if ("throw" === n) throw r;
            return r
        }, bo
    }

    function Ro() {
        if (vo) return ko;
        vo = 1;
        var e = y(),
            t = ao(),
            n = vt(),
            r = Lo(),
            o = rt(),
            i = qt(),
            a = Se(),
            s = so().IteratorPrototype,
            l = Eo(),
            c = jo(),
            u = Io(),
            h = o("toStringTag"),
            p = "IteratorHelper",
            d = "WrapForValidIterator",
            f = "normal",
            m = "throw",
            g = i.set,
            b = function(n) {
                var o = i.getterFor(n ? d : p);
                return r(t(s), {
                    next: function() {
                        var e = o(this);
                        if (n) return e.nextHandler();
                        if (e.done) return l(void 0, !0);
                        try {
                            var t = e.nextHandler();
                            return e.returnHandlerResult ? t : l(t, e.done)
                        } catch (t) {
                            throw e.done = !0, t
                        }
                    },
                    return: function() {
                        var t = o(this),
                            r = t.iterator;
                        if (t.done = !0, n) {
                            var i = a(r, "return");
                            return i ? e(i, r) : l(void 0, !0)
                        }
                        if (t.inner) try {
                            c(t.inner.iterator, f)
                        } catch (e) {
                            return c(r, m, e)
                        }
                        if (t.openIters) try {
                            u(t.openIters, f)
                        } catch (e) {
                            return c(r, m, e)
                        }
                        return r && c(r, f), l(void 0, !0)
                    }
                })
            },
            k = b(!0),
            v = b(!1);
        return n(v, h, "Iterator Helper"), ko = function(e, t, n) {
            var r = function(r, o) {
                o ? (o.iterator = r.iterator, o.next = r.next) : o = r, o.type = t ? d : p, o.returnHandlerResult = !!n, o.nextHandler = e, o.counter = 0, o.done = !1, g(this, o)
            };
            return r.prototype = t ? k : v, r
        }
    }

    function Po() {
        if (wo) return xo;
        wo = 1;
        var e = yt(),
            t = jo();
        return xo = function(n, r, o, i) {
            try {
                return i ? r(e(o)[0], o[1]) : r(o)
            } catch (e) {
                t(n, "throw", e)
            }
        }, xo
    }

    function Do() {
        return Co ? So : (Co = 1, So = function(e, t) {
            var n = "function" == typeof Iterator && Iterator.prototype[e];
            if (n) try {
                n.call({
                    next: null
                }, t).next()
            } catch (e) {
                return !0
            }
        })
    }

    function No() {
        if (Ao) return zo;
        Ao = 1;
        var e = i();
        return zo = function(t, n) {
            var r = e.Iterator,
                o = r && r.prototype,
                i = o && o[t],
                a = !1;
            if (i) try {
                i.call({
                    next: function() {
                        return {
                            done: !0
                        }
                    },
                    return: function() {
                        a = !0
                    }
                }, -1)
            } catch (e) {
                e instanceof n || (a = !1)
            }
            if (!a) return i
        }
    }! function() {
        if (_o) return Oo;
        _o = 1;
        var e = lr(),
            t = y(),
            n = we(),
            r = yt(),
            o = To(),
            i = Ro(),
            a = Po(),
            s = jo(),
            l = Do(),
            c = No(),
            u = Ye(),
            h = !u && !l("map", function() {}),
            p = !u && !h && c("map", TypeError),
            d = u || h || p,
            f = i(function() {
                var e = this.iterator,
                    n = r(t(this.next, e));
                if (!(this.done = !!n.done)) return a(e, this.mapper, [n.value, this.counter++], !0)
            });
        e({
            target: "Iterator",
            proto: !0,
            real: !0,
            forced: d
        }, {
            map: function(e) {
                r(this);
                try {
                    n(e)
                } catch (e) {
                    s(this, "throw", e)
                }
                return p ? t(p, this, e) : new f(o(this), {
                    mapper: e
                })
            }
        })
    }();
    var Mo, Fo, Bo, qo, Wo, Uo, $o, Go, Vo, Ho, Ko, Qo = {};

    function Yo() {
        if (Fo) return Mo;
        Fo = 1;
        var e = yt();
        return Mo = function() {
            var t = e(this),
                n = "";
            return t.hasIndices && (n += "d"), t.global && (n += "g"), t.ignoreCase && (n += "i"), t.multiline && (n += "m"), t.dotAll && (n += "s"), t.unicode && (n += "u"), t.unicodeSets && (n += "v"), t.sticky && (n += "y"), n
        }
    }

    function Xo() {
        if (qo) return Bo;
        qo = 1;
        var e = m(),
            t = i().RegExp,
            n = e(function() {
                var e = t("a", "y");
                return e.lastIndex = 2, null !== e.exec("abcd")
            }),
            r = n || e(function() {
                return !t("a", "y").sticky
            }),
            o = n || e(function() {
                var e = t("^r", "gy");
                return e.lastIndex = 2, null !== e.exec("str")
            });
        return Bo = {
            BROKEN_CARET: o,
            MISSED_STICKY: r,
            UNSUPPORTED_Y: n
        }
    }

    function Zo() {
        if (Uo) return Wo;
        Uo = 1;
        var e = m(),
            t = i().RegExp;
        return Wo = e(function() {
            var e = t(".", "s");
            return !(e.dotAll && e.test("\n") && "s" === e.flags)
        })
    }

    function Jo() {
        if (Go) return $o;
        Go = 1;
        var e = m(),
            t = i().RegExp;
        return $o = e(function() {
            var e = t("(?<a>b)", "g");
            return "b" !== e.exec("b").groups.a || "bc" !== "b".replace(e, "$<a>c")
        })
    }

    function ei() {
        if (Ho) return Vo;
        Ho = 1;
        var e, t, n = y(),
            r = le(),
            o = br(),
            i = Yo(),
            a = Xo(),
            s = Je(),
            l = ao(),
            c = qt().get,
            u = Zo(),
            h = Jo(),
            p = s("native-string-replace", String.prototype.replace),
            d = RegExp.prototype.exec,
            f = d,
            m = r("".charAt),
            g = r("".indexOf),
            b = r("".replace),
            k = r("".slice),
            v = (t = /b*/g, n(d, e = /a/, "a"), n(d, t, "a"), 0 !== e.lastIndex || 0 !== t.lastIndex),
            x = a.BROKEN_CARET,
            w = void 0 !== /()??/.exec("")[1];
        return (v || w || x || u || h) && (f = function(e) {
            var t, r, a, s, u, h, y, S = this,
                C = c(S),
                z = o(e),
                A = C.raw;
            if (A) return A.lastIndex = S.lastIndex, t = n(f, A, z), S.lastIndex = A.lastIndex, t;
            var _ = C.groups,
                O = x && S.sticky,
                T = n(i, S),
                L = S.source,
                E = 0,
                j = z;
            if (O && (T = b(T, "y", ""), -1 === g(T, "g") && (T += "g"), j = k(z, S.lastIndex), S.lastIndex > 0 && (!S.multiline || S.multiline && "\n" !== m(z, S.lastIndex - 1)) && (L = "(?: " + L + ")", j = " " + j, E++), r = new RegExp("^(?:" + L + ")", T)), w && (r = new RegExp("^" + L + "$(?!\\s)", T)), v && (a = S.lastIndex), s = n(d, O ? r : S, j), O ? s ? (s.input = k(s.input, E), s[0] = k(s[0], E), s.index = S.lastIndex, S.lastIndex += s[0].length) : S.lastIndex = 0 : v && s && (S.lastIndex = S.global ? s.index + s[0].length : a), w && s && s.length > 1 && n(p, s[0], r, function() {
                    for (u = 1; u < arguments.length - 2; u++) void 0 === arguments[u] && (s[u] = void 0)
                }), s && _)
                for (s.groups = h = l(null), u = 0; u < _.length; u++) h[(y = _[u])[0]] = s[y[1]];
            return s
        }), Vo = f
    }

    function ti() {
        if (Ko) return Qo;
        Ko = 1;
        var e = lr(),
            t = ei();
        return e({
            target: "RegExp",
            proto: !0,
            forced: /./.exec !== t
        }, {
            exec: t
        }), Qo
    }
    ti();
    var ni, ri, oi, ii, ai, si, li, ci, ui, hi, pi, di, fi, mi, gi, bi, yi, ki, vi, xi = {};

    function wi() {
        if (ri) return ni;
        ri = 1;
        var e = le(),
            t = Set.prototype;
        return ni = {
            Set: Set,
            add: e(t.add),
            has: e(t.has),
            remove: e(t.delete),
            proto: t
        }
    }

    function Si() {
        if (ii) return oi;
        ii = 1;
        var e = wi().has;
        return oi = function(t) {
            return e(t), t
        }
    }

    function Ci() {
        if (si) return ai;
        si = 1;
        var e = y();
        return ai = function(t, n, r) {
            for (var o, i, a = r ? t : t.iterator, s = t.next; !(o = e(s, a)).done;)
                if (void 0 !== (i = n(o.value))) return i
        }
    }

    function zi() {
        if (ci) return li;
        ci = 1;
        var e = le(),
            t = Ci(),
            n = wi(),
            r = n.Set,
            o = n.proto,
            i = e(o.forEach),
            a = e(o.keys),
            s = a(new r).next;
        return li = function(e, n, r) {
            return r ? t({
                iterator: a(e),
                next: s
            }, n) : i(e, n)
        }
    }

    function Ai() {
        if (hi) return ui;
        hi = 1;
        var e = wi(),
            t = zi(),
            n = e.Set,
            r = e.add;
        return ui = function(e) {
            var o = new n;
            return t(e, function(e) {
                r(o, e)
            }), o
        }
    }

    function _i() {
        if (di) return pi;
        di = 1;
        var e = ur(),
            t = wi();
        return pi = e(t.proto, "size", "get") || function(e) {
            return e.size
        }
    }

    function Oi() {
        if (mi) return fi;
        mi = 1;
        var e = we(),
            t = yt(),
            n = y(),
            r = cn(),
            o = To(),
            i = "Invalid size",
            a = RangeError,
            s = TypeError,
            l = Math.max,
            c = function(t, n) {
                this.set = t, this.size = l(n, 0), this.has = e(t.has), this.keys = e(t.keys)
            };
        return c.prototype = {
            getIterator: function() {
                return o(t(n(this.keys, this.set)))
            },
            includes: function(e) {
                return n(this.has, this.set, e)
            }
        }, fi = function(e) {
            t(e);
            var n = +e.size;
            if (n != n) throw new s(i);
            var o = r(n);
            if (o < 0) throw new a(i);
            return new c(e, o)
        }
    }

    function Ti() {
        if (ki) return yi;
        ki = 1;
        var e = me(),
            t = function(e) {
                return {
                    size: e,
                    has: function() {
                        return !1
                    },
                    keys: function() {
                        return {
                            next: function() {
                                return {
                                    done: !0
                                }
                            }
                        }
                    }
                }
            },
            n = function(e) {
                return {
                    size: e,
                    has: function() {
                        return !0
                    },
                    keys: function() {
                        throw new Error("e")
                    }
                }
            };
        return yi = function(r, o) {
            var i = e("Set");
            try {
                (new i)[r](t(0));
                try {
                    return (new i)[r](t(-1)), !1
                } catch (e) {
                    if (!o) return !0;
                    try {
                        return (new i)[r](n(-1 / 0)), !1
                    } catch (e) {
                        return o(new i([1, 2])[r](n(1 / 0)))
                    }
                }
            } catch (e) {
                return !1
            }
        }, yi
    }! function() {
        if (vi) return xi;
        vi = 1;
        var e = lr(),
            t = function() {
                if (bi) return gi;
                bi = 1;
                var e = Si(),
                    t = wi(),
                    n = Ai(),
                    r = _i(),
                    o = Oi(),
                    i = zi(),
                    a = Ci(),
                    s = t.has,
                    l = t.remove;
                return gi = function(t) {
                    var c = e(this),
                        u = o(t),
                        h = n(c);
                    return r(c) <= u.size ? i(c, function(e) {
                        u.includes(e) && l(h, e)
                    }) : a(u.getIterator(), function(e) {
                        s(h, e) && l(h, e)
                    }), h
                }
            }(),
            n = m(),
            r = !Ti()("difference", function(e) {
                return 0 === e.size
            }) || n(function() {
                var e = {
                        size: 1,
                        has: function() {
                            return !0
                        },
                        keys: function() {
                            var e = 0;
                            return {
                                next: function() {
                                    var n = e++ > 1;
                                    return t.has(1) && t.clear(), {
                                        done: n,
                                        value: 2
                                    }
                                }
                            }
                        }
                    },
                    t = new Set([1, 2, 3, 4]);
                return 3 !== t.difference(e).size
            });
        e({
            target: "Set",
            proto: !0,
            real: !0,
            forced: r
        }, {
            difference: t
        })
    }();
    var Li, Ei, ji, Ii = {};
    ! function() {
        if (ji) return Ii;
        ji = 1;
        var e = lr(),
            t = m(),
            n = function() {
                if (Ei) return Li;
                Ei = 1;
                var e = Si(),
                    t = wi(),
                    n = _i(),
                    r = Oi(),
                    o = zi(),
                    i = Ci(),
                    a = t.Set,
                    s = t.add,
                    l = t.has;
                return Li = function(t) {
                    var c = e(this),
                        u = r(t),
                        h = new a;
                    return n(c) > u.size ? i(u.getIterator(), function(e) {
                        l(c, e) && s(h, e)
                    }) : o(c, function(e) {
                        u.includes(e) && s(h, e)
                    }), h
                }
            }();
        e({
            target: "Set",
            proto: !0,
            real: !0,
            forced: !Ti()("intersection", function(e) {
                return 2 === e.size && e.has(1) && e.has(2)
            }) || t(function() {
                return "3,2" !== String(Array.from(new Set([1, 2, 3]).intersection(new Set([3, 2]))))
            })
        }, {
            intersection: n
        })
    }();
    var Ri, Pi, Di, Ni = {};
    ! function() {
        if (Di) return Ni;
        Di = 1;
        var e = lr(),
            t = function() {
                if (Pi) return Ri;
                Pi = 1;
                var e = Si(),
                    t = wi().has,
                    n = _i(),
                    r = Oi(),
                    o = zi(),
                    i = Ci(),
                    a = jo();
                return Ri = function(s) {
                    var l = e(this),
                        c = r(s);
                    if (n(l) <= c.size) return !1 !== o(l, function(e) {
                        if (c.includes(e)) return !1
                    }, !0);
                    var u = c.getIterator();
                    return !1 !== i(u, function(e) {
                        if (t(l, e)) return a(u, "normal", !1)
                    })
                }
            }();
        e({
            target: "Set",
            proto: !0,
            real: !0,
            forced: !Ti()("isDisjointFrom", function(e) {
                return !e
            })
        }, {
            isDisjointFrom: t
        })
    }();
    var Mi, Fi, Bi, qi = {};
    ! function() {
        if (Bi) return qi;
        Bi = 1;
        var e = lr(),
            t = function() {
                if (Fi) return Mi;
                Fi = 1;
                var e = Si(),
                    t = _i(),
                    n = zi(),
                    r = Oi();
                return Mi = function(o) {
                    var i = e(this),
                        a = r(o);
                    return !(t(i) > a.size) && !1 !== n(i, function(e) {
                        if (!a.includes(e)) return !1
                    }, !0)
                }
            }();
        e({
            target: "Set",
            proto: !0,
            real: !0,
            forced: !Ti()("isSubsetOf", function(e) {
                return e
            })
        }, {
            isSubsetOf: t
        })
    }();
    var Wi, Ui, $i, Gi = {};
    ! function() {
        if ($i) return Gi;
        $i = 1;
        var e = lr(),
            t = function() {
                if (Ui) return Wi;
                Ui = 1;
                var e = Si(),
                    t = wi().has,
                    n = _i(),
                    r = Oi(),
                    o = Ci(),
                    i = jo();
                return Wi = function(a) {
                    var s = e(this),
                        l = r(a);
                    if (n(s) < l.size) return !1;
                    var c = l.getIterator();
                    return !1 !== o(c, function(e) {
                        if (!t(s, e)) return i(c, "normal", !1)
                    })
                }
            }();
        e({
            target: "Set",
            proto: !0,
            real: !0,
            forced: !Ti()("isSupersetOf", function(e) {
                return !e
            })
        }, {
            isSupersetOf: t
        })
    }();
    var Vi, Hi, Ki, Qi, Yi, Xi = {};

    function Zi() {
        return Qi ? Ki : (Qi = 1, Ki = function(e) {
            try {
                var t = new Set,
                    n = {
                        size: 0,
                        has: function() {
                            return !0
                        },
                        keys: function() {
                            return Object.defineProperty({}, "next", {
                                get: function() {
                                    return t.clear(), t.add(4),
                                        function() {
                                            return {
                                                done: !0
                                            }
                                        }
                                }
                            })
                        }
                    },
                    r = t[e](n);
                return 1 === r.size && 4 === r.values().next().value
            } catch (e) {
                return !1
            }
        })
    }! function() {
        if (Yi) return Xi;
        Yi = 1;
        var e = lr(),
            t = function() {
                if (Hi) return Vi;
                Hi = 1;
                var e = Si(),
                    t = wi(),
                    n = Ai(),
                    r = Oi(),
                    o = Ci(),
                    i = t.add,
                    a = t.has,
                    s = t.remove;
                return Vi = function(t) {
                    var l = e(this),
                        c = r(t).getIterator(),
                        u = n(l);
                    return o(c, function(e) {
                        a(l, e) ? s(u, e) : i(u, e)
                    }), u
                }
            }(),
            n = Zi();
        e({
            target: "Set",
            proto: !0,
            real: !0,
            forced: !Ti()("symmetricDifference") || !n("symmetricDifference")
        }, {
            symmetricDifference: t
        })
    }();
    var Ji, ea, ta, na = {};
    ! function() {
        if (ta) return na;
        ta = 1;
        var e = lr(),
            t = function() {
                if (ea) return Ji;
                ea = 1;
                var e = Si(),
                    t = wi().add,
                    n = Ai(),
                    r = Oi(),
                    o = Ci();
                return Ji = function(i) {
                    var a = e(this),
                        s = r(i).getIterator(),
                        l = n(a);
                    return o(s, function(e) {
                        t(l, e)
                    }), l
                }
            }(),
            n = Zi();
        e({
            target: "Set",
            proto: !0,
            real: !0,
            forced: !Ti()("union") || !n("union")
        }, {
            union: t
        })
    }();
    var ra, oa, ia, aa, sa, la, ca, ua = {};

    function ha() {
        return oa ? ra : (oa = 1, ra = "\t\n\v\f\r                　\u2028\u2029\ufeff")
    }! function() {
        if (ca) return ua;
        ca = 1;
        var e = lr(),
            t = function() {
                if (aa) return ia;
                aa = 1;
                var e = le(),
                    t = he(),
                    n = br(),
                    r = ha(),
                    o = e("".replace),
                    i = RegExp("^[" + r + "]+"),
                    a = RegExp("(^|[^" + r + "])[" + r + "]+$"),
                    s = function(e) {
                        return function(r) {
                            var s = n(t(r));
                            return 1 & e && (s = o(s, i, "")), 2 & e && (s = o(s, a, "$1")), s
                        }
                    };
                return ia = {
                    start: s(1),
                    end: s(2),
                    trim: s(3)
                }
            }().trim,
            n = function() {
                if (la) return sa;
                la = 1;
                var e = Nt().PROPER,
                    t = m(),
                    n = ha();
                return sa = function(r) {
                    return t(function() {
                        return !!n[r]() || "​᠎" !== "​᠎" [r]() || e && n[r].name !== r
                    })
                }
            }();
        e({
            target: "String",
            proto: !0,
            forced: n("trim")
        }, {
            trim: function() {
                return t(this)
            }
        })
    }();
    var pa, da, fa, ma, ga, ba, ya, ka, va, xa, wa, Sa, Ca, za, Aa, _a, Oa, Ta = {};

    function La() {
        if (ba) return ga;
        ba = 1;
        var e = rt(),
            t = ao(),
            n = kt().f,
            r = e("unscopables"),
            o = Array.prototype;
        return void 0 === o[r] && n(o, r, {
            configurable: !0,
            value: t(null)
        }), ga = function(e) {
            o[r][e] = !0
        }
    }

    function Ea() {
        return ka ? ya : (ka = 1, ya = {})
    }

    function ja() {
        if (xa) return va;
        xa = 1;
        var e = kt().f,
            t = tt(),
            n = rt()("toStringTag");
        return va = function(r, o, i) {
            r && !i && (r = r.prototype), r && !t(r, n) && e(r, n, {
                configurable: !0,
                value: o
            })
        }
    }

    function Ia() {
        if (za) return Ca;
        za = 1;
        var e = lr(),
            t = y(),
            n = Ye(),
            r = Nt(),
            o = de(),
            i = function() {
                if (Sa) return wa;
                Sa = 1;
                var e = so().IteratorPrototype,
                    t = ao(),
                    n = se(),
                    r = ja(),
                    o = Ea(),
                    i = function() {
                        return this
                    };
                return wa = function(a, s, l, c) {
                    var u = s + " Iterator";
                    return a.prototype = t(e, {
                        next: n(+!c, l)
                    }), r(a, u, !1, !0), o[u] = i, a
                }
            }(),
            a = $r(),
            s = dr(),
            l = ja(),
            c = vt(),
            u = Ut(),
            h = rt(),
            p = Ea(),
            d = so(),
            f = r.PROPER,
            m = r.CONFIGURABLE,
            g = d.IteratorPrototype,
            b = d.BUGGY_SAFARI_ITERATORS,
            k = h("iterator"),
            v = "keys",
            x = "values",
            w = "entries",
            S = function() {
                return this
            };
        return Ca = function(r, h, d, y, C, z, A) {
            i(d, h, y);
            var _, O, T, L = function(e) {
                    if (e === C && P) return P;
                    if (!b && e && e in I) return I[e];
                    switch (e) {
                        case v:
                        case x:
                        case w:
                            return function() {
                                return new d(this, e)
                            }
                    }
                    return function() {
                        return new d(this)
                    }
                },
                E = h + " Iterator",
                j = !1,
                I = r.prototype,
                R = I[k] || I["@@iterator"] || C && I[C],
                P = !b && R || L(C),
                D = "Array" === h && I.entries || R;
            if (D && (_ = a(D.call(new r))) !== Object.prototype && _.next && (n || a(_) === g || (s ? s(_, g) : o(_[k]) || u(_, k, S)), l(_, E, !0, !0), n && (p[E] = S)), f && C === x && R && R.name !== x && (!n && m ? c(I, "name", x) : (j = !0, P = function() {
                    return t(R, this)
                })), C)
                if (O = {
                        values: L(x),
                        keys: z ? P : L(v),
                        entries: L(w)
                    }, A)
                    for (T in O)(b || j || !(T in I)) && u(I, T, O[T]);
                else e({
                    target: h,
                    proto: !0,
                    forced: b || j
                }, O);
            return n && !A || I[k] === P || u(I, k, P, {
                name: C
            }), p[h] = P, O
        }
    }! function() {
        if (Oa) return Ta;
        Oa = 1;
        var e = i(),
            t = da ? pa : (da = 1, pa = {
                CSSRuleList: 0,
                CSSStyleDeclaration: 0,
                CSSValueList: 0,
                ClientRectList: 0,
                DOMRectList: 0,
                DOMStringList: 0,
                DOMTokenList: 1,
                DataTransferItemList: 0,
                FileList: 0,
                HTMLAllCollection: 0,
                HTMLCollection: 0,
                HTMLFormElement: 0,
                HTMLSelectElement: 0,
                MediaList: 0,
                MimeTypeArray: 0,
                NamedNodeMap: 0,
                NodeList: 1,
                PaintRequestList: 0,
                Plugin: 0,
                PluginArray: 0,
                SVGLengthList: 0,
                SVGNumberList: 0,
                SVGPathSegList: 0,
                SVGPointList: 0,
                SVGStringList: 0,
                SVGTransformList: 0,
                SourceBufferList: 0,
                StyleSheetList: 0,
                TextTrackCueList: 0,
                TextTrackList: 0,
                TouchList: 0
            }),
            n = function() {
                if (ma) return fa;
                ma = 1;
                var e = at()("span").classList,
                    t = e && e.constructor && e.constructor.prototype;
                return fa = t === Object.prototype ? void 0 : t
            }(),
            r = function() {
                if (_a) return Aa;
                _a = 1;
                var e = pe(),
                    t = La(),
                    n = Ea(),
                    r = qt(),
                    o = kt().f,
                    i = Ia(),
                    a = Eo(),
                    s = Ye(),
                    l = g(),
                    c = "Array Iterator",
                    u = r.set,
                    h = r.getterFor(c);
                Aa = i(Array, "Array", function(t, n) {
                    u(this, {
                        type: c,
                        target: e(t),
                        index: 0,
                        kind: n
                    })
                }, function() {
                    var e = h(this),
                        t = e.target,
                        n = e.index++;
                    if (!t || n >= t.length) return e.target = null, a(void 0, !0);
                    switch (e.kind) {
                        case "keys":
                            return a(n, !1);
                        case "values":
                            return a(t[n], !1)
                    }
                    return a([n, t[n]], !1)
                }, "values");
                var p = n.Arguments = n.Array;
                if (t("keys"), t("values"), t("entries"), !s && l && "values" !== p.name) try {
                    o(p, "name", {
                        value: "values"
                    })
                } catch (e) {}
                return Aa
            }(),
            o = vt(),
            a = ja(),
            s = rt()("iterator"),
            l = r.values,
            c = function(e, n) {
                if (e) {
                    if (e[s] !== l) try {
                        o(e, s, l)
                    } catch (t) {
                        e[s] = l
                    }
                    if (a(e, n, !0), t[n])
                        for (var i in r)
                            if (e[i] !== r[i]) try {
                                o(e, i, r[i])
                            } catch (t) {
                                e[i] = r[i]
                            }
                }
            };
        for (var u in t) c(e[u] && e[u].prototype, u);
        c(n, "DOMTokenList")
    }();
    const Ra = 10,
        Pa = 11,
        Da = 12,
        Na = 13,
        Ma = 15,
        Fa = 16,
        Ba = 17,
        qa = 18,
        Wa = 19,
        Ua = 20,
        $a = 21,
        Ga = 22,
        Va = 23,
        Ha = 24,
        Ka = 25;

    function Qa(e) {
        return e >= 48 && e <= 57
    }

    function Ya(e) {
        return Qa(e) || e >= 65 && e <= 70 || e >= 97 && e <= 102
    }

    function Xa(e) {
        return e >= 65 && e <= 90
    }

    function Za(e) {
        return function(e) {
            return Xa(e) || function(e) {
                return e >= 97 && e <= 122
            }(e)
        }(e) || function(e) {
            return e >= 128
        }(e) || 95 === e
    }

    function Ja(e) {
        return Za(e) || Qa(e) || 45 === e
    }

    function es(e) {
        return e >= 0 && e <= 8 || 11 === e || e >= 14 && e <= 31 || 127 === e
    }

    function ts(e) {
        return 10 === e || 13 === e || 12 === e
    }

    function ns(e) {
        return ts(e) || 32 === e || 9 === e
    }

    function rs(e, t) {
        return 92 === e && (!ts(t) && 0 !== t)
    }

    function os(e, t, n) {
        return 45 === e ? Za(t) || 45 === t || rs(t, n) : !!Za(e) || 92 === e && rs(e, t)
    }

    function is(e, t, n) {
        return 43 === e || 45 === e ? Qa(t) ? 2 : 46 === t && Qa(n) ? 3 : 0 : 46 === e ? Qa(t) ? 2 : 0 : Qa(e) ? 1 : 0
    }

    function as(e) {
        return 65279 === e || 65534 === e ? 1 : 0
    }
    const ss = new Array(128),
        ls = 130;
    for (let e = 0; e < ss.length; e++) ss[e] = (ns(e) ? ls : Qa(e) && 131) || Za(e) && 132 || es(e) && 133 || e || 128;

    function cs(e) {
        return e < 128 ? ss[e] : 132
    }

    function us(e, t) {
        return t < e.length ? e.charCodeAt(t) : 0
    }

    function hs(e, t, n) {
        return 13 === n && 10 === us(e, t + 1) ? 2 : 1
    }

    function ps(e, t, n) {
        let r = e.charCodeAt(t);
        return Xa(r) && (r |= 32), r === n
    }

    function ds(e, t, n, r) {
        if (n - t !== r.length) return !1;
        if (t < 0 || n > e.length) return !1;
        for (let o = t; o < n; o++) {
            const n = r.charCodeAt(o - t);
            let i = e.charCodeAt(o);
            if (Xa(i) && (i |= 32), i !== n) return !1
        }
        return !0
    }

    function fs(e, t) {
        for (; t < e.length && ns(e.charCodeAt(t)); t++);
        return t
    }

    function ms(e, t) {
        for (; t < e.length && Qa(e.charCodeAt(t)); t++);
        return t
    }

    function gs(e, t) {
        if (Ya(us(e, (t += 2) - 1))) {
            for (const n = Math.min(e.length, t + 5); t < n && Ya(us(e, t)); t++);
            const n = us(e, t);
            ns(n) && (t += hs(e, t, n))
        }
        return t
    }

    function bs(e, t) {
        for (; t < e.length; t++) {
            const n = e.charCodeAt(t);
            if (!Ja(n)) {
                if (!rs(n, us(e, t + 1))) break;
                t = gs(e, t) - 1
            }
        }
        return t
    }

    function ys(e, t) {
        let n = e.charCodeAt(t);
        if (43 !== n && 45 !== n || (n = e.charCodeAt(t += 1)), Qa(n) && (t = ms(e, t + 1), n = e.charCodeAt(t)), 46 === n && Qa(e.charCodeAt(t + 1)) && (t = ms(e, t += 2)), ps(e, t, 101)) {
            let r = 0;
            n = e.charCodeAt(t + 1), 45 !== n && 43 !== n || (r = 1, n = e.charCodeAt(t + 2)), Qa(n) && (t = ms(e, t + 1 + r + 1))
        }
        return t
    }

    function ks(e, t) {
        for (; t < e.length; t++) {
            const n = e.charCodeAt(t);
            if (41 === n) {
                t++;
                break
            }
            rs(n, us(e, t + 1)) && (t = gs(e, t))
        }
        return t
    }

    function vs(e) {
        if (1 === e.length && !Ya(e.charCodeAt(0))) return e[0];
        let t = parseInt(e, 16);
        return (0 === t || t >= 55296 && t <= 57343 || t > 1114111) && (t = 65533), String.fromCodePoint(t)
    }
    var xs = ["EOF-token", "ident-token", "function-token", "at-keyword-token", "hash-token", "string-token", "bad-string-token", "url-token", "bad-url-token", "delim-token", "number-token", "percentage-token", "dimension-token", "whitespace-token", "CDO-token", "CDC-token", "colon-token", "semicolon-token", "comma-token", "[-token", "]-token", "(-token", ")-token", "{-token", "}-token", "comment-token"];

    function ws(e = null, t) {
        return null === e || e.length < t ? new Uint32Array(Math.max(t + 1024, 16384)) : e
    }

    function Ss(e) {
        const t = e.source,
            n = t.length,
            r = t.length > 0 ? as(t.charCodeAt(0)) : 0,
            o = ws(e.lines, n),
            i = ws(e.columns, n);
        let a = e.startLine,
            s = e.startColumn;
        for (let e = r; e < n; e++) {
            const r = t.charCodeAt(e);
            o[e] = a, i[e] = s++, 10 !== r && 13 !== r && 12 !== r || (13 === r && e + 1 < n && 10 === t.charCodeAt(e + 1) && (e++, o[e] = a, i[e] = s), a++, s = 1)
        }
        o[n] = a, i[n] = s, e.lines = o, e.columns = i, e.computed = !0
    }
    class Cs {
        constructor(e, t, n, r) {
            this.setSource(e, t, n, r), this.lines = null, this.columns = null
        }
        setSource(e = "", t = 0, n = 1, r = 1) {
            this.source = e, this.startOffset = t, this.startLine = n, this.startColumn = r, this.computed = !1
        }
        getLocation(e, t) {
            return this.computed || Ss(this), {
                source: t,
                offset: this.startOffset + e,
                line: this.lines[e],
                column: this.columns[e]
            }
        }
        getLocationRange(e, t, n) {
            return this.computed || Ss(this), {
                source: n,
                start: {
                    offset: this.startOffset + e,
                    line: this.lines[e],
                    column: this.columns[e]
                },
                end: {
                    offset: this.startOffset + t,
                    line: this.lines[t],
                    column: this.columns[t]
                }
            }
        }
    }
    const zs = 16777215,
        As = 24,
        _s = new Uint8Array(32);

    function Os(e) {
        return 0 !== _s[e]
    }
    _s[2] = Ga, _s[21] = Ga, _s[19] = Ua, _s[23] = Ha;
    class Ts {
        constructor(e, t) {
            this.setSource(e, t)
        }
        reset() {
            this.eof = !1, this.tokenIndex = -1, this.tokenType = 0, this.tokenStart = this.firstCharOffset, this.tokenEnd = this.firstCharOffset
        }
        setSource(e = "", t = () => {}) {
            const n = (e = String(e || "")).length,
                r = ws(this.offsetAndType, e.length + 1),
                o = ws(this.balance, e.length + 1);
            let i = 0,
                a = -1,
                s = 0,
                l = e.length;
            this.offsetAndType = null, this.balance = null, o.fill(0), t(e, (e, t, n) => {
                const c = i++;
                if (r[c] = e << As | n, -1 === a && (a = t), o[c] = l, e === s) {
                    const e = o[l];
                    o[l] = c, l = e, s = _s[r[e] >> As]
                } else Os(e) && (l = c, s = _s[e])
            }), r[i] = 0 | n, o[i] = i;
            for (let e = 0; e < i; e++) {
                const t = o[e];
                if (t <= e) {
                    const n = o[t];
                    n !== e && (o[e] = n)
                } else t > i && (o[e] = i)
            }
            this.source = e, this.firstCharOffset = -1 === a ? 0 : a, this.tokenCount = i, this.offsetAndType = r, this.balance = o, this.reset(), this.next()
        }
        lookupType(e) {
            return (e += this.tokenIndex) < this.tokenCount ? this.offsetAndType[e] >> As : 0
        }
        lookupTypeNonSC(e) {
            for (let t = this.tokenIndex; t < this.tokenCount; t++) {
                const n = this.offsetAndType[t] >> As;
                if (n !== Na && n !== Ka && 0 === e--) return n
            }
            return 0
        }
        lookupOffset(e) {
            return (e += this.tokenIndex) < this.tokenCount ? this.offsetAndType[e - 1] & zs : this.source.length
        }
        lookupOffsetNonSC(e) {
            for (let t = this.tokenIndex; t < this.tokenCount; t++) {
                const n = this.offsetAndType[t] >> As;
                if (n !== Na && n !== Ka && 0 === e--) return t - this.tokenIndex
            }
            return 0
        }
        lookupValue(e, t) {
            return (e += this.tokenIndex) < this.tokenCount && ds(this.source, this.offsetAndType[e - 1] & zs, this.offsetAndType[e] & zs, t)
        }
        getTokenStart(e) {
            return e === this.tokenIndex ? this.tokenStart : e > 0 ? e < this.tokenCount ? this.offsetAndType[e - 1] & zs : this.offsetAndType[this.tokenCount] & zs : this.firstCharOffset
        }
        substrToCursor(e) {
            return this.source.substring(e, this.tokenStart)
        }
        isBalanceEdge(e) {
            return this.balance[this.tokenIndex] < e
        }
        isDelim(e, t) {
            return t ? 9 === this.lookupType(t) && this.source.charCodeAt(this.lookupOffset(t)) === e : 9 === this.tokenType && this.source.charCodeAt(this.tokenStart) === e
        }
        skip(e) {
            let t = this.tokenIndex + e;
            t < this.tokenCount ? (this.tokenIndex = t, this.tokenStart = this.offsetAndType[t - 1] & zs, t = this.offsetAndType[t], this.tokenType = t >> As, this.tokenEnd = t & zs) : (this.tokenIndex = this.tokenCount, this.next())
        }
        next() {
            let e = this.tokenIndex + 1;
            e < this.tokenCount ? (this.tokenIndex = e, this.tokenStart = this.tokenEnd, e = this.offsetAndType[e], this.tokenType = e >> As, this.tokenEnd = e & zs) : (this.eof = !0, this.tokenIndex = this.tokenCount, this.tokenType = 0, this.tokenStart = this.tokenEnd = this.source.length)
        }
        skipSC() {
            for (; this.tokenType === Na || this.tokenType === Ka;) this.next()
        }
        skipUntilBalanced(e, t) {
            let n = e,
                r = 0,
                o = 0;
            e: for (; n < this.tokenCount && (r = this.balance[n], !(r < e)); n++) switch (o = n > 0 ? this.offsetAndType[n - 1] & zs : this.firstCharOffset, t(this.source.charCodeAt(o))) {
                case 1:
                    break e;
                case 2:
                    n++;
                    break e;
                default:
                    Os(this.offsetAndType[n] >> As) && (n = r)
            }
            this.skip(n - this.tokenIndex)
        }
        forEachToken(e) {
            for (let t = 0, n = this.firstCharOffset; t < this.tokenCount; t++) {
                const r = n,
                    o = this.offsetAndType[t],
                    i = o & zs;
                n = i, e(o >> As, r, i, t)
            }
        }
        dump() {
            const e = new Array(this.tokenCount);
            return this.forEachToken((t, n, r, o) => {
                e[o] = {
                    idx: o,
                    type: xs[t],
                    chunk: this.source.substring(n, r),
                    balance: this.balance[o]
                }
            }), e
        }
    }

    function Ls(e, t) {
        function n(t) {
            return t < a ? e.charCodeAt(t) : 0
        }

        function r() {
            return c = ys(e, c), os(n(c), n(c + 1), n(c + 2)) ? (s = Da, void(c = bs(e, c))) : 37 === n(c) ? (s = Pa, void c++) : void(s = Ra)
        }

        function o() {
            const t = c;
            return c = bs(e, c), ds(e, t, c, "url") && 40 === n(c) ? (c = fs(e, c + 1), 34 === n(c) || 39 === n(c) ? (s = 2, void(c = t + 4)) : void
                function() {
                    for (s = 7, c = fs(e, c); c < e.length; c++) {
                        const t = e.charCodeAt(c);
                        switch (cs(t)) {
                            case 41:
                                return void c++;
                            case ls:
                                return c = fs(e, c), 41 === n(c) || c >= e.length ? void(c < e.length && c++) : (c = ks(e, c), void(s = 8));
                            case 34:
                            case 39:
                            case 40:
                            case 133:
                                return c = ks(e, c), void(s = 8);
                            case 92:
                                if (rs(t, n(c + 1))) {
                                    c = gs(e, c) - 1;
                                    break
                                }
                                return c = ks(e, c), void(s = 8)
                        }
                    }
                }()) : 40 === n(c) ? (s = 2, void c++) : void(s = 1)
        }

        function i(t) {
            for (t || (t = n(c++)), s = 5; c < e.length; c++) {
                const r = e.charCodeAt(c);
                switch (cs(r)) {
                    case t:
                        return void c++;
                    case ls:
                        if (ts(r)) return c += hs(e, c, r), void(s = 6);
                        break;
                    case 92:
                        if (c === e.length - 1) break;
                        const o = n(c + 1);
                        ts(o) ? c += hs(e, c + 1, o) : rs(r, o) && (c = gs(e, c) - 1)
                }
            }
        }
        const a = (e = String(e || "")).length;
        let s, l = as(n(0)),
            c = l;
        for (; c < a;) {
            const a = e.charCodeAt(c);
            switch (cs(a)) {
                case ls:
                    s = Na, c = fs(e, c + 1);
                    break;
                case 34:
                    i();
                    break;
                case 35:
                    Ja(n(c + 1)) || rs(n(c + 1), n(c + 2)) ? (s = 4, c = bs(e, c + 1)) : (s = 9, c++);
                    break;
                case 39:
                    i();
                    break;
                case 40:
                    s = $a, c++;
                    break;
                case 41:
                    s = Ga, c++;
                    break;
                case 43:
                    is(a, n(c + 1), n(c + 2)) ? r() : (s = 9, c++);
                    break;
                case 44:
                    s = qa, c++;
                    break;
                case 45:
                    is(a, n(c + 1), n(c + 2)) ? r() : 45 === n(c + 1) && 62 === n(c + 2) ? (s = Ma, c += 3) : os(a, n(c + 1), n(c + 2)) ? o() : (s = 9, c++);
                    break;
                case 46:
                    is(a, n(c + 1), n(c + 2)) ? r() : (s = 9, c++);
                    break;
                case 47:
                    42 === n(c + 1) ? (s = Ka, c = e.indexOf("*/", c + 2), c = -1 === c ? e.length : c + 2) : (s = 9, c++);
                    break;
                case 58:
                    s = Fa, c++;
                    break;
                case 59:
                    s = Ba, c++;
                    break;
                case 60:
                    33 === n(c + 1) && 45 === n(c + 2) && 45 === n(c + 3) ? (s = 14, c += 4) : (s = 9, c++);
                    break;
                case 64:
                    os(n(c + 1), n(c + 2), n(c + 3)) ? (s = 3, c = bs(e, c + 1)) : (s = 9, c++);
                    break;
                case 91:
                    s = Wa, c++;
                    break;
                case 92:
                    rs(a, n(c + 1)) ? o() : (s = 9, c++);
                    break;
                case 93:
                    s = Ua, c++;
                    break;
                case 123:
                    s = Va, c++;
                    break;
                case 125:
                    s = Ha, c++;
                    break;
                case 131:
                    r();
                    break;
                case 132:
                    o();
                    break;
                default:
                    s = 9, c++
            }
            t(s, l, l = c)
        }
    }
    let Es = null;
    class js {
        static createItem(e) {
            return {
                prev: null,
                next: null,
                data: e
            }
        }
        constructor() {
            this.head = null, this.tail = null, this.cursor = null
        }
        createItem(e) {
            return js.createItem(e)
        }
        allocateCursor(e, t) {
            let n;
            return null !== Es ? (n = Es, Es = Es.cursor, n.prev = e, n.next = t, n.cursor = this.cursor) : n = {
                prev: e,
                next: t,
                cursor: this.cursor
            }, this.cursor = n, n
        }
        releaseCursor() {
            const {
                cursor: e
            } = this;
            this.cursor = e.cursor, e.prev = null, e.next = null, e.cursor = Es, Es = e
        }
        updateCursors(e, t, n, r) {
            let {
                cursor: o
            } = this;
            for (; null !== o;) o.prev === e && (o.prev = t), o.next === n && (o.next = r), o = o.cursor
        }*[Symbol.iterator]() {
            for (let e = this.head; null !== e; e = e.next) yield e.data
        }
        get size() {
            let e = 0;
            for (let t = this.head; null !== t; t = t.next) e++;
            return e
        }
        get isEmpty() {
            return null === this.head
        }
        get first() {
            return this.head && this.head.data
        }
        get last() {
            return this.tail && this.tail.data
        }
        fromArray(e) {
            let t = null;
            this.head = null;
            for (let n of e) {
                const e = js.createItem(n);
                null !== t ? t.next = e : this.head = e, e.prev = t, t = e
            }
            return this.tail = t, this
        }
        toArray() {
            return [...this]
        }
        toJSON() {
            return [...this]
        }
        forEach(e, t = this) {
            const n = this.allocateCursor(null, this.head);
            for (; null !== n.next;) {
                const r = n.next;
                n.next = r.next, e.call(t, r.data, r, this)
            }
            this.releaseCursor()
        }
        forEachRight(e, t = this) {
            const n = this.allocateCursor(this.tail, null);
            for (; null !== n.prev;) {
                const r = n.prev;
                n.prev = r.prev, e.call(t, r.data, r, this)
            }
            this.releaseCursor()
        }
        reduce(e, t, n = this) {
            let r, o = this.allocateCursor(null, this.head),
                i = t;
            for (; null !== o.next;) r = o.next, o.next = r.next, i = e.call(n, i, r.data, r, this);
            return this.releaseCursor(), i
        }
        reduceRight(e, t, n = this) {
            let r, o = this.allocateCursor(this.tail, null),
                i = t;
            for (; null !== o.prev;) r = o.prev, o.prev = r.prev, i = e.call(n, i, r.data, r, this);
            return this.releaseCursor(), i
        }
        some(e, t = this) {
            for (let n = this.head; null !== n; n = n.next)
                if (e.call(t, n.data, n, this)) return !0;
            return !1
        }
        map(e, t = this) {
            const n = new js;
            for (let r = this.head; null !== r; r = r.next) n.appendData(e.call(t, r.data, r, this));
            return n
        }
        filter(e, t = this) {
            const n = new js;
            for (let r = this.head; null !== r; r = r.next) e.call(t, r.data, r, this) && n.appendData(r.data);
            return n
        }
        nextUntil(e, t, n = this) {
            if (null === e) return;
            const r = this.allocateCursor(null, e);
            for (; null !== r.next;) {
                const e = r.next;
                if (r.next = e.next, t.call(n, e.data, e, this)) break
            }
            this.releaseCursor()
        }
        prevUntil(e, t, n = this) {
            if (null === e) return;
            const r = this.allocateCursor(e, null);
            for (; null !== r.prev;) {
                const e = r.prev;
                if (r.prev = e.prev, t.call(n, e.data, e, this)) break
            }
            this.releaseCursor()
        }
        clear() {
            this.head = null, this.tail = null
        }
        copy() {
            const e = new js;
            for (let t of this) e.appendData(t);
            return e
        }
        prepend(e) {
            return this.updateCursors(null, e, this.head, e), null !== this.head ? (this.head.prev = e, e.next = this.head) : this.tail = e, this.head = e, this
        }
        prependData(e) {
            return this.prepend(js.createItem(e))
        }
        append(e) {
            return this.insert(e)
        }
        appendData(e) {
            return this.insert(js.createItem(e))
        }
        insert(e, t = null) {
            if (null !== t)
                if (this.updateCursors(t.prev, e, t, e), null === t.prev) {
                    if (this.head !== t) throw new Error("before doesn't belong to list");
                    this.head = e, t.prev = e, e.next = t, this.updateCursors(null, e)
                } else t.prev.next = e, e.prev = t.prev, t.prev = e, e.next = t;
            else this.updateCursors(this.tail, e, null, e), null !== this.tail ? (this.tail.next = e, e.prev = this.tail) : this.head = e, this.tail = e;
            return this
        }
        insertData(e, t) {
            return this.insert(js.createItem(e), t)
        }
        remove(e) {
            if (this.updateCursors(e, e.prev, e, e.next), null !== e.prev) e.prev.next = e.next;
            else {
                if (this.head !== e) throw new Error("item doesn't belong to list");
                this.head = e.next
            }
            if (null !== e.next) e.next.prev = e.prev;
            else {
                if (this.tail !== e) throw new Error("item doesn't belong to list");
                this.tail = e.prev
            }
            return e.prev = null, e.next = null, e
        }
        push(e) {
            this.insert(js.createItem(e))
        }
        pop() {
            return null !== this.tail ? this.remove(this.tail) : null
        }
        unshift(e) {
            this.prepend(js.createItem(e))
        }
        shift() {
            return null !== this.head ? this.remove(this.head) : null
        }
        prependList(e) {
            return this.insertList(e, this.head)
        }
        appendList(e) {
            return this.insertList(e)
        }
        insertList(e, t) {
            return null === e.head || (null != t ? (this.updateCursors(t.prev, e.tail, t, e.head), null !== t.prev ? (t.prev.next = e.head, e.head.prev = t.prev) : this.head = e.head, t.prev = e.tail, e.tail.next = t) : (this.updateCursors(this.tail, e.tail, null, e.head), null !== this.tail ? (this.tail.next = e.head, e.head.prev = this.tail) : this.head = e.head, this.tail = e.tail), e.head = null, e.tail = null), this
        }
        replace(e, t) {
            "head" in t ? this.insertList(t, e) : this.insert(t, e), this.remove(e)
        }
    }

    function Is(e, t) {
        const n = Object.create(SyntaxError.prototype),
            r = new Error;
        return Object.assign(n, {
            name: e,
            message: t,
            get stack() {
                return (r.stack || "").replace(/^(.+\n){1,3}/, `${e}: ${t}\n`)
            }
        })
    }
    const Rs = "    ";

    function Ps({
        source: e,
        line: t,
        column: n,
        baseLine: r,
        baseColumn: o
    }, i) {
        function a(e, t) {
            return s.slice(e, t).map((t, n) => String(e + n + 1).padStart(u) + " |" + t).join("\n")
        }
        const s = ("\n".repeat(Math.max(r - 1, 0)) + " ".repeat(Math.max(o - 1, 0)) + e).split(/\r\n?|\n|\f/),
            l = Math.max(1, t - i) - 1,
            c = Math.min(t + i, s.length + 1),
            u = Math.max(4, String(c).length) + 1;
        let h = 0;
        (n += 3 * (s[t - 1].substr(0, n - 1).match(/\t/g) || []).length) > 100 && (h = n - 60 + 3, n = 58);
        for (let e = l; e <= c; e++) e >= 0 && e < s.length && (s[e] = s[e].replace(/\t/g, Rs), s[e] = (h > 0 && s[e].length > h ? "…" : "") + s[e].substr(h, 98) + (s[e].length > h + 100 - 1 ? "…" : ""));
        return [a(l, t), new Array(n + u + 2).join("-") + "^", a(t, c)].filter(Boolean).join("\n").replace(/^(\s+\d+\s+\|\n)+/, "").replace(/\n(\s+\d+\s+\|)+$/, "")
    }

    function Ds(e, t, n, r, o, i = 1, a = 1) {
        return Object.assign(Is("SyntaxError", e), {
            source: t,
            offset: n,
            line: r,
            column: o,
            sourceFragment: e => Ps({
                source: t,
                line: r,
                column: o,
                baseLine: i,
                baseColumn: a
            }, isNaN(e) ? 0 : e),
            get formattedMessage() {
                return `Parse error: ${e}\n` + Ps({
                    source: t,
                    line: r,
                    column: o,
                    baseLine: i,
                    baseColumn: a
                }, 2)
            }
        })
    }

    function Ns(e) {
        const t = this.createList();
        let n = !1;
        const r = {
            recognizer: e
        };
        for (; !this.eof;) {
            switch (this.tokenType) {
                case Ka:
                    this.next();
                    continue;
                case Na:
                    n = !0, this.next();
                    continue
            }
            let o = e.getNode.call(this, r);
            if (void 0 === o) break;
            n && (e.onWhiteSpace && e.onWhiteSpace.call(this, o, t, r), n = !1), t.push(o)
        }
        return n && e.onWhiteSpace && e.onWhiteSpace.call(this, null, t, r), t
    }
    const Ms = () => {};

    function Fs(e) {
        return function() {
            return this[e]()
        }
    }

    function Bs(e) {
        const t = Object.create(null);
        for (const n of Object.keys(e)) {
            const r = e[n],
                o = r.parse || r;
            o && (t[n] = o)
        }
        return t
    }

    function qs(e) {
        let t = "",
            n = "<unknown>",
            r = !1,
            o = Ms,
            i = !1;
        const a = new Cs,
            s = Object.assign(new Ts, function(e) {
                const t = {
                    context: Object.create(null),
                    features: Object.assign(Object.create(null), e.features),
                    scope: Object.assign(Object.create(null), e.scope),
                    atrule: Bs(e.atrule),
                    pseudo: Bs(e.pseudo),
                    node: Bs(e.node)
                };
                for (const [n, r] of Object.entries(e.parseContext)) switch (typeof r) {
                    case "function":
                        t.context[n] = r;
                        break;
                    case "string":
                        t.context[n] = Fs(r)
                }
                return {
                    config: t,
                    ...t,
                    ...t.node
                }
            }(e || {}), {
                parseAtrulePrelude: !0,
                parseRulePrelude: !0,
                parseValue: !0,
                parseCustomProperty: !1,
                readSequence: Ns,
                consumeUntilBalanceEnd: () => 0,
                consumeUntilLeftCurlyBracket: e => 123 === e ? 1 : 0,
                consumeUntilLeftCurlyBracketOrSemicolon: e => 123 === e || 59 === e ? 1 : 0,
                consumeUntilExclamationMarkOrSemicolon: e => 33 === e || 59 === e ? 1 : 0,
                consumeUntilSemicolonIncluded: e => 59 === e ? 2 : 0,
                createList: () => new js,
                createSingleNodeList: e => (new js).appendData(e),
                getFirstListNode: e => e && e.first,
                getLastListNode: e => e && e.last,
                parseWithFallback(e, t) {
                    const n = this.tokenIndex;
                    try {
                        return e.call(this)
                    } catch (e) {
                        if (i) throw e;
                        this.skip(n - this.tokenIndex);
                        const r = t.call(this);
                        return i = !0, o(e, r), i = !1, r
                    }
                },
                lookupNonWSType(e) {
                    let t;
                    do {
                        if (t = this.lookupType(e++), t !== Na && t !== Ka) return t
                    } while (0 !== t);
                    return 0
                },
                charCodeAt: e => e >= 0 && e < t.length ? t.charCodeAt(e) : 0,
                substring: (e, n) => t.substring(e, n),
                substrToCursor(e) {
                    return this.source.substring(e, this.tokenStart)
                },
                cmpChar: (e, n) => ps(t, e, n),
                cmpStr: (e, n, r) => ds(t, e, n, r),
                consume(e) {
                    const t = this.tokenStart;
                    return this.eat(e), this.substrToCursor(t)
                },
                consumeFunctionName() {
                    const e = t.substring(this.tokenStart, this.tokenEnd - 1);
                    return this.eat(2), e
                },
                consumeNumber(e) {
                    const n = t.substring(this.tokenStart, ys(t, this.tokenStart));
                    return this.eat(e), n
                },
                eat(e) {
                    if (this.tokenType !== e) {
                        const t = xs[e].slice(0, -6).replace(/-/g, " ").replace(/^./, e => e.toUpperCase());
                        let n = `${/[[\](){}]/.test(t)?`
                        "${t}"
                        `:t} is expected`, r = this.tokenStart;
                        switch (e) {
                            case 1:
                                2 === this.tokenType || 7 === this.tokenType ? (r = this.tokenEnd - 1, n = "Identifier is expected but function found") : n = "Identifier is expected";
                                break;
                            case 4:
                                this.isDelim(35) && (this.next(), r++, n = "Name is expected");
                                break;
                            case Pa:
                                this.tokenType === Ra && (r = this.tokenEnd, n = "Percent sign is expected")
                        }
                        this.error(n, r)
                    }
                    this.next()
                },
                eatIdent(e) {
                    1 === this.tokenType && !1 !== this.lookupValue(0, e) || this.error(`Identifier "${e}" is expected`), this.next()
                },
                eatDelim(e) {
                    this.isDelim(e) || this.error(`Delim "${String.fromCharCode(e)}" is expected`), this.next()
                },
                getLocation: (e, t) => r ? a.getLocationRange(e, t, n) : null,
                getLocationFromList(e) {
                    if (r) {
                        const t = this.getFirstListNode(e),
                            r = this.getLastListNode(e);
                        return a.getLocationRange(null !== t ? t.loc.start.offset - a.startOffset : this.tokenStart, null !== r ? r.loc.end.offset - a.startOffset : this.tokenStart, n)
                    }
                    return null
                },
                error(e, n) {
                    const r = void 0 !== n && n < t.length ? a.getLocation(n) : this.eof ? a.getLocation(function(e, t) {
                        for (; t >= 0 && ns(e.charCodeAt(t)); t--);
                        return t + 1
                    }(t, t.length - 1)) : a.getLocation(this.tokenStart);
                    throw new Ds(e || "Unexpected input", t, r.offset, r.line, r.column, a.startLine, a.startColumn)
                }
            });
        return Object.assign(function(e, l) {
            t = e, l = l || {}, s.setSource(t, Ls), a.setSource(t, l.offset, l.line, l.column), n = l.filename || "<unknown>", r = Boolean(l.positions), o = "function" == typeof l.onParseError ? l.onParseError : Ms, i = !1, s.parseAtrulePrelude = !("parseAtrulePrelude" in l) || Boolean(l.parseAtrulePrelude), s.parseRulePrelude = !("parseRulePrelude" in l) || Boolean(l.parseRulePrelude), s.parseValue = !("parseValue" in l) || Boolean(l.parseValue), s.parseCustomProperty = "parseCustomProperty" in l && Boolean(l.parseCustomProperty);
            const {
                context: c = "default",
                onComment: u
            } = l;
            if (c in s.context == !1) throw new Error("Unknown context `" + c + "`");
            "function" == typeof u && s.forEachToken((e, n, r) => {
                if (e === Ka) {
                    const e = s.getLocation(n, r),
                        o = ds(t, r - 2, r, "*/") ? t.slice(n + 2, r - 2) : t.slice(n + 2, r);
                    u(o, e)
                }
            });
            const h = s.context[c].call(s, l);
            return s.eof || s.error(), h
        }, {
            SyntaxError: Ds,
            config: s.config
        })
    }
    var Ws, Us, $s = {},
        Gs = {},
        Vs = {};

    function Hs() {
        if (Ws) return Vs;
        Ws = 1;
        var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".split("");
        return Vs.encode = function(t) {
            if (0 <= t && t < e.length) return e[t];
            throw new TypeError("Must be between 0 and 63: " + t)
        }, Vs.decode = function(e) {
            return 65 <= e && e <= 90 ? e - 65 : 97 <= e && e <= 122 ? e - 97 + 26 : 48 <= e && e <= 57 ? e - 48 + 52 : 43 == e ? 62 : 47 == e ? 63 : -1
        }, Vs
    }
    var Ks, Qs = {};

    function Ys() {
        return Ks || (Ks = 1, function(e) {
            e.getArg = function(e, t, n) {
                if (t in e) return e[t];
                if (3 === arguments.length) return n;
                throw new Error('"' + t + '" is a required argument.')
            };
            var t = /^(?:([\w+\-.]+):)?\/\/(?:(\w+:\w+)@)?([\w.-]*)(?::(\d+))?(.*)$/,
                n = /^data:.+\,.+$/;

            function r(e) {
                var n = e.match(t);
                return n ? {
                    scheme: n[1],
                    auth: n[2],
                    host: n[3],
                    port: n[4],
                    path: n[5]
                } : null
            }

            function o(e) {
                var t = "";
                return e.scheme && (t += e.scheme + ":"), t += "//", e.auth && (t += e.auth + "@"), e.host && (t += e.host), e.port && (t += ":" + e.port), e.path && (t += e.path), t
            }
            e.urlParse = r, e.urlGenerate = o;
            var i, a, s = (i = function(t) {
                var n = t,
                    i = r(t);
                if (i) {
                    if (!i.path) return t;
                    n = i.path
                }
                for (var a = e.isAbsolute(n), s = [], l = 0, c = 0;;) {
                    if (l = c, -1 === (c = n.indexOf("/", l))) {
                        s.push(n.slice(l));
                        break
                    }
                    for (s.push(n.slice(l, c)); c < n.length && "/" === n[c];) c++
                }
                var u, h = 0;
                for (c = s.length - 1; c >= 0; c--) "." === (u = s[c]) ? s.splice(c, 1) : ".." === u ? h++ : h > 0 && ("" === u ? (s.splice(c + 1, h), h = 0) : (s.splice(c, 2), h--));
                return "" === (n = s.join("/")) && (n = a ? "/" : "."), i ? (i.path = n, o(i)) : n
            }, a = [], function(e) {
                for (var t = 0; t < a.length; t++)
                    if (a[t].input === e) {
                        var n = a[0];
                        return a[0] = a[t], a[t] = n, a[0].result
                    }
                var r = i(e);
                return a.unshift({
                    input: e,
                    result: r
                }), a.length > 32 && a.pop(), r
            });

            function l(e, t) {
                "" === e && (e = "."), "" === t && (t = ".");
                var i = r(t),
                    a = r(e);
                if (a && (e = a.path || "/"), i && !i.scheme) return a && (i.scheme = a.scheme), o(i);
                if (i || t.match(n)) return t;
                if (a && !a.host && !a.path) return a.host = t, o(a);
                var l = "/" === t.charAt(0) ? t : s(e.replace(/\/+$/, "") + "/" + t);
                return a ? (a.path = l, o(a)) : l
            }
            e.normalize = s, e.join = l, e.isAbsolute = function(e) {
                return "/" === e.charAt(0) || t.test(e)
            }, e.relative = function(e, t) {
                "" === e && (e = "."), e = e.replace(/\/$/, "");
                for (var n = 0; 0 !== t.indexOf(e + "/");) {
                    var r = e.lastIndexOf("/");
                    if (r < 0) return t;
                    if ((e = e.slice(0, r)).match(/^([^\/]+:\/)?\/*$/)) return t;
                    ++n
                }
                return Array(n + 1).join("../") + t.substr(e.length + 1)
            };
            var c = !("__proto__" in Object.create(null));

            function u(e) {
                return e
            }

            function h(e) {
                if (!e) return !1;
                var t = e.length;
                if (t < 9) return !1;
                if (95 !== e.charCodeAt(t - 1) || 95 !== e.charCodeAt(t - 2) || 111 !== e.charCodeAt(t - 3) || 116 !== e.charCodeAt(t - 4) || 111 !== e.charCodeAt(t - 5) || 114 !== e.charCodeAt(t - 6) || 112 !== e.charCodeAt(t - 7) || 95 !== e.charCodeAt(t - 8) || 95 !== e.charCodeAt(t - 9)) return !1;
                for (var n = t - 10; n >= 0; n--)
                    if (36 !== e.charCodeAt(n)) return !1;
                return !0
            }

            function p(e, t) {
                return e === t ? 0 : null === e ? 1 : null === t ? -1 : e > t ? 1 : -1
            }
            e.toSetString = c ? u : function(e) {
                return h(e) ? "$" + e : e
            }, e.fromSetString = c ? u : function(e) {
                return h(e) ? e.slice(1) : e
            }, e.compareByOriginalPositions = function(e, t, n) {
                var r = p(e.source, t.source);
                return 0 !== r || 0 !== (r = e.originalLine - t.originalLine) || 0 !== (r = e.originalColumn - t.originalColumn) || n || 0 !== (r = e.generatedColumn - t.generatedColumn) || 0 !== (r = e.generatedLine - t.generatedLine) ? r : p(e.name, t.name)
            }, e.compareByOriginalPositionsNoSource = function(e, t, n) {
                var r;
                return 0 !== (r = e.originalLine - t.originalLine) || 0 !== (r = e.originalColumn - t.originalColumn) || n || 0 !== (r = e.generatedColumn - t.generatedColumn) || 0 !== (r = e.generatedLine - t.generatedLine) ? r : p(e.name, t.name)
            }, e.compareByGeneratedPositionsDeflated = function(e, t, n) {
                var r = e.generatedLine - t.generatedLine;
                return 0 !== r || 0 !== (r = e.generatedColumn - t.generatedColumn) || n || 0 !== (r = p(e.source, t.source)) || 0 !== (r = e.originalLine - t.originalLine) || 0 !== (r = e.originalColumn - t.originalColumn) ? r : p(e.name, t.name)
            }, e.compareByGeneratedPositionsDeflatedNoLine = function(e, t, n) {
                var r = e.generatedColumn - t.generatedColumn;
                return 0 !== r || n || 0 !== (r = p(e.source, t.source)) || 0 !== (r = e.originalLine - t.originalLine) || 0 !== (r = e.originalColumn - t.originalColumn) ? r : p(e.name, t.name)
            }, e.compareByGeneratedPositionsInflated = function(e, t) {
                var n = e.generatedLine - t.generatedLine;
                return 0 !== n || 0 !== (n = e.generatedColumn - t.generatedColumn) || 0 !== (n = p(e.source, t.source)) || 0 !== (n = e.originalLine - t.originalLine) || 0 !== (n = e.originalColumn - t.originalColumn) ? n : p(e.name, t.name)
            }, e.parseSourceMapInput = function(e) {
                return JSON.parse(e.replace(/^\)]}'[^\n]*\n/, ""))
            }, e.computeSourceURL = function(e, t, n) {
                if (t = t || "", e && ("/" !== e[e.length - 1] && "/" !== t[0] && (e += "/"), t = e + t), n) {
                    var i = r(n);
                    if (!i) throw new Error("sourceMapURL could not be parsed");
                    if (i.path) {
                        var a = i.path.lastIndexOf("/");
                        a >= 0 && (i.path = i.path.substring(0, a + 1))
                    }
                    t = l(o(i), t)
                }
                return s(t)
            }
        }(Qs)), Qs
    }
    var Xs, Zs = {};
    var Js, el, tl = {};

    function nl() {
        if (Js) return tl;
        Js = 1;
        var e = Ys();

        function t() {
            this._array = [], this._sorted = !0, this._last = {
                generatedLine: -1,
                generatedColumn: 0
            }
        }
        return t.prototype.unsortedForEach = function(e, t) {
            this._array.forEach(e, t)
        }, t.prototype.add = function(t) {
            var n, r, o, i, a, s;
            n = this._last, r = t, o = n.generatedLine, i = r.generatedLine, a = n.generatedColumn, s = r.generatedColumn, i > o || i == o && s >= a || e.compareByGeneratedPositionsInflated(n, r) <= 0 ? (this._last = t, this._array.push(t)) : (this._sorted = !1, this._array.push(t))
        }, t.prototype.toArray = function() {
            return this._sorted || (this._array.sort(e.compareByGeneratedPositionsInflated), this._sorted = !0), this._array
        }, tl.MappingList = t, tl
    }
    var rl = function() {
        if (el) return $s;
        el = 1;
        var e = function() {
                if (Us) return Gs;
                Us = 1;
                var e = Hs();
                return Gs.encode = function(t) {
                    var n, r = "",
                        o = function(e) {
                            return e < 0 ? 1 + (-e << 1) : 0 + (e << 1)
                        }(t);
                    do {
                        n = 31 & o, (o >>>= 5) > 0 && (n |= 32), r += e.encode(n)
                    } while (o > 0);
                    return r
                }, Gs.decode = function(t, n, r) {
                    var o, i, a, s, l = t.length,
                        c = 0,
                        u = 0;
                    do {
                        if (n >= l) throw new Error("Expected more digits in base 64 VLQ value.");
                        if (-1 === (i = e.decode(t.charCodeAt(n++)))) throw new Error("Invalid base64 digit: " + t.charAt(n - 1));
                        o = !!(32 & i), c += (i &= 31) << u, u += 5
                    } while (o);
                    r.value = (s = (a = c) >> 1, 1 & ~a ? s : -s), r.rest = n
                }, Gs
            }(),
            t = Ys(),
            n = function() {
                if (Xs) return Zs;
                Xs = 1;
                var e = Ys(),
                    t = Object.prototype.hasOwnProperty,
                    n = "undefined" != typeof Map;

                function r() {
                    this._array = [], this._set = n ? new Map : Object.create(null)
                }
                return r.fromArray = function(e, t) {
                    for (var n = new r, o = 0, i = e.length; o < i; o++) n.add(e[o], t);
                    return n
                }, r.prototype.size = function() {
                    return n ? this._set.size : Object.getOwnPropertyNames(this._set).length
                }, r.prototype.add = function(r, o) {
                    var i = n ? r : e.toSetString(r),
                        a = n ? this.has(r) : t.call(this._set, i),
                        s = this._array.length;
                    a && !o || this._array.push(r), a || (n ? this._set.set(r, s) : this._set[i] = s)
                }, r.prototype.has = function(r) {
                    if (n) return this._set.has(r);
                    var o = e.toSetString(r);
                    return t.call(this._set, o)
                }, r.prototype.indexOf = function(r) {
                    if (n) {
                        var o = this._set.get(r);
                        if (o >= 0) return o
                    } else {
                        var i = e.toSetString(r);
                        if (t.call(this._set, i)) return this._set[i]
                    }
                    throw new Error('"' + r + '" is not in the set.')
                }, r.prototype.at = function(e) {
                    if (e >= 0 && e < this._array.length) return this._array[e];
                    throw new Error("No element indexed by " + e)
                }, r.prototype.toArray = function() {
                    return this._array.slice()
                }, Zs.ArraySet = r, Zs
            }().ArraySet,
            r = nl().MappingList;

        function o(e) {
            e || (e = {}), this._file = t.getArg(e, "file", null), this._sourceRoot = t.getArg(e, "sourceRoot", null), this._skipValidation = t.getArg(e, "skipValidation", !1), this._ignoreInvalidMapping = t.getArg(e, "ignoreInvalidMapping", !1), this._sources = new n, this._names = new n, this._mappings = new r, this._sourcesContents = null
        }
        return o.prototype._version = 3, o.fromSourceMap = function(e, n) {
            var r = e.sourceRoot,
                i = new o(Object.assign(n || {}, {
                    file: e.file,
                    sourceRoot: r
                }));
            return e.eachMapping(function(e) {
                var n = {
                    generated: {
                        line: e.generatedLine,
                        column: e.generatedColumn
                    }
                };
                null != e.source && (n.source = e.source, null != r && (n.source = t.relative(r, n.source)), n.original = {
                    line: e.originalLine,
                    column: e.originalColumn
                }, null != e.name && (n.name = e.name)), i.addMapping(n)
            }), e.sources.forEach(function(n) {
                var o = n;
                null !== r && (o = t.relative(r, n)), i._sources.has(o) || i._sources.add(o);
                var a = e.sourceContentFor(n);
                null != a && i.setSourceContent(n, a)
            }), i
        }, o.prototype.addMapping = function(e) {
            var n = t.getArg(e, "generated"),
                r = t.getArg(e, "original", null),
                o = t.getArg(e, "source", null),
                i = t.getArg(e, "name", null);
            (this._skipValidation || !1 !== this._validateMapping(n, r, o, i)) && (null != o && (o = String(o), this._sources.has(o) || this._sources.add(o)), null != i && (i = String(i), this._names.has(i) || this._names.add(i)), this._mappings.add({
                generatedLine: n.line,
                generatedColumn: n.column,
                originalLine: null != r && r.line,
                originalColumn: null != r && r.column,
                source: o,
                name: i
            }))
        }, o.prototype.setSourceContent = function(e, n) {
            var r = e;
            null != this._sourceRoot && (r = t.relative(this._sourceRoot, r)), null != n ? (this._sourcesContents || (this._sourcesContents = Object.create(null)), this._sourcesContents[t.toSetString(r)] = n) : this._sourcesContents && (delete this._sourcesContents[t.toSetString(r)], 0 === Object.keys(this._sourcesContents).length && (this._sourcesContents = null))
        }, o.prototype.applySourceMap = function(e, r, o) {
            var i = r;
            if (null == r) {
                if (null == e.file) throw new Error('SourceMapGenerator.prototype.applySourceMap requires either an explicit source file, or the source map\'s "file" property. Both were omitted.');
                i = e.file
            }
            var a = this._sourceRoot;
            null != a && (i = t.relative(a, i));
            var s = new n,
                l = new n;
            this._mappings.unsortedForEach(function(n) {
                if (n.source === i && null != n.originalLine) {
                    var r = e.originalPositionFor({
                        line: n.originalLine,
                        column: n.originalColumn
                    });
                    null != r.source && (n.source = r.source, null != o && (n.source = t.join(o, n.source)), null != a && (n.source = t.relative(a, n.source)), n.originalLine = r.line, n.originalColumn = r.column, null != r.name && (n.name = r.name))
                }
                var c = n.source;
                null == c || s.has(c) || s.add(c);
                var u = n.name;
                null == u || l.has(u) || l.add(u)
            }, this), this._sources = s, this._names = l, e.sources.forEach(function(n) {
                var r = e.sourceContentFor(n);
                null != r && (null != o && (n = t.join(o, n)), null != a && (n = t.relative(a, n)), this.setSourceContent(n, r))
            }, this)
        }, o.prototype._validateMapping = function(e, t, n, r) {
            if (t && "number" != typeof t.line && "number" != typeof t.column) {
                var o = "original.line and original.column are not numbers -- you probably meant to omit the original mapping entirely and only map the generated position. If so, pass null for the original mapping instead of an object with empty or null values.";
                if (this._ignoreInvalidMapping) return "undefined" != typeof console && console.warn && console.warn(o), !1;
                throw new Error(o)
            }
            if ((!(e && "line" in e && "column" in e && e.line > 0 && e.column >= 0) || t || n || r) && !(e && "line" in e && "column" in e && t && "line" in t && "column" in t && e.line > 0 && e.column >= 0 && t.line > 0 && t.column >= 0 && n)) {
                o = "Invalid mapping: " + JSON.stringify({
                    generated: e,
                    source: n,
                    original: t,
                    name: r
                });
                if (this._ignoreInvalidMapping) return "undefined" != typeof console && console.warn && console.warn(o), !1;
                throw new Error(o)
            }
        }, o.prototype._serializeMappings = function() {
            for (var n, r, o, i, a = 0, s = 1, l = 0, c = 0, u = 0, h = 0, p = "", d = this._mappings.toArray(), f = 0, m = d.length; f < m; f++) {
                if (n = "", (r = d[f]).generatedLine !== s)
                    for (a = 0; r.generatedLine !== s;) n += ";", s++;
                else if (f > 0) {
                    if (!t.compareByGeneratedPositionsInflated(r, d[f - 1])) continue;
                    n += ","
                }
                n += e.encode(r.generatedColumn - a), a = r.generatedColumn, null != r.source && (i = this._sources.indexOf(r.source), n += e.encode(i - h), h = i, n += e.encode(r.originalLine - 1 - c), c = r.originalLine - 1, n += e.encode(r.originalColumn - l), l = r.originalColumn, null != r.name && (o = this._names.indexOf(r.name), n += e.encode(o - u), u = o)), p += n
            }
            return p
        }, o.prototype._generateSourcesContent = function(e, n) {
            return e.map(function(e) {
                if (!this._sourcesContents) return null;
                null != n && (e = t.relative(n, e));
                var r = t.toSetString(e);
                return Object.prototype.hasOwnProperty.call(this._sourcesContents, r) ? this._sourcesContents[r] : null
            }, this)
        }, o.prototype.toJSON = function() {
            var e = {
                version: this._version,
                sources: this._sources.toArray(),
                names: this._names.toArray(),
                mappings: this._serializeMappings()
            };
            return null != this._file && (e.file = this._file), null != this._sourceRoot && (e.sourceRoot = this._sourceRoot), this._sourcesContents && (e.sourcesContent = this._generateSourcesContent(e.sources, e.sourceRoot)), e
        }, o.prototype.toString = function() {
            return JSON.stringify(this.toJSON())
        }, $s.SourceMapGenerator = o, $s
    }();
    const ol = new Set(["Atrule", "Selector", "Declaration"]);
    const il = (e, t) => {
            if (9 === e && (e = t), "string" == typeof e) {
                const t = e.charCodeAt(0);
                return t > 127 ? 32768 : t << 8
            }
            return e
        },
        al = [
            [1, 1],
            [1, 2],
            [1, 7],
            [1, 8],
            [1, "-"],
            [1, Ra],
            [1, Pa],
            [1, Da],
            [1, Ma],
            [1, $a],
            [3, 1],
            [3, 2],
            [3, 7],
            [3, 8],
            [3, "-"],
            [3, Ra],
            [3, Pa],
            [3, Da],
            [3, Ma],
            [4, 1],
            [4, 2],
            [4, 7],
            [4, 8],
            [4, "-"],
            [4, Ra],
            [4, Pa],
            [4, Da],
            [4, Ma],
            [Da, 1],
            [Da, 2],
            [Da, 7],
            [Da, 8],
            [Da, "-"],
            [Da, Ra],
            [Da, Pa],
            [Da, Da],
            [Da, Ma],
            ["#", 1],
            ["#", 2],
            ["#", 7],
            ["#", 8],
            ["#", "-"],
            ["#", Ra],
            ["#", Pa],
            ["#", Da],
            ["#", Ma],
            ["-", 1],
            ["-", 2],
            ["-", 7],
            ["-", 8],
            ["-", "-"],
            ["-", Ra],
            ["-", Pa],
            ["-", Da],
            ["-", Ma],
            [Ra, 1],
            [Ra, 2],
            [Ra, 7],
            [Ra, 8],
            [Ra, Ra],
            [Ra, Pa],
            [Ra, Da],
            [Ra, "%"],
            [Ra, Ma],
            ["@", 1],
            ["@", 2],
            ["@", 7],
            ["@", 8],
            ["@", "-"],
            ["@", Ma],
            [".", Ra],
            [".", Pa],
            [".", Da],
            ["+", Ra],
            ["+", Pa],
            ["+", Da],
            ["/", "*"]
        ],
        sl = al.concat([
            [1, 4],
            [Da, 4],
            [4, 4],
            [3, $a],
            [3, 5],
            [3, Fa],
            [Pa, Pa],
            [Pa, Da],
            [Pa, 2],
            [Pa, "-"],
            [Ga, 1],
            [Ga, 2],
            [Ga, Pa],
            [Ga, Da],
            [Ga, 4],
            [Ga, "-"]
        ]);

    function ll(e) {
        const t = new Set(e.map(([e, t]) => il(e) << 16 | il(t)));
        return function(e, n, r) {
            const o = il(n, r),
                i = r.charCodeAt(0);
            return (45 === i && 1 !== n && 2 !== n && n !== Ma || 43 === i ? t.has(e << 16 | i << 8) : t.has(e << 16 | o)) && this.emit(" ", Na, !0), o
        }
    }
    const cl = ll(al),
        ul = ll(sl);
    var hl = Object.freeze({
        __proto__: null,
        safe: ul,
        spec: cl
    });

    function pl(e, t) {
        if ("function" == typeof t) {
            let n = null;
            return void e.children.forEach(e => {
                null !== n && t.call(this, n), this.node(e), n = e
            })
        }
        e.children.forEach(this.node, this)
    }

    function dl(e) {
        Ls(e, (t, n, r) => {
            this.token(t, e.slice(n, r))
        })
    }

    function fl(e) {
        const t = new Map;
        for (let [n, r] of Object.entries(e.node)) {
            "function" == typeof(r.generate || r) && t.set(n, r.generate || r)
        }
        return function(e, n) {
            let r = "",
                o = 0,
                i = {
                    node(e) {
                        if (!t.has(e.type)) throw new Error("Unknown node type: " + e.type);
                        t.get(e.type).call(a, e)
                    },
                    tokenBefore: ul,
                    token(e, t) {
                        o = this.tokenBefore(o, e, t), this.emit(t, e, !1), 9 === e && 92 === t.charCodeAt(0) && this.emit("\n", Na, !0)
                    },
                    emit(e) {
                        r += e
                    },
                    result: () => r
                };
            n && ("function" == typeof n.decorator && (i = n.decorator(i)), n.sourceMap && (i = function(e) {
                const t = new rl.SourceMapGenerator,
                    n = {
                        line: 1,
                        column: 0
                    },
                    r = {
                        line: 0,
                        column: 0
                    },
                    o = {
                        line: 1,
                        column: 0
                    },
                    i = {
                        generated: o
                    };
                let a = 1,
                    s = 0,
                    l = !1;
                const c = e.node;
                e.node = function(e) {
                    if (e.loc && e.loc.start && ol.has(e.type)) {
                        const c = e.loc.start.line,
                            u = e.loc.start.column - 1;
                        r.line === c && r.column === u || (r.line = c, r.column = u, n.line = a, n.column = s, l && (l = !1, n.line === o.line && n.column === o.column || t.addMapping(i)), l = !0, t.addMapping({
                            source: e.loc.source,
                            original: r,
                            generated: n
                        }))
                    }
                    c.call(this, e), l && ol.has(e.type) && (o.line = a, o.column = s)
                };
                const u = e.emit;
                e.emit = function(e, t, n) {
                    for (let t = 0; t < e.length; t++) 10 === e.charCodeAt(t) ? (a++, s = 0) : s++;
                    u(e, t, n)
                };
                const h = e.result;
                return e.result = function() {
                    return l && t.addMapping(i), {
                        css: h(),
                        map: t
                    }
                }, e
            }(i)), n.mode in hl && (i.tokenBefore = hl[n.mode]));
            const a = {
                node: e => i.node(e),
                children: pl,
                token: (e, t) => i.token(e, t),
                tokenize: dl
            };
            return i.node(e), i.result()
        }
    }
    const {
        hasOwnProperty: ml
    } = Object.prototype, gl = function() {};

    function bl(e) {
        return "function" == typeof e ? e : gl
    }

    function yl(e, t) {
        return function(n, r, o) {
            n.type === t && e.call(this, n, r, o)
        }
    }

    function kl(e, t) {
        const n = t.structure,
            r = [];
        for (const e in n) {
            if (!1 === ml.call(n, e)) continue;
            let t = n[e];
            const o = {
                name: e,
                type: !1,
                nullable: !1
            };
            Array.isArray(t) || (t = [t]);
            for (const e of t) null === e ? o.nullable = !0 : "string" == typeof e ? o.type = "node" : Array.isArray(e) && (o.type = "list");
            o.type && r.push(o)
        }
        return r.length ? {
            context: t.walkContext,
            fields: r
        } : null
    }

    function vl(e, t) {
        const n = e.fields.slice(),
            r = e.context,
            o = "string" == typeof r;
        return t && n.reverse(),
            function(e, i, a, s) {
                let l;
                o && (l = i[r], i[r] = e);
                for (const r of n) {
                    const n = e[r.name];
                    if (!r.nullable || n)
                        if ("list" === r.type) {
                            if (t ? n.reduceRight(s, !1) : n.reduce(s, !1)) return !0
                        } else if (a(n)) return !0
                }
                o && (i[r] = l)
            }
    }

    function xl({
        StyleSheet: e,
        Atrule: t,
        Rule: n,
        Block: r,
        DeclarationList: o
    }) {
        return {
            Atrule: {
                StyleSheet: e,
                Atrule: t,
                Rule: n,
                Block: r
            },
            Rule: {
                StyleSheet: e,
                Atrule: t,
                Rule: n,
                Block: r
            },
            Declaration: {
                StyleSheet: e,
                Atrule: t,
                Rule: n,
                Block: r,
                DeclarationList: o
            }
        }
    }

    function wl(e) {
        const t = function(e) {
                const t = {};
                for (const n in e.node)
                    if (ml.call(e.node, n)) {
                        const r = e.node[n];
                        if (!r.structure) throw new Error("Missed `structure` field in `" + n + "` node type definition");
                        t[n] = kl(0, r)
                    }
                return t
            }(e),
            n = {},
            r = {},
            o = Symbol("break-walk"),
            i = Symbol("skip-node");
        for (const e in t) ml.call(t, e) && null !== t[e] && (n[e] = vl(t[e], !1), r[e] = vl(t[e], !0));
        const a = xl(n),
            s = xl(r),
            l = function(e, l) {
                function c(e, t, n) {
                    const r = u.call(f, e, t, n);
                    return r === o || r !== i && (!(!p.hasOwnProperty(e.type) || !p[e.type](e, f, c, d)) || h.call(f, e, t, n) === o)
                }
                let u = gl,
                    h = gl,
                    p = n,
                    d = (e, t, n, r) => e || c(t, n, r);
                const f = {
                    break: o,
                    skip: i,
                    root: e,
                    stylesheet: null,
                    atrule: null,
                    atrulePrelude: null,
                    rule: null,
                    selector: null,
                    block: null,
                    declaration: null,
                    function: null
                };
                if ("function" == typeof l) u = l;
                else if (l && (u = bl(l.enter), h = bl(l.leave), l.reverse && (p = r), l.visit)) {
                    if (a.hasOwnProperty(l.visit)) p = l.reverse ? s[l.visit] : a[l.visit];
                    else if (!t.hasOwnProperty(l.visit)) throw new Error("Bad value `" + l.visit + "` for `visit` option (should be: " + Object.keys(t).sort().join(", ") + ")");
                    u = yl(u, l.visit), h = yl(h, l.visit)
                }
                if (u === gl && h === gl) throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function");
                c(e)
            };
        return l.break = o, l.skip = i, l.find = function(e, t) {
            let n = null;
            return l(e, function(e, r, i) {
                if (t.call(this, e, r, i)) return n = e, o
            }), n
        }, l.findLast = function(e, t) {
            let n = null;
            return l(e, {
                reverse: !0,
                enter(e, r, i) {
                    if (t.call(this, e, r, i)) return n = e, o
                }
            }), n
        }, l.findAll = function(e, t) {
            const n = [];
            return l(e, function(e, r, o) {
                t.call(this, e, r, o) && n.push(e)
            }), n
        }, l
    }

    function Sl(e) {
        return e
    }

    function Cl(e, t, n, r) {
        let o;
        switch (e.type) {
            case "Group":
                o = function(e, t, n, r) {
                    const o = " " === e.combinator || r ? e.combinator : " " + e.combinator + " ",
                        i = e.terms.map(e => Cl(e, t, n, r)).join(o);
                    return e.explicit || n ? (r || "," === i[0] ? "[" : "[ ") + i + (r ? "]" : " ]") : i
                }(e, t, n, r) + (e.disallowEmpty ? "!" : "");
                break;
            case "Multiplier":
                return Cl(e.term, t, n, r) + t(function(e) {
                    const {
                        min: t,
                        max: n,
                        comma: r
                    } = e;
                    return 0 === t && 0 === n ? r ? "#?" : "*" : 0 === t && 1 === n ? "?" : 1 === t && 0 === n ? r ? "#" : "+" : 1 === t && 1 === n ? "" : (r ? "#" : "") + (t === n ? "{" + t + "}" : "{" + t + "," + (0 !== n ? n : "") + "}")
                }(e), e);
            case "Boolean":
                o = "<boolean-expr[" + Cl(e.term, t, n, r) + "]>";
                break;
            case "Type":
                o = "<" + e.name + (e.opts ? t(function(e) {
                    if ("Range" === e.type) return " [" + (null === e.min ? "-∞" : e.min) + "," + (null === e.max ? "∞" : e.max) + "]";
                    throw new Error("Unknown node type `" + e.type + "`")
                }(e.opts), e.opts) : "") + ">";
                break;
            case "Property":
                o = "<'" + e.name + "'>";
                break;
            case "Keyword":
                o = e.name;
                break;
            case "AtKeyword":
                o = "@" + e.name;
                break;
            case "Function":
                o = e.name + "(";
                break;
            case "String":
            case "Token":
                o = e.value;
                break;
            case "Comma":
                o = ",";
                break;
            default:
                throw new Error("Unknown node type `" + e.type + "`")
        }
        return t(o, e)
    }

    function zl(e, t) {
        let n = Sl,
            r = !1,
            o = !1;
        return "function" == typeof t ? n = t : t && (r = Boolean(t.forceBraces), o = Boolean(t.compact), "function" == typeof t.decorate && (n = t.decorate)), Cl(e, n, r, o)
    }
    const Al = {
        offset: 0,
        line: 1,
        column: 1
    };

    function _l(e, t) {
        const n = e && e.loc && e.loc[t];
        return n ? "line" in n ? Ol(n) : n : null
    }

    function Ol({
        offset: e,
        line: t,
        column: n
    }, r) {
        const o = {
            offset: e,
            line: t,
            column: n
        };
        if (r) {
            const e = r.split(/\n|\r\n?|\f/);
            o.offset += r.length, o.line += e.length - 1, o.column = 1 === e.length ? o.column + r.length : e.pop().length + 1
        }
        return o
    }
    const Tl = function(e, t) {
            const n = Is("SyntaxReferenceError", e + (t ? " `" + t + "`" : ""));
            return n.reference = t, n
        },
        Ll = function(e, t, n, r) {
            const o = Is("SyntaxMatchError", e),
                {
                    css: i,
                    mismatchOffset: a,
                    mismatchLength: s,
                    start: l,
                    end: c
                } = function(e, t) {
                    const n = e.tokens,
                        r = e.longestMatch,
                        o = r < n.length && n[r].node || null,
                        i = o !== t ? o : null;
                    let a, s, l = 0,
                        c = 0,
                        u = 0,
                        h = "";
                    for (let e = 0; e < n.length; e++) {
                        const t = n[e].value;
                        e === r && (c = t.length, l = h.length), null !== i && n[e].node === i && (e <= r ? u++ : u = 0), h += t
                    }
                    return r === n.length || u > 1 ? (a = _l(i || t, "end") || Ol(Al, h), s = Ol(a)) : (a = _l(i, "start") || Ol(_l(t, "start") || Al, h.slice(0, l)), s = _l(i, "end") || Ol(a, h.substr(l, c))), {
                        css: h,
                        mismatchOffset: l,
                        mismatchLength: c,
                        start: a,
                        end: s
                    }
                }(r, n);
            return o.rawMessage = e, o.syntax = t ? zl(t) : "<generic>", o.css = i, o.mismatchOffset = a, o.mismatchLength = s, o.message = e + "\n  syntax: " + o.syntax + "\n   value: " + (i || "<empty string>") + "\n  --------" + new Array(o.mismatchOffset + 1).join("-") + "^", Object.assign(o, l), o.loc = {
                source: n && n.loc && n.loc.source || "<unknown>",
                start: l,
                end: c
            }, o
        },
        El = new Map,
        jl = new Map,
        Il = function(e) {
            if (El.has(e)) return El.get(e);
            const t = e.toLowerCase();
            let n = El.get(t);
            if (void 0 === n) {
                const e = Pl(t, 0),
                    r = e ? "" : Dl(t, 0);
                n = Object.freeze({
                    basename: t.substr(r.length),
                    name: t,
                    prefix: r,
                    vendor: r,
                    custom: e
                })
            }
            return El.set(e, n), n
        },
        Rl = function(e) {
            if (jl.has(e)) return jl.get(e);
            let t = e,
                n = e[0];
            "/" === n ? n = "/" === e[1] ? "//" : "/" : "_" !== n && "*" !== n && "$" !== n && "#" !== n && "+" !== n && "&" !== n && (n = "");
            const r = Pl(t, n.length);
            if (!r && (t = t.toLowerCase(), jl.has(t))) {
                const n = jl.get(t);
                return jl.set(e, n), n
            }
            const o = r ? "" : Dl(t, n.length),
                i = t.substr(0, n.length + o.length),
                a = Object.freeze({
                    basename: t.substr(i.length),
                    name: t.substr(n.length),
                    hack: n,
                    vendor: o,
                    prefix: i,
                    custom: r
                });
            return jl.set(e, a), a
        };

    function Pl(e, t) {
        return t = t || 0, e.length - t >= 2 && 45 === e.charCodeAt(t) && 45 === e.charCodeAt(t + 1)
    }

    function Dl(e, t) {
        if (t = t || 0, e.length - t >= 3 && 45 === e.charCodeAt(t) && 45 !== e.charCodeAt(t + 1)) {
            const n = e.indexOf("-", t + 2);
            if (-1 !== n) return e.substring(t, n + 1)
        }
        return ""
    }
    const Nl = ["initial", "inherit", "unset", "revert", "revert-layer"],
        Ml = 45,
        Fl = !0;

    function Bl(e, t) {
        return null !== e && 9 === e.type && e.value.charCodeAt(0) === t
    }

    function ql(e, t, n) {
        for (; null !== e && (e.type === Na || e.type === Ka);) e = n(++t);
        return t
    }

    function Wl(e, t, n, r) {
        if (!e) return 0;
        const o = e.value.charCodeAt(t);
        if (43 === o || o === Ml) {
            if (n) return 0;
            t++
        }
        for (; t < e.value.length; t++)
            if (!Qa(e.value.charCodeAt(t))) return 0;
        return r + 1
    }

    function Ul(e, t, n) {
        let r = !1,
            o = ql(e, t, n);
        if (null === (e = n(o))) return t;
        if (e.type !== Ra) {
            if (!Bl(e, 43) && !Bl(e, Ml)) return t;
            if (r = !0, o = ql(n(++o), o, n), null === (e = n(o)) || e.type !== Ra) return 0
        }
        if (!r) {
            const t = e.value.charCodeAt(0);
            if (43 !== t && t !== Ml) return 0
        }
        return Wl(e, r ? 0 : 1, r, o)
    }

    function $l(e, t) {
        return null !== e && 9 === e.type && e.value.charCodeAt(0) === t
    }

    function Gl(e, t, n) {
        let r = 0;
        for (let o = t; o < e.value.length; o++) {
            const i = e.value.charCodeAt(o);
            if (45 === i && n && 0 !== r) return Gl(e, t + r + 1, !1), 6;
            if (!Ya(i)) return 0;
            if (++r > 6) return 0
        }
        return r
    }

    function Vl(e, t, n) {
        if (!e) return 0;
        for (; $l(n(t), 63);) {
            if (++e > 6) return 0;
            t++
        }
        return t
    }
    const Hl = ["calc(", "-moz-calc(", "-webkit-calc("],
        Kl = new Map([
            [2, Ga],
            [$a, Ga],
            [Wa, Ua],
            [Va, Ha]
        ]);

    function Ql(e, t) {
        return t < e.length ? e.charCodeAt(t) : 0
    }

    function Yl(e, t) {
        return ds(e, 0, e.length, t)
    }

    function Xl(e, t) {
        for (let n = 0; n < t.length; n++)
            if (Yl(e, t[n])) return !0;
        return !1
    }

    function Zl(e, t) {
        return t === e.length - 2 && (92 === Ql(e, t) && Qa(Ql(e, t + 1)))
    }

    function Jl(e, t, n) {
        if (e && "Range" === e.type) {
            const r = Number(void 0 !== n && n !== t.length ? t.substr(0, n) : t);
            if (isNaN(r)) return !0;
            if (null !== e.min && r < e.min && "string" != typeof e.min) return !0;
            if (null !== e.max && r > e.max && "string" != typeof e.max) return !0
        }
        return !1
    }

    function ec(e) {
        return function(t, n, r) {
            return null === t ? 0 : 2 === t.type && Xl(t.value, Hl) ? function(e, t) {
                let n = 0,
                    r = [],
                    o = 0;
                e: do {
                    switch (e.type) {
                        case Ha:
                        case Ga:
                        case Ua:
                            if (e.type !== n) break e;
                            if (n = r.pop(), 0 === r.length) {
                                o++;
                                break e
                            }
                            break;
                        case 2:
                        case $a:
                        case Wa:
                        case Va:
                            r.push(n), n = Kl.get(e.type)
                    }
                    o++
                } while (e = t(o));
                return o
            }(t, n) : e(t, n, r)
        }
    }

    function tc(e) {
        return function(t) {
            return null === t || t.type !== e ? 0 : 1
        }
    }

    function nc(e) {
        return null === e || 1 !== e.type || 45 !== Ql(e.value, 0) || 45 !== Ql(e.value, 1) ? 0 : 1
    }

    function rc(e) {
        return e && (e = new Set(e)),
            function(t, n, r) {
                if (null === t || t.type !== Da) return 0;
                const o = ys(t.value, 0);
                if (null !== e) {
                    const n = t.value.indexOf("\\", o),
                        r = -1 !== n && Zl(t.value, n) ? t.value.substring(o, n) : t.value.substr(o);
                    if (!1 === e.has(r.toLowerCase())) return 0
                }
                return Jl(r, t.value, o) ? 0 : 1
            }
    }

    function oc(e) {
        return "function" != typeof e && (e = function() {
                return 0
            }),
            function(t, n, r) {
                return null !== t && t.type === Ra && 0 === Number(t.value) ? 1 : e(t, n, r)
            }
    }
    const ic = {
            "ident-token": tc(1),
            "function-token": tc(2),
            "at-keyword-token": tc(3),
            "hash-token": tc(4),
            "string-token": tc(5),
            "bad-string-token": tc(6),
            "url-token": tc(7),
            "bad-url-token": tc(8),
            "delim-token": tc(9),
            "number-token": tc(Ra),
            "percentage-token": tc(Pa),
            "dimension-token": tc(Da),
            "whitespace-token": tc(Na),
            "CDO-token": tc(14),
            "CDC-token": tc(Ma),
            "colon-token": tc(Fa),
            "semicolon-token": tc(Ba),
            "comma-token": tc(qa),
            "[-token": tc(Wa),
            "]-token": tc(Ua),
            "(-token": tc($a),
            ")-token": tc(Ga),
            "{-token": tc(Va),
            "}-token": tc(Ha)
        },
        ac = {
            string: tc(5),
            ident: tc(1),
            percentage: ec(function(e, t, n) {
                return null === e || e.type !== Pa || Jl(n, e.value, e.value.length - 1) ? 0 : 1
            }),
            zero: oc(),
            number: ec(function(e, t, n) {
                if (null === e) return 0;
                const r = ys(e.value, 0);
                return r === e.value.length || Zl(e.value, r) ? Jl(n, e.value, r) ? 0 : 1 : 0
            }),
            integer: ec(function(e, t, n) {
                if (null === e || e.type !== Ra) return 0;
                let r = 43 === Ql(e.value, 0) || 45 === Ql(e.value, 0) ? 1 : 0;
                for (; r < e.value.length; r++)
                    if (!Qa(Ql(e.value, r))) return 0;
                return Jl(n, e.value, r) ? 0 : 1
            }),
            "custom-ident": function(e) {
                if (null === e || 1 !== e.type) return 0;
                const t = e.value.toLowerCase();
                return Xl(t, Nl) || Yl(t, "default") ? 0 : 1
            },
            "dashed-ident": nc,
            "custom-property-name": function(e) {
                return nc(e) ? "--" === e.value ? 0 : 1 : 0
            },
            "hex-color": function(e) {
                if (null === e || 4 !== e.type) return 0;
                const t = e.value.length;
                if (4 !== t && 5 !== t && 7 !== t && 9 !== t) return 0;
                for (let n = 1; n < t; n++)
                    if (!Ya(Ql(e.value, n))) return 0;
                return 1
            },
            "id-selector": function(e) {
                return null === e || 4 !== e.type ? 0 : os(Ql(e.value, 1), Ql(e.value, 2), Ql(e.value, 3)) ? 1 : 0
            },
            "an-plus-b": function(e, t) {
                let n = 0;
                if (!e) return 0;
                if (e.type === Ra) return Wl(e, 0, false, n);
                if (1 === e.type && e.value.charCodeAt(0) === Ml) {
                    if (!ps(e.value, 1, 110)) return 0;
                    switch (e.value.length) {
                        case 2:
                            return Ul(t(++n), n, t);
                        case 3:
                            return e.value.charCodeAt(2) !== Ml ? 0 : (n = ql(t(++n), n, t), Wl(e = t(n), 0, Fl, n));
                        default:
                            return e.value.charCodeAt(2) !== Ml ? 0 : Wl(e, 3, Fl, n)
                    }
                } else if (1 === e.type || Bl(e, 43) && 1 === t(n + 1).type) {
                    if (1 !== e.type && (e = t(++n)), null === e || !ps(e.value, 0, 110)) return 0;
                    switch (e.value.length) {
                        case 1:
                            return Ul(t(++n), n, t);
                        case 2:
                            return e.value.charCodeAt(1) !== Ml ? 0 : (n = ql(t(++n), n, t), Wl(e = t(n), 0, Fl, n));
                        default:
                            return e.value.charCodeAt(1) !== Ml ? 0 : Wl(e, 2, Fl, n)
                    }
                } else if (e.type === Da) {
                    let r = e.value.charCodeAt(0),
                        o = 43 === r || r === Ml ? 1 : 0,
                        i = o;
                    for (; i < e.value.length && Qa(e.value.charCodeAt(i)); i++);
                    return i === o ? 0 : ps(e.value, i, 110) ? i + 1 === e.value.length ? Ul(t(++n), n, t) : e.value.charCodeAt(i + 1) !== Ml ? 0 : i + 2 === e.value.length ? (n = ql(t(++n), n, t), Wl(e = t(n), 0, Fl, n)) : Wl(e, i + 2, Fl, n) : 0
                }
                return 0
            },
            urange: function(e, t) {
                let n = 0;
                if (null === e || 1 !== e.type || !ps(e.value, 0, 117)) return 0;
                if (null === (e = t(++n))) return 0;
                if ($l(e, 43)) return null === (e = t(++n)) ? 0 : 1 === e.type ? Vl(Gl(e, 0, !0), ++n, t) : $l(e, 63) ? Vl(1, ++n, t) : 0;
                if (e.type === Ra) {
                    const r = Gl(e, 1, !0);
                    return 0 === r ? 0 : null === (e = t(++n)) ? n : e.type === Da || e.type === Ra ? function(e, t) {
                        return e.value.charCodeAt(0) === t
                    }(e, 45) && Gl(e, 1, !1) ? n + 1 : 0 : Vl(r, n, t)
                }
                return e.type === Da ? Vl(Gl(e, 1, !0), ++n, t) : 0
            },
            "declaration-value": function(e, t) {
                if (!e) return 0;
                let n = 0,
                    r = [],
                    o = 0;
                e: do {
                    switch (e.type) {
                        case 6:
                        case 8:
                            break e;
                        case Ha:
                        case Ga:
                        case Ua:
                            if (e.type !== n) break e;
                            n = r.pop();
                            break;
                        case Ba:
                            if (0 === n) break e;
                            break;
                        case 9:
                            if (0 === n && "!" === e.value) break e;
                            break;
                        case 2:
                        case $a:
                        case Wa:
                        case Va:
                            r.push(n), n = Kl.get(e.type)
                    }
                    o++
                } while (e = t(o));
                return o
            },
            "any-value": function(e, t) {
                if (!e) return 0;
                let n = 0,
                    r = [],
                    o = 0;
                e: do {
                    switch (e.type) {
                        case 6:
                        case 8:
                            break e;
                        case Ha:
                        case Ga:
                        case Ua:
                            if (e.type !== n) break e;
                            n = r.pop();
                            break;
                        case 2:
                        case $a:
                        case Wa:
                        case Va:
                            r.push(n), n = Kl.get(e.type)
                    }
                    o++
                } while (e = t(o));
                return o
            }
        };

    function sc(e) {
        const {
            angle: t,
            decibel: n,
            frequency: r,
            flex: o,
            length: i,
            resolution: a,
            semitones: s,
            time: l
        } = e || {};
        return {
            dimension: ec(rc(null)),
            angle: ec(rc(t)),
            decibel: ec(rc(n)),
            frequency: ec(rc(r)),
            flex: ec(rc(o)),
            length: ec(oc(rc(i))),
            resolution: ec(rc(a)),
            semitones: ec(rc(s)),
            time: ec(rc(l))
        }
    }
    var lc = Object.freeze({
        __proto__: null,
        angle: ["deg", "grad", "rad", "turn"],
        decibel: ["db"],
        flex: ["fr"],
        frequency: ["hz", "khz"],
        length: ["cm", "mm", "q", "in", "pt", "pc", "px", "em", "rem", "ex", "rex", "cap", "rcap", "ch", "rch", "ic", "ric", "lh", "rlh", "vw", "svw", "lvw", "dvw", "vh", "svh", "lvh", "dvh", "vi", "svi", "lvi", "dvi", "vb", "svb", "lvb", "dvb", "vmin", "svmin", "lvmin", "dvmin", "vmax", "svmax", "lvmax", "dvmax", "cqw", "cqh", "cqi", "cqb", "cqmin", "cqmax"],
        resolution: ["dpi", "dpcm", "dppx", "x"],
        semitones: ["st"],
        time: ["s", "ms"]
    });

    function cc(e, t, n) {
        return Object.assign(Is("SyntaxError", e), {
            input: t,
            offset: n,
            rawMessage: e,
            message: e + "\n  " + t + "\n--" + new Array((n || t.length) + 1).join("-") + "^"
        })
    }
    const uc = new Uint8Array(128).map((e, t) => /[a-zA-Z0-9\-]/.test(String.fromCharCode(t)) ? 1 : 0);
    class hc {
        constructor(e) {
            this.str = e, this.pos = 0
        }
        charCodeAt(e) {
            return e < this.str.length ? this.str.charCodeAt(e) : 0
        }
        charCode() {
            return this.charCodeAt(this.pos)
        }
        isNameCharCode(e = this.charCode()) {
            return e < 128 && 1 === uc[e]
        }
        nextCharCode() {
            return this.charCodeAt(this.pos + 1)
        }
        nextNonWsCode(e) {
            return this.charCodeAt(this.findWsEnd(e))
        }
        skipWs() {
            this.pos = this.findWsEnd(this.pos)
        }
        findWsEnd(e) {
            for (; e < this.str.length; e++) {
                const t = this.str.charCodeAt(e);
                if (13 !== t && 10 !== t && 12 !== t && 32 !== t && 9 !== t) break
            }
            return e
        }
        substringToPos(e) {
            return this.str.substring(this.pos, this.pos = e)
        }
        eat(e) {
            this.charCode() !== e && this.error("Expect `" + String.fromCharCode(e) + "`"), this.pos++
        }
        peek() {
            return this.pos < this.str.length ? this.str.charAt(this.pos++) : ""
        }
        error(e) {
            throw new cc(e, this.str, this.pos)
        }
        scanSpaces() {
            return this.substringToPos(this.findWsEnd(this.pos))
        }
        scanWord() {
            let e = this.pos;
            for (; e < this.str.length; e++) {
                const t = this.str.charCodeAt(e);
                if (t >= 128 || 0 === uc[t]) break
            }
            return this.pos === e && this.error("Expect a keyword"), this.substringToPos(e)
        }
        scanNumber() {
            let e = this.pos;
            for (; e < this.str.length; e++) {
                const t = this.str.charCodeAt(e);
                if (t < 48 || t > 57) break
            }
            return this.pos === e && this.error("Expect a number"), this.substringToPos(e)
        }
        scanString() {
            const e = this.str.indexOf("'", this.pos + 1);
            return -1 === e && (this.pos = this.str.length, this.error("Expect an apostrophe")), this.substringToPos(e + 1)
        }
    }
    const pc = 123,
        dc = {
            " ": 1,
            "&&": 2,
            "||": 3,
            "|": 4
        };

    function fc(e) {
        let t = null,
            n = null;
        return e.eat(pc), e.skipWs(), t = e.scanNumber(e), e.skipWs(), 44 === e.charCode() ? (e.pos++, e.skipWs(), 125 !== e.charCode() && (n = e.scanNumber(e), e.skipWs())) : n = t, e.eat(125), {
            min: Number(t),
            max: n ? Number(n) : 0
        }
    }

    function mc(e, t) {
        const n = function(e) {
            let t = null,
                n = !1;
            switch (e.charCode()) {
                case 42:
                    e.pos++, t = {
                        min: 0,
                        max: 0
                    };
                    break;
                case 43:
                    e.pos++, t = {
                        min: 1,
                        max: 0
                    };
                    break;
                case 63:
                    e.pos++, t = {
                        min: 0,
                        max: 1
                    };
                    break;
                case 35:
                    e.pos++, n = !0, e.charCode() === pc ? t = fc(e) : 63 === e.charCode() ? (e.pos++, t = {
                        min: 0,
                        max: 0
                    }) : t = {
                        min: 1,
                        max: 0
                    };
                    break;
                case pc:
                    t = fc(e);
                    break;
                default:
                    return null
            }
            return {
                type: "Multiplier",
                comma: n,
                min: t.min,
                max: t.max,
                term: null
            }
        }(e);
        return null !== n ? (n.term = t, 35 === e.charCode() && 43 === e.charCodeAt(e.pos - 1) ? mc(e, n) : n) : t
    }

    function gc(e) {
        const t = e.peek();
        return "" === t ? null : mc(e, {
            type: "Token",
            value: t
        })
    }

    function bc(e) {
        let t, n = null;
        if (e.eat(60), t = e.scanWord(), "boolean-expr" === t) {
            e.eat(91);
            const t = kc(e, 93);
            return e.eat(93), e.eat(62), mc(e, {
                type: "Boolean",
                term: 1 === t.terms.length ? t.terms[0] : t
            })
        }
        return 40 === e.charCode() && 41 === e.nextCharCode() && (e.pos += 2, t += "()"), 91 === e.charCodeAt(e.findWsEnd(e.pos)) && (e.skipWs(), n = function(e) {
            let t = null,
                n = null,
                r = 1;
            return e.eat(91), 45 === e.charCode() && (e.peek(), r = -1), -1 == r && 8734 === e.charCode() ? e.peek() : (t = r * Number(e.scanNumber(e)), e.isNameCharCode() && (t += e.scanWord())), e.skipWs(), e.eat(44), e.skipWs(), 8734 === e.charCode() ? e.peek() : (r = 1, 45 === e.charCode() && (e.peek(), r = -1), n = r * Number(e.scanNumber(e)), e.isNameCharCode() && (n += e.scanWord())), e.eat(93), {
                type: "Range",
                min: t,
                max: n
            }
        }(e)), e.eat(62), mc(e, {
            type: "Type",
            name: t,
            opts: n
        })
    }

    function yc(e, t) {
        function n(e, t) {
            return {
                type: "Group",
                terms: e,
                combinator: t,
                disallowEmpty: !1,
                explicit: !1
            }
        }
        let r;
        for (t = Object.keys(t).sort((e, t) => dc[e] - dc[t]); t.length > 0;) {
            r = t.shift();
            let o = 0,
                i = 0;
            for (; o < e.length; o++) {
                const t = e[o];
                "Combinator" === t.type && (t.value === r ? (-1 === i && (i = o - 1), e.splice(o, 1), o--) : (-1 !== i && o - i > 1 && (e.splice(i, o - i, n(e.slice(i, o), r)), o = i + 1), i = -1))
            } - 1 !== i && t.length && e.splice(i, o - i, n(e.slice(i, o), r))
        }
        return r
    }

    function kc(e, t) {
        const n = Object.create(null),
            r = [];
        let o, i = null,
            a = e.pos;
        for (; e.charCode() !== t && (o = vc(e, t));) "Spaces" !== o.type && ("Combinator" === o.type ? (null !== i && "Combinator" !== i.type || (e.pos = a, e.error("Unexpected combinator")), n[o.value] = !0) : null !== i && "Combinator" !== i.type && (n[" "] = !0, r.push({
            type: "Combinator",
            value: " "
        })), r.push(o), i = o, a = e.pos);
        return null !== i && "Combinator" === i.type && (e.pos -= a, e.error("Unexpected combinator")), {
            type: "Group",
            terms: r,
            combinator: yc(r, n) || " ",
            disallowEmpty: !1,
            explicit: !1
        }
    }

    function vc(e, t) {
        let n = e.charCode();
        switch (n) {
            case 93:
                break;
            case 91:
                return mc(e, function(e, t) {
                    let n;
                    return e.eat(91), n = kc(e, t), e.eat(93), n.explicit = !0, 33 === e.charCode() && (e.pos++, n.disallowEmpty = !0), n
                }(e, t));
            case 60:
                return 39 === e.nextCharCode() ? function(e) {
                    let t;
                    return e.eat(60), e.eat(39), t = e.scanWord(), e.eat(39), e.eat(62), mc(e, {
                        type: "Property",
                        name: t
                    })
                }(e) : bc(e);
            case 124:
                return {
                    type: "Combinator",
                    value: e.substringToPos(e.pos + (124 === e.nextCharCode() ? 2 : 1))
                };
            case 38:
                return e.pos++, e.eat(38), {
                    type: "Combinator",
                    value: "&&"
                };
            case 44:
                return e.pos++, {
                    type: "Comma"
                };
            case 39:
                return mc(e, {
                    type: "String",
                    value: e.scanString()
                });
            case 32:
            case 9:
            case 10:
            case 13:
            case 12:
                return {
                    type: "Spaces",
                    value: e.scanSpaces()
                };
            case 64:
                return n = e.nextCharCode(), e.isNameCharCode(n) ? (e.pos++, {
                    type: "AtKeyword",
                    name: e.scanWord()
                }) : gc(e);
            case 42:
            case 43:
            case 63:
            case 35:
            case 33:
                break;
            case pc:
                if (n = e.nextCharCode(), n < 48 || n > 57) return gc(e);
                break;
            default:
                return e.isNameCharCode(n) ? function(e) {
                    const t = e.scanWord();
                    return 40 === e.charCode() ? (e.pos++, {
                        type: "Function",
                        name: t
                    }) : mc(e, {
                        type: "Keyword",
                        name: t
                    })
                }(e) : gc(e)
        }
    }

    function xc(e) {
        const t = new hc(e),
            n = kc(t);
        return t.pos !== e.length && t.error("Unexpected input"), 1 === n.terms.length && "Group" === n.terms[0].type ? n.terms[0] : n
    }
    const wc = function() {};

    function Sc(e) {
        return "function" == typeof e ? e : wc
    }
    const Cc = {
        decorator(e) {
            const t = [];
            let n = null;
            return { ...e,
                node(t) {
                    const r = n;
                    n = t, e.node.call(this, t), n = r
                },
                emit(e, r, o) {
                    t.push({
                        type: r,
                        value: e,
                        node: o ? null : n
                    })
                },
                result: () => t
            }
        }
    };

    function zc(e, t) {
        return "string" == typeof e ? function(e) {
            const t = [];
            return Ls(e, (n, r, o) => t.push({
                type: n,
                value: e.slice(r, o),
                node: null
            })), t
        }(e) : t.generate(e, Cc)
    }
    const Ac = {
            type: "Match"
        },
        _c = {
            type: "Mismatch"
        },
        Oc = {
            type: "DisallowEmpty"
        };

    function Tc(e, t, n) {
        return t === Ac && n === _c || e === Ac && t === Ac && n === Ac ? e : ("If" === e.type && e.else === _c && t === Ac && (t = e.then, e = e.match), {
            type: "If",
            match: e,
            then: t,
            else: n
        })
    }

    function Lc(e) {
        return e.length > 2 && 40 === e.charCodeAt(e.length - 2) && 41 === e.charCodeAt(e.length - 1)
    }

    function Ec(e) {
        return "Keyword" === e.type || "AtKeyword" === e.type || "Function" === e.type || "Type" === e.type && Lc(e.name)
    }

    function jc(e, t = " ", n = !1) {
        return {
            type: "Group",
            terms: e,
            combinator: t,
            disallowEmpty: !1,
            explicit: n
        }
    }

    function Ic(e, t, n = new Set) {
        if (!n.has(e)) switch (n.add(e), e.type) {
            case "If":
                e.match = Ic(e.match, t, n), e.then = Ic(e.then, t, n), e.else = Ic(e.else, t, n);
                break;
            case "Type":
                return t[e.name] || e
        }
        return e
    }

    function Rc(e, t, n) {
        switch (e) {
            case " ":
                {
                    let e = Ac;
                    for (let n = t.length - 1; n >= 0; n--) {
                        e = Tc(t[n], e, _c)
                    }
                    return e
                }
            case "|":
                {
                    let e = _c,
                        n = null;
                    for (let r = t.length - 1; r >= 0; r--) {
                        let o = t[r];
                        if (Ec(o) && (null === n && r > 0 && Ec(t[r - 1]) && (n = Object.create(null), e = Tc({
                                type: "Enum",
                                map: n
                            }, Ac, e)), null !== n)) {
                            const e = (Lc(o.name) ? o.name.slice(0, -1) : o.name).toLowerCase();
                            if (e in n == !1) {
                                n[e] = o;
                                continue
                            }
                        }
                        n = null, e = Tc(o, Ac, e)
                    }
                    return e
                }
            case "&&":
                {
                    if (t.length > 5) return {
                        type: "MatchOnce",
                        terms: t,
                        all: !0
                    };
                    let n = _c;
                    for (let r = t.length - 1; r >= 0; r--) {
                        const o = t[r];
                        let i;
                        i = t.length > 1 ? Rc(e, t.filter(function(e) {
                            return e !== o
                        }), !1) : Ac, n = Tc(o, i, n)
                    }
                    return n
                }
            case "||":
                {
                    if (t.length > 5) return {
                        type: "MatchOnce",
                        terms: t,
                        all: !1
                    };
                    let r = n ? Ac : _c;
                    for (let n = t.length - 1; n >= 0; n--) {
                        const o = t[n];
                        let i;
                        i = t.length > 1 ? Rc(e, t.filter(function(e) {
                            return e !== o
                        }), !0) : Ac, r = Tc(o, i, r)
                    }
                    return r
                }
        }
    }

    function Pc(e) {
        if ("function" == typeof e) return {
            type: "Generic",
            fn: e
        };
        switch (e.type) {
            case "Group":
                {
                    let t = Rc(e.combinator, e.terms.map(Pc), !1);
                    return e.disallowEmpty && (t = Tc(t, Oc, _c)),
                    t
                }
            case "Multiplier":
                return function(e) {
                    let t = Ac,
                        n = Pc(e.term);
                    if (0 === e.max) n = Tc(n, Oc, _c), t = Tc(n, null, _c), t.then = Tc(Ac, Ac, t), e.comma && (t.then.else = Tc({
                        type: "Comma",
                        syntax: e
                    }, t, _c));
                    else
                        for (let r = e.min || 1; r <= e.max; r++) e.comma && t !== Ac && (t = Tc({
                            type: "Comma",
                            syntax: e
                        }, t, _c)), t = Tc(n, Tc(Ac, Ac, t), _c);
                    if (0 === e.min) t = Tc(Ac, Ac, t);
                    else
                        for (let r = 0; r < e.min - 1; r++) e.comma && t !== Ac && (t = Tc({
                            type: "Comma",
                            syntax: e
                        }, t, _c)), t = Tc(n, t, _c);
                    return t
                }(e);
            case "Boolean":
                {
                    const t = Pc(e.term),
                        n = Pc(jc([jc([{
                            type: "Keyword",
                            name: "not"
                        }, {
                            type: "Type",
                            name: "!boolean-group"
                        }]), jc([{
                            type: "Type",
                            name: "!boolean-group"
                        }, jc([{
                            type: "Multiplier",
                            comma: !1,
                            min: 0,
                            max: 0,
                            term: jc([{
                                type: "Keyword",
                                name: "and"
                            }, {
                                type: "Type",
                                name: "!boolean-group"
                            }])
                        }, {
                            type: "Multiplier",
                            comma: !1,
                            min: 0,
                            max: 0,
                            term: jc([{
                                type: "Keyword",
                                name: "or"
                            }, {
                                type: "Type",
                                name: "!boolean-group"
                            }])
                        }], "|")])], "|")),
                        r = Pc(jc([{
                            type: "Type",
                            name: "!term"
                        }, jc([{
                            type: "Token",
                            value: "("
                        }, {
                            type: "Type",
                            name: "!self"
                        }, {
                            type: "Token",
                            value: ")"
                        }]), {
                            type: "Type",
                            name: "general-enclosed"
                        }], "|"));
                    return Ic(r, {
                        "!term": t,
                        "!self": n
                    }),
                    Ic(n, {
                        "!boolean-group": r
                    }),
                    n
                }
            case "Type":
            case "Property":
                return {
                    type: e.type,
                    name: e.name,
                    syntax: e
                };
            case "Keyword":
                return {
                    type: e.type,
                    name: e.name.toLowerCase(),
                    syntax: e
                };
            case "AtKeyword":
                return {
                    type: e.type,
                    name: "@" + e.name.toLowerCase(),
                    syntax: e
                };
            case "Function":
                return {
                    type: e.type,
                    name: e.name.toLowerCase() + "(",
                    syntax: e
                };
            case "String":
                return 3 === e.value.length ? {
                    type: "Token",
                    value: e.value.charAt(1),
                    syntax: e
                } : {
                    type: e.type,
                    value: e.value.substr(1, e.value.length - 2).replace(/\\'/g, "'"),
                    syntax: e
                };
            case "Token":
                return {
                    type: e.type,
                    value: e.value,
                    syntax: e
                };
            case "Comma":
                return {
                    type: e.type,
                    syntax: e
                };
            default:
                throw new Error("Unknown node type:", e.type)
        }
    }

    function Dc(e, t) {
        return "string" == typeof e && (e = xc(e)), {
            type: "MatchGraph",
            match: Pc(e),
            syntax: t || null,
            source: e
        }
    }
    const {
        hasOwnProperty: Nc
    } = Object.prototype, Mc = "Match";

    function Fc(e, t) {
        if (e.length !== t.length) return !1;
        for (let n = 0; n < e.length; n++) {
            const r = t.charCodeAt(n);
            let o = e.charCodeAt(n);
            if (o >= 65 && o <= 90 && (o |= 32), o !== r) return !1
        }
        return !0
    }

    function Bc(e) {
        return null === e || (e.type === qa || 2 === e.type || e.type === $a || e.type === Wa || e.type === Va || function(e) {
            return 9 === e.type && "?" !== e.value
        }(e))
    }

    function qc(e) {
        return null === e || (e.type === Ga || e.type === Ua || e.type === Ha || 9 === e.type && "/" === e.value)
    }

    function Wc(e, t, n) {
        const r = function(e, t, n) {
            function r() {
                do {
                    y++, b = y < e.length ? e[y] : null
                } while (null !== b && (b.type === Na || b.type === Ka))
            }

            function o(t) {
                const n = y + t;
                return n < e.length ? e[n] : null
            }

            function i(e, t) {
                return {
                    nextState: e,
                    matchStack: v,
                    syntaxStack: h,
                    thenStack: p,
                    tokenIndex: y,
                    prev: t
                }
            }

            function a(e) {
                p = {
                    nextState: e,
                    matchStack: v,
                    syntaxStack: h,
                    prev: p
                }
            }

            function s(e) {
                d = i(e, d)
            }

            function l() {
                v = {
                    type: 1,
                    syntax: t.syntax,
                    token: b,
                    prev: v
                }, r(), f = null, y > k && (k = y)
            }

            function c() {
                h = {
                    syntax: t.syntax,
                    opts: t.syntax.opts || null !== h && h.opts || null,
                    prev: h
                }, v = {
                    type: 2,
                    syntax: t.syntax,
                    token: v.token,
                    prev: v
                }
            }

            function u() {
                v = 2 === v.type ? v.prev : {
                    type: 3,
                    syntax: h.syntax,
                    token: v.token,
                    prev: v
                }, h = h.prev
            }
            let h = null,
                p = null,
                d = null,
                f = null,
                m = 0,
                g = null,
                b = null,
                y = -1,
                k = 0,
                v = {
                    type: 0,
                    syntax: null,
                    token: null,
                    prev: null
                };
            for (r(); null === g && ++m < 15e3;) switch (t.type) {
                case "Match":
                    if (null === p) {
                        if (null !== b && (y !== e.length - 1 || "\\0" !== b.value && "\\9" !== b.value)) {
                            t = _c;
                            break
                        }
                        g = Mc;
                        break
                    }
                    if ((t = p.nextState) === Oc) {
                        if (p.matchStack === v) {
                            t = _c;
                            break
                        }
                        t = Ac
                    }
                    for (; p.syntaxStack !== h;) u();
                    p = p.prev;
                    break;
                case "Mismatch":
                    if (null !== f && !1 !== f)(null === d || y > d.tokenIndex) && (d = f, f = !1);
                    else if (null === d) {
                        g = "Mismatch";
                        break
                    }
                    t = d.nextState, p = d.thenStack, h = d.syntaxStack, v = d.matchStack, y = d.tokenIndex, b = y < e.length ? e[y] : null, d = d.prev;
                    break;
                case "MatchGraph":
                    t = t.match;
                    break;
                case "If":
                    t.else !== _c && s(t.else), t.then !== Ac && a(t.then), t = t.match;
                    break;
                case "MatchOnce":
                    t = {
                        type: "MatchOnceBuffer",
                        syntax: t,
                        index: 0,
                        mask: 0
                    };
                    break;
                case "MatchOnceBuffer":
                    {
                        const e = t.syntax.terms;
                        if (t.index === e.length) {
                            if (0 === t.mask || t.syntax.all) {
                                t = _c;
                                break
                            }
                            t = Ac;
                            break
                        }
                        if (t.mask === (1 << e.length) - 1) {
                            t = Ac;
                            break
                        }
                        for (; t.index < e.length; t.index++) {
                            const n = 1 << t.index;
                            if (0 === (t.mask & n)) {
                                s(t), a({
                                    type: "AddMatchOnce",
                                    syntax: t.syntax,
                                    mask: t.mask | n
                                }), t = e[t.index++];
                                break
                            }
                        }
                        break
                    }
                case "AddMatchOnce":
                    t = {
                        type: "MatchOnceBuffer",
                        syntax: t.syntax,
                        index: 0,
                        mask: t.mask
                    };
                    break;
                case "Enum":
                    if (null !== b) {
                        let e = b.value.toLowerCase();
                        if (-1 !== e.indexOf("\\") && (e = e.replace(/\\[09].*$/, "")), Nc.call(t.map, e)) {
                            t = t.map[e];
                            break
                        }
                    }
                    t = _c;
                    break;
                case "Generic":
                    {
                        const e = null !== h ? h.opts : null,
                            n = y + Math.floor(t.fn(b, o, e));
                        if (!isNaN(n) && n > y) {
                            for (; y < n;) l();
                            t = Ac
                        } else t = _c;
                        break
                    }
                case "Type":
                case "Property":
                    {
                        const e = "Type" === t.type ? "types" : "properties",
                            r = Nc.call(n, e) ? n[e][t.name] : null;
                        if (!r || !r.match) throw new Error("Bad syntax reference: " + ("Type" === t.type ? "<" + t.name + ">" : "<'" + t.name + "'>"));
                        if (!1 !== f && null !== b && "Type" === t.type && ("custom-ident" === t.name && 1 === b.type || "length" === t.name && "0" === b.value)) {
                            null === f && (f = i(t, d)), t = _c;
                            break
                        }
                        c(),
                        t = r.matchRef || r.match;
                        break
                    }
                case "Keyword":
                    {
                        const e = t.name;
                        if (null !== b) {
                            let n = b.value;
                            if (-1 !== n.indexOf("\\") && (n = n.replace(/\\[09].*$/, "")), Fc(n, e)) {
                                l(), t = Ac;
                                break
                            }
                        }
                        t = _c;
                        break
                    }
                case "AtKeyword":
                case "Function":
                    if (null !== b && Fc(b.value, t.name)) {
                        l(), t = Ac;
                        break
                    }
                    t = _c;
                    break;
                case "Token":
                    if (null !== b && b.value === t.value) {
                        l(), t = Ac;
                        break
                    }
                    t = _c;
                    break;
                case "Comma":
                    null !== b && b.type === qa ? Bc(v.token) ? t = _c : (l(), t = qc(b) ? _c : Ac) : t = Bc(v.token) || qc(b) ? Ac : _c;
                    break;
                case "String":
                    let r = "",
                        m = y;
                    for (; m < e.length && r.length < t.value.length; m++) r += e[m].value;
                    if (Fc(r, t.value)) {
                        for (; y < m;) l();
                        t = Ac
                    } else t = _c;
                    break;
                default:
                    throw new Error("Unknown node type: " + t.type)
            }
            switch (g) {
                case null:
                    console.warn("[csstree-match] BREAK after 15000 iterations"), g = "Maximum iteration number exceeded (please fill an issue on https://github.com/csstree/csstree/issues)", v = null;
                    break;
                case Mc:
                    for (; null !== h;) u();
                    break;
                default:
                    v = null
            }
            return {
                tokens: e,
                reason: g,
                iterations: m,
                match: v,
                longestMatch: k
            }
        }(e, t, n || {});
        if (null === r.match) return r;
        let o = r.match,
            i = r.match = {
                syntax: t.syntax || null,
                match: []
            };
        const a = [i];
        for (o = function(e) {
                let t = null,
                    n = null,
                    r = e;
                for (; null !== r;) n = r.prev, r.prev = t, t = r, r = n;
                return t
            }(o).prev; null !== o;) {
            switch (o.type) {
                case 2:
                    i.match.push(i = {
                        syntax: o.syntax,
                        match: []
                    }), a.push(i);
                    break;
                case 3:
                    a.pop(), i = a[a.length - 1];
                    break;
                default:
                    i.match.push({
                        syntax: o.syntax || null,
                        token: o.token.value,
                        node: o.token.node
                    })
            }
            o = o.prev
        }
        return r
    }

    function Uc(e) {
        function t(e) {
            return null !== e && ("Type" === e.type || "Property" === e.type || "Keyword" === e.type)
        }
        let n = null;
        return null !== this.matched && function r(o) {
            if (Array.isArray(o.match)) {
                for (let e = 0; e < o.match.length; e++)
                    if (r(o.match[e])) return t(o.syntax) && n.unshift(o.syntax), !0
            } else if (o.node === e) return n = t(o.syntax) ? [o.syntax] : [], !0;
            return !1
        }(this.matched), n
    }

    function $c(e, t, n) {
        const r = Uc.call(e, t);
        return null !== r && r.some(n)
    }
    var Gc = Object.freeze({
        __proto__: null,
        getTrace: Uc,
        isKeyword: function(e) {
            return $c(this, e, e => "Keyword" === e.type)
        },
        isProperty: function(e, t) {
            return $c(this, e, e => "Property" === e.type && e.name === t)
        },
        isType: function(e, t) {
            return $c(this, e, e => "Type" === e.type && e.name === t)
        }
    });

    function Vc(e) {
        return "node" in e ? e.node : Vc(e.match[0])
    }

    function Hc(e) {
        return "node" in e ? e.node : Hc(e.match[e.match.length - 1])
    }

    function Kc(e, t, n, r, o) {
        const i = [];
        return null !== n.matched && function n(a) {
            if (null !== a.syntax && a.syntax.type === r && a.syntax.name === o) {
                const n = Vc(a),
                    r = Hc(a);
                e.syntax.walk(t, function(e, t, o) {
                    if (e === n) {
                        const e = new js;
                        do {
                            if (e.appendData(t.data), t.data === r) break;
                            t = t.next
                        } while (null !== t);
                        i.push({
                            parent: o,
                            nodes: e
                        })
                    }
                })
            }
            Array.isArray(a.match) && a.match.forEach(n)
        }(n.matched), i
    }
    const {
        hasOwnProperty: Qc
    } = Object.prototype;

    function Yc(e) {
        return "number" == typeof e && isFinite(e) && Math.floor(e) === e && e >= 0
    }

    function Xc(e) {
        return Boolean(e) && Yc(e.offset) && Yc(e.line) && Yc(e.column)
    }

    function Zc(e, t) {
        return function(n, r) {
            if (!n || n.constructor !== Object) return r(n, "Type of node should be an Object");
            for (let o in n) {
                let i = !0;
                if (!1 !== Qc.call(n, o)) {
                    if ("type" === o) n.type !== e && r(n, "Wrong node type `" + n.type + "`, expected `" + e + "`");
                    else if ("loc" === o) {
                        if (null === n.loc) continue;
                        if (n.loc && n.loc.constructor === Object)
                            if ("string" != typeof n.loc.source) o += ".source";
                            else if (Xc(n.loc.start)) {
                            if (Xc(n.loc.end)) continue;
                            o += ".end"
                        } else o += ".start";
                        i = !1
                    } else if (t.hasOwnProperty(o)) {
                        i = !1;
                        for (let e = 0; !i && e < t[o].length; e++) {
                            const r = t[o][e];
                            switch (r) {
                                case String:
                                    i = "string" == typeof n[o];
                                    break;
                                case Boolean:
                                    i = "boolean" == typeof n[o];
                                    break;
                                case null:
                                    i = null === n[o];
                                    break;
                                default:
                                    "string" == typeof r ? i = n[o] && n[o].type === r : Array.isArray(r) && (i = n[o] instanceof js)
                            }
                        }
                    } else r(n, "Unknown field `" + o + "` for " + e + " node type");
                    i || r(n, "Bad value for `" + e + "." + o + "`")
                }
            }
            for (const o in t) Qc.call(t, o) && !1 === Qc.call(n, o) && r(n, "Field `" + e + "." + o + "` is missed")
        }
    }

    function Jc(e, t) {
        const n = [];
        for (let r = 0; r < e.length; r++) {
            const o = e[r];
            if (o === String || o === Boolean) n.push(o.name.toLowerCase());
            else if (null === o) n.push("null");
            else if ("string" == typeof o) n.push(o);
            else {
                if (!Array.isArray(o)) throw new Error("Wrong value `" + o + "` in `" + t + "` structure definition");
                n.push("List<" + (Jc(o, t) || "any") + ">")
            }
        }
        return n.join(" | ")
    }

    function eu(e, t) {
        const n = t.structure,
            r = {
                type: String,
                loc: !0
            },
            o = {
                type: '"' + e + '"'
            };
        for (const t in n) {
            if (!1 === Qc.call(n, t)) continue;
            const i = r[t] = Array.isArray(n[t]) ? n[t].slice() : [n[t]];
            o[t] = Jc(i, e + "." + t)
        }
        return {
            docs: o,
            check: Zc(e, r)
        }
    }

    function tu(e, t, n) {
        const r = {};
        for (const o in e) e[o].syntax && (r[o] = n ? e[o].syntax : zl(e[o].syntax, {
            compact: t
        }));
        return r
    }

    function nu(e, t, n) {
        const r = {};
        for (const [o, i] of Object.entries(e)) r[o] = {
            prelude: i.prelude && (n ? i.prelude.syntax : zl(i.prelude.syntax, {
                compact: t
            })),
            descriptors: i.descriptors && tu(i.descriptors, t, n)
        };
        return r
    }

    function ru(e, t, n) {
        return {
            matched: e,
            iterations: n,
            error: t,
            ...Gc
        }
    }

    function ou(e, t, n, r) {
        const o = zc(n, e.syntax);
        let i;
        return function(e) {
            for (let t = 0; t < e.length; t++)
                if ("var(" === e[t].value.toLowerCase()) return !0;
            return !1
        }(o) ? ru(null, new Error("Matching for a tree with var() is not supported")) : (r && (i = Wc(o, e.cssWideKeywordsSyntax, e)), r && i.match || (i = Wc(o, t.match, e), i.match) ? ru(i.match, null, i.iterations) : ru(null, new Ll(i.reason, t.syntax, n, i), i.iterations))
    }
    class iu {
        constructor(e, t, n) {
            if (this.cssWideKeywords = Nl, this.syntax = t, this.generic = !1, this.units = { ...lc
                }, this.atrules = Object.create(null), this.properties = Object.create(null), this.types = Object.create(null), this.structure = n || function(e) {
                    const t = {};
                    if (e.node)
                        for (const n in e.node)
                            if (Qc.call(e.node, n)) {
                                const r = e.node[n];
                                if (!r.structure) throw new Error("Missed `structure` field in `" + n + "` node type definition");
                                t[n] = eu(n, r)
                            }
                    return t
                }(e), e) {
                if (e.cssWideKeywords && (this.cssWideKeywords = e.cssWideKeywords), e.units)
                    for (const t of Object.keys(lc)) Array.isArray(e.units[t]) && (this.units[t] = e.units[t]);
                if (e.types)
                    for (const [t, n] of Object.entries(e.types)) this.addType_(t, n);
                if (e.generic) {
                    this.generic = !0;
                    for (const [e, t] of Object.entries(function(e) {
                            return { ...ic,
                                ...ac,
                                ...sc(e)
                            }
                        }(this.units))) this.addType_(e, t)
                }
                if (e.atrules)
                    for (const [t, n] of Object.entries(e.atrules)) this.addAtrule_(t, n);
                if (e.properties)
                    for (const [t, n] of Object.entries(e.properties)) this.addProperty_(t, n)
            }
            this.cssWideKeywordsSyntax = Dc(this.cssWideKeywords.join(" |  "))
        }
        checkStructure(e) {
            function t(e, t) {
                r.push({
                    node: e,
                    message: t
                })
            }
            const n = this.structure,
                r = [];
            return this.syntax.walk(e, function(e) {
                n.hasOwnProperty(e.type) ? n[e.type].check(e, t) : t(e, "Unknown node type `" + e.type + "`")
            }), !!r.length && r
        }
        createDescriptor(e, t, n, r = null) {
            const o = {
                    type: t,
                    name: n
                },
                i = {
                    type: t,
                    name: n,
                    parent: r,
                    serializable: "string" == typeof e || e && "string" == typeof e.type,
                    syntax: null,
                    match: null,
                    matchRef: null
                };
            return "function" == typeof e ? i.match = Dc(e, o) : ("string" == typeof e ? Object.defineProperty(i, "syntax", {
                get: () => (Object.defineProperty(i, "syntax", {
                    value: xc(e)
                }), i.syntax)
            }) : i.syntax = e, Object.defineProperty(i, "match", {
                get: () => (Object.defineProperty(i, "match", {
                    value: Dc(i.syntax, o)
                }), i.match)
            }), "Property" === t && Object.defineProperty(i, "matchRef", {
                get() {
                    const e = i.syntax,
                        t = function(e) {
                            const t = e.terms[0];
                            return !1 === e.explicit && 1 === e.terms.length && "Multiplier" === t.type && !0 === t.comma
                        }(e) ? Dc({ ...e,
                            terms: [e.terms[0].term]
                        }, o) : null;
                    return Object.defineProperty(i, "matchRef", {
                        value: t
                    }), t
                }
            })), i
        }
        addAtrule_(e, t) {
            t && (this.atrules[e] = {
                type: "Atrule",
                name: e,
                prelude: t.prelude ? this.createDescriptor(t.prelude, "AtrulePrelude", e) : null,
                descriptors: t.descriptors ? Object.keys(t.descriptors).reduce((n, r) => (n[r] = this.createDescriptor(t.descriptors[r], "AtruleDescriptor", r, e), n), Object.create(null)) : null
            })
        }
        addProperty_(e, t) {
            t && (this.properties[e] = this.createDescriptor(t, "Property", e))
        }
        addType_(e, t) {
            t && (this.types[e] = this.createDescriptor(t, "Type", e))
        }
        checkAtruleName(e) {
            if (!this.getAtrule(e)) return new Tl("Unknown at-rule", "@" + e)
        }
        checkAtrulePrelude(e, t) {
            const n = this.checkAtruleName(e);
            if (n) return n;
            const r = this.getAtrule(e);
            return !r.prelude && t ? new SyntaxError("At-rule `@" + e + "` should not contain a prelude") : !r.prelude || t || ou(this, r.prelude, "", !1).matched ? void 0 : new SyntaxError("At-rule `@" + e + "` should contain a prelude")
        }
        checkAtruleDescriptorName(e, t) {
            const n = this.checkAtruleName(e);
            if (n) return n;
            const r = this.getAtrule(e),
                o = Il(t);
            return r.descriptors ? r.descriptors[o.name] || r.descriptors[o.basename] ? void 0 : new Tl("Unknown at-rule descriptor", t) : new SyntaxError("At-rule `@" + e + "` has no known descriptors")
        }
        checkPropertyName(e) {
            if (!this.getProperty(e)) return new Tl("Unknown property", e)
        }
        matchAtrulePrelude(e, t) {
            const n = this.checkAtrulePrelude(e, t);
            if (n) return ru(null, n);
            const r = this.getAtrule(e);
            return r.prelude ? ou(this, r.prelude, t || "", !1) : ru(null, null)
        }
        matchAtruleDescriptor(e, t, n) {
            const r = this.checkAtruleDescriptorName(e, t);
            if (r) return ru(null, r);
            const o = this.getAtrule(e),
                i = Il(t);
            return ou(this, o.descriptors[i.name] || o.descriptors[i.basename], n, !1)
        }
        matchDeclaration(e) {
            return "Declaration" !== e.type ? ru(null, new Error("Not a Declaration node")) : this.matchProperty(e.property, e.value)
        }
        matchProperty(e, t) {
            if (Rl(e).custom) return ru(null, new Error("Lexer matching doesn't applicable for custom properties"));
            const n = this.checkPropertyName(e);
            return n ? ru(null, n) : ou(this, this.getProperty(e), t, !0)
        }
        matchType(e, t) {
            const n = this.getType(e);
            return n ? ou(this, n, t, !1) : ru(null, new Tl("Unknown type", e))
        }
        match(e, t) {
            return "string" == typeof e || e && e.type ? ("string" != typeof e && e.match || (e = this.createDescriptor(e, "Type", "anonymous")), ou(this, e, t, !1)) : ru(null, new Tl("Bad syntax"))
        }
        findValueFragments(e, t, n, r) {
            return Kc(this, t, this.matchProperty(e, t), n, r)
        }
        findDeclarationValueFragments(e, t, n) {
            return Kc(this, e.value, this.matchDeclaration(e), t, n)
        }
        findAllFragments(e, t, n) {
            const r = [];
            return this.syntax.walk(e, {
                visit: "Declaration",
                enter: e => {
                    r.push.apply(r, this.findDeclarationValueFragments(e, t, n))
                }
            }), r
        }
        getAtrule(e, t = !0) {
            const n = Il(e);
            return (n.vendor && t ? this.atrules[n.name] || this.atrules[n.basename] : this.atrules[n.name]) || null
        }
        getAtrulePrelude(e, t = !0) {
            const n = this.getAtrule(e, t);
            return n && n.prelude || null
        }
        getAtruleDescriptor(e, t) {
            return this.atrules.hasOwnProperty(e) && this.atrules.declarators && this.atrules[e].declarators[t] || null
        }
        getProperty(e, t = !0) {
            const n = Rl(e);
            return (n.vendor && t ? this.properties[n.name] || this.properties[n.basename] : this.properties[n.name]) || null
        }
        getType(e) {
            return hasOwnProperty.call(this.types, e) ? this.types[e] : null
        }
        validate() {
            function e(e, t) {
                return t ? `<${e}>` : `<'${e}'>`
            }

            function t(i, a, s, l) {
                if (s.has(a)) return s.get(a);
                s.set(a, !1), null !== l.syntax && function(e, t, n) {
                    let r = wc,
                        o = wc;
                    if ("function" == typeof t ? r = t : t && (r = Sc(t.enter), o = Sc(t.leave)), r === wc && o === wc) throw new Error("Neither `enter` nor `leave` walker handler is set or both aren't a function");
                    ! function e(t) {
                        switch (r.call(n, t), t.type) {
                            case "Group":
                                t.terms.forEach(e);
                                break;
                            case "Multiplier":
                            case "Boolean":
                                e(t.term);
                                break;
                            case "Type":
                            case "Property":
                            case "Keyword":
                            case "AtKeyword":
                            case "Function":
                            case "String":
                            case "Token":
                            case "Comma":
                                break;
                            default:
                                throw new Error("Unknown type: " + t.type)
                        }
                        o.call(n, t)
                    }(e)
                }(l.syntax, function(l) {
                    if ("Type" !== l.type && "Property" !== l.type) return;
                    const c = "Type" === l.type ? i.types : i.properties,
                        u = "Type" === l.type ? r : o;
                    hasOwnProperty.call(c, l.name) ? t(i, l.name, u, c[l.name]) && (n.push(`${e(a,s===r)} used broken syntax definition ${e(l.name,"Type"===l.type)}`), s.set(a, !0)) : (n.push(`${e(a,s===r)} used missed syntax definition ${e(l.name,"Type"===l.type)}`), s.set(a, !0))
                }, this)
            }
            const n = [];
            let r = new Map,
                o = new Map;
            for (const e in this.types) t(this, e, r, this.types[e]);
            for (const e in this.properties) t(this, e, o, this.properties[e]);
            const i = [...r.keys()].filter(e => r.get(e)),
                a = [...o.keys()].filter(e => o.get(e));
            return i.length || a.length ? {
                errors: n,
                types: i,
                properties: a
            } : null
        }
        dump(e, t) {
            return {
                generic: this.generic,
                cssWideKeywords: this.cssWideKeywords,
                units: this.units,
                types: tu(this.types, !t, e),
                properties: tu(this.properties, !t, e),
                atrules: nu(this.atrules, !t, e)
            }
        }
        toString() {
            return JSON.stringify(this.dump())
        }
    }

    function au(e, t) {
        return "string" == typeof t && /^\s*\|/.test(t) ? "string" == typeof e ? e + t : t.replace(/^\s*\|\s*/, "") : t || null
    }

    function su(e, t) {
        const n = Object.create(null);
        for (const [r, o] of Object.entries(e))
            if (o) {
                n[r] = {};
                for (const e of Object.keys(o)) t.includes(e) && (n[r][e] = o[e])
            }
        return n
    }

    function lu(e, t) {
        const n = { ...e
        };
        for (const [r, o] of Object.entries(t)) switch (r) {
            case "generic":
                n[r] = Boolean(o);
                break;
            case "cssWideKeywords":
                n[r] = e[r] ? [...e[r], ...o] : o || [];
                break;
            case "units":
                n[r] = { ...e[r]
                };
                for (const [e, t] of Object.entries(o)) n[r][e] = Array.isArray(t) ? t : [];
                break;
            case "atrules":
                n[r] = { ...e[r]
                };
                for (const [e, t] of Object.entries(o)) {
                    const o = n[r][e] || {},
                        i = n[r][e] = {
                            prelude: o.prelude || null,
                            descriptors: { ...o.descriptors
                            }
                        };
                    if (t) {
                        i.prelude = t.prelude ? au(i.prelude, t.prelude) : i.prelude || null;
                        for (const [e, n] of Object.entries(t.descriptors || {})) i.descriptors[e] = n ? au(i.descriptors[e], n) : null;
                        Object.keys(i.descriptors).length || (i.descriptors = null)
                    }
                }
                break;
            case "types":
            case "properties":
                n[r] = { ...e[r]
                };
                for (const [e, t] of Object.entries(o)) n[r][e] = au(n[r][e], t);
                break;
            case "scope":
            case "features":
                n[r] = { ...e[r]
                };
                for (const [e, t] of Object.entries(o)) n[r][e] = { ...n[r][e],
                    ...t
                };
                break;
            case "parseContext":
                n[r] = { ...e[r],
                    ...o
                };
                break;
            case "atrule":
            case "pseudo":
                n[r] = { ...e[r],
                    ...su(o, ["parse"])
                };
                break;
            case "node":
                n[r] = { ...e[r],
                    ...su(o, ["name", "structure", "parse", "generate", "walkContext"])
                }
        }
        return n
    }

    function cu(e) {
        const t = qs(e),
            n = wl(e),
            r = fl(e),
            {
                fromPlainObject: o,
                toPlainObject: i
            } = function(e) {
                return {
                    fromPlainObject: t => (e(t, {
                        enter(e) {
                            e.children && e.children instanceof js == 0 && (e.children = (new js).fromArray(e.children))
                        }
                    }), t),
                    toPlainObject: t => (e(t, {
                        leave(e) {
                            e.children && e.children instanceof js && (e.children = e.children.toArray())
                        }
                    }), t)
                }
            }(n),
            a = {
                lexer: null,
                createLexer: e => new iu(e, a, a.lexer.structure),
                tokenize: Ls,
                parse: t,
                generate: r,
                walk: n,
                find: n.find,
                findLast: n.findLast,
                findAll: n.findAll,
                fromPlainObject: o,
                toPlainObject: i,
                fork(t) {
                    const n = lu({}, e);
                    return cu("function" == typeof t ? t(n) : lu(n, t))
                }
            };
        return a.lexer = new iu({
            generic: e.generic,
            cssWideKeywords: e.cssWideKeywords,
            units: e.units,
            types: e.types,
            atrules: e.atrules,
            properties: e.properties,
            node: e.node
        }, a), a
    }
    const uu = 43,
        hu = 45,
        pu = 110,
        du = !0;

    function fu(e, t) {
        let n = this.tokenStart + e;
        const r = this.charCodeAt(n);
        for (r !== uu && r !== hu || (t && this.error("Number sign is not allowed"), n++); n < this.tokenEnd; n++) Qa(this.charCodeAt(n)) || this.error("Integer is expected", n)
    }

    function mu(e) {
        return fu.call(this, 0, e)
    }

    function gu(e, t) {
        if (!this.cmpChar(this.tokenStart + e, t)) {
            let n = "";
            switch (t) {
                case pu:
                    n = "N is expected";
                    break;
                case hu:
                    n = "HyphenMinus is expected"
            }
            this.error(n, this.tokenStart + e)
        }
    }

    function bu() {
        let e = 0,
            t = 0,
            n = this.tokenType;
        for (; n === Na || n === Ka;) n = this.lookupType(++e);
        if (n !== Ra) {
            if (!this.isDelim(uu, e) && !this.isDelim(hu, e)) return null;
            t = this.isDelim(uu, e) ? uu : hu;
            do {
                n = this.lookupType(++e)
            } while (n === Na || n === Ka);
            n !== Ra && (this.skip(e), mu.call(this, du))
        }
        return e > 0 && this.skip(e), 0 === t && (n = this.charCodeAt(this.tokenStart), n !== uu && n !== hu && this.error("Number sign is expected")), mu.call(this, 0 !== t), t === hu ? "-" + this.consume(Ra) : this.consume(Ra)
    }
    const yu = {
        a: [String, null],
        b: [String, null]
    };

    function ku() {
        const e = this.tokenStart;
        let t = null,
            n = null;
        if (this.tokenType === Ra) mu.call(this, false), n = this.consume(Ra);
        else if (1 === this.tokenType && this.cmpChar(this.tokenStart, hu)) switch (t = "-1", gu.call(this, 1, pu), this.tokenEnd - this.tokenStart) {
            case 2:
                this.next(), n = bu.call(this);
                break;
            case 3:
                gu.call(this, 2, hu), this.next(), this.skipSC(), mu.call(this, du), n = "-" + this.consume(Ra);
                break;
            default:
                gu.call(this, 2, hu), fu.call(this, 3, du), this.next(), n = this.substrToCursor(e + 2)
        } else if (1 === this.tokenType || this.isDelim(uu) && 1 === this.lookupType(1)) {
            let r = 0;
            switch (t = "1", this.isDelim(uu) && (r = 1, this.next()), gu.call(this, 0, pu), this.tokenEnd - this.tokenStart) {
                case 1:
                    this.next(), n = bu.call(this);
                    break;
                case 2:
                    gu.call(this, 1, hu), this.next(), this.skipSC(), mu.call(this, du), n = "-" + this.consume(Ra);
                    break;
                default:
                    gu.call(this, 1, hu), fu.call(this, 2, du), this.next(), n = this.substrToCursor(e + r + 1)
            }
        } else if (this.tokenType === Da) {
            const r = this.charCodeAt(this.tokenStart),
                o = r === uu || r === hu;
            let i = this.tokenStart + o;
            for (; i < this.tokenEnd && Qa(this.charCodeAt(i)); i++);
            i === this.tokenStart + o && this.error("Integer is expected", this.tokenStart + o), gu.call(this, i - this.tokenStart, pu), t = this.substring(e, i), i + 1 === this.tokenEnd ? (this.next(), n = bu.call(this)) : (gu.call(this, i - this.tokenStart + 1, hu), i + 2 === this.tokenEnd ? (this.next(), this.skipSC(), mu.call(this, du), n = "-" + this.consume(Ra)) : (fu.call(this, i - this.tokenStart + 2, du), this.next(), n = this.substrToCursor(i + 1)))
        } else this.error();
        return null !== t && t.charCodeAt(0) === uu && (t = t.substr(1)), null !== n && n.charCodeAt(0) === uu && (n = n.substr(1)), {
            type: "AnPlusB",
            loc: this.getLocation(e, this.tokenStart),
            a: t,
            b: n
        }
    }
    var vu = Object.freeze({
        __proto__: null,
        generate: function(e) {
            if (e.a) {
                const t = ("+1" === e.a || "1" === e.a ? "n" : "-1" === e.a && "-n") || e.a + "n";
                if (e.b) {
                    const n = "-" === e.b[0] || "+" === e.b[0] ? e.b : "+" + e.b;
                    this.tokenize(t + n)
                } else this.tokenize(t)
            } else this.tokenize(e.b)
        },
        name: "AnPlusB",
        parse: ku,
        structure: yu
    });

    function xu() {
        return this.Raw(this.consumeUntilLeftCurlyBracketOrSemicolon, !0)
    }

    function wu() {
        for (let e, t = 1; e = this.lookupType(t); t++) {
            if (e === Ha) return !0;
            if (e === Va || 3 === e) return !1
        }
        return !1
    }
    const Su = {
        name: String,
        prelude: ["AtrulePrelude", "Raw", null],
        block: ["Block", null]
    };

    function Cu(e = !1) {
        const t = this.tokenStart;
        let n, r, o = null,
            i = null;
        switch (this.eat(3), n = this.substrToCursor(t + 1), r = n.toLowerCase(), this.skipSC(), !1 === this.eof && this.tokenType !== Va && this.tokenType !== Ba && (o = this.parseAtrulePrelude ? this.parseWithFallback(this.AtrulePrelude.bind(this, n, e), xu) : xu.call(this, this.tokenIndex), this.skipSC()), this.tokenType) {
            case Ba:
                this.next();
                break;
            case Va:
                i = hasOwnProperty.call(this.atrule, r) && "function" == typeof this.atrule[r].block ? this.atrule[r].block.call(this, e) : this.Block(wu.call(this))
        }
        return {
            type: "Atrule",
            loc: this.getLocation(t, this.tokenStart),
            name: n,
            prelude: o,
            block: i
        }
    }
    var zu = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(3, "@" + e.name), null !== e.prelude && this.node(e.prelude), e.block ? this.node(e.block) : this.token(Ba, ";")
        },
        name: "Atrule",
        parse: Cu,
        structure: Su,
        walkContext: "atrule"
    });

    function Au(e) {
        let t = null;
        return null !== e && (e = e.toLowerCase()), this.skipSC(), t = hasOwnProperty.call(this.atrule, e) && "function" == typeof this.atrule[e].prelude ? this.atrule[e].prelude.call(this) : this.readSequence(this.scope.AtrulePrelude), this.skipSC(), !0 !== this.eof && this.tokenType !== Va && this.tokenType !== Ba && this.error("Semicolon or block is expected"), {
            type: "AtrulePrelude",
            loc: this.getLocationFromList(t),
            children: t
        }
    }
    var _u = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e)
        },
        name: "AtrulePrelude",
        parse: Au,
        structure: {
            children: [
                []
            ]
        },
        walkContext: "atrulePrelude"
    });

    function Ou() {
        this.eof && this.error("Unexpected end of input");
        const e = this.tokenStart;
        let t = !1;
        return this.isDelim(42) ? (t = !0, this.next()) : this.isDelim(124) || this.eat(1), this.isDelim(124) ? 61 !== this.charCodeAt(this.tokenStart + 1) ? (this.next(), this.eat(1)) : t && this.error("Identifier is expected", this.tokenEnd) : t && this.error("Vertical line is expected"), {
            type: "Identifier",
            loc: this.getLocation(e, this.tokenStart),
            name: this.substrToCursor(e)
        }
    }

    function Tu() {
        const e = this.tokenStart,
            t = this.charCodeAt(e);
        return 61 !== t && 126 !== t && 94 !== t && 36 !== t && 42 !== t && 124 !== t && this.error("Attribute selector (=, ~=, ^=, $=, *=, |=) is expected"), this.next(), 61 !== t && (this.isDelim(61) || this.error("Equal sign is expected"), this.next()), this.substrToCursor(e)
    }
    const Lu = {
        name: "Identifier",
        matcher: [String, null],
        value: ["String", "Identifier", null],
        flags: [String, null]
    };

    function Eu() {
        const e = this.tokenStart;
        let t, n = null,
            r = null,
            o = null;
        return this.eat(Wa), this.skipSC(), t = Ou.call(this), this.skipSC(), this.tokenType !== Ua && (1 !== this.tokenType && (n = Tu.call(this), this.skipSC(), r = 5 === this.tokenType ? this.String() : this.Identifier(), this.skipSC()), 1 === this.tokenType && (o = this.consume(1), this.skipSC())), this.eat(Ua), {
            type: "AttributeSelector",
            loc: this.getLocation(e, this.tokenStart),
            name: t,
            matcher: n,
            value: r,
            flags: o
        }
    }
    var ju = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(9, "["), this.node(e.name), null !== e.matcher && (this.tokenize(e.matcher), this.node(e.value)), null !== e.flags && this.token(1, e.flags), this.token(9, "]")
        },
        name: "AttributeSelector",
        parse: Eu,
        structure: Lu
    });

    function Iu() {
        return this.Raw(null, !0)
    }

    function Ru() {
        return this.parseWithFallback(this.Rule, Iu)
    }

    function Pu() {
        return this.Raw(this.consumeUntilSemicolonIncluded, !0)
    }

    function Du() {
        if (this.tokenType === Ba) return Pu.call(this, this.tokenIndex);
        const e = this.parseWithFallback(this.Declaration, Pu);
        return this.tokenType === Ba && this.next(), e
    }

    function Nu(e) {
        const t = e ? Du : Ru,
            n = this.tokenStart;
        let r = this.createList();
        this.eat(Va);
        e: for (; !this.eof;) switch (this.tokenType) {
            case Ha:
                break e;
            case Na:
            case Ka:
                this.next();
                break;
            case 3:
                r.push(this.parseWithFallback(this.Atrule.bind(this, e), Iu));
                break;
            default:
                e && this.isDelim(38) ? r.push(Ru.call(this)) : r.push(t.call(this))
        }
        return this.eof || this.eat(Ha), {
            type: "Block",
            loc: this.getLocation(n, this.tokenStart),
            children: r
        }
    }
    var Mu = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(Va, "{"), this.children(e, e => {
                "Declaration" === e.type && this.token(Ba, ";")
            }), this.token(Ha, "}")
        },
        name: "Block",
        parse: Nu,
        structure: {
            children: [
                ["Atrule", "Rule", "Declaration"]
            ]
        },
        walkContext: "block"
    });

    function Fu(e, t) {
        const n = this.tokenStart;
        let r = null;
        return this.eat(Wa), r = e.call(this, t), this.eof || this.eat(Ua), {
            type: "Brackets",
            loc: this.getLocation(n, this.tokenStart),
            children: r
        }
    }
    var Bu = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(9, "["), this.children(e), this.token(9, "]")
        },
        name: "Brackets",
        parse: Fu,
        structure: {
            children: [
                []
            ]
        }
    });

    function qu() {
        const e = this.tokenStart;
        return this.eat(Ma), {
            type: "CDC",
            loc: this.getLocation(e, this.tokenStart)
        }
    }
    var Wu = Object.freeze({
        __proto__: null,
        generate: function() {
            this.token(Ma, "--\x3e")
        },
        name: "CDC",
        parse: qu,
        structure: []
    });

    function Uu() {
        const e = this.tokenStart;
        return this.eat(14), {
            type: "CDO",
            loc: this.getLocation(e, this.tokenStart)
        }
    }
    var $u = Object.freeze({
        __proto__: null,
        generate: function() {
            this.token(14, "\x3c!--")
        },
        name: "CDO",
        parse: Uu,
        structure: []
    });
    const Gu = {
        name: String
    };

    function Vu() {
        return this.eatDelim(46), {
            type: "ClassSelector",
            loc: this.getLocation(this.tokenStart - 1, this.tokenEnd),
            name: this.consume(1)
        }
    }
    var Hu = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(9, "."), this.token(1, e.name)
        },
        name: "ClassSelector",
        parse: Vu,
        structure: Gu
    });
    const Ku = {
        name: String
    };

    function Qu() {
        const e = this.tokenStart;
        let t;
        switch (this.tokenType) {
            case Na:
                t = " ";
                break;
            case 9:
                switch (this.charCodeAt(this.tokenStart)) {
                    case 62:
                    case 43:
                    case 126:
                        this.next();
                        break;
                    case 47:
                        this.next(), this.eatIdent("deep"), this.eatDelim(47);
                        break;
                    default:
                        this.error("Combinator is expected")
                }
                t = this.substrToCursor(e)
        }
        return {
            type: "Combinator",
            loc: this.getLocation(e, this.tokenStart),
            name: t
        }
    }
    var Yu = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.tokenize(e.name)
        },
        name: "Combinator",
        parse: Qu,
        structure: Ku
    });
    const Xu = {
        value: String
    };

    function Zu() {
        const e = this.tokenStart;
        let t = this.tokenEnd;
        return this.eat(Ka), t - e + 2 >= 2 && 42 === this.charCodeAt(t - 2) && 47 === this.charCodeAt(t - 1) && (t -= 2), {
            type: "Comment",
            loc: this.getLocation(e, this.tokenStart),
            value: this.substring(e + 2, t)
        }
    }
    var Ju = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(Ka, "/*" + e.value + "*/")
        },
        name: "Comment",
        parse: Zu,
        structure: Xu
    });
    const eh = new Set([Fa, Ga, 0]),
        th = {
            kind: String,
            children: [
                ["Identifier", "Feature", "FeatureFunction", "FeatureRange", "SupportsDeclaration"]
            ]
        };

    function nh(e) {
        return 1 === this.lookupTypeNonSC(1) && eh.has(this.lookupTypeNonSC(2)) ? this.Feature(e) : this.FeatureRange(e)
    }
    const rh = {
        media: nh,
        container: nh,
        supports() {
            return this.SupportsDeclaration()
        }
    };

    function oh(e = "media") {
        const t = this.createList();
        e: for (; !this.eof;) switch (this.tokenType) {
            case Ka:
            case Na:
                this.next();
                continue;
            case 1:
                t.push(this.Identifier());
                break;
            case $a:
                {
                    let n = this.parseWithFallback(() => rh[e].call(this, e), () => null);n || (n = this.parseWithFallback(() => {
                        this.eat($a);
                        const t = this.Condition(e);
                        return this.eat(Ga), t
                    }, () => this.GeneralEnclosed(e))),
                    t.push(n);
                    break
                }
            case 2:
                {
                    let n = this.parseWithFallback(() => this.FeatureFunction(e), () => null);n || (n = this.GeneralEnclosed(e)),
                    t.push(n);
                    break
                }
            default:
                break e
        }
        return t.isEmpty && this.error("Condition is expected"), {
            type: "Condition",
            loc: this.getLocationFromList(t),
            kind: e,
            children: t
        }
    }
    var ih = Object.freeze({
        __proto__: null,
        generate: function(e) {
            e.children.forEach(e => {
                "Condition" === e.type ? (this.token($a, "("), this.node(e), this.token(Ga, ")")) : this.node(e)
            })
        },
        name: "Condition",
        parse: oh,
        structure: th
    });

    function ah() {
        return this.Raw(this.consumeUntilExclamationMarkOrSemicolon, !0)
    }

    function sh() {
        return this.Raw(this.consumeUntilExclamationMarkOrSemicolon, !1)
    }

    function lh() {
        const e = this.tokenIndex,
            t = this.Value();
        return "Raw" !== t.type && !1 === this.eof && this.tokenType !== Ba && !1 === this.isDelim(33) && !1 === this.isBalanceEdge(e) && this.error(), t
    }
    const ch = {
        important: [Boolean, String],
        property: String,
        value: ["Value", "Raw"]
    };

    function uh() {
        const e = this.tokenStart,
            t = this.tokenIndex,
            n = hh.call(this),
            r = Pl(n),
            o = r ? this.parseCustomProperty : this.parseValue,
            i = r ? sh : ah;
        let a, s = !1;
        this.skipSC(), this.eat(Fa);
        const l = this.tokenIndex;
        if (r || this.skipSC(), a = o ? this.parseWithFallback(lh, i) : i.call(this, this.tokenIndex), r && "Value" === a.type && a.children.isEmpty)
            for (let e = l - this.tokenIndex; e <= 0; e++)
                if (this.lookupType(e) === Na) {
                    a.children.appendData({
                        type: "WhiteSpace",
                        loc: null,
                        value: " "
                    });
                    break
                }
        return this.isDelim(33) && (s = ph.call(this), this.skipSC()), !1 === this.eof && this.tokenType !== Ba && !1 === this.isBalanceEdge(t) && this.error(), {
            type: "Declaration",
            loc: this.getLocation(e, this.tokenStart),
            important: s,
            property: n,
            value: a
        }
    }

    function hh() {
        const e = this.tokenStart;
        if (9 === this.tokenType) switch (this.charCodeAt(this.tokenStart)) {
            case 42:
            case 36:
            case 43:
            case 35:
            case 38:
                this.next();
                break;
            case 47:
                this.next(), this.isDelim(47) && this.next()
        }
        return 4 === this.tokenType ? this.eat(4) : this.eat(1), this.substrToCursor(e)
    }

    function ph() {
        this.eat(9), this.skipSC();
        const e = this.consume(1);
        return "important" === e || e
    }
    var dh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(1, e.property), this.token(Fa, ":"), this.node(e.value), e.important && (this.token(9, "!"), this.token(1, !0 === e.important ? "important" : e.important))
        },
        name: "Declaration",
        parse: uh,
        structure: ch,
        walkContext: "declaration"
    });

    function fh() {
        return this.Raw(this.consumeUntilSemicolonIncluded, !0)
    }

    function mh() {
        const e = this.createList();
        for (; !this.eof;) switch (this.tokenType) {
            case Na:
            case Ka:
            case Ba:
                this.next();
                break;
            case 3:
                e.push(this.parseWithFallback(this.Atrule.bind(this, !0), fh));
                break;
            default:
                this.isDelim(38) ? e.push(this.parseWithFallback(this.Rule, fh)) : e.push(this.parseWithFallback(this.Declaration, fh))
        }
        return {
            type: "DeclarationList",
            loc: this.getLocationFromList(e),
            children: e
        }
    }
    var gh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e, e => {
                "Declaration" === e.type && this.token(Ba, ";")
            })
        },
        name: "DeclarationList",
        parse: mh,
        structure: {
            children: [
                ["Declaration", "Atrule", "Rule"]
            ]
        }
    });
    const bh = {
        value: String,
        unit: String
    };

    function yh() {
        const e = this.tokenStart,
            t = this.consumeNumber(Da);
        return {
            type: "Dimension",
            loc: this.getLocation(e, this.tokenStart),
            value: t,
            unit: this.substring(e + t.length, this.tokenStart)
        }
    }
    var kh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(Da, e.value + e.unit)
        },
        name: "Dimension",
        parse: yh,
        structure: bh
    });
    const vh = {
        kind: String,
        name: String,
        value: ["Identifier", "Number", "Dimension", "Ratio", "Function", null]
    };

    function xh(e) {
        const t = this.tokenStart;
        let n, r = null;
        if (this.eat($a), this.skipSC(), n = this.consume(1), this.skipSC(), this.tokenType !== Ga) {
            switch (this.eat(Fa), this.skipSC(), this.tokenType) {
                case Ra:
                    r = 9 === this.lookupNonWSType(1) ? this.Ratio() : this.Number();
                    break;
                case Da:
                    r = this.Dimension();
                    break;
                case 1:
                    r = this.Identifier();
                    break;
                case 2:
                    r = this.parseWithFallback(() => {
                        const e = this.Function(this.readSequence, this.scope.Value);
                        return this.skipSC(), this.isDelim(47) && this.error(), e
                    }, () => this.Ratio());
                    break;
                default:
                    this.error("Number, dimension, ratio or identifier is expected")
            }
            this.skipSC()
        }
        return this.eof || this.eat(Ga), {
            type: "Feature",
            loc: this.getLocation(t, this.tokenStart),
            kind: e,
            name: n,
            value: r
        }
    }
    var wh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token($a, "("), this.token(1, e.name), null !== e.value && (this.token(Fa, ":"), this.node(e.value)), this.token(Ga, ")")
        },
        name: "Feature",
        parse: xh,
        structure: vh
    });
    const Sh = {
        kind: String,
        feature: String,
        value: ["Declaration", "Selector"]
    };

    function Ch(e, t) {
        const n = (this.features[e] || {})[t];
        return "function" != typeof n && this.error(`Unknown feature ${t}()`), n
    }

    function zh(e = "unknown") {
        const t = this.tokenStart,
            n = this.consumeFunctionName(),
            r = Ch.call(this, e, n.toLowerCase());
        this.skipSC();
        const o = this.parseWithFallback(() => {
            const e = this.tokenIndex,
                t = r.call(this);
            return !1 === this.eof && !1 === this.isBalanceEdge(e) && this.error(), t
        }, () => this.Raw(null, !1));
        return this.eof || this.eat(Ga), {
            type: "FeatureFunction",
            loc: this.getLocation(t, this.tokenStart),
            kind: e,
            feature: n,
            value: o
        }
    }
    var Ah = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(2, e.feature + "("), this.node(e.value), this.token(Ga, ")")
        },
        name: "FeatureFunction",
        parse: zh,
        structure: Sh
    });
    const _h = {
        kind: String,
        left: ["Identifier", "Number", "Dimension", "Ratio", "Function"],
        leftComparison: String,
        middle: ["Identifier", "Number", "Dimension", "Ratio", "Function"],
        rightComparison: [String, null],
        right: ["Identifier", "Number", "Dimension", "Ratio", "Function", null]
    };

    function Oh() {
        switch (this.skipSC(), this.tokenType) {
            case Ra:
                return this.isDelim(47, this.lookupOffsetNonSC(1)) ? this.Ratio() : this.Number();
            case Da:
                return this.Dimension();
            case 1:
                return this.Identifier();
            case 2:
                return this.parseWithFallback(() => {
                    const e = this.Function(this.readSequence, this.scope.Value);
                    return this.skipSC(), this.isDelim(47) && this.error(), e
                }, () => this.Ratio());
            default:
                this.error("Number, dimension, ratio or identifier is expected")
        }
    }

    function Th(e) {
        if (this.skipSC(), this.isDelim(60) || this.isDelim(62)) {
            const e = this.source[this.tokenStart];
            return this.next(), this.isDelim(61) ? (this.next(), e + "=") : e
        }
        if (this.isDelim(61)) return "=";
        this.error(`Expected ${e?'":", ':""}"<", ">", "=" or ")"`)
    }

    function Lh(e = "unknown") {
        const t = this.tokenStart;
        this.skipSC(), this.eat($a);
        const n = Oh.call(this),
            r = Th.call(this, "Identifier" === n.type),
            o = Oh.call(this);
        let i = null,
            a = null;
        return this.lookupNonWSType(0) !== Ga && (i = Th.call(this), a = Oh.call(this)), this.skipSC(), this.eat(Ga), {
            type: "FeatureRange",
            loc: this.getLocation(t, this.tokenStart),
            kind: e,
            left: n,
            leftComparison: r,
            middle: o,
            rightComparison: i,
            right: a
        }
    }
    var Eh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token($a, "("), this.node(e.left), this.tokenize(e.leftComparison), this.node(e.middle), e.right && (this.tokenize(e.rightComparison), this.node(e.right)), this.token(Ga, ")")
        },
        name: "FeatureRange",
        parse: Lh,
        structure: _h
    });
    const jh = {
        name: String,
        children: [
            []
        ]
    };

    function Ih(e, t) {
        const n = this.tokenStart,
            r = this.consumeFunctionName(),
            o = r.toLowerCase();
        let i;
        return i = t.hasOwnProperty(o) ? t[o].call(this, t) : e.call(this, t), this.eof || this.eat(Ga), {
            type: "Function",
            loc: this.getLocation(n, this.tokenStart),
            name: r,
            children: i
        }
    }
    var Rh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(2, e.name + "("), this.children(e), this.token(Ga, ")")
        },
        name: "Function",
        parse: Ih,
        structure: jh,
        walkContext: "function"
    });
    const Ph = {
        kind: String,
        function: [String, null],
        children: [
            []
        ]
    };

    function Dh(e) {
        const t = this.tokenStart;
        let n = null;
        2 === this.tokenType ? n = this.consumeFunctionName() : this.eat($a);
        const r = this.parseWithFallback(() => {
            const e = this.tokenIndex,
                t = this.readSequence(this.scope.Value);
            return !1 === this.eof && !1 === this.isBalanceEdge(e) && this.error(), t
        }, () => this.createSingleNodeList(this.Raw(null, !1)));
        return this.eof || this.eat(Ga), {
            type: "GeneralEnclosed",
            loc: this.getLocation(t, this.tokenStart),
            kind: e,
            function: n,
            children: r
        }
    }
    var Nh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            e.function ? this.token(2, e.function+"(") : this.token($a, "("), this.children(e), this.token(Ga, ")")
        },
        name: "GeneralEnclosed",
        parse: Dh,
        structure: Ph
    });
    const Mh = {
        value: String
    };

    function Fh() {
        const e = this.tokenStart;
        return this.eat(4), {
            type: "Hash",
            loc: this.getLocation(e, this.tokenStart),
            value: this.substrToCursor(e + 1)
        }
    }
    var Bh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(4, "#" + e.value)
        },
        name: "Hash",
        parse: Fh,
        structure: Mh,
        xxx: "XXX"
    });
    const qh = {
        name: String
    };

    function Wh() {
        return {
            type: "Identifier",
            loc: this.getLocation(this.tokenStart, this.tokenEnd),
            name: this.consume(1)
        }
    }
    var Uh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(1, e.name)
        },
        name: "Identifier",
        parse: Wh,
        structure: qh
    });
    const $h = {
        name: String
    };

    function Gh() {
        const e = this.tokenStart;
        return this.eat(4), {
            type: "IdSelector",
            loc: this.getLocation(e, this.tokenStart),
            name: this.substrToCursor(e + 1)
        }
    }
    var Vh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(9, "#" + e.name)
        },
        name: "IdSelector",
        parse: Gh,
        structure: $h
    });
    const Hh = {
        name: String
    };

    function Kh() {
        let e = this.tokenStart,
            t = this.consume(1);
        for (; this.isDelim(46);) this.eat(9), t += "." + this.consume(1);
        return {
            type: "Layer",
            loc: this.getLocation(e, this.tokenStart),
            name: t
        }
    }
    var Qh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.tokenize(e.name)
        },
        name: "Layer",
        parse: Kh,
        structure: Hh
    });

    function Yh() {
        const e = this.createList();
        for (this.skipSC(); !this.eof && (e.push(this.Layer()), this.lookupTypeNonSC(0) === qa);) this.skipSC(), this.next(), this.skipSC();
        return {
            type: "LayerList",
            loc: this.getLocationFromList(e),
            children: e
        }
    }
    var Xh = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e, () => this.token(qa, ","))
        },
        name: "LayerList",
        parse: Yh,
        structure: {
            children: [
                ["Layer"]
            ]
        }
    });
    const Zh = {
        modifier: [String, null],
        mediaType: [String, null],
        condition: ["Condition", null]
    };

    function Jh() {
        const e = this.tokenStart;
        let t = null,
            n = null,
            r = null;
        if (this.skipSC(), 1 === this.tokenType && this.lookupTypeNonSC(1) !== $a) {
            const e = this.consume(1),
                o = e.toLowerCase();
            switch ("not" === o || "only" === o ? (this.skipSC(), t = o, n = this.consume(1)) : n = e, this.lookupTypeNonSC(0)) {
                case 1:
                    this.skipSC(), this.eatIdent("and"), r = this.Condition("media");
                    break;
                case Va:
                case Ba:
                case qa:
                case 0:
                    break;
                default:
                    this.error("Identifier or parenthesis is expected")
            }
        } else switch (this.tokenType) {
            case 1:
            case $a:
            case 2:
                r = this.Condition("media");
                break;
            case Va:
            case Ba:
            case 0:
                break;
            default:
                this.error("Identifier or parenthesis is expected")
        }
        return {
            type: "MediaQuery",
            loc: this.getLocation(e, this.tokenStart),
            modifier: t,
            mediaType: n,
            condition: r
        }
    }
    var ep = Object.freeze({
        __proto__: null,
        generate: function(e) {
            e.mediaType ? (e.modifier && this.token(1, e.modifier), this.token(1, e.mediaType), e.condition && (this.token(1, "and"), this.node(e.condition))) : e.condition && this.node(e.condition)
        },
        name: "MediaQuery",
        parse: Jh,
        structure: Zh
    });

    function tp() {
        const e = this.createList();
        for (this.skipSC(); !this.eof && (e.push(this.MediaQuery()), this.tokenType === qa);) this.next();
        return {
            type: "MediaQueryList",
            loc: this.getLocationFromList(e),
            children: e
        }
    }
    var np = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e, () => this.token(qa, ","))
        },
        name: "MediaQueryList",
        parse: tp,
        structure: {
            children: [
                ["MediaQuery"]
            ]
        }
    });

    function rp() {
        const e = this.tokenStart;
        return this.eatDelim(38), {
            type: "NestingSelector",
            loc: this.getLocation(e, this.tokenStart)
        }
    }
    var op = Object.freeze({
        __proto__: null,
        generate: function() {
            this.token(9, "&")
        },
        name: "NestingSelector",
        parse: rp,
        structure: {}
    });

    function ip() {
        this.skipSC();
        const e = this.tokenStart;
        let t, n = e,
            r = null;
        return t = this.lookupValue(0, "odd") || this.lookupValue(0, "even") ? this.Identifier() : this.AnPlusB(), n = this.tokenStart, this.skipSC(), this.lookupValue(0, "of") && (this.next(), r = this.SelectorList(), n = this.tokenStart), {
            type: "Nth",
            loc: this.getLocation(e, n),
            nth: t,
            selector: r
        }
    }
    var ap = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.node(e.nth), null !== e.selector && (this.token(1, "of"), this.node(e.selector))
        },
        name: "Nth",
        parse: ip,
        structure: {
            nth: ["AnPlusB", "Identifier"],
            selector: ["SelectorList", null]
        }
    });
    const sp = {
        value: String
    };

    function lp() {
        return {
            type: "Number",
            loc: this.getLocation(this.tokenStart, this.tokenEnd),
            value: this.consume(Ra)
        }
    }
    var cp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(Ra, e.value)
        },
        name: "Number",
        parse: lp,
        structure: sp
    });
    const up = {
        value: String
    };

    function hp() {
        const e = this.tokenStart;
        return this.next(), {
            type: "Operator",
            loc: this.getLocation(e, this.tokenStart),
            value: this.substrToCursor(e)
        }
    }
    var pp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.tokenize(e.value)
        },
        name: "Operator",
        parse: hp,
        structure: up
    });

    function dp(e, t) {
        const n = this.tokenStart;
        let r = null;
        return this.eat($a), r = e.call(this, t), this.eof || this.eat(Ga), {
            type: "Parentheses",
            loc: this.getLocation(n, this.tokenStart),
            children: r
        }
    }
    var fp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token($a, "("), this.children(e), this.token(Ga, ")")
        },
        name: "Parentheses",
        parse: dp,
        structure: {
            children: [
                []
            ]
        }
    });
    const mp = {
        value: String
    };

    function gp() {
        return {
            type: "Percentage",
            loc: this.getLocation(this.tokenStart, this.tokenEnd),
            value: this.consumeNumber(Pa)
        }
    }
    var bp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(Pa, e.value + "%")
        },
        name: "Percentage",
        parse: gp,
        structure: mp
    });
    const yp = {
        name: String,
        children: [
            ["Raw"], null
        ]
    };

    function kp() {
        const e = this.tokenStart;
        let t, n, r = null;
        return this.eat(Fa), 2 === this.tokenType ? (t = this.consumeFunctionName(), n = t.toLowerCase(), this.lookupNonWSType(0) == Ga ? r = this.createList() : hasOwnProperty.call(this.pseudo, n) ? (this.skipSC(), r = this.pseudo[n].call(this), this.skipSC()) : (r = this.createList(), r.push(this.Raw(null, !1))), this.eat(Ga)) : t = this.consume(1), {
            type: "PseudoClassSelector",
            loc: this.getLocation(e, this.tokenStart),
            name: t,
            children: r
        }
    }
    var vp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(Fa, ":"), null === e.children ? this.token(1, e.name) : (this.token(2, e.name + "("), this.children(e), this.token(Ga, ")"))
        },
        name: "PseudoClassSelector",
        parse: kp,
        structure: yp,
        walkContext: "function"
    });
    const xp = {
        name: String,
        children: [
            ["Raw"], null
        ]
    };

    function wp() {
        const e = this.tokenStart;
        let t, n, r = null;
        return this.eat(Fa), this.eat(Fa), 2 === this.tokenType ? (t = this.consumeFunctionName(), n = t.toLowerCase(), this.lookupNonWSType(0) == Ga ? r = this.createList() : hasOwnProperty.call(this.pseudo, n) ? (this.skipSC(), r = this.pseudo[n].call(this), this.skipSC()) : (r = this.createList(), r.push(this.Raw(null, !1))), this.eat(Ga)) : t = this.consume(1), {
            type: "PseudoElementSelector",
            loc: this.getLocation(e, this.tokenStart),
            name: t,
            children: r
        }
    }
    var Sp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(Fa, ":"), this.token(Fa, ":"), null === e.children ? this.token(1, e.name) : (this.token(2, e.name + "("), this.children(e), this.token(Ga, ")"))
        },
        name: "PseudoElementSelector",
        parse: wp,
        structure: xp,
        walkContext: "function"
    });

    function Cp() {
        switch (this.skipSC(), this.tokenType) {
            case Ra:
                return this.Number();
            case 2:
                return this.Function(this.readSequence, this.scope.Value);
            default:
                this.error("Number of function is expected")
        }
    }

    function zp() {
        const e = this.tokenStart,
            t = Cp.call(this);
        let n = null;
        return this.skipSC(), this.isDelim(47) && (this.eatDelim(47), n = Cp.call(this)), {
            type: "Ratio",
            loc: this.getLocation(e, this.tokenStart),
            left: t,
            right: n
        }
    }
    var Ap = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.node(e.left), this.token(9, "/"), e.right ? this.node(e.right) : this.node(Ra, 1)
        },
        name: "Ratio",
        parse: zp,
        structure: {
            left: ["Number", "Function"],
            right: ["Number", "Function", null]
        }
    });

    function _p() {
        return this.tokenIndex > 0 && this.lookupType(-1) === Na ? this.tokenIndex > 1 ? this.getTokenStart(this.tokenIndex - 1) : this.firstCharOffset : this.tokenStart
    }
    const Op = {
        value: String
    };

    function Tp(e, t) {
        const n = this.getTokenStart(this.tokenIndex);
        let r;
        return this.skipUntilBalanced(this.tokenIndex, e || this.consumeUntilBalanceEnd), r = t && this.tokenStart > n ? _p.call(this) : this.tokenStart, {
            type: "Raw",
            loc: this.getLocation(n, r),
            value: this.substring(n, r)
        }
    }
    var Lp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.tokenize(e.value)
        },
        name: "Raw",
        parse: Tp,
        structure: Op
    });

    function Ep() {
        return this.Raw(this.consumeUntilLeftCurlyBracket, !0)
    }

    function jp() {
        const e = this.SelectorList();
        return "Raw" !== e.type && !1 === this.eof && this.tokenType !== Va && this.error(), e
    }

    function Ip() {
        const e = this.tokenIndex,
            t = this.tokenStart;
        let n, r;
        return n = this.parseRulePrelude ? this.parseWithFallback(jp, Ep) : Ep.call(this, e), r = this.Block(!0), {
            type: "Rule",
            loc: this.getLocation(t, this.tokenStart),
            prelude: n,
            block: r
        }
    }
    var Rp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.node(e.prelude), this.node(e.block)
        },
        name: "Rule",
        parse: Ip,
        structure: {
            prelude: ["SelectorList", "Raw"],
            block: ["Block"]
        },
        walkContext: "rule"
    });

    function Pp() {
        let e = null,
            t = null;
        this.skipSC();
        const n = this.tokenStart;
        return this.tokenType === $a && (this.next(), this.skipSC(), e = this.parseWithFallback(this.SelectorList, () => this.Raw(!1, !0)), this.skipSC(), this.eat(Ga)), 1 === this.lookupNonWSType(0) && (this.skipSC(), this.eatIdent("to"), this.skipSC(), this.eat($a), this.skipSC(), t = this.parseWithFallback(this.SelectorList, () => this.Raw(!1, !0)), this.skipSC(), this.eat(Ga)), {
            type: "Scope",
            loc: this.getLocation(n, this.tokenStart),
            root: e,
            limit: t
        }
    }
    var Dp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            e.root && (this.token($a, "("), this.node(e.root), this.token(Ga, ")")), e.limit && (this.token(1, "to"), this.token($a, "("), this.node(e.limit), this.token(Ga, ")"))
        },
        name: "Scope",
        parse: Pp,
        structure: {
            root: ["SelectorList", "Raw", null],
            limit: ["SelectorList", "Raw", null]
        }
    });

    function Np() {
        const e = this.readSequence(this.scope.Selector);
        return null === this.getFirstListNode(e) && this.error("Selector is expected"), {
            type: "Selector",
            loc: this.getLocationFromList(e),
            children: e
        }
    }
    var Mp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e)
        },
        name: "Selector",
        parse: Np,
        structure: {
            children: [
                ["TypeSelector", "IdSelector", "ClassSelector", "AttributeSelector", "PseudoClassSelector", "PseudoElementSelector", "Combinator"]
            ]
        }
    });

    function Fp() {
        const e = this.createList();
        for (; !this.eof && (e.push(this.Selector()), this.tokenType === qa);) this.next();
        return {
            type: "SelectorList",
            loc: this.getLocationFromList(e),
            children: e
        }
    }
    var Bp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e, () => this.token(qa, ","))
        },
        name: "SelectorList",
        parse: Fp,
        structure: {
            children: [
                ["Selector", "Raw"]
            ]
        },
        walkContext: "selector"
    });

    function qp(e) {
        const t = e.length,
            n = e.charCodeAt(0),
            r = 34 === n || 39 === n ? 1 : 0,
            o = 1 === r && t > 1 && e.charCodeAt(t - 1) === n ? t - 2 : t - 1;
        let i = "";
        for (let n = r; n <= o; n++) {
            let r = e.charCodeAt(n);
            if (92 === r) {
                if (n === o) {
                    n !== t - 1 && (i = e.substr(n + 1));
                    break
                }
                if (r = e.charCodeAt(++n), rs(92, r)) {
                    const t = n - 1,
                        r = gs(e, t);
                    n = r - 1, i += vs(e.substring(t + 1, r))
                } else 13 === r && 10 === e.charCodeAt(n + 1) && n++
            } else i += e[n]
        }
        return i
    }
    const Wp = {
        value: String
    };

    function Up() {
        return {
            type: "String",
            loc: this.getLocation(this.tokenStart, this.tokenEnd),
            value: qp(this.consume(5))
        }
    }
    var $p = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(5, function(e) {
                let t = "",
                    n = !1;
                for (let r = 0; r < e.length; r++) {
                    const o = e.charCodeAt(r);
                    0 !== o ? o <= 31 || 127 === o ? (t += "\\" + o.toString(16), n = !0) : 34 === o || 92 === o ? (t += "\\" + e.charAt(r), n = !1) : (n && (Ya(o) || ns(o)) && (t += " "), t += e.charAt(r), n = !1) : t += "�"
                }
                return '"' + t + '"'
            }(e.value))
        },
        name: "String",
        parse: Up,
        structure: Wp
    });

    function Gp() {
        return this.Raw(null, !1)
    }

    function Vp() {
        const e = this.tokenStart,
            t = this.createList();
        let n;
        for (; !this.eof;) {
            switch (this.tokenType) {
                case Na:
                    this.next();
                    continue;
                case Ka:
                    if (33 !== this.charCodeAt(this.tokenStart + 2)) {
                        this.next();
                        continue
                    }
                    n = this.Comment();
                    break;
                case 14:
                    n = this.CDO();
                    break;
                case Ma:
                    n = this.CDC();
                    break;
                case 3:
                    n = this.parseWithFallback(this.Atrule, Gp);
                    break;
                default:
                    n = this.parseWithFallback(this.Rule, Gp)
            }
            t.push(n)
        }
        return {
            type: "StyleSheet",
            loc: this.getLocation(e, this.tokenStart),
            children: t
        }
    }
    var Hp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e)
        },
        name: "StyleSheet",
        parse: Vp,
        structure: {
            children: [
                ["Comment", "CDO", "CDC", "Atrule", "Rule", "Raw"]
            ]
        },
        walkContext: "stylesheet"
    });

    function Kp() {
        const e = this.tokenStart;
        this.eat($a), this.skipSC();
        const t = this.Declaration();
        return this.eof || this.eat(Ga), {
            type: "SupportsDeclaration",
            loc: this.getLocation(e, this.tokenStart),
            declaration: t
        }
    }
    var Qp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token($a, "("), this.node(e.declaration), this.token(Ga, ")")
        },
        name: "SupportsDeclaration",
        parse: Kp,
        structure: {
            declaration: "Declaration"
        }
    });

    function Yp() {
        1 !== this.tokenType && !1 === this.isDelim(42) && this.error("Identifier or asterisk is expected"), this.next()
    }
    const Xp = {
        name: String
    };

    function Zp() {
        const e = this.tokenStart;
        return this.isDelim(124) ? (this.next(), Yp.call(this)) : (Yp.call(this), this.isDelim(124) && (this.next(), Yp.call(this))), {
            type: "TypeSelector",
            loc: this.getLocation(e, this.tokenStart),
            name: this.substrToCursor(e)
        }
    }
    var Jp = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.tokenize(e.name)
        },
        name: "TypeSelector",
        parse: Zp,
        structure: Xp
    });

    function ed(e, t) {
        let n = 0;
        for (let r = this.tokenStart + e; r < this.tokenEnd; r++) {
            const o = this.charCodeAt(r);
            if (45 === o && t && 0 !== n) return ed.call(this, e + n + 1, !1), -1;
            Ya(o) || this.error(t && 0 !== n ? "Hyphen minus" + (n < 6 ? " or hex digit" : "") + " is expected" : n < 6 ? "Hex digit is expected" : "Unexpected input", r), ++n > 6 && this.error("Too many hex digits", r)
        }
        return this.next(), n
    }

    function td(e) {
        let t = 0;
        for (; this.isDelim(63);) ++t > e && this.error("Too many question marks"), this.next()
    }

    function nd(e) {
        this.charCodeAt(this.tokenStart) !== e && this.error((43 === e ? "Plus sign" : "Hyphen minus") + " is expected")
    }

    function rd() {
        let e = 0;
        switch (this.tokenType) {
            case Ra:
                if (e = ed.call(this, 1, !0), this.isDelim(63)) {
                    td.call(this, 6 - e);
                    break
                }
                if (this.tokenType === Da || this.tokenType === Ra) {
                    nd.call(this, 45), ed.call(this, 1, !1);
                    break
                }
                break;
            case Da:
                e = ed.call(this, 1, !0), e > 0 && td.call(this, 6 - e);
                break;
            default:
                if (this.eatDelim(43), 1 === this.tokenType) {
                    e = ed.call(this, 0, !0), e > 0 && td.call(this, 6 - e);
                    break
                }
                if (this.isDelim(63)) {
                    this.next(), td.call(this, 5);
                    break
                }
                this.error("Hex digit or question mark is expected")
        }
    }
    const od = {
        value: String
    };

    function id() {
        const e = this.tokenStart;
        return this.eatIdent("u"), rd.call(this), {
            type: "UnicodeRange",
            loc: this.getLocation(e, this.tokenStart),
            value: this.substrToCursor(e)
        }
    }
    var ad = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.tokenize(e.value)
        },
        name: "UnicodeRange",
        parse: id,
        structure: od
    });
    const sd = {
        value: String
    };

    function ld() {
        const e = this.tokenStart;
        let t;
        switch (this.tokenType) {
            case 7:
                t = function(e) {
                    const t = e.length;
                    let n = 4,
                        r = 41 === e.charCodeAt(t - 1) ? t - 2 : t - 1,
                        o = "";
                    for (; n < r && ns(e.charCodeAt(n));) n++;
                    for (; n < r && ns(e.charCodeAt(r));) r--;
                    for (let i = n; i <= r; i++) {
                        let n = e.charCodeAt(i);
                        if (92 === n) {
                            if (i === r) {
                                i !== t - 1 && (o = e.substr(i + 1));
                                break
                            }
                            if (n = e.charCodeAt(++i), rs(92, n)) {
                                const t = i - 1,
                                    n = gs(e, t);
                                i = n - 1, o += vs(e.substring(t + 1, n))
                            } else 13 === n && 10 === e.charCodeAt(i + 1) && i++
                        } else o += e[i]
                    }
                    return o
                }(this.consume(7));
                break;
            case 2:
                this.cmpStr(this.tokenStart, this.tokenEnd, "url(") || this.error("Function name must be `url`"), this.eat(2), this.skipSC(), t = qp(this.consume(5)), this.skipSC(), this.eof || this.eat(Ga);
                break;
            default:
                this.error("Url or Function is expected")
        }
        return {
            type: "Url",
            loc: this.getLocation(e, this.tokenStart),
            value: t
        }
    }
    var cd = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.token(7, function(e) {
                let t = "",
                    n = !1;
                for (let r = 0; r < e.length; r++) {
                    const o = e.charCodeAt(r);
                    0 !== o ? o <= 31 || 127 === o ? (t += "\\" + o.toString(16), n = !0) : 32 === o || 92 === o || 34 === o || 39 === o || 40 === o || 41 === o ? (t += "\\" + e.charAt(r), n = !1) : (n && Ya(o) && (t += " "), t += e.charAt(r), n = !1) : t += "�"
                }
                return "url(" + t + ")"
            }(e.value))
        },
        name: "Url",
        parse: ld,
        structure: sd
    });

    function ud() {
        const e = this.tokenStart,
            t = this.readSequence(this.scope.Value);
        return {
            type: "Value",
            loc: this.getLocation(e, this.tokenStart),
            children: t
        }
    }
    var hd = Object.freeze({
        __proto__: null,
        generate: function(e) {
            this.children(e)
        },
        name: "Value",
        parse: ud,
        structure: {
            children: [
                []
            ]
        }
    });
    const pd = Object.freeze({
            type: "WhiteSpace",
            loc: null,
            value: " "
        }),
        dd = {
            value: String
        };

    function fd() {
        return this.eat(Na), pd
    }
    var md = Object.freeze({
            __proto__: null,
            generate: function(e) {
                this.token(Na, e.value)
            },
            name: "WhiteSpace",
            parse: fd,
            structure: dd
        }),
        gd = Object.freeze({
            __proto__: null,
            AnPlusB: vu,
            Atrule: zu,
            AtrulePrelude: _u,
            AttributeSelector: ju,
            Block: Mu,
            Brackets: Bu,
            CDC: Wu,
            CDO: $u,
            ClassSelector: Hu,
            Combinator: Yu,
            Comment: Ju,
            Condition: ih,
            Declaration: dh,
            DeclarationList: gh,
            Dimension: kh,
            Feature: wh,
            FeatureFunction: Ah,
            FeatureRange: Eh,
            Function: Rh,
            GeneralEnclosed: Nh,
            Hash: Bh,
            IdSelector: Vh,
            Identifier: Uh,
            Layer: Qh,
            LayerList: Xh,
            MediaQuery: ep,
            MediaQueryList: np,
            NestingSelector: op,
            Nth: ap,
            Number: cp,
            Operator: pp,
            Parentheses: fp,
            Percentage: bp,
            PseudoClassSelector: vp,
            PseudoElementSelector: Sp,
            Ratio: Ap,
            Raw: Lp,
            Rule: Rp,
            Scope: Dp,
            Selector: Mp,
            SelectorList: Bp,
            String: $p,
            StyleSheet: Hp,
            SupportsDeclaration: Qp,
            TypeSelector: Jp,
            UnicodeRange: ad,
            Url: cd,
            Value: hd,
            WhiteSpace: md
        }),
        bd = {
            generic: !0,
            cssWideKeywords: Nl,
            generic: !0,
            cssWideKeywords: ["initial", "inherit", "unset", "revert", "revert-layer"],
            units: {
                angle: ["deg", "grad", "rad", "turn"],
                decibel: ["db"],
                flex: ["fr"],
                frequency: ["hz", "khz"],
                length: ["cm", "mm", "q", "in", "pt", "pc", "px", "em", "rem", "ex", "rex", "cap", "rcap", "ch", "rch", "ic", "ric", "lh", "rlh", "vw", "svw", "lvw", "dvw", "vh", "svh", "lvh", "dvh", "vi", "svi", "lvi", "dvi", "vb", "svb", "lvb", "dvb", "vmin", "svmin", "lvmin", "dvmin", "vmax", "svmax", "lvmax", "dvmax", "cqw", "cqh", "cqi", "cqb", "cqmin", "cqmax"],
                resolution: ["dpi", "dpcm", "dppx", "x"],
                semitones: ["st"],
                time: ["s", "ms"]
            },
            types: {
                "abs()": "abs( <calc-sum> )",
                "absolute-size": "xx-small|x-small|small|medium|large|x-large|xx-large|xxx-large",
                "acos()": "acos( <calc-sum> )",
                "alpha-value": "<number>|<percentage>",
                "angle-percentage": "<angle>|<percentage>",
                "angular-color-hint": "<angle-percentage>",
                "angular-color-stop": "<color>&&<color-stop-angle>?",
                "angular-color-stop-list": "[<angular-color-stop> [, <angular-color-hint>]?]# , <angular-color-stop>",
                "animateable-feature": "scroll-position|contents|<custom-ident>",
                "asin()": "asin( <calc-sum> )",
                "atan()": "atan( <calc-sum> )",
                "atan2()": "atan2( <calc-sum> , <calc-sum> )",
                attachment: "scroll|fixed|local",
                "attr()": "attr( <attr-name> <type-or-unit>? [, <attr-fallback>]? )",
                "attr-matcher": "['~'|'|'|'^'|'$'|'*']? '='",
                "attr-modifier": "i|s",
                "attribute-selector": "'[' <wq-name> ']'|'[' <wq-name> <attr-matcher> [<string-token>|<ident-token>] <attr-modifier>? ']'",
                "auto-repeat": "repeat( [auto-fill|auto-fit] , [<line-names>? <fixed-size>]+ <line-names>? )",
                "auto-track-list": "[<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>? <auto-repeat> [<line-names>? [<fixed-size>|<fixed-repeat>]]* <line-names>?",
                axis: "block|inline|x|y",
                "baseline-position": "[first|last]? baseline",
                "basic-shape": "<inset()>|<xywh()>|<rect()>|<circle()>|<ellipse()>|<polygon()>|<path()>",
                "bg-image": "none|<image>",
                "bg-layer": "<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>",
                "bg-position": "[[left|center|right|top|bottom|<length-percentage>]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]|[center|[left|right] <length-percentage>?]&&[center|[top|bottom] <length-percentage>?]]",
                "bg-size": "[<length-percentage>|auto]{1,2}|cover|contain",
                "blur()": "blur( <length> )",
                "blend-mode": "normal|multiply|screen|overlay|darken|lighten|color-dodge|color-burn|hard-light|soft-light|difference|exclusion|hue|saturation|color|luminosity",
                box: "border-box|padding-box|content-box",
                "brightness()": "brightness( <number-percentage> )",
                "calc()": "calc( <calc-sum> )",
                "calc-sum": "<calc-product> [['+'|'-'] <calc-product>]*",
                "calc-product": "<calc-value> ['*' <calc-value>|'/' <number>]*",
                "calc-value": "<number>|<dimension>|<percentage>|<calc-constant>|( <calc-sum> )",
                "calc-constant": "e|pi|infinity|-infinity|NaN",
                "cf-final-image": "<image>|<color>",
                "cf-mixing-image": "<percentage>?&&<image>",
                "circle()": "circle( [<shape-radius>]? [at <position>]? )",
                "clamp()": "clamp( <calc-sum>#{3} )",
                "class-selector": "'.' <ident-token>",
                "clip-source": "<url>",
                color: "<color-base>|currentColor|<system-color>|<device-cmyk()>|<light-dark()>|<-non-standard-color>",
                "color-stop": "<color-stop-length>|<color-stop-angle>",
                "color-stop-angle": "<angle-percentage>{1,2}",
                "color-stop-length": "<length-percentage>{1,2}",
                "color-stop-list": "[<linear-color-stop> [, <linear-color-hint>]?]# , <linear-color-stop>",
                "color-interpolation-method": "in [<rectangular-color-space>|<polar-color-space> <hue-interpolation-method>?|<custom-color-space>]",
                combinator: "'>'|'+'|'~'|['|' '|']",
                "common-lig-values": "[common-ligatures|no-common-ligatures]",
                "compat-auto": "searchfield|textarea|push-button|slider-horizontal|checkbox|radio|square-button|menulist|listbox|meter|progress-bar|button",
                "composite-style": "clear|copy|source-over|source-in|source-out|source-atop|destination-over|destination-in|destination-out|destination-atop|xor",
                "compositing-operator": "add|subtract|intersect|exclude",
                "compound-selector": "[<type-selector>? <subclass-selector>*]!",
                "compound-selector-list": "<compound-selector>#",
                "complex-selector": "<complex-selector-unit> [<combinator>? <complex-selector-unit>]*",
                "complex-selector-list": "<complex-selector>#",
                "conic-gradient()": "conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )",
                "contextual-alt-values": "[contextual|no-contextual]",
                "content-distribution": "space-between|space-around|space-evenly|stretch",
                "content-list": "[<string>|contents|<image>|<counter>|<quote>|<target>|<leader()>|<attr()>]+",
                "content-position": "center|start|end|flex-start|flex-end",
                "content-replacement": "<image>",
                "contrast()": "contrast( [<number-percentage>] )",
                "cos()": "cos( <calc-sum> )",
                counter: "<counter()>|<counters()>",
                "counter()": "counter( <counter-name> , <counter-style>? )",
                "counter-name": "<custom-ident>",
                "counter-style": "<counter-style-name>|symbols( )",
                "counter-style-name": "<custom-ident>",
                "counters()": "counters( <counter-name> , <string> , <counter-style>? )",
                "cross-fade()": "cross-fade( <cf-mixing-image> , <cf-final-image>? )",
                "cubic-bezier-timing-function": "ease|ease-in|ease-out|ease-in-out|cubic-bezier( <number [0,1]> , <number> , <number [0,1]> , <number> )",
                "deprecated-system-color": "ActiveBorder|ActiveCaption|AppWorkspace|Background|ButtonFace|ButtonHighlight|ButtonShadow|ButtonText|CaptionText|GrayText|Highlight|HighlightText|InactiveBorder|InactiveCaption|InactiveCaptionText|InfoBackground|InfoText|Menu|MenuText|Scrollbar|ThreeDDarkShadow|ThreeDFace|ThreeDHighlight|ThreeDLightShadow|ThreeDShadow|Window|WindowFrame|WindowText",
                "discretionary-lig-values": "[discretionary-ligatures|no-discretionary-ligatures]",
                "display-box": "contents|none",
                "display-inside": "flow|flow-root|table|flex|grid|ruby",
                "display-internal": "table-row-group|table-header-group|table-footer-group|table-row|table-cell|table-column-group|table-column|table-caption|ruby-base|ruby-text|ruby-base-container|ruby-text-container",
                "display-legacy": "inline-block|inline-list-item|inline-table|inline-flex|inline-grid",
                "display-listitem": "<display-outside>?&&[flow|flow-root]?&&list-item",
                "display-outside": "block|inline|run-in",
                "drop-shadow()": "drop-shadow( <length>{2,3} <color>? )",
                "east-asian-variant-values": "[jis78|jis83|jis90|jis04|simplified|traditional]",
                "east-asian-width-values": "[full-width|proportional-width]",
                "element()": "element( <custom-ident> , [first|start|last|first-except]? )|element( <id-selector> )",
                "ellipse()": "ellipse( [<shape-radius>{2}]? [at <position>]? )",
                "ending-shape": "circle|ellipse",
                "env()": "env( <custom-ident> , <declaration-value>? )",
                "exp()": "exp( <calc-sum> )",
                "explicit-track-list": "[<line-names>? <track-size>]+ <line-names>?",
                "family-name": "<string>|<custom-ident>+",
                "feature-tag-value": "<string> [<integer>|on|off]?",
                "feature-type": "@stylistic|@historical-forms|@styleset|@character-variant|@swash|@ornaments|@annotation",
                "feature-value-block": "<feature-type> '{' <feature-value-declaration-list> '}'",
                "feature-value-block-list": "<feature-value-block>+",
                "feature-value-declaration": "<custom-ident> : <integer>+ ;",
                "feature-value-declaration-list": "<feature-value-declaration>",
                "feature-value-name": "<custom-ident>",
                "fill-rule": "nonzero|evenodd",
                "filter-function": "<blur()>|<brightness()>|<contrast()>|<drop-shadow()>|<grayscale()>|<hue-rotate()>|<invert()>|<opacity()>|<saturate()>|<sepia()>",
                "filter-function-list": "[<filter-function>|<url>]+",
                "final-bg-layer": "<'background-color'>||<bg-image>||<bg-position> [/ <bg-size>]?||<repeat-style>||<attachment>||<box>||<box>",
                "fixed-breadth": "<length-percentage>",
                "fixed-repeat": "repeat( [<integer [1,∞]>] , [<line-names>? <fixed-size>]+ <line-names>? )",
                "fixed-size": "<fixed-breadth>|minmax( <fixed-breadth> , <track-breadth> )|minmax( <inflexible-breadth> , <fixed-breadth> )",
                "font-stretch-absolute": "normal|ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded|<percentage>",
                "font-variant-css21": "[normal|small-caps]",
                "font-weight-absolute": "normal|bold|<number [1,1000]>",
                "frequency-percentage": "<frequency>|<percentage>",
                "general-enclosed": "[<function-token> <any-value>? )]|[( <any-value>? )]",
                "generic-family": "<generic-script-specific>|<generic-complete>|<generic-incomplete>|<-non-standard-generic-family>",
                "generic-name": "serif|sans-serif|cursive|fantasy|monospace",
                "geometry-box": "<shape-box>|fill-box|stroke-box|view-box",
                gradient: "<linear-gradient()>|<repeating-linear-gradient()>|<radial-gradient()>|<repeating-radial-gradient()>|<conic-gradient()>|<repeating-conic-gradient()>|<-legacy-gradient>",
                "grayscale()": "grayscale( <number-percentage> )",
                "grid-line": "auto|<custom-ident>|[<integer>&&<custom-ident>?]|[span&&[<integer>||<custom-ident>]]",
                "historical-lig-values": "[historical-ligatures|no-historical-ligatures]",
                "hsl()": "hsl( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsl( <hue> , <percentage> , <percentage> , <alpha-value>? )",
                "hsla()": "hsla( <hue> <percentage> <percentage> [/ <alpha-value>]? )|hsla( <hue> , <percentage> , <percentage> , <alpha-value>? )",
                hue: "<number>|<angle>",
                "hue-rotate()": "hue-rotate( <angle> )",
                "hue-interpolation-method": "[shorter|longer|increasing|decreasing] hue",
                "hwb()": "hwb( [<hue>|none] [<percentage>|none] [<percentage>|none] [/ [<alpha-value>|none]]? )",
                "hypot()": "hypot( <calc-sum># )",
                image: "<url>|<image()>|<image-set()>|<element()>|<paint()>|<cross-fade()>|<gradient>",
                "image()": "image( <image-tags>? [<image-src>? , <color>?]! )",
                "image-set()": "image-set( <image-set-option># )",
                "image-set-option": "[<image>|<string>] [<resolution>||type( <string> )]",
                "image-src": "<url>|<string>",
                "image-tags": "ltr|rtl",
                "inflexible-breadth": "<length-percentage>|min-content|max-content|auto",
                "inset()": "inset( <length-percentage>{1,4} [round <'border-radius'>]? )",
                "invert()": "invert( <number-percentage> )",
                "keyframes-name": "<custom-ident>|<string>",
                "keyframe-block": "<keyframe-selector># { <declaration-list> }",
                "keyframe-block-list": "<keyframe-block>+",
                "keyframe-selector": "from|to|<percentage>|<timeline-range-name> <percentage>",
                "lab()": "lab( [<percentage>|<number>|none] [<percentage>|<number>|none] [<percentage>|<number>|none] [/ [<alpha-value>|none]]? )",
                "layer()": "layer( <layer-name> )",
                "layer-name": "<ident> ['.' <ident>]*",
                "lch()": "lch( [<percentage>|<number>|none] [<percentage>|<number>|none] [<hue>|none] [/ [<alpha-value>|none]]? )",
                "leader()": "leader( <leader-type> )",
                "leader-type": "dotted|solid|space|<string>",
                "length-percentage": "<length>|<percentage>",
                "light-dark()": "light-dark( <color> , <color> )",
                "line-names": "'[' <custom-ident>* ']'",
                "line-name-list": "[<line-names>|<name-repeat>]+",
                "line-style": "none|hidden|dotted|dashed|solid|double|groove|ridge|inset|outset",
                "line-width": "<length>|thin|medium|thick",
                "linear-color-hint": "<length-percentage>",
                "linear-color-stop": "<color> <color-stop-length>?",
                "linear-gradient()": "linear-gradient( [[<angle>|to <side-or-corner>]||<color-interpolation-method>]? , <color-stop-list> )",
                "log()": "log( <calc-sum> , <calc-sum>? )",
                "mask-layer": "<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||<geometry-box>||[<geometry-box>|no-clip]||<compositing-operator>||<masking-mode>",
                "mask-position": "[<length-percentage>|left|center|right] [<length-percentage>|top|center|bottom]?",
                "mask-reference": "none|<image>|<mask-source>",
                "mask-source": "<url>",
                "masking-mode": "alpha|luminance|match-source",
                "matrix()": "matrix( <number>#{6} )",
                "matrix3d()": "matrix3d( <number>#{16} )",
                "max()": "max( <calc-sum># )",
                "media-and": "<media-in-parens> [and <media-in-parens>]+",
                "media-condition": "<media-not>|<media-and>|<media-or>|<media-in-parens>",
                "media-condition-without-or": "<media-not>|<media-and>|<media-in-parens>",
                "media-feature": "( [<mf-plain>|<mf-boolean>|<mf-range>] )",
                "media-in-parens": "( <media-condition> )|<media-feature>|<general-enclosed>",
                "media-not": "not <media-in-parens>",
                "media-or": "<media-in-parens> [or <media-in-parens>]+",
                "media-query": "<media-condition>|[not|only]? <media-type> [and <media-condition-without-or>]?",
                "media-query-list": "<media-query>#",
                "media-type": "<ident>",
                "mf-boolean": "<mf-name>",
                "mf-name": "<ident>",
                "mf-plain": "<mf-name> : <mf-value>",
                "mf-range": "<mf-name> ['<'|'>']? '='? <mf-value>|<mf-value> ['<'|'>']? '='? <mf-name>|<mf-value> '<' '='? <mf-name> '<' '='? <mf-value>|<mf-value> '>' '='? <mf-name> '>' '='? <mf-value>",
                "mf-value": "<number>|<dimension>|<ident>|<ratio>",
                "min()": "min( <calc-sum># )",
                "minmax()": "minmax( [<length-percentage>|min-content|max-content|auto] , [<length-percentage>|<flex>|min-content|max-content|auto] )",
                "mod()": "mod( <calc-sum> , <calc-sum> )",
                "name-repeat": "repeat( [<integer [1,∞]>|auto-fill] , <line-names>+ )",
                "named-color": "transparent|aliceblue|antiquewhite|aqua|aquamarine|azure|beige|bisque|black|blanchedalmond|blue|blueviolet|brown|burlywood|cadetblue|chartreuse|chocolate|coral|cornflowerblue|cornsilk|crimson|cyan|darkblue|darkcyan|darkgoldenrod|darkgray|darkgreen|darkgrey|darkkhaki|darkmagenta|darkolivegreen|darkorange|darkorchid|darkred|darksalmon|darkseagreen|darkslateblue|darkslategray|darkslategrey|darkturquoise|darkviolet|deeppink|deepskyblue|dimgray|dimgrey|dodgerblue|firebrick|floralwhite|forestgreen|fuchsia|gainsboro|ghostwhite|gold|goldenrod|gray|green|greenyellow|grey|honeydew|hotpink|indianred|indigo|ivory|khaki|lavender|lavenderblush|lawngreen|lemonchiffon|lightblue|lightcoral|lightcyan|lightgoldenrodyellow|lightgray|lightgreen|lightgrey|lightpink|lightsalmon|lightseagreen|lightskyblue|lightslategray|lightslategrey|lightsteelblue|lightyellow|lime|limegreen|linen|magenta|maroon|mediumaquamarine|mediumblue|mediumorchid|mediumpurple|mediumseagreen|mediumslateblue|mediumspringgreen|mediumturquoise|mediumvioletred|midnightblue|mintcream|mistyrose|moccasin|navajowhite|navy|oldlace|olive|olivedrab|orange|orangered|orchid|palegoldenrod|palegreen|paleturquoise|palevioletred|papayawhip|peachpuff|peru|pink|plum|powderblue|purple|rebeccapurple|red|rosybrown|royalblue|saddlebrown|salmon|sandybrown|seagreen|seashell|sienna|silver|skyblue|slateblue|slategray|slategrey|snow|springgreen|steelblue|tan|teal|thistle|tomato|turquoise|violet|wheat|white|whitesmoke|yellow|yellowgreen",
                "namespace-prefix": "<ident>",
                "ns-prefix": "[<ident-token>|'*']? '|'",
                "number-percentage": "<number>|<percentage>",
                "numeric-figure-values": "[lining-nums|oldstyle-nums]",
                "numeric-fraction-values": "[diagonal-fractions|stacked-fractions]",
                "numeric-spacing-values": "[proportional-nums|tabular-nums]",
                nth: "<an-plus-b>|even|odd",
                "opacity()": "opacity( [<number-percentage>] )",
                "overflow-position": "unsafe|safe",
                "outline-radius": "<length>|<percentage>",
                "page-body": "<declaration>? [; <page-body>]?|<page-margin-box> <page-body>",
                "page-margin-box": "<page-margin-box-type> '{' <declaration-list> '}'",
                "page-margin-box-type": "@top-left-corner|@top-left|@top-center|@top-right|@top-right-corner|@bottom-left-corner|@bottom-left|@bottom-center|@bottom-right|@bottom-right-corner|@left-top|@left-middle|@left-bottom|@right-top|@right-middle|@right-bottom",
                "page-selector-list": "[<page-selector>#]?",
                "page-selector": "<pseudo-page>+|<ident> <pseudo-page>*",
                "page-size": "A5|A4|A3|B5|B4|JIS-B5|JIS-B4|letter|legal|ledger",
                "path()": "path( [<fill-rule> ,]? <string> )",
                "paint()": "paint( <ident> , <declaration-value>? )",
                "perspective()": "perspective( [<length [0,∞]>|none] )",
                "polygon()": "polygon( <fill-rule>? , [<length-percentage> <length-percentage>]# )",
                "polar-color-space": "hsl|hwb|lch|oklch",
                position: "[[left|center|right]||[top|center|bottom]|[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]?|[[left|right] <length-percentage>]&&[[top|bottom] <length-percentage>]]",
                "pow()": "pow( <calc-sum> , <calc-sum> )",
                "pseudo-class-selector": "':' <ident-token>|':' <function-token> <any-value> ')'",
                "pseudo-element-selector": "':' <pseudo-class-selector>|<legacy-pseudo-element-selector>",
                "pseudo-page": ": [left|right|first|blank]",
                quote: "open-quote|close-quote|no-open-quote|no-close-quote",
                "radial-gradient()": "radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )",
                ratio: "<number [0,∞]> [/ <number [0,∞]>]?",
                "ray()": "ray( <angle>&&<ray-size>?&&contain?&&[at <position>]? )",
                "ray-size": "closest-side|closest-corner|farthest-side|farthest-corner|sides",
                "rectangular-color-space": "srgb|srgb-linear|display-p3|a98-rgb|prophoto-rgb|rec2020|lab|oklab|xyz|xyz-d50|xyz-d65",
                "relative-selector": "<combinator>? <complex-selector>",
                "relative-selector-list": "<relative-selector>#",
                "relative-size": "larger|smaller",
                "rem()": "rem( <calc-sum> , <calc-sum> )",
                "repeat-style": "repeat-x|repeat-y|[repeat|space|round|no-repeat]{1,2}",
                "repeating-conic-gradient()": "repeating-conic-gradient( [from <angle>]? [at <position>]? , <angular-color-stop-list> )",
                "repeating-linear-gradient()": "repeating-linear-gradient( [<angle>|to <side-or-corner>]? , <color-stop-list> )",
                "repeating-radial-gradient()": "repeating-radial-gradient( [<ending-shape>||<size>]? [at <position>]? , <color-stop-list> )",
                "reversed-counter-name": "reversed( <counter-name> )",
                "rgb()": "rgb( <percentage>{3} [/ <alpha-value>]? )|rgb( <number>{3} [/ <alpha-value>]? )|rgb( <percentage>#{3} , <alpha-value>? )|rgb( <number>#{3} , <alpha-value>? )",
                "rgba()": "rgba( <percentage>{3} [/ <alpha-value>]? )|rgba( <number>{3} [/ <alpha-value>]? )|rgba( <percentage>#{3} , <alpha-value>? )|rgba( <number>#{3} , <alpha-value>? )",
                "rotate()": "rotate( [<angle>|<zero>] )",
                "rotate3d()": "rotate3d( <number> , <number> , <number> , [<angle>|<zero>] )",
                "rotateX()": "rotateX( [<angle>|<zero>] )",
                "rotateY()": "rotateY( [<angle>|<zero>] )",
                "rotateZ()": "rotateZ( [<angle>|<zero>] )",
                "round()": "round( <rounding-strategy>? , <calc-sum> , <calc-sum> )",
                "rounding-strategy": "nearest|up|down|to-zero",
                "saturate()": "saturate( <number-percentage> )",
                "scale()": "scale( [<number>|<percentage>]#{1,2} )",
                "scale3d()": "scale3d( [<number>|<percentage>]#{3} )",
                "scaleX()": "scaleX( [<number>|<percentage>] )",
                "scaleY()": "scaleY( [<number>|<percentage>] )",
                "scaleZ()": "scaleZ( [<number>|<percentage>] )",
                "scroll()": "scroll( [<axis>||<scroller>]? )",
                scroller: "root|nearest|self",
                "self-position": "center|start|end|self-start|self-end|flex-start|flex-end",
                "shape-radius": "<length-percentage>|closest-side|farthest-side",
                "sign()": "sign( <calc-sum> )",
                "skew()": "skew( [<angle>|<zero>] , [<angle>|<zero>]? )",
                "skewX()": "skewX( [<angle>|<zero>] )",
                "skewY()": "skewY( [<angle>|<zero>] )",
                "sepia()": "sepia( <number-percentage> )",
                shadow: "inset?&&<length>{2,4}&&<color>?",
                "shadow-t": "[<length>{2,3}&&<color>?]",
                shape: "rect( <top> , <right> , <bottom> , <left> )|rect( <top> <right> <bottom> <left> )",
                "shape-box": "<box>|margin-box",
                "side-or-corner": "[left|right]||[top|bottom]",
                "sin()": "sin( <calc-sum> )",
                "single-animation": "<'animation-duration'>||<easing-function>||<'animation-delay'>||<single-animation-iteration-count>||<single-animation-direction>||<single-animation-fill-mode>||<single-animation-play-state>||[none|<keyframes-name>]||<single-animation-timeline>",
                "single-animation-direction": "normal|reverse|alternate|alternate-reverse",
                "single-animation-fill-mode": "none|forwards|backwards|both",
                "single-animation-iteration-count": "infinite|<number>",
                "single-animation-play-state": "running|paused",
                "single-animation-timeline": "auto|none|<dashed-ident>|<scroll()>|<view()>",
                "single-transition": "[none|<single-transition-property>]||<time>||<easing-function>||<time>||<transition-behavior-value>",
                "single-transition-property": "all|<custom-ident>",
                size: "closest-side|farthest-side|closest-corner|farthest-corner|<length>|<length-percentage>{2}",
                "sqrt()": "sqrt( <calc-sum> )",
                "step-position": "jump-start|jump-end|jump-none|jump-both|start|end",
                "step-timing-function": "step-start|step-end|steps( <integer> [, <step-position>]? )",
                "subclass-selector": "<id-selector>|<class-selector>|<attribute-selector>|<pseudo-class-selector>",
                "supports-condition": "not <supports-in-parens>|<supports-in-parens> [and <supports-in-parens>]*|<supports-in-parens> [or <supports-in-parens>]*",
                "supports-in-parens": "( <supports-condition> )|<supports-feature>|<general-enclosed>",
                "supports-feature": "<supports-decl>|<supports-selector-fn>",
                "supports-decl": "( <declaration> )",
                "supports-selector-fn": "selector( <complex-selector> )",
                symbol: "<string>|<image>|<custom-ident>",
                "system-color": "AccentColor|AccentColorText|ActiveText|ButtonBorder|ButtonFace|ButtonText|Canvas|CanvasText|Field|FieldText|GrayText|Highlight|HighlightText|LinkText|Mark|MarkText|SelectedItem|SelectedItemText|VisitedText",
                "tan()": "tan( <calc-sum> )",
                target: "<target-counter()>|<target-counters()>|<target-text()>",
                "target-counter()": "target-counter( [<string>|<url>] , <custom-ident> , <counter-style>? )",
                "target-counters()": "target-counters( [<string>|<url>] , <custom-ident> , <string> , <counter-style>? )",
                "target-text()": "target-text( [<string>|<url>] , [content|before|after|first-letter]? )",
                "time-percentage": "<time>|<percentage>",
                "timeline-range-name": "cover|contain|entry|exit|entry-crossing|exit-crossing",
                "easing-function": "linear|<cubic-bezier-timing-function>|<step-timing-function>",
                "track-breadth": "<length-percentage>|<flex>|min-content|max-content|auto",
                "track-list": "[<line-names>? [<track-size>|<track-repeat>]]+ <line-names>?",
                "track-repeat": "repeat( [<integer [1,∞]>] , [<line-names>? <track-size>]+ <line-names>? )",
                "track-size": "<track-breadth>|minmax( <inflexible-breadth> , <track-breadth> )|fit-content( <length-percentage> )",
                "transform-function": "<matrix()>|<translate()>|<translateX()>|<translateY()>|<scale()>|<scaleX()>|<scaleY()>|<rotate()>|<skew()>|<skewX()>|<skewY()>|<matrix3d()>|<translate3d()>|<translateZ()>|<scale3d()>|<scaleZ()>|<rotate3d()>|<rotateX()>|<rotateY()>|<rotateZ()>|<perspective()>",
                "transform-list": "<transform-function>+",
                "transition-behavior-value": "normal|allow-discrete",
                "translate()": "translate( <length-percentage> , <length-percentage>? )",
                "translate3d()": "translate3d( <length-percentage> , <length-percentage> , <length> )",
                "translateX()": "translateX( <length-percentage> )",
                "translateY()": "translateY( <length-percentage> )",
                "translateZ()": "translateZ( <length> )",
                "type-or-unit": "string|color|url|integer|number|length|angle|time|frequency|cap|ch|em|ex|ic|lh|rlh|rem|vb|vi|vw|vh|vmin|vmax|mm|Q|cm|in|pt|pc|px|deg|grad|rad|turn|ms|s|Hz|kHz|%",
                "type-selector": "<wq-name>|<ns-prefix>? '*'",
                "var()": "var( <custom-property-name> , <declaration-value>? )",
                "view()": "view( [<axis>||<'view-timeline-inset'>]? )",
                "viewport-length": "auto|<length-percentage>",
                "visual-box": "content-box|padding-box|border-box",
                "wq-name": "<ns-prefix>? <ident-token>",
                "-legacy-gradient": "<-webkit-gradient()>|<-legacy-linear-gradient>|<-legacy-repeating-linear-gradient>|<-legacy-radial-gradient>|<-legacy-repeating-radial-gradient>",
                "-legacy-linear-gradient": "-moz-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-linear-gradient( <-legacy-linear-gradient-arguments> )",
                "-legacy-repeating-linear-gradient": "-moz-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-webkit-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )|-o-repeating-linear-gradient( <-legacy-linear-gradient-arguments> )",
                "-legacy-linear-gradient-arguments": "[<angle>|<side-or-corner>]? , <color-stop-list>",
                "-legacy-radial-gradient": "-moz-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-radial-gradient( <-legacy-radial-gradient-arguments> )",
                "-legacy-repeating-radial-gradient": "-moz-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-webkit-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )|-o-repeating-radial-gradient( <-legacy-radial-gradient-arguments> )",
                "-legacy-radial-gradient-arguments": "[<position> ,]? [[[<-legacy-radial-gradient-shape>||<-legacy-radial-gradient-size>]|[<length>|<percentage>]{2}] ,]? <color-stop-list>",
                "-legacy-radial-gradient-size": "closest-side|closest-corner|farthest-side|farthest-corner|contain|cover",
                "-legacy-radial-gradient-shape": "circle|ellipse",
                "-non-standard-font": "-apple-system-body|-apple-system-headline|-apple-system-subheadline|-apple-system-caption1|-apple-system-caption2|-apple-system-footnote|-apple-system-short-body|-apple-system-short-headline|-apple-system-short-subheadline|-apple-system-short-caption1|-apple-system-short-footnote|-apple-system-tall-body",
                "-non-standard-color": "-moz-ButtonDefault|-moz-ButtonHoverFace|-moz-ButtonHoverText|-moz-CellHighlight|-moz-CellHighlightText|-moz-Combobox|-moz-ComboboxText|-moz-Dialog|-moz-DialogText|-moz-dragtargetzone|-moz-EvenTreeRow|-moz-Field|-moz-FieldText|-moz-html-CellHighlight|-moz-html-CellHighlightText|-moz-mac-accentdarkestshadow|-moz-mac-accentdarkshadow|-moz-mac-accentface|-moz-mac-accentlightesthighlight|-moz-mac-accentlightshadow|-moz-mac-accentregularhighlight|-moz-mac-accentregularshadow|-moz-mac-chrome-active|-moz-mac-chrome-inactive|-moz-mac-focusring|-moz-mac-menuselect|-moz-mac-menushadow|-moz-mac-menutextselect|-moz-MenuHover|-moz-MenuHoverText|-moz-MenuBarText|-moz-MenuBarHoverText|-moz-nativehyperlinktext|-moz-OddTreeRow|-moz-win-communicationstext|-moz-win-mediatext|-moz-activehyperlinktext|-moz-default-background-color|-moz-default-color|-moz-hyperlinktext|-moz-visitedhyperlinktext|-webkit-activelink|-webkit-focus-ring-color|-webkit-link|-webkit-text",
                "-non-standard-image-rendering": "optimize-contrast|-moz-crisp-edges|-o-crisp-edges|-webkit-optimize-contrast",
                "-non-standard-overflow": "overlay|-moz-scrollbars-none|-moz-scrollbars-horizontal|-moz-scrollbars-vertical|-moz-hidden-unscrollable",
                "-non-standard-size": "intrinsic|min-intrinsic|-webkit-fill-available|-webkit-fit-content|-webkit-min-content|-webkit-max-content|-moz-available|-moz-fit-content|-moz-min-content|-moz-max-content",
                "-webkit-gradient()": "-webkit-gradient( <-webkit-gradient-type> , <-webkit-gradient-point> [, <-webkit-gradient-point>|, <-webkit-gradient-radius> , <-webkit-gradient-point>] [, <-webkit-gradient-radius>]? [, <-webkit-gradient-color-stop>]* )",
                "-webkit-gradient-color-stop": "from( <color> )|color-stop( [<number-zero-one>|<percentage>] , <color> )|to( <color> )",
                "-webkit-gradient-point": "[left|center|right|<length-percentage>] [top|center|bottom|<length-percentage>]",
                "-webkit-gradient-radius": "<length>|<percentage>",
                "-webkit-gradient-type": "linear|radial",
                "-webkit-mask-box-repeat": "repeat|stretch|round",
                "-ms-filter-function-list": "<-ms-filter-function>+",
                "-ms-filter-function": "<-ms-filter-function-progid>|<-ms-filter-function-legacy>",
                "-ms-filter-function-progid": "'progid:' [<ident-token> '.']* [<ident-token>|<function-token> <any-value>? )]",
                "-ms-filter-function-legacy": "<ident-token>|<function-token> <any-value>? )",
                "absolute-color-base": "<hex-color>|<absolute-color-function>|<named-color>|transparent",
                "absolute-color-function": "<rgb()>|<rgba()>|<hsl()>|<hsla()>|<hwb()>|<lab()>|<lch()>|<oklab()>|<oklch()>|<color()>",
                age: "child|young|old",
                "anchor-name": "<dashed-ident>",
                "attr-name": "<wq-name>",
                "attr-fallback": "<any-value>",
                "bg-clip": "<box>|border|text",
                bottom: "<length>|auto",
                "container-name": "<custom-ident>",
                "container-condition": "not <query-in-parens>|<query-in-parens> [[and <query-in-parens>]*|[or <query-in-parens>]*]",
                "coord-box": "content-box|padding-box|border-box|fill-box|stroke-box|view-box",
                "generic-voice": "[<age>? <gender> <integer>?]",
                gender: "male|female|neutral",
                "generic-script-specific": "generic( kai )|generic( fangsong )|generic( nastaliq )",
                "generic-complete": "serif|sans-serif|system-ui|cursive|fantasy|math|monospace",
                "generic-incomplete": "ui-serif|ui-sans-serif|ui-monospace|ui-rounded",
                "-non-standard-generic-family": "-apple-system|BlinkMacSystemFont",
                left: "<length>|auto",
                "color-base": "<hex-color>|<color-function>|<named-color>|<color-mix()>|transparent",
                "color-function": "<rgb()>|<rgba()>|<hsl()>|<hsla()>|<hwb()>|<lab()>|<lch()>|<oklab()>|<oklch()>|<color()>",
                "device-cmyk()": "<legacy-device-cmyk-syntax>|<modern-device-cmyk-syntax>",
                "legacy-device-cmyk-syntax": "device-cmyk( <number>#{4} )",
                "modern-device-cmyk-syntax": "device-cmyk( <cmyk-component>{4} [/ [<alpha-value>|none]]? )",
                "cmyk-component": "<number>|<percentage>|none",
                "color-mix()": "color-mix( <color-interpolation-method> , [<color>&&<percentage [0,100]>?]#{2} )",
                "color-space": "<rectangular-color-space>|<polar-color-space>|<custom-color-space>",
                "custom-color-space": "<dashed-ident>",
                paint: "none|<color>|<url> [none|<color>]?|context-fill|context-stroke",
                "palette-identifier": "<dashed-ident>",
                right: "<length>|auto",
                "scope-start": "<forgiving-selector-list>",
                "scope-end": "<forgiving-selector-list>",
                "forgiving-selector-list": "<complex-real-selector-list>",
                "forgiving-relative-selector-list": "<relative-real-selector-list>",
                "selector-list": "<complex-selector-list>",
                "complex-real-selector-list": "<complex-real-selector>#",
                "simple-selector-list": "<simple-selector>#",
                "relative-real-selector-list": "<relative-real-selector>#",
                "complex-selector-unit": "[<compound-selector>? <pseudo-compound-selector>*]!",
                "complex-real-selector": "<compound-selector> [<combinator>? <compound-selector>]*",
                "relative-real-selector": "<combinator>? <complex-real-selector>",
                "pseudo-compound-selector": "<pseudo-element-selector> <pseudo-class-selector>*",
                "simple-selector": "<type-selector>|<subclass-selector>",
                "legacy-pseudo-element-selector": "':' [before|after|first-line|first-letter]",
                "single-animation-composition": "replace|add|accumulate",
                "svg-length": "<percentage>|<length>|<number>",
                "svg-writing-mode": "lr-tb|rl-tb|tb-rl|lr|rl|tb",
                top: "<length>|auto",
                x: "<number>",
                y: "<number>",
                declaration: "<ident-token> : <declaration-value>? ['!' important]?",
                "declaration-list": "[<declaration>? ';']* <declaration>?",
                url: "url( <string> <url-modifier>* )|<url-token>",
                "url-modifier": "<ident>|<function-token> <any-value> )",
                "number-zero-one": "<number [0,1]>",
                "number-one-or-greater": "<number [1,∞]>",
                "color()": "color( <colorspace-params> [/ [<alpha-value>|none]]? )",
                "colorspace-params": "[<predefined-rgb-params>|<xyz-params>]",
                "predefined-rgb-params": "<predefined-rgb> [<number>|<percentage>|none]{3}",
                "predefined-rgb": "srgb|srgb-linear|display-p3|a98-rgb|prophoto-rgb|rec2020",
                "xyz-params": "<xyz-space> [<number>|<percentage>|none]{3}",
                "xyz-space": "xyz|xyz-d50|xyz-d65",
                "oklab()": "oklab( [<percentage>|<number>|none] [<percentage>|<number>|none] [<percentage>|<number>|none] [/ [<alpha-value>|none]]? )",
                "oklch()": "oklch( [<percentage>|<number>|none] [<percentage>|<number>|none] [<hue>|none] [/ [<alpha-value>|none]]? )",
                "offset-path": "<ray()>|<url>|<basic-shape>",
                "rect()": "rect( [<length-percentage>|auto]{4} [round <'border-radius'>]? )",
                "xywh()": "xywh( <length-percentage>{2} <length-percentage [0,∞]>{2} [round <'border-radius'>]? )",
                "query-in-parens": "( <container-condition> )|( <size-feature> )|style( <style-query> )|<general-enclosed>",
                "size-feature": "<mf-plain>|<mf-boolean>|<mf-range>",
                "style-feature": "<declaration>",
                "style-query": "<style-condition>|<style-feature>",
                "style-condition": "not <style-in-parens>|<style-in-parens> [[and <style-in-parens>]*|[or <style-in-parens>]*]",
                "style-in-parens": "( <style-condition> )|( <style-feature> )|<general-enclosed>",
                "-non-standard-display": "-ms-inline-flexbox|-ms-grid|-ms-inline-grid|-webkit-flex|-webkit-inline-flex|-webkit-box|-webkit-inline-box|-moz-inline-stack|-moz-box|-moz-inline-box",
                "inset-area": "[[left|center|right|span-left|span-right|x-start|x-end|span-x-start|span-x-end|x-self-start|x-self-end|span-x-self-start|span-x-self-end|span-all]||[top|center|bottom|span-top|span-bottom|y-start|y-end|span-y-start|span-y-end|y-self-start|y-self-end|span-y-self-start|span-y-self-end|span-all]|[block-start|center|block-end|span-block-start|span-block-end|span-all]||[inline-start|center|inline-end|span-inline-start|span-inline-end|span-all]|[self-block-start|self-block-end|span-self-block-start|span-self-block-end|span-all]||[self-inline-start|self-inline-end|span-self-inline-start|span-self-inline-end|span-all]|[start|center|end|span-start|span-end|span-all]{1,2}|[self-start|center|self-end|span-self-start|span-self-end|span-all]{1,2}]",
                "position-area": "[[left|center|right|span-left|span-right|x-start|x-end|span-x-start|span-x-end|x-self-start|x-self-end|span-x-self-start|span-x-self-end|span-all]||[top|center|bottom|span-top|span-bottom|y-start|y-end|span-y-start|span-y-end|y-self-start|y-self-end|span-y-self-start|span-y-self-end|span-all]|[block-start|center|block-end|span-block-start|span-block-end|span-all]||[inline-start|center|inline-end|span-inline-start|span-inline-end|span-all]|[self-block-start|center|self-block-end|span-self-block-start|span-self-block-end|span-all]||[self-inline-start|center|self-inline-end|span-self-inline-start|span-self-inline-end|span-all]|[start|center|end|span-start|span-end|span-all]{1,2}|[self-start|center|self-end|span-self-start|span-self-end|span-all]{1,2}]",
                "anchor()": "anchor( <anchor-element>?&&<anchor-side> , <length-percentage>? )",
                "anchor-side": "inside|outside|top|left|right|bottom|start|end|self-start|self-end|<percentage>|center",
                "anchor-size()": "anchor-size( [<anchor-element>||<anchor-size>]? , <length-percentage>? )",
                "anchor-size": "width|height|block|inline|self-block|self-inline",
                "anchor-element": "<dashed-ident>",
                "try-size": "most-width|most-height|most-block-size|most-inline-size",
                "try-tactic": "flip-block||flip-inline||flip-start",
                "font-variant-css2": "normal|small-caps",
                "font-width-css3": "normal|ultra-condensed|extra-condensed|condensed|semi-condensed|semi-expanded|expanded|extra-expanded|ultra-expanded",
                "system-family-name": "caption|icon|menu|message-box|small-caption|status-bar"
            },
            properties: {
                "--*": "<declaration-value>",
                "-ms-accelerator": "false|true",
                "-ms-block-progression": "tb|rl|bt|lr",
                "-ms-content-zoom-chaining": "none|chained",
                "-ms-content-zooming": "none|zoom",
                "-ms-content-zoom-limit": "<'-ms-content-zoom-limit-min'> <'-ms-content-zoom-limit-max'>",
                "-ms-content-zoom-limit-max": "<percentage>",
                "-ms-content-zoom-limit-min": "<percentage>",
                "-ms-content-zoom-snap": "<'-ms-content-zoom-snap-type'>||<'-ms-content-zoom-snap-points'>",
                "-ms-content-zoom-snap-points": "snapInterval( <percentage> , <percentage> )|snapList( <percentage># )",
                "-ms-content-zoom-snap-type": "none|proximity|mandatory",
                "-ms-filter": "<string>",
                "-ms-flow-from": "[none|<custom-ident>]#",
                "-ms-flow-into": "[none|<custom-ident>]#",
                "-ms-grid-columns": "none|<track-list>|<auto-track-list>",
                "-ms-grid-rows": "none|<track-list>|<auto-track-list>",
                "-ms-high-contrast-adjust": "auto|none",
                "-ms-hyphenate-limit-chars": "auto|<integer>{1,3}",
                "-ms-hyphenate-limit-lines": "no-limit|<integer>",
                "-ms-hyphenate-limit-zone": "<percentage>|<length>",
                "-ms-ime-align": "auto|after",
                "-ms-overflow-style": "auto|none|scrollbar|-ms-autohiding-scrollbar",
                "-ms-scrollbar-3dlight-color": "<color>",
                "-ms-scrollbar-arrow-color": "<color>",
                "-ms-scrollbar-base-color": "<color>",
                "-ms-scrollbar-darkshadow-color": "<color>",
                "-ms-scrollbar-face-color": "<color>",
                "-ms-scrollbar-highlight-color": "<color>",
                "-ms-scrollbar-shadow-color": "<color>",
                "-ms-scrollbar-track-color": "<color>",
                "-ms-scroll-chaining": "chained|none",
                "-ms-scroll-limit": "<'-ms-scroll-limit-x-min'> <'-ms-scroll-limit-y-min'> <'-ms-scroll-limit-x-max'> <'-ms-scroll-limit-y-max'>",
                "-ms-scroll-limit-x-max": "auto|<length>",
                "-ms-scroll-limit-x-min": "<length>",
                "-ms-scroll-limit-y-max": "auto|<length>",
                "-ms-scroll-limit-y-min": "<length>",
                "-ms-scroll-rails": "none|railed",
                "-ms-scroll-snap-points-x": "snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )",
                "-ms-scroll-snap-points-y": "snapInterval( <length-percentage> , <length-percentage> )|snapList( <length-percentage># )",
                "-ms-scroll-snap-type": "none|proximity|mandatory",
                "-ms-scroll-snap-x": "<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-x'>",
                "-ms-scroll-snap-y": "<'-ms-scroll-snap-type'> <'-ms-scroll-snap-points-y'>",
                "-ms-scroll-translation": "none|vertical-to-horizontal",
                "-ms-text-autospace": "none|ideograph-alpha|ideograph-numeric|ideograph-parenthesis|ideograph-space",
                "-ms-touch-select": "grippers|none",
                "-ms-user-select": "none|element|text",
                "-ms-wrap-flow": "auto|both|start|end|maximum|clear",
                "-ms-wrap-margin": "<length>",
                "-ms-wrap-through": "wrap|none",
                "-moz-appearance": "none|button|button-arrow-down|button-arrow-next|button-arrow-previous|button-arrow-up|button-bevel|button-focus|caret|checkbox|checkbox-container|checkbox-label|checkmenuitem|dualbutton|groupbox|listbox|listitem|menuarrow|menubar|menucheckbox|menuimage|menuitem|menuitemtext|menulist|menulist-button|menulist-text|menulist-textfield|menupopup|menuradio|menuseparator|meterbar|meterchunk|progressbar|progressbar-vertical|progresschunk|progresschunk-vertical|radio|radio-container|radio-label|radiomenuitem|range|range-thumb|resizer|resizerpanel|scale-horizontal|scalethumbend|scalethumb-horizontal|scalethumbstart|scalethumbtick|scalethumb-vertical|scale-vertical|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|separator|sheet|spinner|spinner-downbutton|spinner-textfield|spinner-upbutton|splitter|statusbar|statusbarpanel|tab|tabpanel|tabpanels|tab-scroll-arrow-back|tab-scroll-arrow-forward|textfield|textfield-multiline|toolbar|toolbarbutton|toolbarbutton-dropdown|toolbargripper|toolbox|tooltip|treeheader|treeheadercell|treeheadersortarrow|treeitem|treeline|treetwisty|treetwistyopen|treeview|-moz-mac-unified-toolbar|-moz-win-borderless-glass|-moz-win-browsertabbar-toolbox|-moz-win-communicationstext|-moz-win-communications-toolbox|-moz-win-exclude-glass|-moz-win-glass|-moz-win-mediatext|-moz-win-media-toolbox|-moz-window-button-box|-moz-window-button-box-maximized|-moz-window-button-close|-moz-window-button-maximize|-moz-window-button-minimize|-moz-window-button-restore|-moz-window-frame-bottom|-moz-window-frame-left|-moz-window-frame-right|-moz-window-titlebar|-moz-window-titlebar-maximized",
                "-moz-binding": "<url>|none",
                "-moz-border-bottom-colors": "<color>+|none",
                "-moz-border-left-colors": "<color>+|none",
                "-moz-border-right-colors": "<color>+|none",
                "-moz-border-top-colors": "<color>+|none",
                "-moz-context-properties": "none|[fill|fill-opacity|stroke|stroke-opacity]#",
                "-moz-float-edge": "border-box|content-box|margin-box|padding-box",
                "-moz-force-broken-image-icon": "0|1",
                "-moz-image-region": "<shape>|auto",
                "-moz-orient": "inline|block|horizontal|vertical",
                "-moz-outline-radius": "<outline-radius>{1,4} [/ <outline-radius>{1,4}]?",
                "-moz-outline-radius-bottomleft": "<outline-radius>",
                "-moz-outline-radius-bottomright": "<outline-radius>",
                "-moz-outline-radius-topleft": "<outline-radius>",
                "-moz-outline-radius-topright": "<outline-radius>",
                "-moz-stack-sizing": "ignore|stretch-to-fit",
                "-moz-text-blink": "none|blink",
                "-moz-user-focus": "ignore|normal|select-after|select-before|select-menu|select-same|select-all|none",
                "-moz-user-input": "auto|none|enabled|disabled",
                "-moz-user-modify": "read-only|read-write|write-only",
                "-moz-window-dragging": "drag|no-drag",
                "-moz-window-shadow": "default|menu|tooltip|sheet|none",
                "-webkit-appearance": "none|button|button-bevel|caps-lock-indicator|caret|checkbox|default-button|inner-spin-button|listbox|listitem|media-controls-background|media-controls-fullscreen-background|media-current-time-display|media-enter-fullscreen-button|media-exit-fullscreen-button|media-fullscreen-button|media-mute-button|media-overlay-play-button|media-play-button|media-seek-back-button|media-seek-forward-button|media-slider|media-sliderthumb|media-time-remaining-display|media-toggle-closed-captions-button|media-volume-slider|media-volume-slider-container|media-volume-sliderthumb|menulist|menulist-button|menulist-text|menulist-textfield|meter|progress-bar|progress-bar-value|push-button|radio|scrollbarbutton-down|scrollbarbutton-left|scrollbarbutton-right|scrollbarbutton-up|scrollbargripper-horizontal|scrollbargripper-vertical|scrollbarthumb-horizontal|scrollbarthumb-vertical|scrollbartrack-horizontal|scrollbartrack-vertical|searchfield|searchfield-cancel-button|searchfield-decoration|searchfield-results-button|searchfield-results-decoration|slider-horizontal|slider-vertical|sliderthumb-horizontal|sliderthumb-vertical|square-button|textarea|textfield|-apple-pay-button",
                "-webkit-border-before": "<'border-width'>||<'border-style'>||<color>",
                "-webkit-border-before-color": "<color>",
                "-webkit-border-before-style": "<'border-style'>",
                "-webkit-border-before-width": "<'border-width'>",
                "-webkit-box-reflect": "[above|below|right|left]? <length>? <image>?",
                "-webkit-line-clamp": "none|<integer>",
                "-webkit-mask": "[<mask-reference>||<position> [/ <bg-size>]?||<repeat-style>||[<box>|border|padding|content|text]||[<box>|border|padding|content]]#",
                "-webkit-mask-attachment": "<attachment>#",
                "-webkit-mask-clip": "[<box>|border|padding|content|text]#",
                "-webkit-mask-composite": "<composite-style>#",
                "-webkit-mask-image": "<mask-reference>#",
                "-webkit-mask-origin": "[<box>|border|padding|content]#",
                "-webkit-mask-position": "<position>#",
                "-webkit-mask-position-x": "[<length-percentage>|left|center|right]#",
                "-webkit-mask-position-y": "[<length-percentage>|top|center|bottom]#",
                "-webkit-mask-repeat": "<repeat-style>#",
                "-webkit-mask-repeat-x": "repeat|no-repeat|space|round",
                "-webkit-mask-repeat-y": "repeat|no-repeat|space|round",
                "-webkit-mask-size": "<bg-size>#",
                "-webkit-overflow-scrolling": "auto|touch",
                "-webkit-tap-highlight-color": "<color>",
                "-webkit-text-fill-color": "<color>",
                "-webkit-text-stroke": "<length>||<color>",
                "-webkit-text-stroke-color": "<color>",
                "-webkit-text-stroke-width": "<length>",
                "-webkit-touch-callout": "default|none",
                "-webkit-user-modify": "read-only|read-write|read-write-plaintext-only",
                "accent-color": "auto|<color>",
                "align-content": "normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>",
                "align-items": "normal|stretch|<baseline-position>|[<overflow-position>? <self-position>]",
                "align-self": "auto|normal|stretch|<baseline-position>|<overflow-position>? <self-position>",
                "align-tracks": "[normal|<baseline-position>|<content-distribution>|<overflow-position>? <content-position>]#",
                all: "initial|inherit|unset|revert|revert-layer",
                "anchor-name": "none|<dashed-ident>#",
                "anchor-scope": "none|all|<dashed-ident>#",
                animation: "<single-animation>#",
                "animation-composition": "<single-animation-composition>#",
                "animation-delay": "<time>#",
                "animation-direction": "<single-animation-direction>#",
                "animation-duration": "<time>#",
                "animation-fill-mode": "<single-animation-fill-mode>#",
                "animation-iteration-count": "<single-animation-iteration-count>#",
                "animation-name": "[none|<keyframes-name>]#",
                "animation-play-state": "<single-animation-play-state>#",
                "animation-range": "[<'animation-range-start'> <'animation-range-end'>?]#",
                "animation-range-end": "[normal|<length-percentage>|<timeline-range-name> <length-percentage>?]#",
                "animation-range-start": "[normal|<length-percentage>|<timeline-range-name> <length-percentage>?]#",
                "animation-timing-function": "<easing-function>#",
                "animation-timeline": "<single-animation-timeline>#",
                appearance: "none|auto|textfield|menulist-button|<compat-auto>",
                "aspect-ratio": "auto||<ratio>",
                azimuth: "<angle>|[[left-side|far-left|left|center-left|center|center-right|right|far-right|right-side]||behind]|leftwards|rightwards",
                "backdrop-filter": "none|<filter-function-list>",
                "backface-visibility": "visible|hidden",
                background: "[<bg-layer> ,]* <final-bg-layer>",
                "background-attachment": "<attachment>#",
                "background-blend-mode": "<blend-mode>#",
                "background-clip": "<bg-clip>#",
                "background-color": "<color>",
                "background-image": "<bg-image>#",
                "background-origin": "<box>#",
                "background-position": "<bg-position>#",
                "background-position-x": "[center|[[left|right|x-start|x-end]? <length-percentage>?]!]#",
                "background-position-y": "[center|[[top|bottom|y-start|y-end]? <length-percentage>?]!]#",
                "background-repeat": "<repeat-style>#",
                "background-size": "<bg-size>#",
                "block-size": "<'width'>",
                border: "<line-width>||<line-style>||<color>",
                "border-block": "<'border-top-width'>||<'border-top-style'>||<color>",
                "border-block-color": "<'border-top-color'>{1,2}",
                "border-block-style": "<'border-top-style'>",
                "border-block-width": "<'border-top-width'>",
                "border-block-end": "<'border-top-width'>||<'border-top-style'>||<color>",
                "border-block-end-color": "<'border-top-color'>",
                "border-block-end-style": "<'border-top-style'>",
                "border-block-end-width": "<'border-top-width'>",
                "border-block-start": "<'border-top-width'>||<'border-top-style'>||<color>",
                "border-block-start-color": "<'border-top-color'>",
                "border-block-start-style": "<'border-top-style'>",
                "border-block-start-width": "<'border-top-width'>",
                "border-bottom": "<line-width>||<line-style>||<color>",
                "border-bottom-color": "<'border-top-color'>",
                "border-bottom-left-radius": "<length-percentage>{1,2}",
                "border-bottom-right-radius": "<length-percentage>{1,2}",
                "border-bottom-style": "<line-style>",
                "border-bottom-width": "<line-width>",
                "border-collapse": "collapse|separate",
                "border-color": "<color>{1,4}",
                "border-end-end-radius": "<length-percentage>{1,2}",
                "border-end-start-radius": "<length-percentage>{1,2}",
                "border-image": "<'border-image-source'>||<'border-image-slice'> [/ <'border-image-width'>|/ <'border-image-width'>? / <'border-image-outset'>]?||<'border-image-repeat'>",
                "border-image-outset": "[<length>|<number>]{1,4}",
                "border-image-repeat": "[stretch|repeat|round|space]{1,2}",
                "border-image-slice": "<number-percentage>{1,4}&&fill?",
                "border-image-source": "none|<image>",
                "border-image-width": "[<length-percentage>|<number>|auto]{1,4}",
                "border-inline": "<'border-top-width'>||<'border-top-style'>||<color>",
                "border-inline-end": "<'border-top-width'>||<'border-top-style'>||<color>",
                "border-inline-color": "<'border-top-color'>{1,2}",
                "border-inline-style": "<'border-top-style'>",
                "border-inline-width": "<'border-top-width'>",
                "border-inline-end-color": "<'border-top-color'>",
                "border-inline-end-style": "<'border-top-style'>",
                "border-inline-end-width": "<'border-top-width'>",
                "border-inline-start": "<'border-top-width'>||<'border-top-style'>||<color>",
                "border-inline-start-color": "<'border-top-color'>",
                "border-inline-start-style": "<'border-top-style'>",
                "border-inline-start-width": "<'border-top-width'>",
                "border-left": "<line-width>||<line-style>||<color>",
                "border-left-color": "<color>",
                "border-left-style": "<line-style>",
                "border-left-width": "<line-width>",
                "border-radius": "<length-percentage>{1,4} [/ <length-percentage>{1,4}]?",
                "border-right": "<line-width>||<line-style>||<color>",
                "border-right-color": "<color>",
                "border-right-style": "<line-style>",
                "border-right-width": "<line-width>",
                "border-spacing": "<length> <length>?",
                "border-start-end-radius": "<length-percentage>{1,2}",
                "border-start-start-radius": "<length-percentage>{1,2}",
                "border-style": "<line-style>{1,4}",
                "border-top": "<line-width>||<line-style>||<color>",
                "border-top-color": "<color>",
                "border-top-left-radius": "<length-percentage>{1,2}",
                "border-top-right-radius": "<length-percentage>{1,2}",
                "border-top-style": "<line-style>",
                "border-top-width": "<line-width>",
                "border-width": "<line-width>{1,4}",
                bottom: "<length>|<percentage>|auto",
                "box-align": "start|center|end|baseline|stretch",
                "box-decoration-break": "slice|clone",
                "box-direction": "normal|reverse|inherit",
                "box-flex": "<number>",
                "box-flex-group": "<integer>",
                "box-lines": "single|multiple",
                "box-ordinal-group": "<integer>",
                "box-orient": "horizontal|vertical|inline-axis|block-axis|inherit",
                "box-pack": "start|center|end|justify",
                "box-shadow": "none|<shadow>#",
                "box-sizing": "content-box|border-box",
                "break-after": "auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region",
                "break-before": "auto|avoid|always|all|avoid-page|page|left|right|recto|verso|avoid-column|column|avoid-region|region",
                "break-inside": "auto|avoid|avoid-page|avoid-column|avoid-region",
                "caption-side": "top|bottom|block-start|block-end|inline-start|inline-end",
                caret: "<'caret-color'>||<'caret-shape'>",
                "caret-color": "auto|<color>",
                "caret-shape": "auto|bar|block|underscore",
                clear: "none|left|right|both|inline-start|inline-end",
                clip: "<shape>|auto",
                "clip-path": "<clip-source>|[<basic-shape>||<geometry-box>]|none",
                "clip-rule": "nonzero|evenodd",
                color: "<color>",
                "color-interpolation-filters": "auto|sRGB|linearRGB",
                "color-scheme": "normal|[light|dark|<custom-ident>]+&&only?",
                "column-count": "<integer>|auto",
                "column-fill": "auto|balance",
                "column-gap": "normal|<length-percentage>",
                "column-rule": "<'column-rule-width'>||<'column-rule-style'>||<'column-rule-color'>",
                "column-rule-color": "<color>",
                "column-rule-style": "<'border-style'>",
                "column-rule-width": "<'border-width'>",
                "column-span": "none|all",
                "column-width": "<length>|auto",
                columns: "<'column-width'>||<'column-count'>",
                contain: "none|strict|content|[[size||inline-size]||layout||style||paint]",
                "contain-intrinsic-size": "[auto? [none|<length>]]{1,2}",
                "contain-intrinsic-block-size": "auto? [none|<length>]",
                "contain-intrinsic-height": "auto? [none|<length>]",
                "contain-intrinsic-inline-size": "auto? [none|<length>]",
                "contain-intrinsic-width": "auto? [none|<length>]",
                container: "<'container-name'> [/ <'container-type'>]?",
                "container-name": "none|<custom-ident>+",
                "container-type": "normal||[size|inline-size]",
                content: "normal|none|[<content-replacement>|<content-list>] [/ [<string>|<counter>]+]?",
                "content-visibility": "visible|auto|hidden",
                "counter-increment": "[<counter-name> <integer>?]+|none",
                "counter-reset": "[<counter-name> <integer>?|<reversed-counter-name> <integer>?]+|none",
                "counter-set": "[<counter-name> <integer>?]+|none",
                cursor: "[[<url> [<x> <y>]? ,]* [auto|default|none|context-menu|help|pointer|progress|wait|cell|crosshair|text|vertical-text|alias|copy|move|no-drop|not-allowed|e-resize|n-resize|ne-resize|nw-resize|s-resize|se-resize|sw-resize|w-resize|ew-resize|ns-resize|nesw-resize|nwse-resize|col-resize|row-resize|all-scroll|zoom-in|zoom-out|grab|grabbing|hand|-webkit-grab|-webkit-grabbing|-webkit-zoom-in|-webkit-zoom-out|-moz-grab|-moz-grabbing|-moz-zoom-in|-moz-zoom-out]]",
                d: "none|path( <string> )",
                cx: "<length>|<percentage>",
                cy: "<length>|<percentage>",
                direction: "ltr|rtl",
                display: "[<display-outside>||<display-inside>]|<display-listitem>|<display-internal>|<display-box>|<display-legacy>|<-non-standard-display>",
                "dominant-baseline": "auto|use-script|no-change|reset-size|ideographic|alphabetic|hanging|mathematical|central|middle|text-after-edge|text-before-edge",
                "empty-cells": "show|hide",
                "field-sizing": "content|fixed",
                fill: "<paint>",
                "fill-opacity": "<number-zero-one>",
                "fill-rule": "nonzero|evenodd",
                filter: "none|<filter-function-list>|<-ms-filter-function-list>",
                flex: "none|[<'flex-grow'> <'flex-shrink'>?||<'flex-basis'>]",
                "flex-basis": "content|<'width'>",
                "flex-direction": "row|row-reverse|column|column-reverse",
                "flex-flow": "<'flex-direction'>||<'flex-wrap'>",
                "flex-grow": "<number>",
                "flex-shrink": "<number>",
                "flex-wrap": "nowrap|wrap|wrap-reverse",
                float: "left|right|none|inline-start|inline-end",
                font: "[[<'font-style'>||<font-variant-css2>||<'font-weight'>||<font-width-css3>]? <'font-size'> [/ <'line-height'>]? <'font-family'>#]|<system-family-name>|<-non-standard-font>",
                "font-family": "[<family-name>|<generic-family>]#",
                "font-feature-settings": "normal|<feature-tag-value>#",
                "font-kerning": "auto|normal|none",
                "font-language-override": "normal|<string>",
                "font-optical-sizing": "auto|none",
                "font-palette": "normal|light|dark|<palette-identifier>",
                "font-variation-settings": "normal|[<string> <number>]#",
                "font-size": "<absolute-size>|<relative-size>|<length-percentage>",
                "font-size-adjust": "none|[ex-height|cap-height|ch-width|ic-width|ic-height]? [from-font|<number>]",
                "font-smooth": "auto|never|always|<absolute-size>|<length>",
                "font-stretch": "<font-stretch-absolute>",
                "font-style": "normal|italic|oblique <angle>?",
                "font-synthesis": "none|[weight||style||small-caps||position]",
                "font-synthesis-position": "auto|none",
                "font-synthesis-small-caps": "auto|none",
                "font-synthesis-style": "auto|none",
                "font-synthesis-weight": "auto|none",
                "font-variant": "normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>||stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )||[small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps]||<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero||<east-asian-variant-values>||<east-asian-width-values>||ruby]",
                "font-variant-alternates": "normal|[stylistic( <feature-value-name> )||historical-forms||styleset( <feature-value-name># )||character-variant( <feature-value-name># )||swash( <feature-value-name> )||ornaments( <feature-value-name> )||annotation( <feature-value-name> )]",
                "font-variant-caps": "normal|small-caps|all-small-caps|petite-caps|all-petite-caps|unicase|titling-caps",
                "font-variant-east-asian": "normal|[<east-asian-variant-values>||<east-asian-width-values>||ruby]",
                "font-variant-emoji": "normal|text|emoji|unicode",
                "font-variant-ligatures": "normal|none|[<common-lig-values>||<discretionary-lig-values>||<historical-lig-values>||<contextual-alt-values>]",
                "font-variant-numeric": "normal|[<numeric-figure-values>||<numeric-spacing-values>||<numeric-fraction-values>||ordinal||slashed-zero]",
                "font-variant-position": "normal|sub|super",
                "font-weight": "<font-weight-absolute>|bolder|lighter",
                "forced-color-adjust": "auto|none|preserve-parent-color",
                gap: "<'row-gap'> <'column-gap'>?",
                grid: "<'grid-template'>|<'grid-template-rows'> / [auto-flow&&dense?] <'grid-auto-columns'>?|[auto-flow&&dense?] <'grid-auto-rows'>? / <'grid-template-columns'>",
                "grid-area": "<grid-line> [/ <grid-line>]{0,3}",
                "grid-auto-columns": "<track-size>+",
                "grid-auto-flow": "[row|column]||dense",
                "grid-auto-rows": "<track-size>+",
                "grid-column": "<grid-line> [/ <grid-line>]?",
                "grid-column-end": "<grid-line>",
                "grid-column-gap": "<length-percentage>",
                "grid-column-start": "<grid-line>",
                "grid-gap": "<'grid-row-gap'> <'grid-column-gap'>?",
                "grid-row": "<grid-line> [/ <grid-line>]?",
                "grid-row-end": "<grid-line>",
                "grid-row-gap": "<length-percentage>",
                "grid-row-start": "<grid-line>",
                "grid-template": "none|[<'grid-template-rows'> / <'grid-template-columns'>]|[<line-names>? <string> <track-size>? <line-names>?]+ [/ <explicit-track-list>]?",
                "grid-template-areas": "none|<string>+",
                "grid-template-columns": "none|<track-list>|<auto-track-list>|subgrid <line-name-list>?",
                "grid-template-rows": "none|<track-list>|<auto-track-list>|subgrid <line-name-list>?",
                "hanging-punctuation": "none|[first||[force-end|allow-end]||last]",
                height: "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
                "hyphenate-character": "auto|<string>",
                "hyphenate-limit-chars": "[auto|<integer>]{1,3}",
                hyphens: "none|manual|auto",
                "image-orientation": "from-image|<angle>|[<angle>? flip]",
                "image-rendering": "auto|crisp-edges|pixelated|optimizeSpeed|optimizeQuality|<-non-standard-image-rendering>",
                "image-resolution": "[from-image||<resolution>]&&snap?",
                "ime-mode": "auto|normal|active|inactive|disabled",
                "initial-letter": "normal|[<number> <integer>?]",
                "initial-letter-align": "[auto|alphabetic|hanging|ideographic]",
                "inline-size": "<'width'>",
                "input-security": "auto|none",
                inset: "<'top'>{1,4}",
                "inset-block": "<'top'>{1,2}",
                "inset-block-end": "<'top'>",
                "inset-block-start": "<'top'>",
                "inset-inline": "<'top'>{1,2}",
                "inset-inline-end": "<'top'>",
                "inset-inline-start": "<'top'>",
                "interpolate-size": "numeric-only|allow-keywords",
                isolation: "auto|isolate",
                "justify-content": "normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]",
                "justify-items": "normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]|legacy|legacy&&[left|right|center]",
                "justify-self": "auto|normal|stretch|<baseline-position>|<overflow-position>? [<self-position>|left|right]",
                "justify-tracks": "[normal|<content-distribution>|<overflow-position>? [<content-position>|left|right]]#",
                left: "<length>|<percentage>|auto",
                "letter-spacing": "normal|<length-percentage>",
                "line-break": "auto|loose|normal|strict|anywhere",
                "line-clamp": "none|<integer>",
                "line-height": "normal|<number>|<length>|<percentage>",
                "line-height-step": "<length>",
                "list-style": "<'list-style-type'>||<'list-style-position'>||<'list-style-image'>",
                "list-style-image": "<image>|none",
                "list-style-position": "inside|outside",
                "list-style-type": "<counter-style>|<string>|none",
                margin: "[<length>|<percentage>|auto]{1,4}",
                "margin-block": "<'margin-left'>{1,2}",
                "margin-block-end": "<'margin-left'>",
                "margin-block-start": "<'margin-left'>",
                "margin-bottom": "<length>|<percentage>|auto",
                "margin-inline": "<'margin-left'>{1,2}",
                "margin-inline-end": "<'margin-left'>",
                "margin-inline-start": "<'margin-left'>",
                "margin-left": "<length>|<percentage>|auto",
                "margin-right": "<length>|<percentage>|auto",
                "margin-top": "<length>|<percentage>|auto",
                "margin-trim": "none|in-flow|all",
                marker: "none|<url>",
                "marker-end": "none|<url>",
                "marker-mid": "none|<url>",
                "marker-start": "none|<url>",
                mask: "<mask-layer>#",
                "mask-border": "<'mask-border-source'>||<'mask-border-slice'> [/ <'mask-border-width'>? [/ <'mask-border-outset'>]?]?||<'mask-border-repeat'>||<'mask-border-mode'>",
                "mask-border-mode": "luminance|alpha",
                "mask-border-outset": "[<length>|<number>]{1,4}",
                "mask-border-repeat": "[stretch|repeat|round|space]{1,2}",
                "mask-border-slice": "<number-percentage>{1,4} fill?",
                "mask-border-source": "none|<image>",
                "mask-border-width": "[<length-percentage>|<number>|auto]{1,4}",
                "mask-clip": "[<geometry-box>|no-clip]#",
                "mask-composite": "<compositing-operator>#",
                "mask-image": "<mask-reference>#",
                "mask-mode": "<masking-mode>#",
                "mask-origin": "<geometry-box>#",
                "mask-position": "<position>#",
                "mask-repeat": "<repeat-style>#",
                "mask-size": "<bg-size>#",
                "mask-type": "luminance|alpha",
                "masonry-auto-flow": "[pack|next]||[definite-first|ordered]",
                "math-depth": "auto-add|add( <integer> )|<integer>",
                "math-shift": "normal|compact",
                "math-style": "normal|compact",
                "max-block-size": "<'max-width'>",
                "max-height": "none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
                "max-inline-size": "<'max-width'>",
                "max-lines": "none|<integer>",
                "max-width": "none|<length-percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
                "min-block-size": "<'min-width'>",
                "min-height": "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
                "min-inline-size": "<'min-width'>",
                "min-width": "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
                "mix-blend-mode": "<blend-mode>|plus-lighter",
                "object-fit": "fill|contain|cover|none|scale-down",
                "object-position": "<position>",
                offset: "[<'offset-position'>? [<'offset-path'> [<'offset-distance'>||<'offset-rotate'>]?]?]! [/ <'offset-anchor'>]?",
                "offset-anchor": "auto|<position>",
                "offset-distance": "<length-percentage>",
                "offset-path": "none|<offset-path>||<coord-box>",
                "offset-position": "normal|auto|<position>",
                "offset-rotate": "[auto|reverse]||<angle>",
                opacity: "<alpha-value>",
                order: "<integer>",
                orphans: "<integer>",
                outline: "[<'outline-width'>||<'outline-style'>||<'outline-color'>]",
                "outline-color": "auto|<color>",
                "outline-offset": "<length>",
                "outline-style": "auto|<'border-style'>",
                "outline-width": "<line-width>",
                overflow: "[visible|hidden|clip|scroll|auto]{1,2}|<-non-standard-overflow>",
                "overflow-anchor": "auto|none",
                "overflow-block": "visible|hidden|clip|scroll|auto",
                "overflow-clip-box": "padding-box|content-box",
                "overflow-clip-margin": "<visual-box>||<length [0,∞]>",
                "overflow-inline": "visible|hidden|clip|scroll|auto",
                "overflow-wrap": "normal|break-word|anywhere",
                "overflow-x": "visible|hidden|clip|scroll|auto",
                "overflow-y": "visible|hidden|clip|scroll|auto",
                overlay: "none|auto",
                "overscroll-behavior": "[contain|none|auto]{1,2}",
                "overscroll-behavior-block": "contain|none|auto",
                "overscroll-behavior-inline": "contain|none|auto",
                "overscroll-behavior-x": "contain|none|auto",
                "overscroll-behavior-y": "contain|none|auto",
                padding: "[<length>|<percentage>]{1,4}",
                "padding-block": "<'padding-left'>{1,2}",
                "padding-block-end": "<'padding-left'>",
                "padding-block-start": "<'padding-left'>",
                "padding-bottom": "<length>|<percentage>",
                "padding-inline": "<'padding-left'>{1,2}",
                "padding-inline-end": "<'padding-left'>",
                "padding-inline-start": "<'padding-left'>",
                "padding-left": "<length>|<percentage>",
                "padding-right": "<length>|<percentage>",
                "padding-top": "<length>|<percentage>",
                page: "auto|<custom-ident>",
                "page-break-after": "auto|always|avoid|left|right|recto|verso",
                "page-break-before": "auto|always|avoid|left|right|recto|verso",
                "page-break-inside": "auto|avoid",
                "paint-order": "normal|[fill||stroke||markers]",
                perspective: "none|<length>",
                "perspective-origin": "<position>",
                "place-content": "<'align-content'> <'justify-content'>?",
                "place-items": "<'align-items'> <'justify-items'>?",
                "place-self": "<'align-self'> <'justify-self'>?",
                "pointer-events": "auto|none|visiblePainted|visibleFill|visibleStroke|visible|painted|fill|stroke|all|inherit",
                position: "static|relative|absolute|sticky|fixed|-webkit-sticky",
                "position-anchor": "auto|<anchor-name>",
                "position-area": "none|<position-area>",
                "position-try": "<'position-try-order'>? <'position-try-fallbacks'>",
                "position-try-fallbacks": "none|[[<dashed-ident>||<try-tactic>]|<'position-area'>]#",
                "position-try-order": "normal|<try-size>",
                "position-visibility": "always|[anchors-valid||anchors-visible||no-overflow]",
                "print-color-adjust": "economy|exact",
                quotes: "none|auto|[<string> <string>]+",
                r: "<length>|<percentage>",
                resize: "none|both|horizontal|vertical|block|inline",
                right: "<length>|<percentage>|auto",
                rotate: "none|<angle>|[x|y|z|<number>{3}]&&<angle>",
                "row-gap": "normal|<length-percentage>",
                "ruby-align": "start|center|space-between|space-around",
                "ruby-merge": "separate|collapse|auto",
                "ruby-position": "[alternate||[over|under]]|inter-character",
                rx: "<length>|<percentage>",
                ry: "<length>|<percentage>",
                scale: "none|[<number>|<percentage>]{1,3}",
                "scrollbar-color": "auto|<color>{2}",
                "scrollbar-gutter": "auto|stable&&both-edges?",
                "scrollbar-width": "auto|thin|none",
                "scroll-behavior": "auto|smooth",
                "scroll-margin": "<length>{1,4}",
                "scroll-margin-block": "<length>{1,2}",
                "scroll-margin-block-start": "<length>",
                "scroll-margin-block-end": "<length>",
                "scroll-margin-bottom": "<length>",
                "scroll-margin-inline": "<length>{1,2}",
                "scroll-margin-inline-start": "<length>",
                "scroll-margin-inline-end": "<length>",
                "scroll-margin-left": "<length>",
                "scroll-margin-right": "<length>",
                "scroll-margin-top": "<length>",
                "scroll-padding": "[auto|<length-percentage>]{1,4}",
                "scroll-padding-block": "[auto|<length-percentage>]{1,2}",
                "scroll-padding-block-start": "auto|<length-percentage>",
                "scroll-padding-block-end": "auto|<length-percentage>",
                "scroll-padding-bottom": "auto|<length-percentage>",
                "scroll-padding-inline": "[auto|<length-percentage>]{1,2}",
                "scroll-padding-inline-start": "auto|<length-percentage>",
                "scroll-padding-inline-end": "auto|<length-percentage>",
                "scroll-padding-left": "auto|<length-percentage>",
                "scroll-padding-right": "auto|<length-percentage>",
                "scroll-padding-top": "auto|<length-percentage>",
                "scroll-snap-align": "[none|start|end|center]{1,2}",
                "scroll-snap-coordinate": "none|<position>#",
                "scroll-snap-destination": "<position>",
                "scroll-snap-points-x": "none|repeat( <length-percentage> )",
                "scroll-snap-points-y": "none|repeat( <length-percentage> )",
                "scroll-snap-stop": "normal|always",
                "scroll-snap-type": "none|[x|y|block|inline|both] [mandatory|proximity]?",
                "scroll-snap-type-x": "none|mandatory|proximity",
                "scroll-snap-type-y": "none|mandatory|proximity",
                "scroll-timeline": "[<'scroll-timeline-name'>||<'scroll-timeline-axis'>]#",
                "scroll-timeline-axis": "[block|inline|x|y]#",
                "scroll-timeline-name": "[none|<dashed-ident>]#",
                "shape-image-threshold": "<alpha-value>",
                "shape-margin": "<length-percentage>",
                "shape-outside": "none|[<shape-box>||<basic-shape>]|<image>",
                "shape-rendering": "auto|optimizeSpeed|crispEdges|geometricPrecision",
                stroke: "<paint>",
                "stroke-dasharray": "none|[<svg-length>+]#",
                "stroke-dashoffset": "<svg-length>",
                "stroke-linecap": "butt|round|square",
                "stroke-linejoin": "miter|round|bevel",
                "stroke-miterlimit": "<number-one-or-greater>",
                "stroke-opacity": "<'opacity'>",
                "stroke-width": "<svg-length>",
                "tab-size": "<integer>|<length>",
                "table-layout": "auto|fixed",
                "text-align": "start|end|left|right|center|justify|match-parent",
                "text-align-last": "auto|start|end|left|right|center|justify",
                "text-anchor": "start|middle|end",
                "text-combine-upright": "none|all|[digits <integer>?]",
                "text-decoration": "<'text-decoration-line'>||<'text-decoration-style'>||<'text-decoration-color'>||<'text-decoration-thickness'>",
                "text-decoration-color": "<color>",
                "text-decoration-line": "none|[underline||overline||line-through||blink]|spelling-error|grammar-error",
                "text-decoration-skip": "none|[objects||[spaces|[leading-spaces||trailing-spaces]]||edges||box-decoration]",
                "text-decoration-skip-ink": "auto|all|none",
                "text-decoration-style": "solid|double|dotted|dashed|wavy",
                "text-decoration-thickness": "auto|from-font|<length>|<percentage>",
                "text-emphasis": "<'text-emphasis-style'>||<'text-emphasis-color'>",
                "text-emphasis-color": "<color>",
                "text-emphasis-position": "auto|[over|under]&&[right|left]?",
                "text-emphasis-style": "none|[[filled|open]||[dot|circle|double-circle|triangle|sesame]]|<string>",
                "text-indent": "<length-percentage>&&hanging?&&each-line?",
                "text-justify": "auto|inter-character|inter-word|none",
                "text-orientation": "mixed|upright|sideways",
                "text-overflow": "[clip|ellipsis|<string>]{1,2}",
                "text-rendering": "auto|optimizeSpeed|optimizeLegibility|geometricPrecision",
                "text-shadow": "none|<shadow-t>#",
                "text-size-adjust": "none|auto|<percentage>",
                "text-spacing-trim": "space-all|normal|space-first|trim-start|trim-both|trim-all|auto",
                "text-transform": "none|capitalize|uppercase|lowercase|full-width|full-size-kana",
                "text-underline-offset": "auto|<length>|<percentage>",
                "text-underline-position": "auto|from-font|[under||[left|right]]",
                "text-wrap": "<'text-wrap-mode'>||<'text-wrap-style'>",
                "text-wrap-mode": "auto|wrap|nowrap",
                "text-wrap-style": "auto|balance|stable|pretty",
                "timeline-scope": "none|<dashed-ident>#",
                top: "<length>|<percentage>|auto",
                "touch-action": "auto|none|[[pan-x|pan-left|pan-right]||[pan-y|pan-up|pan-down]||pinch-zoom]|manipulation",
                transform: "none|<transform-list>",
                "transform-box": "content-box|border-box|fill-box|stroke-box|view-box",
                "transform-origin": "[<length-percentage>|left|center|right|top|bottom]|[[<length-percentage>|left|center|right]&&[<length-percentage>|top|center|bottom]] <length>?",
                "transform-style": "flat|preserve-3d",
                transition: "<single-transition>#",
                "transition-behavior": "<transition-behavior-value>#",
                "transition-delay": "<time>#",
                "transition-duration": "<time>#",
                "transition-property": "none|<single-transition-property>#",
                "transition-timing-function": "<easing-function>#",
                translate: "none|<length-percentage> [<length-percentage> <length>?]?",
                "unicode-bidi": "normal|embed|isolate|bidi-override|isolate-override|plaintext|-moz-isolate|-moz-isolate-override|-moz-plaintext|-webkit-isolate|-webkit-isolate-override|-webkit-plaintext",
                "user-select": "auto|text|none|contain|all",
                "vector-effect": "none|non-scaling-stroke|non-scaling-size|non-rotation|fixed-position",
                "vertical-align": "baseline|sub|super|text-top|text-bottom|middle|top|bottom|<percentage>|<length>",
                "view-timeline": "[<'view-timeline-name'> <'view-timeline-axis'>?]#",
                "view-timeline-axis": "[block|inline|x|y]#",
                "view-timeline-inset": "[[auto|<length-percentage>]{1,2}]#",
                "view-timeline-name": "none|<dashed-ident>#",
                "view-transition-name": "none|<custom-ident>",
                visibility: "visible|hidden|collapse",
                "white-space": "normal|pre|nowrap|pre-wrap|pre-line|break-spaces|[<'white-space-collapse'>||<'text-wrap'>||<'white-space-trim'>]",
                "white-space-collapse": "collapse|discard|preserve|preserve-breaks|preserve-spaces|break-spaces",
                widows: "<integer>",
                width: "auto|<length>|<percentage>|min-content|max-content|fit-content|fit-content( <length-percentage> )|stretch|<-non-standard-size>",
                "will-change": "auto|<animateable-feature>#",
                "word-break": "normal|break-all|keep-all|break-word|auto-phrase",
                "word-spacing": "normal|<length>",
                "word-wrap": "normal|break-word",
                "writing-mode": "horizontal-tb|vertical-rl|vertical-lr|sideways-rl|sideways-lr|<svg-writing-mode>",
                x: "<length>|<percentage>",
                y: "<length>|<percentage>",
                "z-index": "auto|<integer>",
                zoom: "normal|reset|<number>|<percentage>",
                "-moz-background-clip": "padding|border",
                "-moz-border-radius-bottomleft": "<'border-bottom-left-radius'>",
                "-moz-border-radius-bottomright": "<'border-bottom-right-radius'>",
                "-moz-border-radius-topleft": "<'border-top-left-radius'>",
                "-moz-border-radius-topright": "<'border-bottom-right-radius'>",
                "-moz-control-character-visibility": "visible|hidden",
                "-moz-osx-font-smoothing": "auto|grayscale",
                "-moz-user-select": "none|text|all|-moz-none",
                "-ms-flex-align": "start|end|center|baseline|stretch",
                "-ms-flex-item-align": "auto|start|end|center|baseline|stretch",
                "-ms-flex-line-pack": "start|end|center|justify|distribute|stretch",
                "-ms-flex-negative": "<'flex-shrink'>",
                "-ms-flex-pack": "start|end|center|justify|distribute",
                "-ms-flex-order": "<integer>",
                "-ms-flex-positive": "<'flex-grow'>",
                "-ms-flex-preferred-size": "<'flex-basis'>",
                "-ms-interpolation-mode": "nearest-neighbor|bicubic",
                "-ms-grid-column-align": "start|end|center|stretch",
                "-ms-grid-row-align": "start|end|center|stretch",
                "-ms-hyphenate-limit-last": "none|always|column|page|spread",
                "-webkit-background-clip": "[<box>|border|padding|content|text]#",
                "-webkit-column-break-after": "always|auto|avoid",
                "-webkit-column-break-before": "always|auto|avoid",
                "-webkit-column-break-inside": "always|auto|avoid",
                "-webkit-font-smoothing": "auto|none|antialiased|subpixel-antialiased",
                "-webkit-mask-box-image": "[<url>|<gradient>|none] [<length-percentage>{4} <-webkit-mask-box-repeat>{2}]?",
                "-webkit-print-color-adjust": "economy|exact",
                "-webkit-text-security": "none|circle|disc|square",
                "-webkit-user-drag": "none|element|auto",
                "-webkit-user-select": "auto|none|text|all",
                "alignment-baseline": "auto|baseline|before-edge|text-before-edge|middle|central|after-edge|text-after-edge|ideographic|alphabetic|hanging|mathematical",
                "baseline-shift": "baseline|sub|super|<svg-length>",
                behavior: "<url>+",
                cue: "<'cue-before'> <'cue-after'>?",
                "cue-after": "<url> <decibel>?|none",
                "cue-before": "<url> <decibel>?|none",
                "glyph-orientation-horizontal": "<angle>",
                "glyph-orientation-vertical": "<angle>",
                kerning: "auto|<svg-length>",
                pause: "<'pause-before'> <'pause-after'>?",
                "pause-after": "<time>|none|x-weak|weak|medium|strong|x-strong",
                "pause-before": "<time>|none|x-weak|weak|medium|strong|x-strong",
                rest: "<'rest-before'> <'rest-after'>?",
                "rest-after": "<time>|none|x-weak|weak|medium|strong|x-strong",
                "rest-before": "<time>|none|x-weak|weak|medium|strong|x-strong",
                src: "[<url> [format( <string># )]?|local( <family-name> )]#",
                speak: "auto|never|always",
                "speak-as": "normal|spell-out||digits||[literal-punctuation|no-punctuation]",
                "unicode-range": "<urange>#",
                "voice-balance": "<number>|left|center|right|leftwards|rightwards",
                "voice-duration": "auto|<time>",
                "voice-family": "[[<family-name>|<generic-voice>] ,]* [<family-name>|<generic-voice>]|preserve",
                "voice-pitch": "<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]",
                "voice-range": "<frequency>&&absolute|[[x-low|low|medium|high|x-high]||[<frequency>|<semitones>|<percentage>]]",
                "voice-rate": "[normal|x-slow|slow|medium|fast|x-fast]||<percentage>",
                "voice-stress": "normal|strong|moderate|none|reduced",
                "voice-volume": "silent|[[x-soft|soft|medium|loud|x-loud]||<decibel>]",
                "white-space-trim": "none|discard-before||discard-after||discard-inner"
            },
            atrules: {
                charset: {
                    prelude: "<string>",
                    descriptors: null
                },
                "counter-style": {
                    prelude: "<counter-style-name>",
                    descriptors: {
                        "additive-symbols": "[<integer>&&<symbol>]#",
                        fallback: "<counter-style-name>",
                        negative: "<symbol> <symbol>?",
                        pad: "<integer>&&<symbol>",
                        prefix: "<symbol>",
                        range: "[[<integer>|infinite]{2}]#|auto",
                        "speak-as": "auto|bullets|numbers|words|spell-out|<counter-style-name>",
                        suffix: "<symbol>",
                        symbols: "<symbol>+",
                        system: "cyclic|numeric|alphabetic|symbolic|additive|[fixed <integer>?]|[extends <counter-style-name>]"
                    }
                },
                document: {
                    prelude: "[<url>|url-prefix( <string> )|domain( <string> )|media-document( <string> )|regexp( <string> )]#",
                    descriptors: null
                },
                "font-palette-values": {
                    prelude: "<dashed-ident>",
                    descriptors: {
                        "base-palette": "light|dark|<integer [0,∞]>",
                        "font-family": "<family-name>#",
                        "override-colors": "[<integer [0,∞]> <absolute-color-base>]#"
                    }
                },
                "font-face": {
                    prelude: null,
                    descriptors: {
                        "ascent-override": "normal|<percentage>",
                        "descent-override": "normal|<percentage>",
                        "font-display": "[auto|block|swap|fallback|optional]",
                        "font-family": "<family-name>",
                        "font-feature-settings": "normal|<feature-tag-value>#",
                        "font-variation-settings": "normal|[<string> <number>]#",
                        "font-stretch": "<font-stretch-absolute>{1,2}",
                        "font-style": "normal|italic|oblique <angle>{0,2}",
                        "font-weight": "<font-weight-absolute>{1,2}",
                        "line-gap-override": "normal|<percentage>",
                        "size-adjust": "<percentage>",
                        src: "[<url> [format( <string># )]?|local( <family-name> )]#",
                        "unicode-range": "<urange>#"
                    }
                },
                "font-feature-values": {
                    prelude: "<family-name>#",
                    descriptors: null
                },
                import: {
                    prelude: "[<string>|<url>] [layer|layer( <layer-name> )]? [supports( [<supports-condition>|<declaration>] )]? <media-query-list>?",
                    descriptors: null
                },
                keyframes: {
                    prelude: "<keyframes-name>",
                    descriptors: null
                },
                layer: {
                    prelude: "[<layer-name>#|<layer-name>?]",
                    descriptors: null
                },
                media: {
                    prelude: "<media-query-list>",
                    descriptors: null
                },
                namespace: {
                    prelude: "<namespace-prefix>? [<string>|<url>]",
                    descriptors: null
                },
                page: {
                    prelude: "<page-selector-list>",
                    descriptors: {
                        bleed: "auto|<length>",
                        marks: "none|[crop||cross]",
                        "page-orientation": "upright|rotate-left|rotate-right",
                        size: "<length>{1,2}|auto|[<page-size>||[portrait|landscape]]"
                    }
                },
                "position-try": {
                    prelude: "<dashed-ident>",
                    descriptors: {
                        top: "<'top'>",
                        left: "<'left'>",
                        bottom: "<'bottom'>",
                        right: "<'right'>",
                        "inset-block-start": "<'inset-block-start'>",
                        "inset-block-end": "<'inset-block-end'>",
                        "inset-inline-start": "<'inset-inline-start'>",
                        "inset-inline-end": "<'inset-inline-end'>",
                        "inset-block": "<'inset-block'>",
                        "inset-inline": "<'inset-inline'>",
                        inset: "<'inset'>",
                        "margin-top": "<'margin-top'>",
                        "margin-left": "<'margin-left'>",
                        "margin-bottom": "<'margin-bottom'>",
                        "margin-right": "<'margin-right'>",
                        "margin-block-start": "<'margin-block-start'>",
                        "margin-block-end": "<'margin-block-end'>",
                        "margin-inline-start": "<'margin-inline-start'>",
                        "margin-inline-end": "<'margin-inline-end'>",
                        margin: "<'margin'>",
                        "margin-block": "<'margin-block'>",
                        "margin-inline": "<'margin-inline'>",
                        width: "<'width'>",
                        height: "<'height'>",
                        "min-width": "<'min-width'>",
                        "min-height": "<'min-height'>",
                        "max-width": "<'max-width'>",
                        "max-height": "<'max-height'>",
                        "block-size": "<'block-size'>",
                        "inline-size": "<'inline-size'>",
                        "min-block-size": "<'min-block-size'>",
                        "min-inline-size": "<'min-inline-size'>",
                        "max-block-size": "<'max-block-size'>",
                        "max-inline-size": "<'max-inline-size'>",
                        "align-self": "<'align-self'>|anchor-center",
                        "justify-self": "<'justify-self'>|anchor-center"
                    }
                },
                property: {
                    prelude: "<custom-property-name>",
                    descriptors: {
                        syntax: "<string>",
                        inherits: "true|false",
                        "initial-value": "<declaration-value>?"
                    }
                },
                scope: {
                    prelude: "[( <scope-start> )]? [to ( <scope-end> )]?",
                    descriptors: null
                },
                "starting-style": {
                    prelude: null,
                    descriptors: null
                },
                supports: {
                    prelude: "<supports-condition>",
                    descriptors: null
                },
                container: {
                    prelude: "[<container-name>]? <container-condition>",
                    descriptors: null
                },
                nest: {
                    prelude: "<complex-selector-list>",
                    descriptors: null
                }
            },
            node: gd
        };

    function yd(e) {
        switch (this.tokenType) {
            case 4:
                return this.Hash();
            case qa:
                return this.Operator();
            case $a:
                return this.Parentheses(this.readSequence, e.recognizer);
            case Wa:
                return this.Brackets(this.readSequence, e.recognizer);
            case 5:
                return this.String();
            case Da:
                return this.Dimension();
            case Pa:
                return this.Percentage();
            case Ra:
                return this.Number();
            case 2:
                return this.cmpStr(this.tokenStart, this.tokenEnd, "url(") ? this.Url() : this.Function(this.readSequence, e.recognizer);
            case 7:
                return this.Url();
            case 1:
                return this.cmpChar(this.tokenStart, 117) && this.cmpChar(this.tokenStart + 1, 43) ? this.UnicodeRange() : this.Identifier();
            case 9:
                {
                    const e = this.charCodeAt(this.tokenStart);
                    if (47 === e || 42 === e || 43 === e || 45 === e) return this.Operator();35 === e && this.error("Hex or identifier is expected", this.tokenStart + 1);
                    break
                }
        }
    }
    var kd = {
        getNode: yd
    };
    var vd = {
        onWhiteSpace: function(e, t) {
            null !== t.last && "Combinator" !== t.last.type && null !== e && "Combinator" !== e.type && t.push({
                type: "Combinator",
                loc: null,
                name: " "
            })
        },
        getNode: function() {
            switch (this.tokenType) {
                case Wa:
                    return this.AttributeSelector();
                case 4:
                    return this.IdSelector();
                case Fa:
                    return this.lookupType(1) === Fa ? this.PseudoElementSelector() : this.PseudoClassSelector();
                case 1:
                    return this.TypeSelector();
                case Ra:
                case Pa:
                    return this.Percentage();
                case Da:
                    46 === this.charCodeAt(this.tokenStart) && this.error("Identifier is expected", this.tokenStart + 1);
                    break;
                case 9:
                    switch (this.charCodeAt(this.tokenStart)) {
                        case 43:
                        case 62:
                        case 126:
                        case 47:
                            return this.Combinator();
                        case 46:
                            return this.ClassSelector();
                        case 42:
                        case 124:
                            return this.TypeSelector();
                        case 35:
                            return this.IdSelector();
                        case 38:
                            return this.NestingSelector()
                    }
                    break
            }
        }
    };

    function xd(e) {
        return null !== e && "Operator" === e.type && ("-" === e.value[e.value.length - 1] || "+" === e.value[e.value.length - 1])
    }
    var wd = {
            getNode: yd,
            onWhiteSpace(e, t) {
                xd(e) && (e.value = " " + e.value), xd(t.last) && (t.last.value += " ")
            },
            expression: function() {
                return this.createSingleNodeList(this.Raw(null, !1))
            },
            var: function() {
                const e = this.createList();
                if (this.skipSC(), e.push(this.Identifier()), this.skipSC(), this.tokenType === qa) {
                    e.push(this.Operator());
                    const t = this.tokenIndex,
                        n = this.parseCustomProperty ? this.Value(null) : this.Raw(this.consumeUntilExclamationMarkOrSemicolon, !1);
                    if ("Value" === n.type && n.children.isEmpty)
                        for (let e = t - this.tokenIndex; e <= 0; e++)
                            if (this.lookupType(e) === Na) {
                                n.children.appendData({
                                    type: "WhiteSpace",
                                    loc: null,
                                    value: " "
                                });
                                break
                            }
                    e.push(n)
                }
                return e
            }
        },
        Sd = Object.freeze({
            __proto__: null,
            AtrulePrelude: kd,
            Selector: vd,
            Value: wd
        });
    const Cd = new Set(["none", "and", "not", "or"]);
    var zd = {
            parse: {
                prelude() {
                    const e = this.createList();
                    if (1 === this.tokenType) {
                        const t = this.substring(this.tokenStart, this.tokenEnd);
                        Cd.has(t.toLowerCase()) || e.push(this.Identifier())
                    }
                    return e.push(this.Condition("container")), e
                },
                block(e = !1) {
                    return this.Block(e)
                }
            }
        },
        Ad = {
            parse: {
                prelude: null,
                block() {
                    return this.Block(!0)
                }
            }
        };

    function _d(e, t) {
        return this.parseWithFallback(() => {
            try {
                return e.call(this)
            } finally {
                this.skipSC(), this.lookupNonWSType(0) !== Ga && this.error()
            }
        }, t || (() => this.Raw(null, !0)))
    }
    const Od = {
        layer() {
            this.skipSC();
            const e = this.createList(),
                t = _d.call(this, this.Layer);
            return "Raw" === t.type && "" === t.value || e.push(t), e
        },
        supports() {
            this.skipSC();
            const e = this.createList(),
                t = _d.call(this, this.Declaration, () => _d.call(this, () => this.Condition("supports")));
            return "Raw" === t.type && "" === t.value || e.push(t), e
        }
    };
    var Td = {
        container: zd,
        "font-face": Ad,
        import: {
            parse: {
                prelude() {
                    const e = this.createList();
                    switch (this.tokenType) {
                        case 5:
                            e.push(this.String());
                            break;
                        case 7:
                        case 2:
                            e.push(this.Url());
                            break;
                        default:
                            this.error("String or url() is expected")
                    }
                    return this.skipSC(), 1 === this.tokenType && this.cmpStr(this.tokenStart, this.tokenEnd, "layer") ? e.push(this.Identifier()) : 2 === this.tokenType && this.cmpStr(this.tokenStart, this.tokenEnd, "layer(") && e.push(this.Function(null, Od)), this.skipSC(), 2 === this.tokenType && this.cmpStr(this.tokenStart, this.tokenEnd, "supports(") && e.push(this.Function(null, Od)), 1 !== this.lookupNonWSType(0) && this.lookupNonWSType(0) !== $a || e.push(this.MediaQueryList()), e
                },
                block: null
            }
        },
        layer: {
            parse: {
                prelude() {
                    return this.createSingleNodeList(this.LayerList())
                },
                block() {
                    return this.Block(!1)
                }
            }
        },
        media: {
            parse: {
                prelude() {
                    return this.createSingleNodeList(this.MediaQueryList())
                },
                block(e = !1) {
                    return this.Block(e)
                }
            }
        },
        nest: {
            parse: {
                prelude() {
                    return this.createSingleNodeList(this.SelectorList())
                },
                block() {
                    return this.Block(!0)
                }
            }
        },
        page: {
            parse: {
                prelude() {
                    return this.createSingleNodeList(this.SelectorList())
                },
                block() {
                    return this.Block(!0)
                }
            }
        },
        scope: {
            parse: {
                prelude() {
                    return this.createSingleNodeList(this.Scope())
                },
                block(e = !1) {
                    return this.Block(e)
                }
            }
        },
        "starting-style": {
            parse: {
                prelude: null,
                block(e = !1) {
                    return this.Block(e)
                }
            }
        },
        supports: {
            parse: {
                prelude() {
                    return this.createSingleNodeList(this.Condition("supports"))
                },
                block(e = !1) {
                    return this.Block(e)
                }
            }
        }
    };
    const Ld = {
            parse() {
                return this.createSingleNodeList(this.SelectorList())
            }
        },
        Ed = {
            parse() {
                return this.createSingleNodeList(this.Selector())
            }
        },
        jd = {
            parse() {
                return this.createSingleNodeList(this.Identifier())
            }
        },
        Id = {
            parse: function() {
                const e = this.createList();
                this.skipSC();
                e: for (; !this.eof;) {
                    switch (this.tokenType) {
                        case 1:
                            e.push(this.Identifier());
                            break;
                        case 5:
                            e.push(this.String());
                            break;
                        case qa:
                            e.push(this.Operator());
                            break;
                        case Ga:
                            break e;
                        default:
                            this.error("Identifier, string or comma is expected")
                    }
                    this.skipSC()
                }
                return e
            }
        },
        Rd = {
            parse() {
                return this.createSingleNodeList(this.Nth())
            }
        };
    var Pd = {
            dir: jd,
            has: Ld,
            lang: Id,
            matches: Ld,
            is: Ld,
            "-moz-any": Ld,
            "-webkit-any": Ld,
            where: Ld,
            not: Ld,
            "nth-child": Rd,
            "nth-last-child": Rd,
            "nth-last-of-type": Rd,
            "nth-of-type": Rd,
            slotted: Ed,
            host: Ed,
            "host-context": Ed
        },
        Dd = Object.freeze({
            __proto__: null,
            AnPlusB: ku,
            Atrule: Cu,
            AtrulePrelude: Au,
            AttributeSelector: Eu,
            Block: Nu,
            Brackets: Fu,
            CDC: qu,
            CDO: Uu,
            ClassSelector: Vu,
            Combinator: Qu,
            Comment: Zu,
            Condition: oh,
            Declaration: uh,
            DeclarationList: mh,
            Dimension: yh,
            Feature: xh,
            FeatureFunction: zh,
            FeatureRange: Lh,
            Function: Ih,
            GeneralEnclosed: Dh,
            Hash: Fh,
            IdSelector: Gh,
            Identifier: Wh,
            Layer: Kh,
            LayerList: Yh,
            MediaQuery: Jh,
            MediaQueryList: tp,
            NestingSelector: rp,
            Nth: ip,
            Number: lp,
            Operator: hp,
            Parentheses: dp,
            Percentage: gp,
            PseudoClassSelector: kp,
            PseudoElementSelector: wp,
            Ratio: zp,
            Raw: Tp,
            Rule: Ip,
            Scope: Pp,
            Selector: Np,
            SelectorList: Fp,
            String: Up,
            StyleSheet: Vp,
            SupportsDeclaration: Kp,
            TypeSelector: Zp,
            UnicodeRange: id,
            Url: ld,
            Value: ud,
            WhiteSpace: fd
        }),
        Nd = cu(lu({}, { ...bd,
            ...{
                parseContext: {
                    default: "StyleSheet",
                    stylesheet: "StyleSheet",
                    atrule: "Atrule",
                    atrulePrelude(e) {
                        return this.AtrulePrelude(e.atrule ? String(e.atrule) : null)
                    },
                    mediaQueryList: "MediaQueryList",
                    mediaQuery: "MediaQuery",
                    condition(e) {
                        return this.Condition(e.kind)
                    },
                    rule: "Rule",
                    selectorList: "SelectorList",
                    selector: "Selector",
                    block() {
                        return this.Block(!0)
                    },
                    declarationList: "DeclarationList",
                    declaration: "Declaration",
                    value: "Value"
                },
                features: {
                    supports: {
                        selector() {
                            return this.Selector()
                        }
                    },
                    container: {
                        style() {
                            return this.Declaration()
                        }
                    }
                },
                scope: Sd,
                atrule: Td,
                pseudo: Pd,
                node: Dd
            },
            ...{
                node: gd
            }
        }));
    const {
        tokenize: Md,
        parse: Fd,
        generate: Bd,
        lexer: qd,
        createLexer: Wd,
        walk: Ud,
        find: $d,
        findLast: Gd,
        findAll: Vd,
        toPlainObject: Hd,
        fromPlainObject: Kd,
        fork: Qd
    } = Nd;

    function Yd(e, t) {
        return t.slice(e.loc.start.offset, e.loc.end.offset)
    }
    class Xd {
        run(e) {
            const t = [];
            for (const n of e) t.push(...n.children);
            return t
        }
        toString() {
            return "ChildComb"
        }
    }
    class Zd {
        run(e) {
            const t = new Set;
            for (const n of e) {
                const e = n.querySelectorAll("*");
                for (const n of e) t.add(n)
            }
            return Array.from(t)
        }
        toString() {
            return "DescComb"
        }
    }
    class Jd {
        run(e) {
            const t = [];
            for (const n of e) {
                const e = n.nextElementSibling;
                e && t.push(e)
            }
            return t
        }
        toString() {
            return "NextSiblComb"
        }
    }
    class ef {
        run(e) {
            const t = new Set;
            for (const n of e) {
                let e = n.nextElementSibling;
                for (; e;) t.add(e), e = e.nextElementSibling
            }
            return Array.from(t)
        }
        toString() {
            return "SubsSiblComb"
        }
    }
    var tf, nf = {};
    ! function() {
        if (tf) return nf;
        tf = 1;
        var e = lr(),
            t = y(),
            n = we(),
            r = yt(),
            o = To(),
            i = Ro(),
            a = Po(),
            s = Ye(),
            l = jo(),
            c = Do(),
            u = No(),
            h = !s && !c("filter", function() {}),
            p = !s && !h && u("filter", TypeError),
            d = s || h || p,
            f = i(function() {
                for (var e, n, o = this.iterator, i = this.predicate, s = this.next;;) {
                    if (e = r(t(s, o)), this.done = !!e.done) return;
                    if (n = e.value, a(o, i, [n, this.counter++], !0)) return n
                }
            });
        e({
            target: "Iterator",
            proto: !0,
            real: !0,
            forced: d
        }, {
            filter: function(e) {
                r(this);
                try {
                    n(e)
                } catch (e) {
                    l(this, "throw", e)
                }
                return p ? t(p, this, e) : new f(o(this), {
                    predicate: e
                })
            }
        })
    }();
    var rf, of , af, sf, lf, cf, uf, hf, pf, df = {};

    function ff() {
        if (cf) return lf;
        cf = 1;
        var e = y(),
            t = tt(),
            n = ge(),
            r = function() {
                if (sf) return af;
                sf = 1;
                var e = i(),
                    t = m(),
                    n = e.RegExp,
                    r = !t(function() {
                        var e = !0;
                        try {
                            n(".", "d")
                        } catch (t) {
                            e = !1
                        }
                        var t = {},
                            r = "",
                            o = e ? "dgimsy" : "gimsy",
                            i = function(e, n) {
                                Object.defineProperty(t, e, {
                                    get: function() {
                                        return r += n, !0
                                    }
                                })
                            },
                            a = {
                                dotAll: "s",
                                global: "g",
                                ignoreCase: "i",
                                multiline: "m",
                                sticky: "y"
                            };
                        for (var s in e && (a.hasIndices = "d"), a) i(s, a[s]);
                        return Object.getOwnPropertyDescriptor(n.prototype, "flags").get.call(t) !== o || r !== o
                    });
                return af = {
                    correct: r
                }
            }(),
            o = Yo(),
            a = RegExp.prototype;
        return lf = r.correct ? function(e) {
            return e.flags
        } : function(i) {
            return r.correct || !n(a, i) || t(i, "flags") ? i.flags : e(o, i)
        }
    }

    function mf() {
        if (hf) return uf;
        hf = 1;
        var e = me(),
            t = Gr(),
            n = rt(),
            r = g(),
            o = n("species");
        return uf = function(n) {
            var i = e(n);
            r && i && !i[o] && t(i, o, {
                configurable: !0,
                get: function() {
                    return this
                }
            })
        }
    }! function() {
        if (pf) return df;
        pf = 1;
        var e = g(),
            t = i(),
            n = le(),
            r = sr(),
            o = mr(),
            a = vt(),
            s = ao(),
            l = mn().f,
            c = ge(),
            u = function() {
                if ( of ) return rf; of = 1;
                var e = fe(),
                    t = ce(),
                    n = rt()("match");
                return rf = function(r) {
                    var o;
                    return e(r) && (void 0 !== (o = r[n]) ? !!o : "RegExp" === t(r))
                }
            }(),
            h = br(),
            p = ff(),
            d = Xo(),
            f = fr(),
            b = Ut(),
            y = m(),
            k = tt(),
            v = qt().enforce,
            x = mf(),
            w = rt(),
            S = Zo(),
            C = Jo(),
            z = w("match"),
            A = t.RegExp,
            _ = A.prototype,
            O = t.SyntaxError,
            T = n(_.exec),
            L = n("".charAt),
            E = n("".replace),
            j = n("".indexOf),
            I = n("".slice),
            R = /^\?<[^\s\d!#%&*+<=>@^][^\s!#%&*+<=>@^]*>/,
            P = /a/g,
            D = /a/g,
            N = new A(P) !== P,
            M = d.MISSED_STICKY,
            F = d.UNSUPPORTED_Y,
            B = e && (!N || M || S || C || y(function() {
                return D[z] = !1, A(P) !== P || A(D) === D || "/a/i" !== String(A(P, "i"))
            }));
        if (r("RegExp", B)) {
            for (var q = function(e, t) {
                    var n, r, i, l, d, f, m = c(_, this),
                        g = u(e),
                        b = void 0 === t,
                        y = [],
                        x = e;
                    if (!m && g && b && e.constructor === q) return e;
                    if ((g || c(_, e)) && (e = e.source, b && (t = p(x))), e = void 0 === e ? "" : h(e), t = void 0 === t ? "" : h(t), x = e, S && "dotAll" in P && (r = !!t && j(t, "s") > -1) && (t = E(t, /s/g, "")), n = t, M && "sticky" in P && (i = !!t && j(t, "y") > -1) && F && (t = E(t, /y/g, "")), C && (l = function(e) {
                            for (var t, n = e.length, r = 0, o = "", i = [], a = s(null), l = !1, c = !1, u = 0, h = ""; r <= n; r++) {
                                if ("\\" === (t = L(e, r))) t += L(e, ++r);
                                else if ("]" === t) l = !1;
                                else if (!l) switch (!0) {
                                    case "[" === t:
                                        l = !0;
                                        break;
                                    case "(" === t:
                                        if (o += t, "?:" === I(e, r + 1, r + 3)) continue;
                                        T(R, I(e, r + 1)) && (r += 2, c = !0), u++;
                                        continue;
                                    case ">" === t && c:
                                        if ("" === h || k(a, h)) throw new O("Invalid capture group name");
                                        a[h] = !0, i[i.length] = [h, u], c = !1, h = "";
                                        continue
                                }
                                c ? h += t : o += t
                            }
                            return [o, i]
                        }(e), e = l[0], y = l[1]), d = o(A(e, t), m ? this : _, q), (r || i || y.length) && (f = v(d), r && (f.dotAll = !0, f.raw = q(function(e) {
                            for (var t, n = e.length, r = 0, o = "", i = !1; r <= n; r++) "\\" !== (t = L(e, r)) ? i || "." !== t ? ("[" === t ? i = !0 : "]" === t && (i = !1), o += t) : o += "[\\s\\S]" : o += t + L(e, ++r);
                            return o
                        }(e), n)), i && (f.sticky = !0), y.length && (f.groups = y)), e !== x) try {
                        a(d, "source", "" === x ? "(?:)" : x)
                    } catch (e) {}
                    return d
                }, W = l(A), U = 0; W.length > U;) f(q, A, W[U++]);
            _.constructor = q, q.prototype = _, b(t, "RegExp", q, {
                constructor: !0
            })
        }
        x("RegExp")
    }();
    var gf, bf = {};
    ! function() {
        if (gf) return bf;
        gf = 1;
        var e = g(),
            t = Zo(),
            n = ce(),
            r = Gr(),
            o = qt().get,
            i = RegExp.prototype,
            a = TypeError;
        e && t && r(i, "dotAll", {
            configurable: !0,
            get: function() {
                if (this !== i) {
                    if ("RegExp" === n(this)) return !!o(this).dotAll;
                    throw new a("Incompatible receiver, RegExp required")
                }
            }
        })
    }();
    var yf, kf, vf, xf, wf, Sf, Cf, zf, Af, _f, Of, Tf = {};

    function Lf() {
        if (Sf) return wf;
        Sf = 1;
        var e = function() {
            if (xf) return vf;
            xf = 1;
            var e = le(),
                t = cn(),
                n = br(),
                r = he(),
                o = e("".charAt),
                i = e("".charCodeAt),
                a = e("".slice),
                s = function(e) {
                    return function(s, l) {
                        var c, u, h = n(r(s)),
                            p = t(l),
                            d = h.length;
                        return p < 0 || p >= d ? e ? "" : void 0 : (c = i(h, p)) < 55296 || c > 56319 || p + 1 === d || (u = i(h, p + 1)) < 56320 || u > 57343 ? e ? o(h, p) : c : e ? a(h, p, p + 2) : u - 56320 + (c - 55296 << 10) + 65536
                    }
                };
            return vf = {
                codeAt: s(!1),
                charAt: s(!0)
            }
        }().charAt;
        return wf = function(t, n, r) {
            return n + (r ? e(t, n).length : 1)
        }, wf
    }

    function Ef() {
        if (zf) return Cf;
        zf = 1;
        var e = le(),
            t = et(),
            n = Math.floor,
            r = e("".charAt),
            o = e("".replace),
            i = e("".slice),
            a = /\$([$&'`]|\d{1,2}|<[^>]*>)/g,
            s = /\$([$&'`]|\d{1,2})/g;
        return Cf = function(e, l, c, u, h, p) {
            var d = c + e.length,
                f = u.length,
                m = s;
            return void 0 !== h && (h = t(h), m = a), o(p, m, function(t, o) {
                var a;
                switch (r(o, 0)) {
                    case "$":
                        return "$";
                    case "&":
                        return e;
                    case "`":
                        return i(l, 0, c);
                    case "'":
                        return i(l, d);
                    case "<":
                        a = h[i(o, 1, -1)];
                        break;
                    default:
                        var s = +o;
                        if (0 === s) return t;
                        if (s > f) {
                            var p = n(s / 10);
                            return 0 === p ? t : p <= f ? void 0 === u[p - 1] ? r(o, 1) : u[p - 1] + r(o, 1) : t
                        }
                        a = u[s - 1]
                }
                return void 0 === a ? "" : a
            })
        }
    }! function() {
        if (Of) return Tf;
        Of = 1;
        var e = cr(),
            t = y(),
            n = le(),
            r = function() {
                if (kf) return yf;
                kf = 1, ti();
                var e = y(),
                    t = Ut(),
                    n = ei(),
                    r = m(),
                    o = rt(),
                    i = vt(),
                    a = o("species"),
                    s = RegExp.prototype;
                return yf = function(l, c, u, h) {
                    var p = o(l),
                        d = !r(function() {
                            var e = {};
                            return e[p] = function() {
                                return 7
                            }, 7 !== "" [l](e)
                        }),
                        f = d && !r(function() {
                            var e = !1,
                                t = /a/;
                            if ("split" === l) {
                                var n = {};
                                n[a] = function() {
                                    return t
                                }, (t = {
                                    constructor: n,
                                    flags: ""
                                })[p] = /./ [p]
                            }
                            return t.exec = function() {
                                return e = !0, null
                            }, t[p](""), !e
                        });
                    if (!d || !f || u) {
                        var m = /./ [p],
                            g = c(p, "" [l], function(t, r, o, i, a) {
                                var l = r.exec;
                                return l === n || l === s.exec ? d && !a ? {
                                    done: !0,
                                    value: e(m, r, o, i)
                                } : {
                                    done: !0,
                                    value: e(t, o, r, i)
                                } : {
                                    done: !1
                                }
                            });
                        t(String.prototype, l, g[0]), t(s, p, g[1])
                    }
                    h && i(s[p], "sham", !0)
                }
            }(),
            o = m(),
            i = yt(),
            a = de(),
            s = fe(),
            l = cn(),
            c = hn(),
            u = br(),
            h = he(),
            p = Lf(),
            d = Se(),
            f = Ef(),
            g = ff(),
            b = function() {
                if (_f) return Af;
                _f = 1;
                var e = y(),
                    t = yt(),
                    n = de(),
                    r = ce(),
                    o = ei(),
                    i = TypeError;
                return Af = function(a, s) {
                    var l = a.exec;
                    if (n(l)) {
                        var c = e(l, a, s);
                        return null !== c && t(c), c
                    }
                    if ("RegExp" === r(a)) return e(o, a, s);
                    throw new i("RegExp#exec called on incompatible receiver")
                }, Af
            }(),
            k = rt()("replace"),
            v = Math.max,
            x = Math.min,
            w = n([].concat),
            S = n([].push),
            C = n("".indexOf),
            z = n("".slice),
            A = function(e) {
                return void 0 === e ? e : String(e)
            },
            _ = "$0" === "a".replace(/./, "$0"),
            O = !!/./ [k] && "" === /./ [k]("a", "$0");
        r("replace", function(n, r, o) {
            var m = O ? "$" : "$0";
            return [function(e, n) {
                var o = h(this),
                    i = s(e) ? d(e, k) : void 0;
                return i ? t(i, e, o, n) : t(r, u(o), e, n)
            }, function(t, n) {
                var s = i(this),
                    h = u(t);
                if ("string" == typeof n && -1 === C(n, m) && -1 === C(n, "$<")) {
                    var d = o(r, s, h, n);
                    if (d.done) return d.value
                }
                var y = a(n);
                y || (n = u(n));
                var k, _ = u(g(s)),
                    O = -1 !== C(_, "g");
                O && (k = -1 !== C(_, "u"), s.lastIndex = 0);
                for (var T, L = []; null !== (T = b(s, h)) && (S(L, T), O);) {
                    "" === u(T[0]) && (s.lastIndex = p(h, c(s.lastIndex), k))
                }
                for (var E = "", j = 0, I = 0; I < L.length; I++) {
                    for (var R, P = u((T = L[I])[0]), D = v(x(l(T.index), h.length), 0), N = [], M = 1; M < T.length; M++) S(N, A(T[M]));
                    var F = T.groups;
                    if (y) {
                        var B = w([P], N, D, h);
                        void 0 !== F && S(B, F), R = u(e(n, void 0, B))
                    } else R = f(P, h, D, N, F, n);
                    D >= j && (E += z(h, j, D) + R, j = D + P.length)
                }
                return E + z(h, j)
            }]
        }, !!o(function() {
            var e = /./;
            return e.exec = function() {
                var e = [];
                return e.groups = {
                    a: "7"
                }, e
            }, "7" !== "".replace(e, "$<a>")
        }) || !_ || O)
    }();
    const jf = /^\/((?:[^/\\\r\n]|\\.)+)\/([gimsuy]*)$/;

    function If(e) {
        const t = e.match(jf);
        if (null === t) return null;
        try {
            return new RegExp(t[1], t[2])
        } catch (e) {
            return null
        }
    }

    function Rf(e) {
        try {
            const t = function(e) {
                return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
            }(e).replace(/\\\*/g, ".*");
            return new RegExp(t)
        } catch (e) {
            return null
        }
    }
    class Pf {
        constructor(t) {
            e(this, "textRe", void 0), e(this, "textSearch", void 0);
            const n = If(t);
            null === n ? this.textSearch = t : this.textRe = n
        }
        run(e) {
            return this.textRe ? e.filter(e => null !== e.textContent && this.textRe.test(e.textContent)) : this.textSearch ? e.filter(e => null !== e.textContent && e.textContent.includes(this.textSearch)) : []
        }
        toString() {
            return ":Contains(".concat((this.textRe || this.textSearch).toString(), ")")
        }
    }
    e(Pf, "requiresContext", !0);
    var Df, Nf, Mf, Ff, Bf, qf, Wf, Uf, $f, Gf, Vf, Hf, Kf, Qf = {};

    function Yf() {
        if (Ff) return Mf;
        Ff = 1;
        var e = function() {
                if (Nf) return Df;
                Nf = 1;
                var e = ce(),
                    t = le();
                return Df = function(n) {
                    if ("Function" === e(n)) return t(n)
                }
            }(),
            t = we(),
            n = b(),
            r = e(e.bind);
        return Mf = function(e, o) {
            return t(e), void 0 === o ? e : n ? r(e, o) : function() {
                return e.apply(o, arguments)
            }
        }, Mf
    }

    function Xf() {
        if (qf) return Bf;
        qf = 1;
        var e = rt(),
            t = Ea(),
            n = e("iterator"),
            r = Array.prototype;
        return Bf = function(e) {
            return void 0 !== e && (t.Array === e || r[n] === e)
        }
    }

    function Zf() {
        if (Uf) return Wf;
        Uf = 1;
        var e = gr(),
            t = Se(),
            n = ue(),
            r = Ea(),
            o = rt()("iterator");
        return Wf = function(i) {
            if (!n(i)) return t(i, o) || t(i, "@@iterator") || r[e(i)]
        }
    }

    function Jf() {
        if (Gf) return $f;
        Gf = 1;
        var e = y(),
            t = we(),
            n = yt(),
            r = xe(),
            o = Zf(),
            i = TypeError;
        return $f = function(a, s) {
            var l = arguments.length < 2 ? o(a) : s;
            if (t(l)) return n(e(l, a));
            throw new i(r(a) + " is not iterable")
        }, $f
    }

    function em() {
        if (Hf) return Vf;
        Hf = 1;
        var e = Yf(),
            t = y(),
            n = yt(),
            r = xe(),
            o = Xf(),
            i = pn(),
            a = ge(),
            s = Jf(),
            l = Zf(),
            c = jo(),
            u = TypeError,
            h = function(e, t) {
                this.stopped = e, this.result = t
            },
            p = h.prototype;
        return Vf = function(d, f, m) {
            var g, b, y, k, v, x, w, S = m && m.that,
                C = !(!m || !m.AS_ENTRIES),
                z = !(!m || !m.IS_RECORD),
                A = !(!m || !m.IS_ITERATOR),
                _ = !(!m || !m.INTERRUPTED),
                O = e(f, S),
                T = function(e) {
                    return g && c(g, "normal"), new h(!0, e)
                },
                L = function(e) {
                    return C ? (n(e), _ ? O(e[0], e[1], T) : O(e[0], e[1])) : _ ? O(e, T) : O(e)
                };
            if (z) g = d.iterator;
            else if (A) g = d;
            else {
                if (!(b = l(d))) throw new u(r(d) + " is not iterable");
                if (o(b)) {
                    for (y = 0, k = i(d); k > y; y++)
                        if ((v = L(d[y])) && a(p, v)) return v;
                    return new h(!1)
                }
                g = s(d, b)
            }
            for (x = z ? d.next : g.next; !(w = t(x, g)).done;) {
                try {
                    v = L(w.value)
                } catch (e) {
                    c(g, "throw", e)
                }
                if ("object" == typeof v && v && a(p, v)) return v
            }
            return new h(!1)
        }, Vf
    }! function() {
        if (Kf) return Qf;
        Kf = 1;
        var e = lr(),
            t = y(),
            n = em(),
            r = we(),
            o = yt(),
            i = To(),
            a = jo(),
            s = No()("forEach", TypeError);
        e({
            target: "Iterator",
            proto: !0,
            real: !0,
            forced: s
        }, {
            forEach: function(e) {
                o(this);
                try {
                    r(e)
                } catch (e) {
                    a(this, "throw", e)
                }
                if (s) return t(s, this, e);
                var l = i(this),
                    c = 0;
                n(l, function(t) {
                    e(t, c++)
                }, {
                    IS_RECORD: !0
                })
            }
        })
    }();
    class tm {
        constructor(t) {
            e(this, "query", void 0), this.query = t
        }
        match(e) {
            let t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
            const n = new Set,
                r = Array.isArray(e) ? e : [e];
            for (const e of this.query) try {
                let t = r;
                for (const n of e)
                    if (t = n.run(t), 0 === t.length) break;
                t.forEach(e => n.add(e))
            } catch (e) {
                if (null == t || !t.forgiving) throw e
            }
            return Array.from(n)
        }
    }
    class nm {
        constructor(t) {
            e(this, "executor", void 0), this.executor = new tm(ym(t))
        }
        run(e) {
            return e.filter(e => this.executor.match(e).length > 0)
        }
        toString() {
            return ":Has(...)"
        }
    }
    e(nm, "requiresContext", !0);
    class rm {
        constructor(t) {
            e(this, "executor", void 0), this.executor = new tm(ym(t))
        }
        run(e) {
            const t = new Set,
                n = this.executor.match(document.documentElement, {
                    forgiving: !0
                });
            for (const e of n) t.add(e);
            return e.filter(e => t.has(e))
        }
        toString() {
            return ":Is(...)"
        }
    }
    e(rm, "requiresContext", !0);
    class om {
        constructor(t) {
            if (e(this, "name", void 0), e(this, "value", void 0), 0 === t.length) throw new Error("Invalid syntax");
            const n = this.parseArg(t);
            this.name = n.name, this.value = n.value
        }
        run(e) {
            return e.filter(e => this.matchesElement(e))
        }
        toString() {
            let e = "";
            return e += this.name.toString(), this.value && (e += "=" + this.value.toString()), ":MatchesAttr(".concat(e, ")")
        }
        parseArg(e) {
            const t = e.split("=");
            return 1 === t.length ? {
                name: this.parseMatcher(t[0])
            } : {
                name: this.parseMatcher(t[0]),
                value: this.parseMatcher(t[1])
            }
        }
        parseMatcher(e) {
            let t = e;
            if (t.length > 2) {
                const e = t[0];
                e !== t[t.length - 1] || '"' !== e && "'" !== e || (t = t.slice(1, -1))
            }
            const n = If(t);
            if (null !== n) return n;
            if (t.includes("*")) {
                const e = Rf(t);
                if (null !== e) return e
            }
            return t
        }
        matchesElement(e) {
            for (const t of e.attributes)
                if (this.matches(this.name, t.name) && (void 0 === this.value || this.matches(this.value, t.value))) return !0;
            return !1
        }
        matches(e, t) {
            return "string" == typeof e ? e === t : e.test(t)
        }
    }
    e(om, "requiresContext", !0);
    class im {
        constructor(t) {
            e(this, "pseudoElement", void 0), e(this, "property", void 0), e(this, "valueRe", void 0), e(this, "valueSearch", void 0);
            const {
                value: n,
                pseudoElement: r,
                property: o
            } = this.parseArgs(t);
            this.pseudoElement = r, this.property = o;
            const i = If(n);
            if (null === i) {
                if (n.includes("*")) {
                    const e = Rf(n);
                    if (null !== e) return void(this.valueRe = e)
                }
                this.valueSearch = n
            } else this.valueRe = i
        }
        parseArgs(e) {
            const t = e.split(",").map(e => e.trim());
            let n, r;
            2 === t.length ? (n = t[0], r = t[1]) : r = t[0];
            const o = r.indexOf(":");
            if (-1 === o) throw new Error("Invalid matches-css syntax: missing colon separator");
            const i = r.substring(0, o).trim(),
                a = r.substring(o + 1).trim();
            if (!i || !a) throw new Error("Invalid matches-css syntax: empty property or value");
            return {
                pseudoElement: n,
                property: i,
                value: a
            }
        }
        run(e) {
            return e.filter(e => this.matchesElement(e))
        }
        matchesElement(e) {
            try {
                const t = window.getComputedStyle(e, this.pseudoElement).getPropertyValue(this.property);
                return this.valueRe ? this.valueRe.test(t) : !!this.valueSearch && t === this.valueSearch
            } catch (e) {
                return !1
            }
        }
        toString() {
            let e = "";
            return this.pseudoElement && (e = this.pseudoElement + ", "), e += this.property + ": ", this.valueRe ? e += this.valueRe.toString() : this.valueSearch && (e += this.valueSearch.toString()), ":MatchesCSS(".concat(e, ")")
        }
    }
    e(im, "requiresContext", !0);
    class am {
        constructor(t) {
            e(this, "pathRe", void 0), e(this, "pathSearch", void 0);
            const n = If(t);
            null === n ? this.pathSearch = t : this.pathRe = n
        }
        run(e) {
            const t = window.location.pathname;
            return this.pathRe ? this.pathRe.test(t) ? e : [] : this.pathSearch && t.includes(this.pathSearch) ? e : []
        }
        toString() {
            return ":MatchesPath(".concat((this.pathRe || this.pathSearch).toString(), ")")
        }
    }
    e(am, "requiresContext", !1);
    class sm {
        constructor(t) {
            e(this, "n", void 0);
            const n = Number.parseInt(t, 10);
            if (Number.isNaN(n)) throw new Error("Invalid text length");
            if (n < 1) throw new Error("Text length cannot be less than 1");
            this.n = n
        }
        run(e) {
            return e.filter(e => null !== e.textContent && e.textContent.length >= this.n)
        }
        toString() {
            return ":MinTextLength(".concat(this.n, ")")
        }
    }
    e(sm, "requiresContext", !0);
    class lm {
        constructor(t) {
            e(this, "executor", void 0), this.executor = new tm(ym(t))
        }
        run(e) {
            const t = new Set,
                n = this.executor.match(document.documentElement);
            for (const e of n) t.add(e);
            const r = [];
            for (const n of e) t.has(n) || r.push(n);
            return r
        }
        toString() {
            return ":Not(...)"
        }
    }
    e(lm, "requiresContext", !0);
    class cm {
        constructor(t) {
            e(this, "distance", void 0), e(this, "selector", void 0);
            const n = Number.parseInt(t);
            if (Number.isNaN(n)) this.selector = t;
            else {
                if (n < 1 || n >= 256) throw new Error("Invalid distance value");
                this.distance = n
            }
        }
        run(e) {
            return this.distance ? this.matchDistance(e) : this.selector ? this.matchSelector(e) : []
        }
        matchDistance(e) {
            const t = [];
            for (const n of e) {
                let e = n;
                for (let t = 0; t < this.distance && (e = e.parentElement, null !== e); t++);
                null !== e && t.push(e)
            }
            return t
        }
        matchSelector(e) {
            const t = [];
            for (const n of e) {
                let e = n.parentElement;
                for (; null !== e;) {
                    if (e.matches(this.selector)) {
                        t.push(e);
                        break
                    }
                    e = e.parentElement
                }
            }
            return t
        }
        toString() {
            return ":Upward(".concat((this.distance || this.selector).toString(), ")")
        }
    }
    e(cm, "requiresContext", !0);
    const um = {
        "-abp-contains": Pf,
        "has-text": Pf,
        contains: Pf,
        "-abp-has": nm,
        has: nm,
        "matches-css": im,
        "matches-path": am,
        "matches-attr": om,
        "min-text-length": sm,
        upward: cm,
        is: rm,
        not: lm
    };
    class hm {
        constructor(t) {
            e(this, "query", void 0), this.query = t
        }
        run(e) {
            const t = [];
            for (const n of e) {
                const e = n.querySelectorAll(this.query);
                for (const n of e) t.push(n)
            }
            return t
        }
        toString() {
            return "RawQuery(".concat(this.query, ")")
        }
    }
    class pm {
        constructor(t) {
            e(this, "query", void 0), this.query = t
        }
        run(e) {
            return "*" === this.query ? e : e.filter(e => e.matches(this.query))
        }
        toString() {
            return "RawMatches(".concat(this.query, ")")
        }
    }

    function dm(e) {
        if (0 === e.length) return [];
        const t = [];
        let n = !1;
        const r = e => {
                switch (e.literal) {
                    case " ":
                        t.push(new Zd);
                        break;
                    case "+":
                        t.push(new Jd);
                        break;
                    case "~":
                        t.push(new ef);
                        break;
                    case ">":
                        t.push(new Xd);
                        break;
                    default:
                        throw new Error('Unknown combinator: "'.concat(e.literal, '"'))
                }
                n = !0
            },
            o = (e, r) => {
                const o = um[e];
                if (!o) throw new Error('Unknown extended pseudo-class ":'.concat(e, '"'));
                o.requiresContext && !n && (t.push(new hm("*")), n = !0), t.push(new o(r)), n = !0
            };
        if ("comb" === e[0].kind) {
            for (let i = 0; i < e.length; i++) {
                const a = e[i];
                switch (a.kind) {
                    case "comb":
                        {
                            const t = e[i + 1];
                            if (!t) throw new Error("Relative selector ends with a dangling combinator");
                            if ("comb" === t.kind) throw new Error("Multiple subsequent combinator tokens in relative selector");r(a);
                            break
                        }
                    case "raw":
                        t.push(new pm(a.literal)), n = !0;
                        break;
                    case "ext":
                        o(a.name, a.args)
                }
            }
            return t
        }
        let i = "";
        const a = () => {
            const e = i.trim();
            e && (t.push(new hm(e)), n = !0), i = ""
        };
        for (let n = 0; n < e.length; n++) {
            const s = e[n];
            switch (s.kind) {
                case "raw":
                    {
                        const e = t[t.length - 1];e instanceof Xd || e instanceof Zd || e instanceof Jd || e instanceof ef ? t.push(new pm(s.literal)) : i += s.literal;
                        break
                    }
                case "comb":
                    {
                        const t = e[n + 1];
                        if (!t) throw new Error("Last token is a dangling combinator");
                        if ("comb" === t.kind) throw new Error("Multiple subsequent combinator tokens");
                        if (i.length > 0 && "raw" === t.kind) i += s.literal;
                        else if ("raw" === t.kind) switch (s.literal) {
                            case " ":
                                break;
                            case ">":
                                i += ":scope" + s.literal;
                                break;
                            default:
                                r(s)
                        } else a(), r(s);
                        break
                    }
                case "ext":
                    a(), o(s.name, s.args)
            }
        }
        return a(), t
    }

    function fm(e, t) {
        const n = [];
        return e.children.forEach(e => {
            "Selector" === e.type && n.push(function(e, t) {
                const n = [];
                let r = "";
                const o = () => {
                        const e = r.trim();
                        e.length > 0 && n.push(new mm(e)), r = ""
                    },
                    i = e => Yd(e, t);
                return Ud(e, e => {
                    switch (e.type) {
                        case "Selector":
                            return;
                        case "IdSelector":
                        case "ClassSelector":
                        case "TypeSelector":
                        case "AttributeSelector":
                            return r += i(e), "AttributeSelector" === e.type ? Ud.skip : void 0;
                        case "Combinator":
                            return o(), void n.push(new gm(e.name));
                        case "PseudoClassSelector":
                            {
                                const a = e.name.toLowerCase();
                                if (a in um) {
                                    var t;
                                    o();
                                    const r = null === (t = e.children) || void 0 === t ? void 0 : t.first;
                                    if (null == r) throw new Error(":".concat(a, ": expected an argument, got null/undefined"));
                                    const s = i(r);
                                    n.push(new bm(a, s))
                                } else r += i(e);
                                return Ud.skip
                            }
                        default:
                            throw new Error("Unexpected node type: ".concat(e.type))
                    }
                }), o(), n
            }(e, t))
        }), n
    }
    class mm {
        constructor(t) {
            e(this, "literal", void 0), e(this, "kind", "raw"), this.literal = t
        }
        toString() {
            return "RawTok(".concat(this.literal, ")")
        }
    }
    class gm {
        constructor(t) {
            e(this, "literal", void 0), e(this, "kind", "comb"), this.literal = t
        }
        toString() {
            return "CombTok(".concat(this.literal, ")")
        }
    }
    class bm {
        constructor(t, n) {
            e(this, "name", void 0), e(this, "args", void 0), e(this, "kind", "ext"), this.name = t, this.args = n
        }
        toString() {
            return "ExtTok(:".concat(this.name, "(").concat(this.args, "))")
        }
    }

    function ym(e) {
        return km(Fd(e, {
            context: "selectorList",
            positions: !0
        }), e)
    }

    function km(e, t) {
        return fm(e, t).map(dm)
    }

    function vm(e) {
        const t = Fd(e, {
            context: "selectorList",
            positions: !0
        });
        let n;
        if (1 === t.children.size) {
            const e = function(e) {
                let t = null;
                return Ud(e, {
                    visit: "PseudoClassSelector",
                    enter(e, n, r) {
                        if ("style" === e.name) {
                            var o;
                            const i = null === (o = e.children) || void 0 === o ? void 0 : o.first;
                            if (null == i) throw new Error(":style() must have an argument");
                            if ("Raw" !== i.type) throw new Error(":style() argument must be 'Raw', got ".concat(i.type));
                            return t = i.value, r.remove(n), this.break
                        }
                    }
                }), t
            }(t.children.first);
            null !== e && (n = function(e) {
                const t = [],
                    n = Fd(e, {
                        context: "declarationList",
                        positions: !0
                    });
                return Ud(n, {
                    visit: "Declaration",
                    enter(n) {
                        if ("boolean" != typeof n.important) throw new Error("Expected declaration.important to be boolean, got ".concat(n.important, " of type ").concat(typeof n.important));
                        return t.push({
                            property: n.property,
                            important: n.important,
                            value: Yd(n.value, e)
                        }), this.skip
                    }
                }), t
            }(e))
        }
        const r = km(t, e);
        return n ? {
            type: "style",
            declarations: n,
            selectorList: r
        } : {
            type: "hide",
            selectorList: r
        }
    }
    const xm = "Zen";
    const wm = (Sm = "engine", {
        log(e) {
            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
            console.log("".concat(xm, "/extended-css/").concat(Sm, ": ").concat(e), ...n)
        },
        debug(e) {
            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
            console.debug("".concat(xm, "/extended-css/").concat(Sm, ": ").concat(e), ...n)
        },
        info(e) {
            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
            console.info("".concat(xm, "/extended-css/").concat(Sm, ": ").concat(e), ...n)
        },
        warn(e) {
            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
            console.warn("".concat(xm, "/extended-css/").concat(Sm, ": ").concat(e), ...n)
        },
        error(e) {
            for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
            console.error("".concat(xm, "/extended-css/").concat(Sm, ": ").concat(e), ...n)
        }
    });
    var Sm;
    class Cm {
        constructor(t) {
            e(this, "rules", void 0), e(this, "target", document.documentElement), e(this, "appliedClasses", new Map), e(this, "observer", null), e(this, "styleEl", null), wm.debug("Initializing engine");
            const n = this.parseRules(t);
            this.rules = n.rules, this.createStyleSheet(n.cssText)
        }
        start() {
            wm.debug("Starting with ".concat(this.rules.length, " rules")), this.applyQueries(), "complete" !== document.readyState && document.addEventListener("DOMContentLoaded", () => {
                this.applyQueries()
            }, {
                once: !0
            }), this.registerObserver()
        }
        stop() {
            this.observer && (this.observer.disconnect(), this.observer = null);
            for (const e of this.appliedClasses.keys()) this.restoreAllClasses(e);
            this.appliedClasses.clear(), this.styleEl && (this.styleEl.remove(), this.styleEl = null), wm.debug("Engine stopped")
        }
        parseRules(e) {
            const t = e.split("\n"),
                n = [];
            let r = "",
                o = 0;
            const i = "zenc_hide";
            let a = !1;
            const s = (e, t) => {
                    if (0 === t.length) return;
                    const i = "zenc_".concat(o++);
                    r += this.buildCssRule(i, t), n.push({
                        executor: e,
                        className: i
                    })
                },
                l = e => {
                    a || (r += this.buildCssRule(i, [{
                        property: "display",
                        value: "none",
                        important: !0
                    }]), a = !0), n.push({
                        executor: e,
                        className: i
                    })
                };
            for (const e of t) {
                const t = e.trim();
                if (0 !== t.length) try {
                    const e = vm(t),
                        n = new tm(e.selectorList);
                    switch (e.type) {
                        case "hide":
                            l(n);
                            break;
                        case "style":
                            s(n, e.declarations);
                            break;
                        default:
                            throw new Error("Unknown rule type ".concat(e.type))
                    }
                } catch (t) {
                    wm.error('Failed to parse rule: "'.concat(e, '"'), t)
                }
            }
            return {
                rules: n,
                cssText: r
            }
        }
        buildCssRule(e, t) {
            const n = t.map(e => "".concat(e.property, ":").concat(e.value).concat(e.important ? "!important" : "")).join(";");
            return ".".concat(e, "{").concat(n, "}")
        }
        applyQueries() {
            const e = performance.now(),
                t = this.collectClassMatches(),
                {
                    added: n,
                    removed: r
                } = this.applyClasses(t),
                o = (performance.now() - e).toFixed(2);
            wm.debug("Applied ".concat(n, " classes, removed ").concat(r, " classes ") + "in ".concat(o, "ms"))
        }
        collectClassMatches() {
            const e = new Map;
            for (const t of this.rules) try {
                const n = t.executor.match(this.target);
                for (const r of n) {
                    if (!(r instanceof HTMLElement)) continue;
                    let n = e.get(r);
                    n || (n = new Set, e.set(r, n)), n.add(t.className)
                }
            } catch (e) {
                wm.error("Failed to apply rule", e)
            }
            return e
        }
        applyClasses(e) {
            let t = 0,
                n = 0;
            for (const t of this.appliedClasses.keys()) {
                const r = this.appliedClasses.get(t),
                    o = e.get(t);
                if (o)
                    for (const e of r.values()) o.has(e) || (t.classList.remove(e), r.delete(e), n++);
                else {
                    for (const e of r.values()) t.classList.remove(e), n++;
                    this.appliedClasses.delete(t)
                }
            }
            for (const [n, r] of e) {
                if (!(n instanceof HTMLElement)) continue;
                let e = this.appliedClasses.get(n);
                e || (e = new Set, this.appliedClasses.set(n, e));
                for (const o of r) e.has(o) || (n.classList.add(o), e.add(o), t++)
            }
            return {
                added: t,
                removed: n
            }
        }
        restoreAllClasses(e) {
            if (!(e instanceof HTMLElement)) return;
            const t = this.appliedClasses.get(e);
            if (t) {
                for (const n of t.values()) e.classList.remove(n);
                this.appliedClasses.delete(e)
            }
        }
        createStyleSheet(e) {
            this.styleEl || (this.styleEl = document.createElement("style"), (document.head || document.documentElement).appendChild(this.styleEl)), this.styleEl.textContent = e
        }
        registerObserver() {
            const e = {
                    childList: !0,
                    subtree: !0,
                    attributes: !0,
                    attributeFilter: ["id", "class"]
                },
                t = function(e, t) {
                    let n, r;
                    return function() {
                        for (var o = arguments.length, i = new Array(o), a = 0; a < o; a++) i[a] = arguments[a];
                        if (void 0 !== r) return;
                        const s = performance.now();
                        if (void 0 !== n) {
                            const o = s - n;
                            if (o < t) {
                                const a = t - o;
                                return void(r = window.setTimeout(() => {
                                    r = void 0, n = performance.now(), e(...i)
                                }, a))
                            }
                        }
                        n = s, e(...i)
                    }
                }(t => {
                    t.disconnect(), this.applyQueries(), t.observe(this.target, e)
                }, 100);
            this.observer = new MutationObserver((e, n) => {
                0 !== e.length && t(n)
            }), this.observer.observe(this.target, e)
        }
    }
    return function(e) {
        new Cm(e).start()
    }
}();

(() => {
    window.extendedCSS(".ta_c:has-text(Sponsored)\nli.b_algo:has(.rms_img[src*=\"id=ODLS.A2450BEC-5595-40BA-9F13-D9EC6AB74B9F\"]):has(.tptt:-abp-contains(/^([Aa]mazon(\\.[acdefinps][aeglnorst]m?\\.?[abjmtu]?[kprux]?)?|Best Buy|Booking\\.com|eBay|eDreams|Lenovo US|Trip\\.com|Tripadvisor|Walmart)$/))\n.slide:has(\u003e .tobitem \u003e a \u003e .rtb_ad_caritem_mvtr)\n#b_results \u003e .b_algo:has(\u003e .b_caption \u003e .b_attribution:matches-css(before, content: /url\\(data:image/))\n.insights \u003e .insml \u003e li \u003e .ins_exp \u003e div \u003e ul \u003e li \u003e .ta_c \u003e a[href*=\"/aclick?ld=\"]:upward(1)\n.tob_calcontainer \u003e div.slide:has(\u003e div.tobitem \u003e a[href*=\"/tracking?adUnit=\"])\n#b_results \u003e li.b_algo:has(\u003e .b_caption \u003e p:matches-css(before, content: /^(Ad|Ann\\.|Annonce|Anúncio|Anzeige|Reklama|Реклама|Reclamă|Publicidade)$/))\nmain[aria-label=\"Search Results\"] \u003e #b_pole:has(#cu_polebanner #cu_poleMSPromoText)\n.ta_c:contains(Sponsored)\nli.b_algo:has(.rms_img[src*=\"id=ODLS.A2450BEC-5595-40BA-9F13-D9EC6AB74B9F\"]):has(.tptt:contains(/^([Aa]mazon(\\.[acdefinps][aeglnorst]m?\\.?[abjmtu]?[kprux]?)?|Best Buy|Booking\\.com|eBay|eDreams|Lenovo US|Trip\\.com|Tripadvisor|Walmart)$/))")
})();
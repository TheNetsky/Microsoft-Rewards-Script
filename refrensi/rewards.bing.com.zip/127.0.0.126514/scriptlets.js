var scriptlet = function() {
    "use strict";

    function e(e) {
        return null !== e && ("function" == typeof e || "object" == typeof e)
    }

    function t(t, n, o) {
        const i = n.split(".");
        let s = t;
        for (let t = 0; t < i.length; t++) {
            const n = i[t],
                a = t === i.length - 1,
                c = i.slice(0, t + 1);
            if (a) {
                const e = c[c.length - 1],
                    t = Object.getOwnPropertyDescriptor(s, e) || {},
                    r = t.get,
                    n = t.set;
                let a = t.value;
                Object.defineProperty(s, i[i.length - 1], {
                    configurable: !0,
                    enumerable: !0,
                    get() {
                        return o.onGet && o.onGet(), r ? r.call(this) : a
                    },
                    set(e) {
                        o.onSet && o.onSet(), n ? n.call(this, e) : a = e
                    }
                })
            } else {
                const a = r(s, n),
                    c = Object.prototype.hasOwnProperty.call(s, n);
                if (a && !c) {
                    let r;
                    const a = (t, r) => new Proxy(t, {
                        get(t, n) {
                            const i = Reflect.get(t, n, t);
                            return 1 === r.length && n === r[0] ? (o.onGet && o.onGet(), i) : n === r[0] && e(i) ? a(i, r.slice(1)) : i
                        },
                        set: (e, t, n) => (1 === r.length && t === r[0] && o.onSet && o.onSet(), Reflect.set(e, t, n))
                    });
                    return void Object.defineProperty(s, n, {
                        configurable: !0,
                        enumerable: !0,
                        get: () => e(r) ? a(r, i.slice(t + 1)) : r,
                        set(e) {
                            r = e
                        }
                    })
                }
                s = s[n]
            }
        }
    }

    function r(e, t) {
        if (!e) return !0;
        const r = Object.getOwnPropertyDescriptor(e, t);
        return !r || Boolean(r.configurable)
    }
    const n = "Zen";

    function o(e) {
        return {
            log(t) {
                for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
                console.log(`${n} (${e}): ${t}`, ...o)
            },
            debug(t) {
                for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
                console.debug(`${n} (${e}): ${t}`, ...o)
            },
            info(t) {
                for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
                console.info(`${n} (${e}): ${t}`, ...o)
            },
            warn(t) {
                for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
                console.warn(`${n} (${e}): ${t}`, ...o)
            },
            error(t) {
                for (var r = arguments.length, o = new Array(r > 1 ? r - 1 : 0), i = 1; i < r; i++) o[i - 1] = arguments[i];
                console.error(`${n} (${e}): ${t}`, ...o)
            }
        }
    }
    const i = /^\/((?:[^/\\\r\n]|\\.)+)\/([gimsuy]*)$/;

    function s(e) {
        const t = e.match(i);
        if (null === t) return null;
        try {
            return new RegExp(t[1], t[2])
        } catch {
            return null
        }
    }

    function a(e, t) {
        try {
            return new RegExp(function(e) {
                return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
            }(e), t)
        } catch {
            return null
        }
    }

    function c() {
        return Math.random().toString(36).substring(2, 15)
    }
    const u = o("abort-current-inline-script");
    const l = o("abort-on-property-read");

    function f(e) {
        if ("string" != typeof e || 0 === e.length) return void l.warn("property should be a non-empty string");
        const r = c();
        t(window, e, {
            onGet: () => {
                throw l.info(`Blocked ${e} read`), new ReferenceError(`Aborted script with ID: ${r}`)
            }
        }), window.addEventListener("error", (e => {
            e.error instanceof ReferenceError && e.error.message.includes(r) && e.preventDefault()
        }))
    }
    const p = o("abort-on-property-write");

    function y(e) {
        if ("string" != typeof e || 0 === e.length) return void p.warn("property should be a non-empty string");
        const r = c();
        t(window, e, {
            onSet: () => {
                throw p.info(`Blocked ${e} write`), new ReferenceError(`Aborted script with ID: ${r}`)
            }
        }), window.addEventListener("error", (e => {
            e.error instanceof ReferenceError && e.error.message.includes(r) && e.preventDefault()
        }))
    }

    function d(e) {
        const {
            stack: t
        } = new Error;
        return void 0 !== t && t.split("\n").slice(2).map((e => e.trim())).some((t => e.test(t)))
    }
    const h = o("abort-on-stack-trace");

    function g(e, r) {
        if ("string" != typeof e || 0 === e.length) return void h.warn("property should be a non-empty string");
        if ("string" != typeof r || 0 === r.length) return void h.warn("stack should be a non-empty string");
        const n = s(r) || a(r),
            o = c(),
            i = () => {
                if (null !== n && d(n)) throw h.info(`Blocked script on '${r}' stack`), new ReferenceError(`Aborted script with ID: ${o}`)
            };
        t(window, e, {
            onGet: i,
            onSet: i
        }), window.addEventListener("error", (e => {
            e.error instanceof ReferenceError && e.error.message.includes(o) && e.preventDefault()
        }))
    }

    function v(e, t, r) {
        const n = m(e),
            o = m(t);
        let i = null;
        return "string" == typeof r && (i = s(r) || a(r)),
            function(e) {
                if ("object" == typeof e && (null === i || d(i))) {
                    if (o.length > 0) {
                        let t = !1;
                        for (const r of o)
                            if (b(e, r)) {
                                t = !0;
                                break
                            }
                        if (!t) return
                    }
                    for (const t of n) w(e, t)
                }
            }
    }

    function w(e, t) {
        if (0 === t.length || null == e) return;
        const [r, ...n] = t;
        if ("*" !== r)
            if ("[]" !== r) Object.hasOwn(e, r) && (0 === n.length ? delete e[r] : w(e[r], n));
            else {
                if (!Array.isArray(e)) return;
                for (let t = 0; t < e.length; t++) w(e[t], n)
            }
        else {
            const r = Object.getOwnPropertyNames(e).filter((t => "object" == typeof e[t] || Array.isArray(e[t])));
            for (const o of r) w(e[o], t), w(e[o], n)
        }
    }

    function b(e, t) {
        if (null == e) return !1;
        if (0 === t.length) return !0;
        if ("*" === t[0]) {
            const r = Object.getOwnPropertyNames(e).filter((t => "object" == typeof e[t] || Array.isArray(e[t])));
            for (const n of r)
                if (b(e[n], t) || b(e[n], t.slice(1))) return !0;
            return !1
        }
        if ("[]" === t[0]) {
            if (!Array.isArray(e)) return !1;
            for (let r = 0; r < e.length; r++)
                if (b(e[r], t.slice(1))) return !0;
            return !1
        }
        return !!Object.hasOwn(e, t[0]) && b(e[t[0]], t.slice(1))
    }

    function m(e) {
        return "string" != typeof e ? [] : e.split(/\s+/).filter(Boolean).map((e => e.split(".")))
    }
    const S = o("json-prune");
    const E = ["url", "method", "credentials", "cache", "redirect", "referrer", "referrerPolicy", "integrity", "mode"];

    function P(e) {
        if ("" === e || "*" === e) return {};
        const t = {},
            r = e.split(" ");
        for (const e of r) {
            if (!e.includes(":")) {
                t.url = s(e) || a(e) || e;
                continue
            }
            const [r, n] = e.split(":");
            if ("" === r || void 0 === n || "" === n) throw new Error(`Invalid segment: "${e}"`);
            if (!E.includes(r)) throw new Error(`Invalid segment key: "${r}"`);
            t[r] = s(n) || n
        }
        return t
    }

    function O(e, t) {
        let r;
        r = t[0] instanceof Request ? t[0] : void 0 !== t[1] ? { ...t[1],
            url: t[0].toString()
        } : {
            url: t[0].toString()
        };
        for (const t of Object.keys(e))
            if (void 0 === r[t] || !x(e[t], r[t])) return !1;
        return !0
    }

    function R(e) {
        for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
        const o = {
            method: r[0],
            url: r[1].toString()
        };
        for (const t of Object.keys(e))
            if (void 0 === o[t] || !x(e[t], o[t])) return !1;
        return !0
    }

    function x(e, t) {
        return "string" == typeof e ? e === t : e.test(t)
    }

    function j(e) {
        const t = parseInt(e, 10);
        if (isNaN(t)) throw new Error("input is NaN");
        if (!Number.isFinite(t)) throw new Error("input is Infinite");
        return t
    }
    const k = /length:(\d+)-(\d+)/,
        T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+=~";

    function L(e) {
        if ("false" === e) return "";
        let t, r;
        const n = e.match(k);
        if ("true" === e) t = 10, r = 10;
        else {
            if (!n) throw new Error("Invalid pattern");
            if (t = j(n[1]), r = j(n[2]), r > 5e5) throw new Error("maxLength exceeds limit");
            if (t > r) throw new Error("minLength exceeds maxLength")
        }
        const o = function(e, t) {
            return e = Math.ceil(e), t = Math.floor(t), Math.floor(Math.random() * (t - e + 1) + e)
        }(t, r);
        return function(e) {
            let t = "";
            for (let r = 0; r < e; r++) t += T.charAt(Math.floor(Math.random() * T.length));
            return t
        }(o)
    }
    const A = o("json-prune-fetch-response");
    var D = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
        $ = function(e) {
            return e && e.Math === Math && e
        },
        N = $("object" == typeof globalThis && globalThis) || $("object" == typeof window && window) || $("object" == typeof self && self) || $("object" == typeof D && D) || $("object" == typeof D && D) || function() {
            return this
        }() || Function("return this")(),
        I = {},
        M = function(e) {
            try {
                return !!e()
            } catch (e) {
                return !0
            }
        },
        C = !M((function() {
            return 7 !== Object.defineProperty({}, 1, {
                get: function() {
                    return 7
                }
            })[1]
        })),
        H = !M((function() {
            var e = function() {}.bind();
            return "function" != typeof e || e.hasOwnProperty("prototype")
        })),
        q = H,
        B = Function.prototype.call,
        z = q ? B.bind(B) : function() {
            return B.apply(B, arguments)
        },
        X = {},
        F = {}.propertyIsEnumerable,
        U = Object.getOwnPropertyDescriptor,
        G = U && !F.call({
            1: 2
        }, 1);
    X.f = G ? function(e) {
        var t = U(this, e);
        return !!t && t.enumerable
    } : F;
    var W, J, _ = function(e, t) {
            return {
                enumerable: !(1 & e),
                configurable: !(2 & e),
                writable: !(4 & e),
                value: t
            }
        },
        V = H,
        K = Function.prototype,
        Y = K.call,
        Z = V && K.bind.bind(Y, Y),
        Q = V ? Z : function(e) {
            return function() {
                return Y.apply(e, arguments)
            }
        },
        ee = Q,
        te = ee({}.toString),
        re = ee("".slice),
        ne = function(e) {
            return re(te(e), 8, -1)
        },
        oe = M,
        ie = ne,
        se = Object,
        ae = Q("".split),
        ce = oe((function() {
            return !se("z").propertyIsEnumerable(0)
        })) ? function(e) {
            return "String" === ie(e) ? ae(e, "") : se(e)
        } : se,
        ue = function(e) {
            return null == e
        },
        le = ue,
        fe = TypeError,
        pe = function(e) {
            if (le(e)) throw new fe("Can't call method on " + e);
            return e
        },
        ye = ce,
        de = pe,
        he = function(e) {
            return ye(de(e))
        },
        ge = "object" == typeof document && document.all,
        ve = void 0 === ge && void 0 !== ge ? function(e) {
            return "function" == typeof e || e === ge
        } : function(e) {
            return "function" == typeof e
        },
        we = ve,
        be = function(e) {
            return "object" == typeof e ? null !== e : we(e)
        },
        me = N,
        Se = ve,
        Ee = function(e, t) {
            return arguments.length < 2 ? (r = me[e], Se(r) ? r : void 0) : me[e] && me[e][t];
            var r
        },
        Pe = Q({}.isPrototypeOf),
        Oe = N.navigator,
        Re = Oe && Oe.userAgent,
        xe = Re ? String(Re) : "",
        je = N,
        ke = xe,
        Te = je.process,
        Le = je.Deno,
        Ae = Te && Te.versions || Le && Le.version,
        De = Ae && Ae.v8;
    De && (J = (W = De.split("."))[0] > 0 && W[0] < 4 ? 1 : +(W[0] + W[1])), !J && ke && (!(W = ke.match(/Edge\/(\d+)/)) || W[1] >= 74) && (W = ke.match(/Chrome\/(\d+)/)) && (J = +W[1]);
    var $e = J,
        Ne = $e,
        Ie = M,
        Me = N.String,
        Ce = !!Object.getOwnPropertySymbols && !Ie((function() {
            var e = Symbol("symbol detection");
            return !Me(e) || !(Object(e) instanceof Symbol) || !Symbol.sham && Ne && Ne < 41
        })),
        He = Ce && !Symbol.sham && "symbol" == typeof Symbol.iterator,
        qe = Ee,
        Be = ve,
        ze = Pe,
        Xe = Object,
        Fe = He ? function(e) {
            return "symbol" == typeof e
        } : function(e) {
            var t = qe("Symbol");
            return Be(t) && ze(t.prototype, Xe(e))
        },
        Ue = String,
        Ge = ve,
        We = function(e) {
            try {
                return Ue(e)
            } catch (e) {
                return "Object"
            }
        },
        Je = TypeError,
        _e = function(e) {
            if (Ge(e)) return e;
            throw new Je(We(e) + " is not a function")
        },
        Ve = _e,
        Ke = ue,
        Ye = function(e, t) {
            var r = e[t];
            return Ke(r) ? void 0 : Ve(r)
        },
        Ze = z,
        Qe = ve,
        et = be,
        tt = TypeError,
        rt = {
            exports: {}
        },
        nt = N,
        ot = Object.defineProperty,
        it = function(e, t) {
            try {
                ot(nt, e, {
                    value: t,
                    configurable: !0,
                    writable: !0
                })
            } catch (r) {
                nt[e] = t
            }
            return t
        },
        st = N,
        at = it,
        ct = "__core-js_shared__",
        ut = rt.exports = st[ct] || at(ct, {});
    (ut.versions || (ut.versions = [])).push({
        version: "3.41.0",
        mode: "global",
        copyright: "© 2014-2025 Denis Pushkarev (zloirock.ru)",
        license: "https://github.com/zloirock/core-js/blob/v3.41.0/LICENSE",
        source: "https://github.com/zloirock/core-js"
    });
    var lt = rt.exports,
        ft = lt,
        pt = function(e, t) {
            return ft[e] || (ft[e] = t || {})
        },
        yt = pe,
        dt = Object,
        ht = function(e) {
            return dt(yt(e))
        },
        gt = ht,
        vt = Q({}.hasOwnProperty),
        wt = Object.hasOwn || function(e, t) {
            return vt(gt(e), t)
        },
        bt = Q,
        mt = 0,
        St = Math.random(),
        Et = bt(1..toString),
        Pt = function(e) {
            return "Symbol(" + (void 0 === e ? "" : e) + ")_" + Et(++mt + St, 36)
        },
        Ot = pt,
        Rt = wt,
        xt = Pt,
        jt = Ce,
        kt = He,
        Tt = N.Symbol,
        Lt = Ot("wks"),
        At = kt ? Tt.for || Tt : Tt && Tt.withoutSetter || xt,
        Dt = function(e) {
            return Rt(Lt, e) || (Lt[e] = jt && Rt(Tt, e) ? Tt[e] : At("Symbol." + e)), Lt[e]
        },
        $t = z,
        Nt = be,
        It = Fe,
        Mt = Ye,
        Ct = function(e, t) {
            var r, n;
            if ("string" === t && Qe(r = e.toString) && !et(n = Ze(r, e))) return n;
            if (Qe(r = e.valueOf) && !et(n = Ze(r, e))) return n;
            if ("string" !== t && Qe(r = e.toString) && !et(n = Ze(r, e))) return n;
            throw new tt("Can't convert object to primitive value")
        },
        Ht = TypeError,
        qt = Dt("toPrimitive"),
        Bt = function(e, t) {
            if (!Nt(e) || It(e)) return e;
            var r, n = Mt(e, qt);
            if (n) {
                if (void 0 === t && (t = "default"), r = $t(n, e, t), !Nt(r) || It(r)) return r;
                throw new Ht("Can't convert object to primitive value")
            }
            return void 0 === t && (t = "number"), Ct(e, t)
        },
        zt = Fe,
        Xt = function(e) {
            var t = Bt(e, "string");
            return zt(t) ? t : t + ""
        },
        Ft = be,
        Ut = N.document,
        Gt = Ft(Ut) && Ft(Ut.createElement),
        Wt = function(e) {
            return Gt ? Ut.createElement(e) : {}
        },
        Jt = !C && !M((function() {
            return 7 !== Object.defineProperty(Wt("div"), "a", {
                get: function() {
                    return 7
                }
            }).a
        })),
        _t = C,
        Vt = z,
        Kt = X,
        Yt = _,
        Zt = he,
        Qt = Xt,
        er = wt,
        tr = Jt,
        rr = Object.getOwnPropertyDescriptor;
    I.f = _t ? rr : function(e, t) {
        if (e = Zt(e), t = Qt(t), tr) try {
            return rr(e, t)
        } catch (e) {}
        if (er(e, t)) return Yt(!Vt(Kt.f, e, t), e[t])
    };
    var nr = {},
        or = C && M((function() {
            return 42 !== Object.defineProperty((function() {}), "prototype", {
                value: 42,
                writable: !1
            }).prototype
        })),
        ir = be,
        sr = String,
        ar = TypeError,
        cr = function(e) {
            if (ir(e)) return e;
            throw new ar(sr(e) + " is not an object")
        },
        ur = C,
        lr = Jt,
        fr = or,
        pr = cr,
        yr = Xt,
        dr = TypeError,
        hr = Object.defineProperty,
        gr = Object.getOwnPropertyDescriptor,
        vr = "enumerable",
        wr = "configurable",
        br = "writable";
    nr.f = ur ? fr ? function(e, t, r) {
        if (pr(e), t = yr(t), pr(r), "function" == typeof e && "prototype" === t && "value" in r && br in r && !r[br]) {
            var n = gr(e, t);
            n && n[br] && (e[t] = r.value, r = {
                configurable: wr in r ? r[wr] : n[wr],
                enumerable: vr in r ? r[vr] : n[vr],
                writable: !1
            })
        }
        return hr(e, t, r)
    } : hr : function(e, t, r) {
        if (pr(e), t = yr(t), pr(r), lr) try {
            return hr(e, t, r)
        } catch (e) {}
        if ("get" in r || "set" in r) throw new dr("Accessors not supported");
        return "value" in r && (e[t] = r.value), e
    };
    var mr = nr,
        Sr = _,
        Er = C ? function(e, t, r) {
            return mr.f(e, t, Sr(1, r))
        } : function(e, t, r) {
            return e[t] = r, e
        },
        Pr = {
            exports: {}
        },
        Or = C,
        Rr = wt,
        xr = Function.prototype,
        jr = Or && Object.getOwnPropertyDescriptor,
        kr = Rr(xr, "name"),
        Tr = {
            EXISTS: kr,
            PROPER: kr && "something" === function() {}.name,
            CONFIGURABLE: kr && (!Or || Or && jr(xr, "name").configurable)
        },
        Lr = ve,
        Ar = lt,
        Dr = Q(Function.toString);
    Lr(Ar.inspectSource) || (Ar.inspectSource = function(e) {
        return Dr(e)
    });
    var $r, Nr, Ir, Mr = Ar.inspectSource,
        Cr = ve,
        Hr = N.WeakMap,
        qr = Cr(Hr) && /native code/.test(String(Hr)),
        Br = Pt,
        zr = pt("keys"),
        Xr = {},
        Fr = qr,
        Ur = N,
        Gr = be,
        Wr = Er,
        Jr = wt,
        _r = lt,
        Vr = function(e) {
            return zr[e] || (zr[e] = Br(e))
        },
        Kr = Xr,
        Yr = "Object already initialized",
        Zr = Ur.TypeError,
        Qr = Ur.WeakMap;
    if (Fr || _r.state) {
        var en = _r.state || (_r.state = new Qr);
        en.get = en.get, en.has = en.has, en.set = en.set, $r = function(e, t) {
            if (en.has(e)) throw new Zr(Yr);
            return t.facade = e, en.set(e, t), t
        }, Nr = function(e) {
            return en.get(e) || {}
        }, Ir = function(e) {
            return en.has(e)
        }
    } else {
        var tn = Vr("state");
        Kr[tn] = !0, $r = function(e, t) {
            if (Jr(e, tn)) throw new Zr(Yr);
            return t.facade = e, Wr(e, tn, t), t
        }, Nr = function(e) {
            return Jr(e, tn) ? e[tn] : {}
        }, Ir = function(e) {
            return Jr(e, tn)
        }
    }
    var rn = {
            set: $r,
            get: Nr,
            has: Ir,
            enforce: function(e) {
                return Ir(e) ? Nr(e) : $r(e, {})
            },
            getterFor: function(e) {
                return function(t) {
                    var r;
                    if (!Gr(t) || (r = Nr(t)).type !== e) throw new Zr("Incompatible receiver, " + e + " required");
                    return r
                }
            }
        },
        nn = Q,
        on = M,
        sn = ve,
        an = wt,
        cn = C,
        un = Tr.CONFIGURABLE,
        ln = Mr,
        fn = rn.enforce,
        pn = rn.get,
        yn = String,
        dn = Object.defineProperty,
        hn = nn("".slice),
        gn = nn("".replace),
        vn = nn([].join),
        wn = cn && !on((function() {
            return 8 !== dn((function() {}), "length", {
                value: 8
            }).length
        })),
        bn = String(String).split("String"),
        mn = Pr.exports = function(e, t, r) {
            "Symbol(" === hn(yn(t), 0, 7) && (t = "[" + gn(yn(t), /^Symbol\(([^)]*)\).*$/, "$1") + "]"), r && r.getter && (t = "get " + t), r && r.setter && (t = "set " + t), (!an(e, "name") || un && e.name !== t) && (cn ? dn(e, "name", {
                value: t,
                configurable: !0
            }) : e.name = t), wn && r && an(r, "arity") && e.length !== r.arity && dn(e, "length", {
                value: r.arity
            });
            try {
                r && an(r, "constructor") && r.constructor ? cn && dn(e, "prototype", {
                    writable: !1
                }) : e.prototype && (e.prototype = void 0)
            } catch (e) {}
            var n = fn(e);
            return an(n, "source") || (n.source = vn(bn, "string" == typeof t ? t : "")), e
        };
    Function.prototype.toString = mn((function() {
        return sn(this) && pn(this).source || ln(this)
    }), "toString");
    var Sn = Pr.exports,
        En = ve,
        Pn = nr,
        On = Sn,
        Rn = it,
        xn = function(e, t, r, n) {
            n || (n = {});
            var o = n.enumerable,
                i = void 0 !== n.name ? n.name : t;
            if (En(r) && On(r, i, n), n.global) o ? e[t] = r : Rn(t, r);
            else {
                try {
                    n.unsafe ? e[t] && (o = !0) : delete e[t]
                } catch (e) {}
                o ? e[t] = r : Pn.f(e, t, {
                    value: r,
                    enumerable: !1,
                    configurable: !n.nonConfigurable,
                    writable: !n.nonWritable
                })
            }
            return e
        },
        jn = {},
        kn = Math.ceil,
        Tn = Math.floor,
        Ln = Math.trunc || function(e) {
            var t = +e;
            return (t > 0 ? Tn : kn)(t)
        },
        An = function(e) {
            var t = +e;
            return t != t || 0 === t ? 0 : Ln(t)
        },
        Dn = An,
        $n = Math.max,
        Nn = Math.min,
        In = An,
        Mn = Math.min,
        Cn = function(e) {
            var t = In(e);
            return t > 0 ? Mn(t, 9007199254740991) : 0
        },
        Hn = Cn,
        qn = function(e) {
            return Hn(e.length)
        },
        Bn = he,
        zn = function(e, t) {
            var r = Dn(e);
            return r < 0 ? $n(r + t, 0) : Nn(r, t)
        },
        Xn = qn,
        Fn = function(e) {
            return function(t, r, n) {
                var o = Bn(t),
                    i = Xn(o);
                if (0 === i) return !e && -1;
                var s, a = zn(n, i);
                if (e && r != r) {
                    for (; i > a;)
                        if ((s = o[a++]) != s) return !0
                } else
                    for (; i > a; a++)
                        if ((e || a in o) && o[a] === r) return e || a || 0;
                return !e && -1
            }
        },
        Un = {
            includes: Fn(!0),
            indexOf: Fn(!1)
        },
        Gn = wt,
        Wn = he,
        Jn = Un.indexOf,
        _n = Xr,
        Vn = Q([].push),
        Kn = function(e, t) {
            var r, n = Wn(e),
                o = 0,
                i = [];
            for (r in n) !Gn(_n, r) && Gn(n, r) && Vn(i, r);
            for (; t.length > o;) Gn(n, r = t[o++]) && (~Jn(i, r) || Vn(i, r));
            return i
        },
        Yn = ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf"].concat("length", "prototype");
    jn.f = Object.getOwnPropertyNames || function(e) {
        return Kn(e, Yn)
    };
    var Zn = {};
    Zn.f = Object.getOwnPropertySymbols;
    var Qn = Ee,
        eo = jn,
        to = Zn,
        ro = cr,
        no = Q([].concat),
        oo = Qn("Reflect", "ownKeys") || function(e) {
            var t = eo.f(ro(e)),
                r = to.f;
            return r ? no(t, r(e)) : t
        },
        io = wt,
        so = oo,
        ao = I,
        co = nr,
        uo = M,
        lo = ve,
        fo = /#|\.prototype\./,
        po = function(e, t) {
            var r = ho[yo(e)];
            return r === vo || r !== go && (lo(t) ? uo(t) : !!t)
        },
        yo = po.normalize = function(e) {
            return String(e).replace(fo, ".").toLowerCase()
        },
        ho = po.data = {},
        go = po.NATIVE = "N",
        vo = po.POLYFILL = "P",
        wo = po,
        bo = N,
        mo = I.f,
        So = Er,
        Eo = xn,
        Po = it,
        Oo = function(e, t, r) {
            for (var n = so(t), o = co.f, i = ao.f, s = 0; s < n.length; s++) {
                var a = n[s];
                io(e, a) || r && io(r, a) || o(e, a, i(t, a))
            }
        },
        Ro = wo,
        xo = function(e, t) {
            var r, n, o, i, s, a = e.target,
                c = e.global,
                u = e.stat;
            if (r = c ? bo : u ? bo[a] || Po(a, {}) : bo[a] && bo[a].prototype)
                for (n in t) {
                    if (i = t[n], o = e.dontCallGetSet ? (s = mo(r, n)) && s.value : r[n], !Ro(c ? n : a + (u ? "." : "#") + n, e.forced) && void 0 !== o) {
                        if (typeof i == typeof o) continue;
                        Oo(i, o)
                    }(e.sham || o && o.sham) && So(i, "sham", !0), Eo(r, n, i, e)
                }
        },
        jo = ne,
        ko = C,
        To = Array.isArray || function(e) {
            return "Array" === jo(e)
        },
        Lo = TypeError,
        Ao = Object.getOwnPropertyDescriptor,
        Do = ko && ! function() {
            if (void 0 !== this) return !0;
            try {
                Object.defineProperty([], "length", {
                    writable: !1
                }).length = 1
            } catch (e) {
                return e instanceof TypeError
            }
        }(),
        $o = TypeError,
        No = ht,
        Io = qn,
        Mo = Do ? function(e, t) {
            if (To(e) && !Ao(e, "length").writable) throw new Lo("Cannot set read only .length");
            return e.length = t
        } : function(e, t) {
            return e.length = t
        },
        Co = function(e) {
            if (e > 9007199254740991) throw $o("Maximum allowed index exceeded");
            return e
        };
    xo({
        target: "Array",
        proto: !0,
        arity: 1,
        forced: M((function() {
            return 4294967297 !== [].push.call({
                length: 4294967296
            }, 1)
        })) || ! function() {
            try {
                Object.defineProperty([], "length", {
                    writable: !1
                }).push()
            } catch (e) {
                return e instanceof TypeError
            }
        }()
    }, {
        push: function(e) {
            var t = No(this),
                r = Io(t),
                n = arguments.length;
            Co(r + n);
            for (var o = 0; o < n; o++) t[r] = arguments[o], r++;
            return Mo(t, r), r
        }
    });
    const Ho = o("json-prune-xhr-response"),
        qo = Symbol("requestHeaders"),
        Bo = Symbol("shouldPrune"),
        zo = Symbol("openArgs"),
        Xo = Symbol("responseHeaders");
    const Fo = o("no-protected-audience");
    const Uo = o("no-topics");
    const Go = o("nowebrtc");
    const Wo = o("prevent-addEventListener");
    var Jo = {};
    Jo[Dt("toStringTag")] = "z";
    var _o = "[object z]" === String(Jo),
        Vo = ve,
        Ko = ne,
        Yo = Dt("toStringTag"),
        Zo = Object,
        Qo = "Arguments" === Ko(function() {
            return arguments
        }()),
        ei = _o ? Ko : function(e) {
            var t, r, n;
            return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(r = function(e, t) {
                try {
                    return e[t]
                } catch (e) {}
            }(t = Zo(e), Yo)) ? r : Qo ? Ko(t) : "Object" === (n = Ko(t)) && Vo(t.callee) ? "Arguments" : n
        },
        ti = String,
        ri = function(e) {
            if ("Symbol" === ei(e)) throw new TypeError("Cannot convert a Symbol value to a string");
            return ti(e)
        },
        ni = TypeError,
        oi = function(e, t) {
            if (e < t) throw new ni("Not enough arguments");
            return e
        },
        ii = xn,
        si = Q,
        ai = ri,
        ci = oi,
        ui = URLSearchParams,
        li = ui.prototype,
        fi = si(li.append),
        pi = si(li.delete),
        yi = si(li.forEach),
        di = si([].push),
        hi = new ui("a=1&a=2&b=3");
    hi.delete("a", 1), hi.delete("b", void 0), hi + "" != "a=2" && ii(li, "delete", (function(e) {
        var t = arguments.length,
            r = t < 2 ? void 0 : arguments[1];
        if (t && void 0 === r) return pi(this, e);
        var n = [];
        yi(this, (function(e, t) {
            di(n, {
                key: t,
                value: e
            })
        })), ci(t, 1);
        for (var o, i = ai(e), s = ai(r), a = 0, c = 0, u = !1, l = n.length; a < l;) o = n[a++], u || o.key === i ? (u = !0, pi(this, o.key)) : c++;
        for (; c < l;)(o = n[c++]).key === i && o.value === s || fi(this, o.key, o.value)
    }), {
        enumerable: !0,
        unsafe: !0
    });
    var gi = xn,
        vi = Q,
        wi = ri,
        bi = oi,
        mi = URLSearchParams,
        Si = mi.prototype,
        Ei = vi(Si.getAll),
        Pi = vi(Si.has),
        Oi = new mi("a=1");
    !Oi.has("a", 2) && Oi.has("a", void 0) || gi(Si, "has", (function(e) {
        var t = arguments.length,
            r = t < 2 ? void 0 : arguments[1];
        if (t && void 0 === r) return Pi(this, e);
        var n = Ei(this, e);
        bi(t, 1);
        for (var o = wi(r), i = 0; i < n.length;)
            if (n[i++] === o) return !0;
        return !1
    }), {
        enumerable: !0,
        unsafe: !0
    });
    var Ri = Sn,
        xi = nr,
        ji = function(e, t, r) {
            return r.get && Ri(r.get, t, {
                getter: !0
            }), r.set && Ri(r.set, t, {
                setter: !0
            }), xi.f(e, t, r)
        },
        ki = C,
        Ti = Q,
        Li = ji,
        Ai = URLSearchParams.prototype,
        Di = Ti(Ai.forEach);
    ki && !("size" in Ai) && Li(Ai, "size", {
        get: function() {
            var e = 0;
            return Di(this, (function() {
                e++
            })), e
        },
        configurable: !0,
        enumerable: !0
    });
    const $i = o("prevent-fetch");

    function Ni(e) {
        let t, r, n = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "emptyObj",
            o = arguments.length > 2 ? arguments[2] : void 0;
        if ("undefined" != typeof fetch && "undefined" != typeof Proxy && "undefined" != typeof Response) {
            switch (n) {
                case "":
                case "emptyObj":
                    t = "{}";
                    break;
                case "emptyArr":
                    t = "[]";
                    break;
                case "emptyStr":
                    t = "";
                    break;
                default:
                    return void $i.warn(`Invalid responseBody: ${n}`)
            }
            if ("string" != typeof o || "basic" === o || "cors" === o || "opaque" === o) {
                try {
                    r = P(e)
                } catch (e) {
                    $i.warn("Error parsing props", e)
                }
                fetch = new Proxy(fetch, {
                    apply: async (e, n, i) => {
                        if (!O(r, i)) return Reflect.apply(e, n, i);
                        const s = new Response(t, {
                            status: 200,
                            statusText: "OK",
                            headers: new Headers({
                                "Content-Length": t.length.toString(),
                                "Content-Type": "application/json",
                                Date: (new Date).toUTCString()
                            })
                        });
                        if ("opaque" === o) Object.defineProperties(s, {
                            url: {
                                value: ""
                            },
                            status: {
                                value: 0
                            },
                            statusText: {
                                value: ""
                            },
                            body: {
                                value: null
                            },
                            type: {
                                value: "opaque"
                            },
                            headers: {
                                value: new Headers
                            }
                        });
                        else {
                            let e;
                            e = i[0] instanceof URL ? i[0].toString() : i[0] instanceof Request ? i[0].url : i[0], Object.defineProperties(s, {
                                url: {
                                    value: e
                                },
                                type: {
                                    value: o || "basic"
                                }
                            })
                        }
                        return s
                    }
                })
            } else $i.warn(`Invalid responseType: ${o}`)
        } else $i.warn("Either fetch, Proxy, or Response is not supported in this environment")
    }

    function Ii(e) {
        let {
            callback: t,
            delay: r,
            matchCallback: n,
            matchDelay: o
        } = e;
        if ("function" != typeof t && "string" != typeof t) return !1;
        if ("string" != typeof n || o && !qi(o)) return !1;
        const {
            isInverted: i,
            regexp: s
        } = Ci(n), {
            isInverted: a,
            match: c
        } = Hi(o), u = Bi(r), l = String(t), f = s ? .test(l) !== i, p = null !== c && u === c !== a;
        return null === c ? f : n ? f && p : p
    }
    const Mi = e => {
            let t = !1;
            return e.startsWith("!") && (e = e.slice(1), t = !0), {
                isReverse: t,
                value: e
            }
        },
        Ci = e => {
            const {
                isReverse: t,
                value: r
            } = Mi(e);
            return {
                isInverted: t,
                regexp: s(r) || a(r)
            }
        },
        Hi = e => {
            const {
                isReverse: t,
                value: r
            } = Mi(e), n = parseInt(r, 10);
            return {
                isInverted: t,
                match: Number.isNaN(n) ? null : n
            }
        },
        qi = e => {
            if ("string" != typeof e) return !1;
            const t = e => "number" == typeof e && !Number.isNaN(e) && Number.isFinite(e);
            return e.startsWith("!") ? t(+e.slice(1)) : t(+e)
        },
        Bi = e => {
            const t = Math.floor(parseInt(e, 10));
            return "number" != typeof t || Number.isNaN(t) ? e : t
        },
        zi = o("prevent-set-interval");
    const Xi = o("prevent-set-timeout");
    const Fi = o("prevent-window-open");

    function Ui(e, t, r) {
        let n;
        try {
            n = "1" === e || "0" === e ? function(e, t, r) {
                let n, o = !1;
                "0" === e && (o = !0);
                if ("string" == typeof t && t.length > 0 && (n = (s(t) || a(t)) ? ? void 0, void 0 === n)) throw new Error("Could not parse search");
                let i = () => {};
                if ("trueFunc" === r) i = () => !0;
                else if ("string" == typeof r && r.length > 0) {
                    if (!r.startsWith("{") || !r.endsWith("}")) throw new Error(`Invalid replacement ${r}`);
                    const e = r.slice(1, -1).split("=");
                    if (2 !== e.length || 0 === e[0].length || "noopFunc" !== e[1]) throw new Error(`Invalid replacement ${r}`);
                    i = {
                        [e[0]]: () => {}
                    }
                }
                return (e, t, r) => {
                    let s;
                    if (0 === r.length || null == r[0]) s = "";
                    else if ("string" == typeof r[0]) s = r[0];
                    else {
                        if (!(r[0] instanceof URL)) return Reflect.apply(e, t, r);
                        s = r[0].toString()
                    }
                    if (void 0 !== n) {
                        let i = n.test(s);
                        if (o && (i = !i), !i) return Reflect.apply(e, t, r)
                    }
                    return Fi.info("Preventing window.open", {
                        args: r
                    }), i
                }
            }(e, t, r) : function(e, t, r) {
                let n, o, i = !1;
                if ("string" == typeof e && e.length > 0 && (i = "!" === e[0], i && (e = e.slice(1)), n = (s(e) || a(e)) ? ? void 0, void 0 === n)) throw new Error("Could not parse match");
                "string" == typeof t && t.length > 0 && (o = j(t));
                if ("string" == typeof r && "obj" !== r && "blank" !== r) throw new Error(`Replacement type ${r} not supported`);
                return (e, t, s) => {
                    let a, c, u;
                    if (0 === s.length || null == s[0]) a = "";
                    else if ("string" == typeof s[0]) a = s[0];
                    else {
                        if (!(s[0] instanceof URL)) return Reflect.apply(e, t, s);
                        a = s[0].toString()
                    }
                    if (void 0 !== n) {
                        let r = n.test(a);
                        if (i && (r = !r), !r) return Reflect.apply(e, t, s)
                    }
                    if (Fi.info("Preventing window.open", {
                            args: s
                        }), "blank" === r) return Reflect.apply(e, t, ["about:blank", ...s.slice(1)]);
                    if ("obj" === r) c = document.createElement("object"), c.data = a;
                    else c = document.createElement("iframe"), c.src = a;
                    if (c.style.setProperty("height", "1px", "important"), c.style.setProperty("width", "1px", "important"), c.style.setProperty("position", "absolute", "important"), c.style.setProperty("top", "-9999px", "important"), document.body.appendChild(c), void 0 !== o && setTimeout((() => {
                            c.remove()
                        }), 1e3 * o), "obj" === r) {
                        if (u = c.contentWindow, null === u || "object" != typeof u) return null;
                        Object.defineProperties(u, {
                            closed: {
                                value: !1
                            },
                            opener: {
                                value: window
                            },
                            frameElement: {
                                value: null
                            }
                        })
                    } else u = new Proxy(window, {
                        get: (e, t, r) => {
                            if ("closed" === t) return !1;
                            const n = Reflect.get(e, t, r);
                            return "function" == typeof n ? () => {} : n
                        },
                        set: () => !0
                    });
                    return u
                }
            }(e, t, r)
        } catch (e) {
            return void Fi.warn("Error while making handler", {
                ex: e
            })
        }
        window.open = new Proxy(window.open, {
            apply: n
        })
    }
    var Gi = "undefined" != typeof ArrayBuffer && "undefined" != typeof DataView,
        Wi = Q,
        Ji = _e,
        _i = function(e, t, r) {
            try {
                return Wi(Ji(Object.getOwnPropertyDescriptor(e, t)[r]))
            } catch (e) {}
        },
        Vi = N,
        Ki = _i,
        Yi = ne,
        Zi = Vi.ArrayBuffer,
        Qi = Vi.TypeError,
        es = Zi && Ki(Zi.prototype, "byteLength", "get") || function(e) {
            if ("ArrayBuffer" !== Yi(e)) throw new Qi("ArrayBuffer expected");
            return e.byteLength
        },
        ts = Gi,
        rs = es,
        ns = N.DataView,
        os = function(e) {
            if (!ts || 0 !== rs(e)) return !1;
            try {
                return new ns(e), !1
            } catch (e) {
                return !0
            }
        },
        is = C,
        ss = ji,
        as = os,
        cs = ArrayBuffer.prototype;
    is && !("detached" in cs) && ss(cs, "detached", {
        configurable: !0,
        get: function() {
            return as(this)
        }
    });
    var us, ls, fs, ps, ys = An,
        ds = Cn,
        hs = RangeError,
        gs = os,
        vs = TypeError,
        ws = N,
        bs = xe,
        ms = ne,
        Ss = function(e) {
            return bs.slice(0, e.length) === e
        },
        Es = Ss("Bun/") ? "BUN" : Ss("Cloudflare-Workers") ? "CLOUDFLARE" : Ss("Deno/") ? "DENO" : Ss("Node.js/") ? "NODE" : ws.Bun && "string" == typeof Bun.version ? "BUN" : ws.Deno && "object" == typeof Deno.version ? "DENO" : "process" === ms(ws.process) ? "NODE" : ws.window && ws.document ? "BROWSER" : "REST",
        Ps = N,
        Os = "NODE" === Es,
        Rs = M,
        xs = $e,
        js = Es,
        ks = N.structuredClone,
        Ts = !!ks && !Rs((function() {
            if ("DENO" === js && xs > 92 || "NODE" === js && xs > 94 || "BROWSER" === js && xs > 97) return !1;
            var e = new ArrayBuffer(8),
                t = ks(e, {
                    transfer: [e]
                });
            return 0 !== e.byteLength || 8 !== t.byteLength
        })),
        Ls = N,
        As = function(e) {
            if (Os) {
                try {
                    return Ps.process.getBuiltinModule(e)
                } catch (e) {}
                try {
                    return Function('return require("' + e + '")')()
                } catch (e) {}
            }
        },
        Ds = Ts,
        $s = Ls.structuredClone,
        Ns = Ls.ArrayBuffer,
        Is = Ls.MessageChannel,
        Ms = !1;
    if (Ds) Ms = function(e) {
        $s(e, {
            transfer: [e]
        })
    };
    else if (Ns) try {
        Is || (us = As("worker_threads")) && (Is = us.MessageChannel), Is && (ls = new Is, fs = new Ns(2), ps = function(e) {
            ls.port1.postMessage(null, [e])
        }, 2 === fs.byteLength && (ps(fs), 0 === fs.byteLength && (Ms = ps)))
    } catch (e) {}
    var Cs = N,
        Hs = Q,
        qs = _i,
        Bs = function(e) {
            if (void 0 === e) return 0;
            var t = ys(e),
                r = ds(t);
            if (t !== r) throw new hs("Wrong length or index");
            return r
        },
        zs = function(e) {
            if (gs(e)) throw new vs("ArrayBuffer is detached");
            return e
        },
        Xs = es,
        Fs = Ms,
        Us = Ts,
        Gs = Cs.structuredClone,
        Ws = Cs.ArrayBuffer,
        Js = Cs.DataView,
        _s = Math.min,
        Vs = Ws.prototype,
        Ks = Js.prototype,
        Ys = Hs(Vs.slice),
        Zs = qs(Vs, "resizable", "get"),
        Qs = qs(Vs, "maxByteLength", "get"),
        ea = Hs(Ks.getInt8),
        ta = Hs(Ks.setInt8),
        ra = (Us || Fs) && function(e, t, r) {
            var n, o = Xs(e),
                i = void 0 === t ? o : Bs(t),
                s = !Zs || !Zs(e);
            if (zs(e), Us && (e = Gs(e, {
                    transfer: [e]
                }), o === i && (r || s))) return e;
            if (o >= i && (!r || s)) n = Ys(e, 0, i);
            else {
                var a = r && !s && Qs ? {
                    maxByteLength: Qs(e)
                } : void 0;
                n = new Ws(i, a);
                for (var c = new Js(e), u = new Js(n), l = _s(i, o), f = 0; f < l; f++) ta(u, f, ea(c, f))
            }
            return Us || Fs(e), n
        },
        na = ra;
    na && xo({
        target: "ArrayBuffer",
        proto: !0
    }, {
        transfer: function() {
            return na(this, arguments.length ? arguments[0] : void 0, !0)
        }
    });
    var oa = ra;
    oa && xo({
        target: "ArrayBuffer",
        proto: !0
    }, {
        transferToFixedLength: function() {
            return oa(this, arguments.length ? arguments[0] : void 0, !1)
        }
    });
    const ia = o("prevent-xhr"),
        sa = Symbol("prevent"),
        aa = Symbol("url"),
        ca = Symbol("responseHeaders");

    function ua(e, t) {
        if ("undefined" == typeof Proxy) return void ia.warn("Proxy is not supported in this environment");
        if ("string" != typeof e) return void ia.warn("propsToMatch is required");
        let r;
        try {
            r = P(e)
        } catch (e) {
            return void ia.warn("error parsing props", e)
        }
        XMLHttpRequest.prototype.open = new Proxy(XMLHttpRequest.prototype.open, {
            apply: (e, t, n) => t[sa] || R(r, ...n) ? (ia.debug("Preventing XHR request", n), t[sa] = !0, t[aa] = n[1].toString(), Reflect.apply(e, t, n)) : (t[sa] = !1, Reflect.apply(e, t, n))
        }), XMLHttpRequest.prototype.send = new Proxy(XMLHttpRequest.prototype.send, {
            apply: (e, r, n) => {
                if (!r[sa]) return Reflect.apply(e, r, n);
                setTimeout((() => {
                    const e = {
                        readyState: {
                            value: r.DONE,
                            writable: !1
                        },
                        statusText: {
                            value: "OK",
                            writable: !1
                        },
                        response: {
                            value: "",
                            writable: !1
                        },
                        responseText: {
                            value: "",
                            writable: !1
                        },
                        responseURL: {
                            value: r[aa],
                            writable: !1
                        },
                        responseXML: {
                            value: null,
                            writable: !1
                        },
                        status: {
                            value: 200,
                            writable: !1
                        }
                    };
                    switch (r[ca] = {
                        date: (new Date).toUTCString(),
                        "content-length": "0"
                    }, r.responseType) {
                        case "arraybuffer":
                            e.response.value = new ArrayBuffer(0), r[ca]["content-type"] = "application/octet-stream";
                            break;
                        case "blob":
                            e.response.value = new Blob([]), r[ca]["content-type"] = "application/octet-stream";
                            break;
                        case "document":
                            {
                                const t = (new DOMParser).parseFromString("", "text/html");e.response.value = t,
                                e.responseXML.value = t,
                                r[ca]["content-type"] = "text/html",
                                r[ca]["content-length"] = t.documentElement.outerHTML.length.toString();
                                break
                            }
                        case "json":
                            e.response.value = {}, e.responseText.value = "{}", r[ca]["content-type"] = "application/json", r[ca]["content-length"] = "2";
                            break;
                        default:
                            if (r[ca]["content-type"] = "text/plain", "string" != typeof t || "" === t) break;
                            try {
                                const n = L(t);
                                e.response.value = n, e.responseText.value = n, r[ca]["content-length"] = n.length.toString()
                            } catch (e) {
                                ia.error("Generating random response text", e)
                            }
                    }
                    Object.defineProperties(r, e), r.dispatchEvent(new Event("readystatechange")), r.dispatchEvent(new Event("load")), r.dispatchEvent(new Event("loadend"))
                }), 1)
            }
        }), XMLHttpRequest.prototype.getResponseHeader = new Proxy(XMLHttpRequest.prototype.getResponseHeader, {
            apply: (e, t, r) => t[sa] ? t.readyState !== t.DONE ? null : t[ca][r[0].toLowerCase()] ? ? null : Reflect.apply(e, t, r)
        }), XMLHttpRequest.prototype.getAllResponseHeaders = new Proxy(XMLHttpRequest.prototype.getAllResponseHeaders, {
            apply: (e, t, r) => {
                if (!t[sa]) return Reflect.apply(e, t, r);
                if (t.readyState !== t.DONE) return null;
                let n = "";
                for (const [e, r] of Object.entries(t[ca])) n += `${e}: ${r}\r\n`;
                return n
            }
        })
    }
    const la = o("sanitize-clipboard");

    function fa(e, t) {
        try {
            const r = new URL(e);
            let n = !1;
            for (const e of t)
                if ("string" == typeof e) r.searchParams.has(e) && (r.searchParams.delete(e), n = !0);
                else
                    for (const t of Array.from(r.searchParams.keys())) e.test(t) && (r.searchParams.delete(t), n = !0);
            return n ? r.toString() : e
        } catch {
            return e
        }
    }
    const pa = o("set-constant");
    var ya = Q,
        da = Set.prototype,
        ha = {
            Set: Set,
            add: ya(da.add),
            has: ya(da.has),
            remove: ya(da.delete),
            proto: da
        },
        ga = ha.has,
        va = function(e) {
            return ga(e), e
        },
        wa = z,
        ba = function(e, t, r) {
            for (var n, o, i = r ? e : e.iterator, s = e.next; !(n = wa(s, i)).done;)
                if (void 0 !== (o = t(n.value))) return o
        },
        ma = Q,
        Sa = ba,
        Ea = ha.Set,
        Pa = ha.proto,
        Oa = ma(Pa.forEach),
        Ra = ma(Pa.keys),
        xa = Ra(new Ea).next,
        ja = function(e, t, r) {
            return r ? Sa({
                iterator: Ra(e),
                next: xa
            }, t) : Oa(e, t)
        },
        ka = ja,
        Ta = ha.Set,
        La = ha.add,
        Aa = function(e) {
            var t = new Ta;
            return ka(e, (function(e) {
                La(t, e)
            })), t
        },
        Da = _i(ha.proto, "size", "get") || function(e) {
            return e.size
        },
        $a = _e,
        Na = cr,
        Ia = z,
        Ma = An,
        Ca = function(e) {
            return {
                iterator: e,
                next: e.next,
                done: !1
            }
        },
        Ha = "Invalid size",
        qa = RangeError,
        Ba = TypeError,
        za = Math.max,
        Xa = function(e, t) {
            this.set = e, this.size = za(t, 0), this.has = $a(e.has), this.keys = $a(e.keys)
        };
    Xa.prototype = {
        getIterator: function() {
            return Ca(Na(Ia(this.keys, this.set)))
        },
        includes: function(e) {
            return Ia(this.has, this.set, e)
        }
    };
    var Fa = function(e) {
            Na(e);
            var t = +e.size;
            if (t != t) throw new Ba(Ha);
            var r = Ma(t);
            if (r < 0) throw new qa(Ha);
            return new Xa(e, r)
        },
        Ua = va,
        Ga = Aa,
        Wa = Da,
        Ja = Fa,
        _a = ja,
        Va = ba,
        Ka = ha.has,
        Ya = ha.remove,
        Za = Ee,
        Qa = function(e) {
            return {
                size: e,
                has: function() {
                    return !1
                },
                keys: function() {
                    return {
                        next: function() {
                            return {
                                done: !0
                            }
                        }
                    }
                }
            }
        },
        ec = function(e) {
            return {
                size: e,
                has: function() {
                    return !0
                },
                keys: function() {
                    throw new Error("e")
                }
            }
        },
        tc = function(e, t) {
            var r = Za("Set");
            try {
                (new r)[e](Qa(0));
                try {
                    return (new r)[e](Qa(-1)), !1
                } catch (o) {
                    if (!t) return !0;
                    try {
                        return (new r)[e](ec(-1 / 0)), !1
                    } catch (o) {
                        var n = new r;
                        return n.add(1), n.add(2), t(n[e](ec(1 / 0)))
                    }
                }
            } catch (e) {
                return !1
            }
        },
        rc = function(e) {
            var t = Ua(this),
                r = Ja(e),
                n = Ga(t);
            return Wa(t) <= r.size ? _a(t, (function(e) {
                r.includes(e) && Ya(n, e)
            })) : Va(r.getIterator(), (function(e) {
                Ka(t, e) && Ya(n, e)
            })), n
        };
    xo({
        target: "Set",
        proto: !0,
        real: !0,
        forced: !tc("difference", (function(e) {
            return 0 === e.size
        }))
    }, {
        difference: rc
    });
    var nc = va,
        oc = Da,
        ic = Fa,
        sc = ja,
        ac = ba,
        cc = ha.Set,
        uc = ha.add,
        lc = ha.has,
        fc = M,
        pc = function(e) {
            var t = nc(this),
                r = ic(e),
                n = new cc;
            return oc(t) > r.size ? ac(r.getIterator(), (function(e) {
                lc(t, e) && uc(n, e)
            })) : sc(t, (function(e) {
                r.includes(e) && uc(n, e)
            })), n
        };
    xo({
        target: "Set",
        proto: !0,
        real: !0,
        forced: !tc("intersection", (function(e) {
            return 2 === e.size && e.has(1) && e.has(2)
        })) || fc((function() {
            return "3,2" !== String(Array.from(new Set([1, 2, 3]).intersection(new Set([3, 2]))))
        }))
    }, {
        intersection: pc
    });
    var yc = z,
        dc = cr,
        hc = Ye,
        gc = function(e, t, r) {
            var n, o;
            dc(e);
            try {
                if (!(n = hc(e, "return"))) {
                    if ("throw" === t) throw r;
                    return r
                }
                n = yc(n, e)
            } catch (e) {
                o = !0, n = e
            }
            if ("throw" === t) throw r;
            if (o) throw n;
            return dc(n), r
        },
        vc = va,
        wc = ha.has,
        bc = Da,
        mc = Fa,
        Sc = ja,
        Ec = ba,
        Pc = gc,
        Oc = function(e) {
            var t = vc(this),
                r = mc(e);
            if (bc(t) <= r.size) return !1 !== Sc(t, (function(e) {
                if (r.includes(e)) return !1
            }), !0);
            var n = r.getIterator();
            return !1 !== Ec(n, (function(e) {
                if (wc(t, e)) return Pc(n, "normal", !1)
            }))
        };
    xo({
        target: "Set",
        proto: !0,
        real: !0,
        forced: !tc("isDisjointFrom", (function(e) {
            return !e
        }))
    }, {
        isDisjointFrom: Oc
    });
    var Rc = va,
        xc = Da,
        jc = ja,
        kc = Fa,
        Tc = function(e) {
            var t = Rc(this),
                r = kc(e);
            return !(xc(t) > r.size) && !1 !== jc(t, (function(e) {
                if (!r.includes(e)) return !1
            }), !0)
        };
    xo({
        target: "Set",
        proto: !0,
        real: !0,
        forced: !tc("isSubsetOf", (function(e) {
            return e
        }))
    }, {
        isSubsetOf: Tc
    });
    var Lc = va,
        Ac = ha.has,
        Dc = Da,
        $c = Fa,
        Nc = ba,
        Ic = gc,
        Mc = function(e) {
            var t = Lc(this),
                r = $c(e);
            if (Dc(t) < r.size) return !1;
            var n = r.getIterator();
            return !1 !== Nc(n, (function(e) {
                if (!Ac(t, e)) return Ic(n, "normal", !1)
            }))
        };
    xo({
        target: "Set",
        proto: !0,
        real: !0,
        forced: !tc("isSupersetOf", (function(e) {
            return !e
        }))
    }, {
        isSupersetOf: Mc
    });
    var Cc = va,
        Hc = Aa,
        qc = Fa,
        Bc = ba,
        zc = ha.add,
        Xc = ha.has,
        Fc = ha.remove,
        Uc = function(e) {
            var t = Cc(this),
                r = qc(e).getIterator(),
                n = Hc(t);
            return Bc(r, (function(e) {
                Xc(t, e) ? Fc(n, e) : zc(n, e)
            })), n
        };
    xo({
        target: "Set",
        proto: !0,
        real: !0,
        forced: !tc("symmetricDifference")
    }, {
        symmetricDifference: Uc
    });
    var Gc = va,
        Wc = ha.add,
        Jc = Aa,
        _c = Fa,
        Vc = ba,
        Kc = function(e) {
            var t = Gc(this),
                r = _c(e).getIterator(),
                n = Jc(t);
            return Vc(r, (function(e) {
                Wc(n, e)
            })), n
        };
    xo({
        target: "Set",
        proto: !0,
        real: !0,
        forced: !tc("union")
    }, {
        union: Kc
    });
    const Yc = new Set(["undefined", "false", "true", "null", "yes", "no", "on", "off", "accept", "accepted", "reject", "rejected", "allowed", "denied", "forbidden", "forever", ""]);

    function Zc(e) {
        if (Yc.has(e.toLowerCase())) return e;
        if ("emptyArr" === e) return "[]";
        if ("emptyObj" === e) return "{}";
        if ("$remove$" === e) return "$remove$";
        const t = parseInt(e);
        if (!isNaN(t) && t >= 0 && t <= 32767) return e;
        throw new Error("Invalid value")
    }

    function Qc(e, t) {
        const r = s(t);
        if (null !== r) {
            const t = Object.keys(e);
            for (const n of t) r.test(n) && e.removeItem(n)
        } else e.removeItem(t)
    }
    const eu = o("index"),
        tu = new Map([
            ["abort-current-inline-script", function(e, r) {
                if ("string" != typeof e || 0 === e.length) return void u.warn("property should be a non-empty string");
                let n;
                "string" == typeof r && r.length > 0 && (n = s(r) || a(r));
                const o = c(),
                    i = document.currentScript,
                    l = () => {
                        const t = document.currentScript;
                        if (t instanceof HTMLScriptElement && t !== i && (!n || n.test(t.textContent || ""))) throw u.info(`Blocked ${e} in currentScript`), new ReferenceError(`Aborted script with ID: ${o}`)
                    };
                t(window, e, {
                    onGet: l,
                    onSet: l
                }), window.addEventListener("error", (e => {
                    e.error instanceof ReferenceError && e.error.message.includes(o) && e.preventDefault()
                }))
            }],
            ["abort-on-property-read", f],
            ["aopr", f],
            ["abort-on-property-write", y],
            ["aopw", y],
            ["abort-on-stack-trace", g],
            ["aost", g],
            ["json-prune", function(e, t, r) {
                if ("undefined" == typeof Proxy) return void S.warn("Proxy not available in this environment");
                if ("string" != typeof e || 0 === e.length) return void S.warn("propsToRemove should be a non-empty string");
                const n = v(e, t, r);
                JSON.parse = new Proxy(JSON.parse, {
                    apply: (e, t, r) => {
                        const o = Reflect.apply(e, t, r);
                        return n(o), o
                    }
                }), "undefined" != typeof Response && (Response.prototype.json = new Proxy(Response.prototype.json, {
                    apply: async (e, t, r) => {
                        const o = await Reflect.apply(e, t, r);
                        return n(o), o
                    }
                }))
            }],
            ["nowebrtc", function() {
                if (!window.RTCPeerConnection) return;
                const e = e => {
                        Go.log(`document tried to create an RTCPeerConnection with config: ${e}`)
                    },
                    t = () => {};
                e.prototype = {
                    close: t,
                    createDataChannel: t,
                    createOffer: t,
                    setRemoteDescription: t,
                    toString: () => "[object RTCPeerConnection]"
                };
                const r = window.RTCPeerConnection;
                window.RTCPeerConnection = e, r.prototype && (r.prototype.createDataChannel = () => ({
                    close: t,
                    send: t
                }))
            }],
            ["prevent-fetch", Ni],
            ["no-fetch-if", Ni],
            ["prevent-xhr", ua],
            ["no-xhr-if", ua],
            ["set-local-storage-item", function(e, t) {
                if ("string" != typeof e) throw new Error(`key should be string, is ${e}`);
                if ("string" != typeof t) throw new Error(`value should be string, is ${t}`);
                const r = Zc(t);
                "$remove$" === r ? Qc(localStorage, e) : localStorage.setItem(e, r)
            }],
            ["set-session-storage-item", function(e, t) {
                if ("string" != typeof e) throw new Error(`key should be string, is ${e}`);
                if ("string" != typeof t) throw new Error(`value should be string, is ${t}`);
                const r = Zc(t);
                "$remove$" === r ? Qc(sessionStorage, e) : sessionStorage.setItem(e, r)
            }],
            ["set-constant", function(t, r, n, o, i) {
                let c;
                switch (void 0 !== i && pa.warn("setProxyTrap will be ignored"), r) {
                    case "undefined":
                        c = void 0;
                        break;
                    case "false":
                        c = !1;
                        break;
                    case "true":
                        c = !0;
                        break;
                    case "null":
                        c = null;
                        break;
                    case "emptyObj":
                        c = {};
                        break;
                    case "emptyArr":
                        c = [];
                        break;
                    case "noopFunc":
                        c = () => {};
                        break;
                    case "noopCallbackFunc":
                        c = () => () => {};
                        break;
                    case "trueFunc":
                        c = () => !0;
                        break;
                    case "falseFunc":
                        c = () => !1;
                        break;
                    case "throwFunc":
                        c = () => {
                            throw new Error
                        };
                        break;
                    case "noopPromiseResolve":
                        c = () => Promise.resolve(new Response("", {
                            status: 200,
                            statusText: "OK"
                        }));
                        break;
                    case "noopPromiseReject":
                        c = () => Promise.reject();
                        break;
                    case "":
                        c = "";
                        break;
                    case "-1":
                        c = -1;
                        break;
                    case "yes":
                        c = "yes";
                        break;
                    case "no":
                        c = "no";
                        break;
                    default:
                        {
                            const e = parseInt(r, 10);
                            if (!isNaN(e) && e >= 0 && e <= 32767) {
                                c = r;
                                break
                            }
                            throw new Error("Invalid value")
                        }
                }
                const u = c;
                switch (o) {
                    case "asFunction":
                        c = () => u;
                        break;
                    case "asCallback":
                        c = () => () => u;
                        break;
                    case "asResolved":
                        c = () => Promise.resolve(u);
                        break;
                    case "asRejected":
                        c = () => Promise.reject(u)
                }
                let l;
                void 0 !== n && "" !== n && (l = s(n) || a(n)), l ? ? = null;
                const f = () => {
                    pa.debug(`Returning fake value for property window.${t}`, {
                        value: r
                    })
                };
                if (!t.includes(".")) {
                    let e = window[t];
                    const r = Object.getOwnPropertyDescriptor(window, t);
                    return void Object.defineProperty(window, t, {
                        configurable: !0,
                        get: () => null === l || d(l) ? (f(), c) : "function" == typeof r ? .get ? r.get.apply(window) : e,
                        set: "function" == typeof r ? .set ? r ? .set.bind(window) : t => {
                            e = t
                        }
                    })
                }
                const p = Object,
                    y = Function,
                    h = t => {
                        let r, n;
                        return (o, i) => {
                            if (1 === t.length && t[0] === i) return f(), c;
                            let s = Reflect.get(o, i, o);
                            const a = p.getOwnPropertyDescriptor(o, i);
                            if (a && "value" in a && !a.configurable && !a.writable) return s;
                            if ("function" == typeof s && /\{\s*\[native code\]/.test(y.prototype.toString.call(s)) && (void 0 !== n && n[i] ? s = n[i] : (s = s.bind(o), void 0 === n && (n = {}), n[i] = s)), t[0] !== i || !e(s) || null !== l && !d(l)) return s;
                            if (r ? .link === s) return r.proxy;
                            const u = new Proxy(s, {
                                get: h(t.slice(1))
                            });
                            return r = {
                                link: s,
                                proxy: u
                            }, u
                        }
                    },
                    g = t.split("."),
                    v = g[0];
                let w = window,
                    b = window[v];
                for (let t = 1; t < g.length; t++) {
                    const r = g[t];
                    if (null != b && t === g.length - 1) {
                        const e = Object.getOwnPropertyDescriptor(b, r);
                        let t = b[r];
                        return void Object.defineProperty(b, r, {
                            configurable: !0,
                            get: () => null === l || d(l) ? (f(), c) : "function" == typeof e ? .get ? e.get.apply(b) : t,
                            set: "function" == typeof e ? .set ? e ? .set.bind(b) : e => {
                                t = e
                            }
                        })
                    }
                    if (null == b || null == b[r]) {
                        const r = Object.getOwnPropertyDescriptor(w, g[t - 1]);
                        let n, o = b;
                        return void Object.defineProperty(w, g[t - 1], {
                            configurable: !0,
                            get: () => {
                                const i = r ? .get ? r.get.apply(w) : o;
                                if (!e(i) || null !== l && !d(l)) return i;
                                if (n ? .capturedValue === i) return n.proxy;
                                const s = new Proxy(i, {
                                    get: h(g.slice(t))
                                });
                                return n = {
                                    capturedValue: i,
                                    proxy: s
                                }, s
                            },
                            set: "function" == typeof r ? .set ? r ? .set.bind(w) : e => {
                                o = e
                            }
                        })
                    }
                    w = b, b = b[r]
                }
                throw pa.warn("Hit an invariant in setConstant", {
                    property: t,
                    value: r,
                    stack: n
                }), new Error("Invariant hit")
            }],
            ["json-prune-fetch-response", function(e, t, r, n) {
                if ("undefined" == typeof Proxy || "undefined" == typeof fetch || "undefined" == typeof Response) return void A.warn("Either Proxy, fetch, or Response is not supported in this environment");
                if ("string" != typeof e || 0 === e.length) return void A.warn("propsToRemove cannot be empty");
                let o;
                if ("string" == typeof r) try {
                    o = P(r)
                } catch (e) {
                    return void A.warn("error parsing propsToMatch", e)
                }
                const i = v(e, t, n);
                window.fetch = new Proxy(window.fetch, {
                    apply: async (e, t, r) => {
                        if (o && !O(o, r)) return Reflect.apply(e, t, r);
                        const n = await Reflect.apply(e, t, r),
                            s = n.clone();
                        let a;
                        try {
                            a = await n.json()
                        } catch (e) {
                            return s
                        }
                        i(a);
                        const c = new Response(JSON.stringify(a), {
                            status: n.status,
                            statusText: n.statusText,
                            headers: n.headers
                        });
                        return Object.defineProperties(c, {
                            url: {
                                value: n.url
                            },
                            type: {
                                value: n.type
                            },
                            ok: {
                                value: n.ok
                            },
                            redirected: {
                                value: n.redirected
                            }
                        }), c
                    }
                })
            }],
            ["json-prune-xhr-response", function(e, t, r, n) {
                if ("undefined" == typeof Proxy) return void Ho.warn("Proxy is not supported in this environment");
                if ("string" != typeof e || 0 === e.length) return void Ho.warn("propsToMatch cannot be empty");
                let o;
                if ("string" == typeof r) try {
                    o = P(r)
                } catch (e) {
                    return void Ho.warn("error parsing propsToMatch", e)
                }
                const i = v(e, t, n),
                    {
                        open: s,
                        send: a
                    } = window.XMLHttpRequest.prototype;
                XMLHttpRequest.prototype.open = new Proxy(XMLHttpRequest.prototype.open, {
                    apply: (e, t, r) => void 0 === o || R(o, ...r) ? (t[Bo] = !0, t[qo] = [], t[zo] = r, t[Xo] = [], Reflect.apply(e, t, r)) : Reflect.apply(e, t, r)
                }), XMLHttpRequest.prototype.setRequestHeader = new Proxy(XMLHttpRequest.prototype.setRequestHeader, {
                    apply: (e, t, r) => t[Bo] ? (t[qo].push(r), Reflect.apply(e, t, r)) : Reflect.apply(e, t, r)
                }), XMLHttpRequest.prototype.send = new Proxy(XMLHttpRequest.prototype.send, {
                    apply: (e, t, r) => {
                        if (!t[Bo]) return Reflect.apply(e, t, r);
                        const n = new XMLHttpRequest;
                        n.addEventListener("readystatechange", (async () => {
                            if (n.readyState !== XMLHttpRequest.DONE) return;
                            const e = {
                                readyState: {
                                    value: n.readyState,
                                    writable: !1
                                },
                                responseURL: {
                                    value: n.responseURL,
                                    writable: !1
                                },
                                status: {
                                    value: n.status,
                                    writable: !1
                                },
                                statusText: {
                                    value: n.statusText,
                                    writable: !1
                                },
                                response: {
                                    value: n.response,
                                    writable: !1
                                }
                            };
                            try {
                                e.responseXML = {
                                    value: n.responseXML,
                                    writable: !1
                                }
                            } catch {}
                            try {
                                e.responseText = {
                                    value: n.responseText,
                                    writable: !1
                                }
                            } catch {}
                            try {
                                if ("" === n.responseType || "text" === n.responseType) {
                                    const t = JSON.parse(n.responseText);
                                    i(t);
                                    const r = JSON.stringify(t);
                                    e.response = {
                                        value: r,
                                        writable: !1
                                    }, e.responseText = {
                                        value: r,
                                        writable: !1
                                    }
                                } else if ("arraybuffer" === n.responseType) {
                                    const t = (new TextDecoder).decode(n.response),
                                        r = JSON.parse(t);
                                    i(r);
                                    const o = (new TextEncoder).encode(JSON.stringify(r));
                                    e.response = {
                                        value: o,
                                        writable: !1
                                    }
                                } else if ("blob" === n.responseType) {
                                    const t = await n.response.text(),
                                        r = JSON.parse(t);
                                    i(r);
                                    const o = new Blob([JSON.stringify(r)]);
                                    e.response = {
                                        value: o,
                                        writable: !1
                                    }
                                } else {
                                    if ("json" !== n.responseType) throw new Error(`Unsupported type: ${n.responseType}`);
                                    i(n.response), e.response = {
                                        value: n.response,
                                        writable: !1
                                    }
                                }
                            } catch (e) {
                                Ho.error("Error parsing/pruning response", e)
                            }
                            Object.defineProperties(t, e);
                            const r = n.getAllResponseHeaders();
                            for (const e of r.trim().split(/[\r\n]+/)) {
                                const [r, n] = e.split(": ");
                                t[Xo].push([r, n])
                            }
                            setTimeout((() => {
                                t.dispatchEvent(new Event("readystatechange")), t.dispatchEvent(new Event("load")), t.dispatchEvent(new Event("loadend"))
                            }), 1)
                        })), s.apply(n, t[zo]);
                        for (const [e, r] of t[qo]) n.setRequestHeader(e, r);
                        try {
                            a.apply(n, r)
                        } catch (n) {
                            return Ho.error("Error sending substitute request", n), Reflect.apply(e, t, r)
                        }
                    }
                }), XMLHttpRequest.prototype.getResponseHeader = new Proxy(XMLHttpRequest.prototype.getResponseHeader, {
                    apply: (e, t, r) => {
                        if (!t[Bo]) return Reflect.apply(e, t, r);
                        let n = null;
                        for (const [e, o] of t[Xo])
                            if (e === r[0]) {
                                n = o;
                                break
                            }
                        return n
                    }
                }), XMLHttpRequest.prototype.getAllResponseHeaders = new Proxy(XMLHttpRequest.prototype.getAllResponseHeaders, {
                    apply: (e, t, r) => t[Bo] ? t[Xo].map((e => {
                        let [t, r] = e;
                        return `${t}: ${r}`
                    })).join("\r\n") : Reflect.apply(e, t, r)
                })
            }],
            ["prevent-window-open", Ui],
            ["nowoif", Ui],
            ["prevent-setTimeout", function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                "undefined" != typeof Proxy ? window.setTimeout = new Proxy(window.setTimeout, {
                    apply: (r, n, o) => {
                        const [i, s] = o;
                        return Ii({
                            callback: i,
                            delay: s,
                            matchCallback: e,
                            matchDelay: t
                        }) ? (Xi.info(`Prevented setTimeout(${String(i)}, ${s})"`), 0) : Reflect.apply(r, n, o)
                    }
                }) : Xi.warn("Proxy not available in this environment")
            }],
            ["prevent-setInterval", function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                "undefined" != typeof Proxy ? window.setInterval = new Proxy(window.setInterval, {
                    apply: (r, n, o) => {
                        const [i, s] = o;
                        return Ii({
                            callback: i,
                            delay: s,
                            matchCallback: e,
                            matchDelay: t
                        }) ? (zi.info(`Prevented setInterval(${String(i)}, ${s})"`), 0) : Reflect.apply(r, n, o)
                    }
                }) : zi.warn("Proxy not available in this environment")
            }],
            ["prevent-addEventListener", function() {
                let e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                if (!e && !t) return;
                const r = s(e) || a(e),
                    n = s(t) || a(t);
                if (!r && !n) return;
                const o = {
                    apply(e, t, o) {
                        const [i, s] = o, a = (e => {
                            try {
                                return "object" == typeof e && "handleEvent" in e && "function" == typeof e.handleEvent ? e.handleEvent.toString() : e.toString()
                            } catch {
                                return ""
                            }
                        })(s);
                        let c = !1;
                        if (r && !n ? c = r.test(i) : n && !r ? c = n.test(i) : r && n && (c = r.test(i) && n.test(a)), !c) return Reflect.apply(e, t, o);
                        Wo.info(`Blocked addEventListener("${i}", ${a})`)
                    }
                };
                window.addEventListener = new Proxy(window.addEventListener, o), document.addEventListener = new Proxy(document.addEventListener, o), Element.prototype.addEventListener = new Proxy(window.Element.prototype.addEventListener, o), EventTarget.prototype.addEventListener = new Proxy(window.EventTarget.prototype.addEventListener, o)
            }],
            ["no-topics", function() {
                const e = "browsingTopics";
                if ("function" != typeof Document || "object" != typeof Document.prototype) return;
                const t = Object.getOwnPropertyDescriptor(Document.prototype, e);
                if (!t || !t.configurable || "function" != typeof t.value) return;
                const r = t.value,
                    n = new Proxy(r, {
                        apply: () => (Uo.info("Preventing Topics API usage"), Promise.resolve(new Response("", {
                            status: 200,
                            statusText: "OK"
                        })))
                    });
                Object.defineProperty(Document.prototype, e, {
                    configurable: !0,
                    get: () => n,
                    set: () => {}
                })
            }],
            ["no-protected-audience", function() {
                if ("function" != typeof Navigator || "object" != typeof Navigator.prototype) return;
                const e = {
                    joinAdInterestGroup: () => Promise.resolve(),
                    runAdAuction: () => Promise.resolve(null),
                    leaveAdInterestGroup: () => Promise.resolve(),
                    clearOriginJoinedAdInterestGroups: () => Promise.resolve(),
                    createAuctionNonce: () => "",
                    updateAdInterestGroups: () => {}
                };
                for (const t of Object.keys(e)) {
                    const r = Object.getOwnPropertyDescriptor(Navigator.prototype, t);
                    if (!r || !r.configurable || "function" != typeof r.value) continue;
                    const n = r.value,
                        o = new Proxy(n, {
                            apply: () => (Fo.info(`Preventing usage of Protected Audience API: ${t}`), e[t]())
                        });
                    Object.defineProperty(Navigator.prototype, t, {
                        configurable: !0,
                        get: () => o,
                        set: () => {}
                    })
                }
            }],
            ["sanitize-clipboard", function(e) {
                if ("string" != typeof e || 0 === e.length) return void la.warn("params should be a non-empty string");
                const t = e.split(" ").map((e => s(e) || e));
                if (navigator.clipboard) {
                    const e = {
                        async apply(e, r, n) {
                            const [o] = n, i = await Promise.resolve(o), s = fa(String(i), t);
                            return s === i ? Reflect.apply(e, r, n) : (la.info(`Sanitized clipboard for '${String(i)}'`), Reflect.apply(e, r, [s]))
                        }
                    };
                    navigator.clipboard.writeText = new Proxy(navigator.clipboard.writeText, e)
                }
                document.addEventListener("copy", (e => {
                    const r = e;
                    let n = window.getSelection() ? .toString() ? ? "";
                    if (!n) {
                        const e = document.activeElement;
                        !e || "INPUT" !== e.tagName && "TEXTAREA" !== e.tagName || null === e.selectionStart || null === e.selectionEnd || e.selectionStart === e.selectionEnd || (n = e.value.slice(e.selectionStart, e.selectionEnd))
                    }
                    if (!n) return;
                    const o = fa(n, t);
                    o !== n && r ? .clipboardData && (r.clipboardData.setData("text/plain", o), r.preventDefault(), la.info(`Sanitized clipboard for '${n}'`))
                }), !0)
            }]
        ]);
    return function(e) {
        if (tu.has(e)) {
            for (var t = arguments.length, r = new Array(t > 1 ? t - 1 : 0), n = 1; n < t; n++) r[n - 1] = arguments[n];
            tu.get(e)(...r)
        } else eu.debug(`Scriptlet ${e} does not exist or is not yet implemented.`)
    }
}();
(() => {
    try {
        scriptlet('set-constant', 'navigator.getBattery', 'noopPromiseResolve')
    } catch (ex) {
        console.error(ex);
    }
    try {
        scriptlet('no-topics')
    } catch (ex) {
        console.error(ex);
    }
    try {
        scriptlet('set-constant', 'navigator.privateAttribution', 'undefined')
    } catch (ex) {
        console.error(ex);
    }
    try {
        scriptlet('no-protected-audience')
    } catch (ex) {
        console.error(ex);
    }
    try {
        scriptlet('json-prune', 'relatedAds')
    } catch (ex) {
        console.error(ex);
    }
    try {
        scriptlet('prevent-setInterval', 'logQueue', '10000')
    } catch (ex) {
        console.error(ex);
    }
    try {
        scriptlet('hide-in-shadow-dom', 'cs-responsive-card[ad]')
    } catch (ex) {
        console.error(ex);
    }
})();
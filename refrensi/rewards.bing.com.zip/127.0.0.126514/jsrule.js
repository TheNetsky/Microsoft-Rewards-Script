(function() {
    ! function() {
        const e = {
            apply: (e, l, t) => {
                const o = t[0];
                return o ? .includes(".b_ad,") ? t[0] = "#b_results" : o ? .includes(".b_restorableLink") && (t[0] = ".b_algo"), Reflect.apply(e, l, t)
            }
        };
        window.Element.prototype.querySelectorAll = new Proxy(window.Element.prototype.querySelectorAll, e)
    }();
})();